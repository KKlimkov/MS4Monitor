﻿"use strict";
import { SoundService } from './SoundService.js';
import { Constants as C, methods as M } from '../observer/methods.js'
export class TaskWrapper {
    constructor(metadata) {
        this.contextStack = {};
        this.prop_link = {};
        this.metadata = metadata || {};
        this.username = $sw.serverState.UserData.user;
        this.groups = $sw.serverState.UserData.groups;
        this.sounService = SoundService;
        this.loginTime = $sw.serverState.UserData.serverTime;
        this.clientaddress = $sw.serverState.currentState.clientAddress;
        this.sessionexpiretime = $sw.serverState.currentState.sessionExpireTime;
    }

    start() {
        this.worker = new Worker(this.metadata.fileName);
        this.worker.onmessage = (e) => {
            switch (e.data.type) {
                case 'sound':
                    this.sounService.call(e.data.params);
                    break;
                case 'stop':
                    this.sounService.stop(e.data.params);
                    break;
                case 'log_message':
                    const pack = {
                        level: 0x00000040,
                        message: e.data.params
                    };
                    const options = {
                        method: M.LogMessage,
                        methodType: C.single,
                        pack
                    }
                    $sw.ServerAdapter.sendRequest(options, data => {
                        if (data.code !== 0) {
                            $ns.add({ type: 'error', time: new Date().toLocaleString(), title: 'LogMessage Error', text: `errro code:${data.hex}</br>description:${data.error_text}` });
                        }
                    });
                    break;
                default:
                    return this._updateModel(e.data);
            }
        }
        // this.worker.onerror = (e) => {
        //     reject(e);
        // };
        this.timer = setInterval(this.execute.bind(this), +this.metadata.interval);
    }

    execute(fbName) {
        this.executeInternal(fbName);
        this._updateModel.bind(this);
    }

    executeInternal(fbName) {
        return this._executeInWorker(this.metadata.fileName, fbName);
    }

    _executeInWorker(fileName, fbName) {
        var p = {
            fbName: fbName,
            input: {
                global: {
                    username: $sw.serverState.UserData.user,
                    groups: $sw.serverState.UserData.groups,
                    logintime: $sw.serverState.UserData.serverTime,
                    fullname: $sw.serverState.UserData.fullName,
                    clientaddress: $sw.serverState.currentState.clientAddress,
                    sessionexpiretime: $sw.serverState.currentState.sessionExpireTime
                }
            }
        };
        this.worker.postMessage(p);
    }


    _updateModel(fbResult) { //path: value
        let context = this;
        for (const key in fbResult) {
            if (fbResult[key].__context && this.contextStack[fbResult[key].__context]) {
                context = this.contextStack[fbResult[key].__context];
                delete this.contextStack[fbResult[key].__context];
                break;
            }
        }
        for (const key in context.prop_link) {
            const tPath = (context.Path ? context.Path.toLowerCase() + '.' : '') + key;
            const path = tPath.split('.');
            const res = this.getValFromPath(fbResult, path);
            if (this[tPath] === res) continue;
            if (typeof res !== 'undefined') {
                const forRemove = [];
                if (Array.isArray(context.prop_link[key])) {
                    for (let i = 0; i < context.prop_link[key].length; i++) {
                        const isOk = context.prop_link[key][i](res);
                        if (!isOk) forRemove.push(i);
                        this[tPath] = res;
                    }
                    if (forRemove.length > 0) {
                        for (const i of forRemove.reverse()) {
                            context.prop_link[key].splice(i, 1);
                        }
                    }
                } else {
                    const isOk = context.prop_link[key](res);
                    this[tPath] = res;
                }
            }
        }
    }

    getValFromPath(obj, path) {
        let j = this.objectToLower(obj);
        for (let i = 0; i < path.length; i++) {
            if (Array.isArray(j)) {
                let i_dec = Number(path[i]) - 1; //lua array count from 1
                j = j[i_dec];
            } else if (typeof j[path[i]] !== 'undefined') {
                j = this.objectToLower(j[path[i]]);
            } else {
                return undefined;
            }
        }
        return j;
    }

    getValue(el) {
        return this[el.PropertyPath.toLowerCase()];
    }

    postMessage(el, value) {
        if (typeof value === 'undefined' || value === null) return;
        const data = { fbName: el.PropertyPath.split('.')[0], input: {} };
        if (!this[el.PropertyPath.toLowerCase()] || this[el.PropertyPath.toLowerCase()] !== value) {
            data.input[el.PropertyPath] = value;
            this.worker.postMessage(data);
        }
    }
    postMessageCallPOU(fb, values, context) {
        const data = { input: {} };
        if (typeof values !== 'undefined' && values !== null) {
            if (context) {
                values.__context = `f${(~~(Math.random() * 1e8)).toString(16)}`;
                this.contextStack[values.__context] = context;
            };
            data.fbName = fb.split('.')[0];
            for (const key in values) {
                data.input[`${fb}.${key}`] = values[key];
            }
        } else {
            data.fbName = fb;
        }
        this.worker.postMessage(data);
    }

    objectToLower(obj) {
        if (typeof obj !== 'object') return obj;
        if (Array.isArray(obj)) return obj;
        let key, keys = Object.keys(obj);
        let n = keys.length;
        const newobj = {}
        while (n--) {
            key = keys[n];
            newobj[key.toLowerCase()] = obj[key];
        }
        return newobj;
    }
    AddLinkCallback(property, callback) {
        if (this.prop_link[property.toLowerCase()]) {
            this.prop_link[property.toLowerCase()].push(callback);
        } else {
            this.prop_link[property.toLowerCase()] = [callback];
        }
    }
}