﻿"use strict";


var SoundService = {};
var sounds = {};
var play_queue = [];
var isPlayingSomething = false;
SoundService.call = function (param) {
    if (!param.Sound) {
        return;
    }

    if (!sounds[param.Sound]) {
        sounds[param.Sound] = new Audio(`resources/${param.Sound}`);
        sounds[param.Sound].setAttribute('filename', param.Sound);
        sounds[param.Sound].onended = this.onAudioEnded.bind(this);
    }
    var sound_index = SoundService.findInQueue(param.Sound);
    if (sound_index != null) {
        play_queue[sound_index].repeat = param.Rep;
        play_queue[sound_index].priority = param.Priority;
        return;
    } else {
        if (param.Play) {
            play_queue.push({
                sound: sounds[param.Sound],
                title: param.Sound,
                repeat: param.Rep,
                priority: param.Priority
            });
            if (!isPlayingSomething) {
                if (window.ipc) {
                    const enablePlay = window.ipc.get().sendSync('server', 'requestPlay', param.Sound);
                    if (!enablePlay) return;
                }
                isPlayingSomething = true;
                const playPromise = sounds[param.Sound].play();
                if (playPromise !== undefined) {
                    playPromise.then(_ => {

                    })
                        .catch(error => {
                            console.log(error);
                        });
                }
            }
        }
    }
};
SoundService.stop = function (param) {
    if (param.Stop)
        if (isPlayingSomething) {
            var sound_index = SoundService.findInQueue(param.Sound);
            if (sound_index != null) {
                isPlayingSomething = false;
                sounds[param.Sound].pause();
                sounds[param.Sound].currentTime = 0;
                play_queue.splice(sound_index, 1);
                if (window.ipc) {
                    window.ipc.get().send('server', 'stopPlay', param.Sound);
                }
            }
        }
    if (!isPlayingSomething && play_queue.length > 0) {
        play_queue[0].sound.play();
        isPlayingSomething = true;
    }
};

SoundService.onAudioEnded = function (e) {
    if (window.ipc) {
        const name = e.srcElement.getAttribute('filename');
        window.ipc.get().send('server', 'stopPlay', name);
    }
    if (play_queue.length == 0) {
        isPlayingSomething = false;
        return;
    }
    if (play_queue[0].repeat) {
        play_queue.push(play_queue[0]);
    }
    play_queue.shift();
    if (play_queue.length > 0) {
        play_queue[0].sound.play();
    }
    else {
        isPlayingSomething = false;
    }
}
SoundService.isInQueue = function (sound) {
    for (var i = 0; i < play_queue.length; i++) {
        if (play_queue[i].title == sound) {
            return true;
        }
    }
    return false;
}
SoundService.findInQueue = function (sound) {
    for (var i = 0; i < play_queue.length; i++) {
        if (play_queue[i].title == sound) {
            return i;
        }
    }
    return null;
}

export { SoundService }