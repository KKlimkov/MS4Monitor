var StandartFunctions = {};
var StandartFunctionsErrors = {
    DIV_0: function () { console.log("Деление на 0") }, //$ns.add({ type: 'error', time: new Date().toLocaleString(), title: "Деление на 0", text: "Деление на 0 в ФБ в задаче экрана" }); },
    LOG_0: function () { console.log("Вне диапазона") } //$ns.add({ type: 'error', time: new Date().toLocaleString(), title: "Вне диапазона", text: "Ошибка значения вне диапазона в ФБ в задаче экрана" }); }
}


StandartFunctions.ABS = function (a) {
    return Math.abs(a);
};

StandartFunctions.ADD = function (a, b) {
    return a + b;
};

StandartFunctions.SUB = function (a, b) {
    return a - b;
};

StandartFunctions.MOD = function (a, b) {
    return a % b;
};

StandartFunctions.DIV_REAL_REAL = function (a, b) {
    return StandartFunctions.DIV(a, b);
};
//Исправить
StandartFunctions.DIV_INT_INT = function (a, b) {
    return Math.round(StandartFunctions.DIV(a, b));
};

StandartFunctions.MUL = function (a, b) {
    return a * b;
};

StandartFunctions.DIV = function (a, b) {
    if (b === 0) {
        StandartFunctionsErrors.DIV_0();
    };
    return a / b;
};


StandartFunctions.SHL_LWORD = function (a, b) {
    return a << b;
};

StandartFunctions.SHL_DWORD = function (a, b) {
    return a << b;
};

StandartFunctions.SHL_WORD = function (a, b) {
    return a << b;
};

StandartFunctions.SHL_BYTE = function (a, b) {
    return a << b;
};

StandartFunctions.SHR_LWORD = function (a, b) {
    return a >>> b;
};

StandartFunctions.SHR_DWORD = function (a, b) {
    return a >>> b;
};

StandartFunctions.SHR_WORD = function (a, b) {
    return a >>> b;
};

StandartFunctions.SHR_BYTE = function (a, b) {
    return a >>> b;
};
//need change
StandartFunctions.ROR_LWORD = function (val, shift) {
    return (val >> shift) | (val << (64 - shift));
};

StandartFunctions.ROR_DWORD = function (val, shift) {
    return (val >> shift) | (val << (32 - shift));
};

StandartFunctions.ROR_WORD = function (val, shift) {
    return ((val >> shift) | (val << (32 - shift))) & 0xFFFF;
};

StandartFunctions.ROR_BYTE = function (val, shift) {
    return ((val >> shift) | (val << (8 - shift))) & 0xFF;
};
//need change
StandartFunctions.ROL_LWORD = function (val, shift) {
    return (val << shift) | (val >> (64 - shift));
};

StandartFunctions.ROL_DWORD = function (val, shift) {
    return (val << shift) | (val >> (32 - shift));
};

StandartFunctions.ROL_WORD = function (val, shift) {
    return ((val << shift) | (val >> (16 - shift))) & 0xFFFF;
};

StandartFunctions.ROL_BYTE = function (val, shift) {
    return ((val << shift) | (val >> (8 - shift))) & 0xFF;
};

StandartFunctions.OR_PARAMS_LWORD = function (a, b) {
    return a | b;
};
StandartFunctions.OR_PARAMS_BOOL = function (a, b) {
    return a | b;
};

StandartFunctions.AND_PARAMS_LWORD = function (a, b) {
    return a & b;
};
StandartFunctions.AND_PARAMS_BOOL = function (a, b) {
    return a & b;
};

StandartFunctions.XOR_PARAMS_LWORD = function (a, b) {
    return a ^ b;
};
StandartFunctions.XOR_PARAMS_BOOL = function (a, b) {
    return a ^ b;
};
//LWORD ??? уточнить 
StandartFunctions.NOT_LWORD = function (a) {
    return 0xffffffffffffffff - a;
};
StandartFunctions.NOT_DWORD = function (a) {
    return 0xffffffff - a;
};
StandartFunctions.NOT_WORD = function (a) {
    return 0xffff - a;
};
StandartFunctions.NOT_BYTE = function (a) {
    return 0xff - a;
};
StandartFunctions.NOT_BOOL = function (a) {
    return !a;
};

StandartFunctions.MAX = function (a, b) {

    return a >= b ? a : b;
};

StandartFunctions.MIN = function (a, b) {

    return a <= b ? a : b;
};

StandartFunctions.LIMIT = function (mn, IN1, mx) {
    if (mn > IN1)
        return mn;
    if (mx < IN1)
        return mx;
    return IN1;

};

StandartFunctions.GT = function (a, b) {
    return a > b ? 1 : 0;
};
StandartFunctions.GE = function (a, b) {
    return a >= b ? 1 : 0;
};
StandartFunctions.EQ = function (a, b) {
    return a == b ? 1 : 0;
};
StandartFunctions.LE = function (a, b) {
    return a <= b ? 1 : 0;
};
StandartFunctions.LT = function (a, b) {
    return a < b ? 1 : 0;
};
StandartFunctions.NE = function (a, b) {
    return a != b ? 1 : 0;
};
StandartFunctions.VALUE_TO_SYSTEM_PARAM = function (a) {
    return a;
}
StandartFunctions.SYSTEM_PARAM_TO_VALUE = function (a) {
    return a;
}
StandartFunctions.LOG_MESSAGE = function (a) {
    console.log(a);
    postMessage({ type: "log_message", params: a });
    return a;
}
StandartFunctions.ADD_TIME_OF_DAY = function (a, b) {
    return a + b;
};
StandartFunctions.ADD_TIME_OF_DAY_TIME = function (in1, in2) {
    return in1 + in2;
}
StandartFunctions.ADD_DATE_AND_TIME_TIME = function (in1, in2) {
    return in1 + in2;
}
StandartFunctions.SUB_TIME = function (in1, in2) {
    return in1 - in2;
}
StandartFunctions.SUB_DATE_DATE = function (in1, in2) {
    return in1 - in2;
}
StandartFunctions.SUB_TIME_OF_DAY_TIME = function (in1, in2) {
    return in1 - in2;
}
StandartFunctions.SUB_TIME_OF_DAY_TIME_OF_DAY = function (in1, in2) {
    return in1 - in2;
}
StandartFunctions.SUB_DATE_AND_TIME_TIME = function (in1, in2) {
    return in1 - in2;
}
StandartFunctions.SUB_DATE_AND_TIME_DATE_AND_TIME = function (in1, in2) {
    return in1 - in2;
}
StandartFunctions.MUL_TIME_ANY_NUM = function (in1, in2) {
    return in1 * in2;
}
StandartFunctions.DIV_TIME_ANY_NUM = function (in1, in2) {
    return in1 / in2;
}
StandartFunctions.CONCAT_PARAMS_ANY_STRING = function (str1, str2) {
    return str1 + str2;
}
StandartFunctions.CONCAT_DATE_TIME_OF_DAY = function (in1, in2) {
    const dt1 = new Date(in1);
    const y = dt1.getFullYear();
    const m = dt1.getMonth();
    const d = dt1.getDate();

    const dt2 = new Date(in2);
    const hh = dt2.getHours();
    const mm = dt2.getHours();
    const ss = dt2.getSeconds();
    const ms = dt2.getMilliseconds();
    const res = new Date(y, m, d, hh, mm, ss, ms);
    return res.getTime();
}
StandartFunctions.CONCAT_DATE = function (year, month, day) {
    return new Date(0).setFullYear(year, month - 1, day)
}
StandartFunctions.CONCAT_TOD = function (hours, minute, sec, ms) {
    var date = new Date(0);
    var offset = date.getTimezoneOffset() * 60 * 1000;
    var res = date.setHours(hours, minute, sec, ms);
    return res - offset;
}
StandartFunctions.CONCAT_DT = function (year, month, day, hours, minute, sec, ms) {
    return new Date(StandartFunctions.CONCAT_DATE(year, month, day)
        + new Date(0).setHours(hours, minute, sec, ms)).getTime()
}
StandartFunctions.SPLIT_DATE = function (t) {
    var date = new Date(t);
    var year = date.getFullYear()
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return [t, year, month, day];
}
StandartFunctions.SPLIT_TOD = function (t) {
    var date = new Date(t);
    var hours = date.getHours()
    var min = date.getMinutes();
    var sec = date.getSeconds();
    var msec = date.getMilliseconds();
    return [t, hours, min, sec, msec];
}
StandartFunctions.SPLIT_DT = function (t) {
    return StandartFunctions.SPLIT_DATE(t).concat(StandartFunctions.SPLIT_TOD(t).slice(1));
}
/* 
            ADD_TIME_OF_DAY_TIME    = ADD,\n"
"           ADD_DATE_AND_TIME_TIME  = ADD,\n"
"           SUB_TIME            = SUB,\n"
"           SUB_DATE_DATE           = SUB,\n"
"           SUB_TIME_OF_DAY_TIME    = SUB,\n"
"           SUB_TIME_OF_DAY_TIME_OF_DAY = SUB,\n"
"           SUB_DATE_AND_TIME_TIME = SUB,\n"
"           SUB_DATE_AND_TIME_DATE_AND_TIME = SUB,\n"
"           MUL_TIME_ANY_NUM        = MUL,\n"
"           DIV_TIME_ANY_NUM        = DIV,\n"
"           CONCAT_PARAMS_ANY_STRING = CONCAT,\n"
"           CONCAT_DATE_TIME_OF_DAY = ADD,\n"
*/
StandartFunctions.MUX = function (k, IN1, IN2) {
    if (k === 0) return IN1;
    if (k === 1) return IN2;
    return 0;
};
StandartFunctions.MOVE = function (a) {
    return a;
};
StandartFunctions.SEL = function (G, IN1, IN2) {
    return G ? IN2 : IN1;
};

StandartFunctions.BYTE_BCD_TO_USINT = function (bcd) {
    var n = 0;
    var m = 1;
    for (var i = 0; i < bcd.length; i += 1) {
        n += (bcd[bcd.length - 1 - i] & 0x0F) * m;
        n += ((bcd[bcd.length - 1 - i] >> 4) & 0x0F) * m * 10;
        m *= 100;
    }
    return n;
};

/*"           BYTE_BCD_TO_USINT   = BYTE_BCD_TO_USINT,\n"
"           WORD_BCD_TO_UINT    = WORD_BCD_TO_UINT,\n"
"           DWORD_BCD_TO_UDINT  = DWORD_BCD_TO_UDINT,\n"
"           LWORD_BCD_TO_ULINT  = LWORD_BCD_TO_ULINT,\n"
"           USINT_TO_BCD_BYTE   = USINT_TO_BCD_BYTE,\n"
"           UINT_TO_BCD_WORD    = UINT_TO_BCD_WORD,\n"
"           UDINT_TO_BCD_DWORD  = UDINT_TO_BCD_DWORD,\n"
"           ULINT_TO_BCD_LWORD  = ULINT_TO_BCD_LWORD,\n"
"       
*/
StandartFunctions.REAL_TO_INT = function (d) {
    return Math.round(d);
};

StandartFunctions.TIME_TO_REAL = function (a) {
    return a;
}

StandartFunctions.REAL_TO_TIME = function (t) {
    return new Date(0).setMilliseconds(t);
}
StandartFunctions.FROM_STRING = function (t) {
    return t;
}
StandartFunctions.DT_FROM_STRING = function (t) {
    return t;
}
StandartFunctions.DATE_FROM_STRING = function (t) {
    return t;
}
StandartFunctions.TOD_FROM_STRING = function (t) {
    return t;
}
StandartFunctions.TIME_FROM_STRING = function (t) {
    return t;
}
StandartFunctions.BOOL_FROM_STRING = function (t) {
    return !!t;
}
StandartFunctions.DT_TO_STRING = function (t) {
    const dt = new Date(t);
    options = {
        year: 'numeric', month: 'numeric', day: 'numeric',
        hour: 'numeric', minute: 'numeric', second: 'numeric',
        hour12: false
    };
    return dt.toLocaleString('ru', options);
}
StandartFunctions.TOD_TO_STRING = function (d) {
    var date = new Date(d);
    var msec = date.getUTCMilliseconds().toString();
    options = {
        hour: 'numeric', minute: 'numeric', second: 'numeric',
        hour12: false, timeZone: "UTC",
    };
    return date.toLocaleString('ru', options) + `.${"000".substr(msec.length) + msec}`;
}

StandartFunctions.TIME_TO_TOD = function (t) {
    return new Date(t);
}

StandartFunctions.TOD_TO_TIME = function (t) {
    return new Date(t).getTime();
}

StandartFunctions.TOD_TO_DT = function (t) {
    return new Date(t).getTime();
}

StandartFunctions.TIME_TO_DT = function (t) {
    return new Date(t).getTime();
}
StandartFunctions.TIME_TO_DATE = function (t) {
    return new Date(t).getTime();
}

StandartFunctions.TIME = function () {
    return Date.now();
}
StandartFunctions.GET_TIME = function () {
    return new Date().getTime();
}
StandartFunctions.GET_UTC_TIME = function () {
    return new Date().getUTCDate();
}
StandartFunctions.GET_LOCAL_TIME = function () {
    return new Date().getTime();
}
StandartFunctions.DATE_TO_DT = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.DATE_TO_TIME = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.DATE_TO_STRING = function (d) {
    return new Date(d).toString();
}
StandartFunctions.DATE_TO_DWORD = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.DT_TO_DWORD = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.DT_TO_TIME = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.DATE_TO_UDINT = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.DT_TO_UDINT = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.DT_TO_TOD = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.DT_TO_DATE = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.DWORD_TO_DATE = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.DWORD_TO_DT = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.UDINT_TO_DATE = function (d) {
    return new Date(d).getTime();
}
StandartFunctions.UDINT_TO_DT = function (d) {
    return new Date(d).getTime();
}
/*
"         
"           DT_TO_DATE          = FILETIME.DT_TO_DATE,\n"
"           DT_TO_TOD           = FILETIME.DT_TO_TOD,\n"
"           TIME_TO_TOD         = FILETIME.TIME_TO_TOD,\n"
"           TOD_TO_TIME         = function(time) return time end,\n"
"           TIME                = FILETIME.GetSysTimeMs,\n"
"           GET_TIME            = FILETIME.GetTime,\n"
"           GET_UTC_TIME        = FILETIME.GetTime,\n"
"           GET_LOCAL_TIME      = FILETIME.GetLocalTime,\n"

"           DATE_TO_DWORD       = FILETIME.DATE_TO_DWORD,\n"
"           DT_TO_DWORD         = FILETIME.DT_TO_DWORD,\n"
"           DATE_TO_UDINT       = FILETIME.DATE_TO_DWORD,\n"
"           DT_TO_UDINT         = FILETIME.DT_TO_DWORD,\n"
"           DWORD_TO_DATE       = FILETIME.DWORD_TO_DATE,\n"
"           DWORD_TO_DT         = FILETIME.DWORD_TO_DT,\n"
"           UDINT_TO_DATE       = FILETIME.DWORD_TO_DATE,\n"
"           UDINT_TO_DT         = FILETIME.DWORD_TO_DT,\n"
"           


*/
StandartFunctions.TRUNC = function (x) {
    return x < 0 ? Math.ceil(x) : Math.floor(x);
};
StandartFunctions.TRUNC_LINT = function (x) {
    return x < 0 ? Math.ceil(x) : Math.floor(x);
};

StandartFunctions.SQRT = function (a) {
    return Math.sqrt(a);
};
StandartFunctions.LN = function (a) {
    if (a === 0) {
        StandartFunctionsErrors.LOG_0();
    }
    return Math.log(a);
};
StandartFunctions.LOG = function (a) {
    if (a === 0) {
        StandartFunctionsErrors.LOG_0();
    }
    return Math.log(a) / Math.LN10;
};
StandartFunctions.EXP = function (a) {
    return Math.exp(a);
};
StandartFunctions.SIN = function (x) {
    return Math.sin(x);
};
StandartFunctions.COS = function (x) {
    return Math.cos(x);
};
StandartFunctions.TAN = function (x) {
    return Math.tan(x);
};
StandartFunctions.ASIN = function (x) {
    return Math.asin(x);
};
StandartFunctions.ACOS = function (x) {
    return Math.acos(x);
};
StandartFunctions.ATAN = function (x) {
    return Math.atan(x);
};
StandartFunctions.EXPT = function (x, y) {
    return Math.pow(x, y);
};

StandartFunctions.LEN = function (str) {
    return str.length;
};
//Функция возвращает L первых символов строки 
StandartFunctions.LEFT = function (str, l) {
    return str.substr(0, l);
};
//Функция возвращает L последних символов строки
StandartFunctions.RIGHT = function (str, l) {
    return str.slice(-l);
};
//Функция возвращает L символов из строки str, начиная  с P-го символа: 
StandartFunctions.MID = function (str, l, p) {
    return str.substr(--p, l);
};
StandartFunctions.INSERT = function (str1, str2, p) {
    var strTmp1 = StandartFunctions.LEFT(str1, p);
    var strTmp2 = str1.substring(p);
    return strTmp1 + str2 + strTmp2;
};

StandartFunctions.DELETE = function (str, l, p) {
    var strTmp1 = StandartFunctions.LEFT(str, --p);
    var strTmp2 = str.substring(p + l);
    return strTmp1 + strTmp2;
};
StandartFunctions.REPLACE = function (str1, str2, l, p) {
    return StandartFunctions.INSERT(StandartFunctions.DELETE(str1, l, p), str2, --p);
};
StandartFunctions.FIND = function (s, w) {
    return s.indexOf(w) + 1;
};
StandartFunctions.TO_BOOL = function (w) {
    return w === 0 ? false : true;

};
StandartFunctions.BOOL_TO_BYTE = function (b) {
    return ~~b;
};
StandartFunctions.TO_STRING = function (str) {
    return str.toString();
}
StandartFunctions.STRING_TO_BYTE = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_WORD = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_LWORD = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_DWORD = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_INT = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_SINT = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_DINT = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_LINT = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_USINT = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_UINT = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_UDINT = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_ULINT = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_TOD = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_TIME = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_DATE = function (str) {
    return parseInt(str);
}
StandartFunctions.STRING_TO_DT = function (str) {
    return parseInt(str);
}
StandartFunctions.GetBit = function (num, pos) {
    return ((num >> pos) & 0x1);
}

StandartFunctions.SetBit = function (num, pos) {
    return ((0x1 << pos) | num);
}

StandartFunctions.TO_BYTE = function (b) {
    return Math.round(b) & 0xFF;
};

StandartFunctions.TO_WORD = function (b) {
    return Math.round(b) & 0xFFFF;
};

StandartFunctions.TO_SINT = function (b) {
    return Math.round(b) & 0xFF;
};

StandartFunctions.TO_INT = function (b) {
    return Math.round(b) & 0xFFFF;
};

StandartFunctions.TO_LINT = function (b) {
    return Math.round(b);
};

StandartFunctions.TO_DINT = function (b) {
    return Math.round(b) & 0xFFFFFFFF;
};

StandartFunctions.TO_DWORD = function (b) {
    return (Math.round(b) & 0xFFFFFFFF) >>> 0;
};

StandartFunctions.TO_LWORD = function (b) {
    return Math.round(b);
};

StandartFunctions.TO_REAL = function (b) {
    return Number(b);
};

StandartFunctions.TO_LREAL = function (b) {
    return Number(b);
};

/*
 
"           
"           TO_BYTE             =   StandardFunctionsC.TO_BYTE,"
"           TO_WORD             =   StandardFunctionsC.TO_WORD,"
"           TO_DWORD            =   StandardFunctionsC.TO_DWORD,"

"           TO_STRING           = tostring,\n"

"           GetBit              = StandardFunctionsC.GetBit,"
"           SetBit              = StandardFunctionsC.SetBit,"

"           
"           CopyTable           = CopyTable\n"
*/
StandartFunctions.ADJUST_TO_TYPE = function (a, b) {
    return a;
};

StandartFunctions.ADJUST_TO_TYPE_REAL = function (a, b) {
    return a;
};

StandartFunctions.CopyTable = function (out) {
    out = out || {};

    for (var i = 1; i < arguments.length; i++) {
        var obj = arguments[i];

        if (!obj)
            continue;

        for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
                if (typeof obj[key] === 'object')
                    deepExtend(out[key], obj[key]);
                else
                    out[key] = obj[key];
            }
        }
    }

    return out;
};

StandartFunctions.OBJECT_TO_STRING = function (obj) {
    return JSON.stringify(obj);
}

StandartFunctions.STRING_TO_OBJECT = function (str) {
    var res
    try {
        res = JSON.parse(str);
    } catch (e) {
        res = {};
    }
    return res;
}

StandartFunctions.LOWER_BOUND = function (a, b) {
    return 1;
};

StandartFunctions.UPPER_BOUND = function (a, b) {
    if (a.length == undefined) //вдруг это не массив  
        return 0;
    if (b <= 1)
        return a.length;
    else {
        for (var i = 1; i < b; i++)
            a = a[0];
        return a.length;
    }
};