﻿function getLeadEdge(cu, leCu) {
    if ((leCu.value == false) && (cu == true)) {
        leCu.value = true;
        return true;
    }
    /*if (cu == false) {
        leCu.value = false;
    }*/
    return false;
}

function getLeadEdgeCTU(cu, leCu) {
    let result = false;
    if (cu != leCu.value) {
        result = !leCu.value && cu;
        leCu.value = cu;
    }
    return result;
}

function getBackEdge(cu, leCu) {
    if ((leCu.value == true) && (cu == false)) {
        leCu.value = false;
        return true;
    }
    /*if (cu == true) {
        leCu.value = true;
    }*/
    return false;
}
function forEach(collection, callback) {
    var i;
    for (i = 0; i < collection.length; i++) {
        callback(collection[i]);
    }
}

function compact(array) {
    var index = -1,
        length = array ? array.length : 0,
        result = [];

    while (++index < length) {
        var value = array[index];
        if (value) {
            result.push(value);
        }
    }
    return result;
}

function pcall() {
    try {
        var funcResult = arguments[0].apply({}, Array.prototype.slice.call(arguments, 1));
        funcResult = funcResult instanceof Array ? funcResult : [funcResult];
        return [true].concat(funcResult);
    }
    catch (ex) {
        console.error(ex.message || ex);
        console.error(ex.stack);
        return [false];
    }
}

function fbcall(fb) {
    try {
        fb._call();
        return true;
    }
    catch (ex) {
        console.error(ex.message || ex);
        console.error(ex.stack);
        return false;
    }
}

function getProp(name) {
    return this.global[name];
}
function setFBParams(params) {
    for (var param in params) {
        if (param == 'global') {
            this.username = params[param].username;
            this.logintime = params[param].logintime;
            if (params[param].groups)
                this.groups = params[param].groups.join();
            this.fullname = params[param].fullname;
            this.clientaddress = params[param].clientaddress;
            this.sessionexpiretime = params[param].sessionexpiretime;
            continue;
        }
        let spl = param.split('.');
        let i = 0; let field = self.GLOBAL;
        while (i !== spl.length - 1) {
            field = field[spl[i]];
            i++;
        }
        field[spl[i]] = params[param];
        self.inputParams[param] = params[param];
    }
}
function getFBParam(path) {
    var pathParts = path.split(propertyPathSeparator),
        currentObject = self.GLOBAL,
        i;

    for (i = 0; i < pathParts.length - 1; i++) {
        var pathPart = pathParts[i];
        var nameParts = compact(pathPart.split(namePartReg));
        var j;
        for (j = 0; j < nameParts.length; j++) {
            var namePart = getPathPart(nameParts[j]);
            currentObject = currentObject[namePart];
        }
    };

    return {
        prop: currentObject,
        key: getPathPart(pathParts[pathParts.length - 1])
    }
}

function getPathPart(namePart) {
    var arrIndex = namePart.match(arrIndexReg);
    if (arrIndex != null) {
        return arrIndex[1];
    } else {
        return namePart;
    }
}

function bindParams(params) {
    params = this.inputParams;
}

function getOutValues() {
    this.outputParams = this.GLOBAL;
    return this.GLOBAL;
}

function getFB(path) {
    let paths = path.split(".");
    let obj = self.GLOBAL;
    for (let i = 0; i < paths.length; i++) {
        if (typeof obj[paths[i]] === "object") {
            obj = obj[paths[i]];
        }
    }
    return obj;
}