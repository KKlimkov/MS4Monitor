const StandardFB = {};

const MAXINT16 = 32767;

const MAXINT32 = 2147483647;
const MAXUINT32 = 4294967295;

const MAXLONG64 = BigInt("9223372036854775807");
const MAXULONG64 = BigInt("18446744073709551615");

const MININT16 = -32768;
const MININT32 = -2147483648;
const MINLONG64 = BigInt("-9223372036854775808");

//TODO: check constansts

/**
 * @return {number}
 */
function StandardFBTime() {
    return new Date();
};
//-------------------------Триггеры--------------------------------------


RS = function () {
    this.Q1 = false;
    this.EnO = true;
    this.R1 = false;
    this.S = false;
};

RS.prototype._call = function () {
    this.Q1 = (this.Q1 || this.S) && !this.R1;
    //sr->Q1=(sr->Q1||sr->S)&&!sr->R1;
};
StandardFB.RS = RS;

SR = function () {
    this.Q1 = false;
    this.EnO = true;
    this.R = false;
    this.S1 = false;
};

SR.prototype._call = function () {
    this.Q1 = (this.Q1 && !this.R) || this.S1;
    //sr->Q1=(sr->Q1&&!sr->R)||sr->S1;
};
StandardFB.SR = SR;

GET_CURRENT_USERNAME = function () {
    this.EnO = true;
    this.Username = "";
    this.FullName = "";
    this.UserGroup = "";
    this.LoginTime = 0;
    this.ClientAddress = "";
    this.SessionExpireTime = 0;
}

GET_CURRENT_USERNAME.prototype._call = function () {
    this.Username = self.username;
    this.FullName = self.fullname;
    this.UserGroup = self.groups;
    this.LoginTime = self.logintime;
    this.ClientAddress = self.clientaddress;
    this.SessionExpireTime = self.sessionexpiretime;
}
StandardFB.GET_CURRENT_USERNAME = GET_CURRENT_USERNAME;

PlaySound = function () {
    this.EnO = true;
    this.Play = false;
    this.Priority = 1;
    this.lePlay = { value: false };
    this.Rep = false;
    this.Stop = false;
    this.leStop = { value: false };
    this.Sound = "";
};

PlaySound.prototype._call = function () {
    if (getLeadEdge(this.Play, this.lePlay) || getBackEdge(this.Play, this.lePlay)) {
        postMessage({ type: "sound", params: this });
    }
    if (getLeadEdge(this.Stop, this.leStop) || getBackEdge(this.Stop, this.leStop)) {
        postMessage({ type: "stop", params: this });
    }
};
StandardFB.PlaySound = PlaySound;

//-------------------------Счетчики--------------------------------------

getCTU = function (maxConst) {
    var maxConst = maxConst;
    return function () {
        if (this.R) {
            this.CV = 0;
        } else if (getLeadEdgeCTU(this.CU, this.leCu)
            && (this.CV < maxConst)) {
            this.CV += 1;
        }
        this.Q = this.CV >= this.PV
    }
}

CTU = function () {
    this.__proto__._call = getCTU(MAXINT16);
    this.leCu = { value: false };
    this.Q = false;
    this.EnO = true;
    this.CV = 0;
};
StandardFB.CTU = CTU;

CTU_DINT = function () {
    this.__proto__._call = getCTU(MAXINT32);
    this.leCu = { value: false };
    this.Q = false;
    this.EnO = true;
    this.CV = 0;
};
StandardFB.CTU_DINT = CTU_DINT;

CTU_LINT = function () {
    this.__proto__._call = getCTU(MAXLONG64);
    this.leCu = { value: false };
    this.Q = false;
    this.EnO = true;
    this.CV = 0;
};
StandardFB.CTU_LINT = CTU_LINT;

CTU_UDINT = function () {
    this.__proto__._call = getCTU(MAXUINT32);
    this.leCu = { value: false };
    this.Q = false;
    this.EnO = true;
    this.CV = 0;
};
StandardFB.CTU_UDINT = CTU_UDINT;

CTU_ULINT = function () {
    this.__proto__._call = getCTU(MAXULONG64);
    this.leCu = { value: false };
    this.Q = false;
    this.EnO = true;
    this.CV = 0;
};
StandardFB.CTU_ULINT = CTU_ULINT;

////////////////////////////////////////////////////////////////////
getCTD = function (minConst) {
    var minConst = minConst;
    return function () {
        if (this.LD) {
            this.CV = this.PV;
        } else if (getLeadEdgeCTU(this.CD, this.leCd)
            && (this.CV > minConst)) {
            this.CV -= 1
        }
        this.Q = this.CV <= 0
    }
}

CTD = function () {
    this.__proto__._call = getCTD(MININT16);
    this.leCd = { value: false };
    this.Q = false;
    this.EnO = true;
    this.CV = 0;
};
StandardFB.CTD = CTD;

CTD_DINT = function () {
    this.__proto__._call = getCTD(MININT32);
    this.leCd = { value: false };
    this.Q = false;
    this.EnO = true;
    this.CV = 0;
};
StandardFB.CTD_DINT = CTD_DINT;

CTD_LINT = function () {
    this.__proto__._call = getCTD(MINLONG64);
    this.leCd = { value: false };
    this.Q = false;
    this.EnO = true;
    this.CV = 0;
};
StandardFB.CTD_LINT = CTD_LINT;

CTD_UDINT = function () {
    this.__proto__._call = getCTD(0);
    this.leCd = { value: false };
    this.Q = false;
    this.EnO = true;
    this.CV = 0;
};
StandardFB.CTD_UDINT = CTD_UDINT;

////////////////////////////////////////////////////////////////////////////
getCTUD = function (minConst, maxConst) {
    var minConst = minConst;
    var maxConst = maxConst;
    return function () {
        if (this.R)
            this.CV = 0;
        else if (this.LD)
            this.CV = this.PV;
        else if (!(this.CU && this.CD)) {
            if (getLeadEdgeCTU(this.CU, this.leCu) && this.CV < maxConst)
                this.CV += 1;
            else if (getLeadEdgeCTU(this.CD, this.leCd) && (this.CV > minConst))
                this.CV -= 1;
        }
        this.QU = this.CV >= this.PV;
        this.QD = this.CV <= 0;
    }
}


CTUD = function () {
    this.__proto__._call = getCTUD(MININT16, MAXINT16);
    this.EnO = true;
    this.CV = 0;
    this.QU = false;
    this.QD = false;
    this.leCu = { value: false };
    this.leCd = { value: false };
};
StandardFB.CTUD = CTUD;

CTUD_DINT = function () {
    this.__proto__._call = getCTUD(MININT32, MAXINT32);
    this.EnO = true;
    this.CV = 0;
    this.QU = false;
    this.QD = false;
    this.leCu = { value: false };
    this.leCd = { value: false };
};
StandardFB.CTUD_DINT = CTUD_DINT;

CTUD_LINT = function () {
    this.__proto__._call = getCTUD(MINLONG64, MAXLONG64);
    this.EnO = true;
    this.CV = 0;
    this.QU = false;
    this.QD = false;
    this.leCu = { value: false };
    this.leCd = { value: false };
};
StandardFB.CTUD_LINT = CTUD_LINT;

CTUD_ULINT = function () {
    this.__proto__._call = getCTUD(0, MAXULONG64);
    this.EnO = true;
    this.CV = 0;
    this.QU = false;
    this.QD = false;
    this.leCu = { value: false };
    this.leCd = { value: false };
};
StandardFB.CTUD_ULINT = CTUD_ULINT;

/////////////////////////////

TP = function () {
    this.EnO = true;
    this.ET = 0;
    this.Q = false;
    this.En = true;
    this.IN = false;
    this.PT = 0;
    this.state = 0;
};

TP.prototype._call = function () {
    if (this.IN) {
        if (this.state == 0) {
            this.safePT = this.PT;
            this.state = 1;
            this.ET = 0;
            this.Q = true;
            this.startTime = StandardFBTime();
            return;
        }
        if (this.state == 1) {
            this.Q = true;
            this.ET = StandardFBTime() - this.startTime;
            if (this.ET >= this.safePT)
                this.state = 2;
            else
                return;
        }
        if (this.state == 2) {
            this.Q = false;
            this.ET = this.safePT;
            return;
        }
    }
    else {
        if (this.state == 1) {
            this.Q = true;
            this.ET = StandardFBTime() - this.startTime;
            if (this.ET >= this.safePT) {
                this.state = 2;
            }
            else
                return;
        }
        if (this.state == 2) {
            this.state = 0;
        }
        if (this.state == 0) {
            this.ET = 0;
            this.Q = false;
            return;
        }

    }
};
StandardFB.TP = TP;

TON = function () {
    this.EnO = true;
    this.ET = 0;
    this.Q = false;
    this.En = true;
    this.IN = false;
    this.PT = 0;
    this.state = 0;
};

TON.prototype._call = function () {
    if (this.IN) {
        if (this.state == 0) {
            this.safePT = this.PT;
            this.startTime = StandardFBTime();
            this.Q = false;
            this.ET = 0;
            this.state = 1;
            return;
        }
        if (this.state == 1) {
            this.Q = false;
            this.ET = StandardFBTime() - this.startTime;
            if (this.ET >= this.safePT) {
                this.state = 2;
            }
            else
                return;
        }
        if (this.state == 2) {
            this.Q = true;
            this.ET = this.safePT;
            return;
        }
    }
    else {
        if (this.state == 1) {
            this.Q = false;
            this.ET = StandardFBTime() - this.startTime;
            if (this.ET >= this.safePT)
                this.state = 2;
            else
                this.state = 0;
            return;
        }
        if (this.state == 2) {
            this.state = 0;
        }
        if (this.state == 0) {
            this.ET = 0;
            this.Q = false;
            return;
        }
    }
};
StandardFB.TON = TON;

TOF = function () {
    this.EnO = true;
    this.ET = 0;
    this.Q = false;
    this.En = true;
    this.IN = false;
    this.PT = 0;
};

TOF.prototype._call = function () {
    if (this.IN) {
        this.state = 1;
        this.Q = true;
        this.ET = 0;
        return;
    }
    else {
        if (this.state == 0) {
            this.ET = this.safePT;
            this.Q = false;
            return;
        }
        if (this.state == 1) {
            this.startTime = StandardFBTime();
            this.safePT = this.PT;
            this.state = 2;
            this.Q = true;
            this.ET = 0;
            return;
        }
        if (this.state == 2) {
            this.Q = true;
            this.ET = StandardFBTime() - this.startTime;
            if (this.ET > this.safePT) {
                this.state = 3;
            }
        }
        if (this.state == 3) {
            this.Q = false;
            this.ET = this.safePT;
        }
    }
};
StandardFB.TOF = TOF;

R_TRIG = function () {
    this.EnO = true;
    this.Q = false;
    this.En = true;
    this.CLK = false;
};

R_TRIG.prototype._call = function () {
    this.Q = this.CLK && !this.M;
    this.M = this.CLK;
};
StandardFB.R_TRIG = R_TRIG;

F_TRIG = function () {
    this.EnO = true;
    this.Q = false;
    this.En = true;
    this.CLK = false;
};

F_TRIG.prototype._call = function () {
    this.Q = !this.CLK && !this.M;
    this.M = !this.CLK;
};
StandardFB.F_TRIG = F_TRIG;
