﻿import { TaskList } from './TaskList.js';
import { TaskWrapper } from './TaskWrapper.js';

/**
 * @todo Fix GlobalSettings.get(Enums.ParameterRoles.REQUEST_SERVER_PREFIX);
 * */
/**
 * @classdesc Диспетчер ФБ в задаче экрана
 */
export class TaskManager {
    constructor() {
        this.tasks = {};
        this.hasTasks = this._addTasks();
    }

    _addTasks() {
        let hasTasks = typeof (TaskList.name) !== 'undefined';
        if (hasTasks) {
            this.tasks[TaskList.name] = this._createTask(TaskList);
            this.defaultTaskName = TaskList.name;
        }
        return hasTasks;
    }

    _createTask(taskDesc) {
        const task = new TaskWrapper({
            name: taskDesc.name,
            interval: taskDesc.interval,
            fileName: this._getTaskFileName(taskDesc.name, taskDesc.type),
            fbMetadata: taskDesc.functionBlocks
        });

        return task;
    }

    _getTaskFileName(taskFileName, type) {
        // const serverPrefix = ``; // TO DO
        switch (type) {
        case "st":
            return `screentask/${taskFileName}.js`;
        default:
            console.log(`Unsupported task type ${type}`)
            break;
        }
    }

    start() {
        for (let task in this.tasks) {
            this.tasks[task].start();
        }
    }

    //пока задача только одна
    getTask() {
        return this.tasks[this.defaultTaskName];
    }

    getTasksCount() {
        return this.tasks[this.defaultTaskName] != undefined ? 1 : 0;
    }
}