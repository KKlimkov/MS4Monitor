"use strict";

export class WindowService {
    constructor() {
        this.observers = [];
        this._windows = [];
        this.container = document.createElement('div');
        document.body.appendChild(this.container);
    }
    addObserver(fn) {
        this.observers.push(fn);
    }
    removeObserver() {
        this.observers = this.observers.filter(subscriber => subscriber !== fn);
    }
    addWindow(win) {
        if (!this.broadcast({ state: 'beforAdd', window: win })) return false;
        this._windows.push(win);
        this.broadcast({ state: 'afterAdd', window: win });
        return this.container.appendChild(win);
    }
    removeWindow(win) {
        if (win) {
            if (!this.broadcast({ state: 'beforDel', window: win })) return false;
            this._windows = this._windows.filter(window => window !== win);
            win.remove();
            this.broadcast({ state: 'afterDel', window: win });
        }
    }
    broadcast(data) {
        for (let i = 0; i < this.observers.length; i++) {
            const ret = this.observers[i](data);
            if (!ret) return false;
        }
        return true;
    }

    windowsByPath(path) {
        return this._windows.filter(win => win.originPath === path);
    }

    get windows() {
        return this._windows;
    }
    set windows(v) {

    }

}