"use strict";
/**
 * @class NotifyService
 * @classdesc Строка статуса
 * */
export class NotifyService {
    constructor(LogLevel = 3) {
        this._logLevel = LogLevel;
        window.addEventListener('error', this.errorHandler.bind(this));
        const root = this._getNotifiButton();
        this._notifysList = new Map();

        this._infopanellist = root.querySelector('.infopanellist');
        this._notifipanel = root.querySelector('.notifipanel');
        this._btnOpen = this._notifipanel.querySelector('.btn-open');
        this._infoText = this._notifipanel.querySelector('.infopanel .info');
        this._clearAll = this._infopanellist.querySelector('#ntf-clear');
        this._close = this._infopanellist.querySelector('#ntf-close');
        this._notifipanel.querySelector('.infopanel .close').onclick = () => {
            this._notifipanel.classList.remove('open');
        };
        this._btnOpen.onclick = () => {
            this._infopanellist.classList.toggle('open');
        }
        this._clearAll.onclick = () => {
            this.removeAll();
        }
        this._close.onclick = () => {
            this.close();
        }
        this._infopanellist.onclick = this.listClick.bind(this);

        this._infopanellist.querySelector('.sizer').onmousedown = this.headerSizeMoveSart.bind(this);
    }
     /**
     * Уровень предупреждений
     * 0 - нет
     * 1 - ошибки
     * 2 - предупреждения
     * 3 - все
     * @type {number}
     */
    get LogLevel() {
        return this._logLevel || 0;
    }
    set LogLevel(v) {
        this._logLevel = v;
    }

    listClick(e) {
        switch (e.target.nodeName) {
            case 'LI':
                e.target.classList.toggle('open');
                break;
            case 'DIV':
                if (e.target.className === 'close') {
                    const index = e.target.dataset.index;
                    e.target.parentNode.parentNode.parentNode.remove();
                    this._notifysList.delete(index);
                    this.update();
                } else {
                    if (e.target.classList.contains('listtitle')) {
                        e.target.parentNode.parentNode.classList.toggle('open');
                    }
                }
                break;
        }
    }

    close() {
        this._notifipanel.classList.remove('open');
        this._infopanellist.classList.remove('open');
    }

    errorHandler(e) {
        e.preventDefault();
        const message = e.error ? e.error.message : e.message;
        const stack = e.error ? e.error.stack : `line: ${e.lineno} col: ${e.colno} file: ${e.filename}`;
        this.add({ type: 'error', time: new Date().toLocaleString(), title: e.message, text: `${message}\n${stack}` });
        return false;
    }

    removeAll() {
        this._notifysList.clear();
        this._infopanellist.children[1].innerHTML = '';
        this.update();
    }

    add(item) {
        if (this._logLevel === 0) return;
        if (this._logLevel === 1 && item.type !== 'error') return;
        if (this._logLevel === 2 && item.type === 'info') return;
        if (item.text && item.text.includes && item.text.includes('ResizeObserver loop limit exceeded')) return;

        if (this._notifysList.size > 100) {
            const key = this._notifysList.keys().next().value;
            this._notifysList.delete(key);
            this._infopanellist.querySelector(`[id="${key}"]`).remove();
        }
        const index = this._getId();

        this._notifysList.set(index, item);
        this._infoText.innerHTML = `${item.time} ${item.title}`;
        this._notifipanel.className = 'notifipanel bottom open';

        this._notifipanel.classList.add(item.type);
        let linkStackText = '';
        if (item.type === 'error' && window.stack.size > 0) {
            window.stack.forEach(el => {
                linkStackText += `<div>Link: ${el.s} => ${el.t} stack:${el.c}</div>`;
            });
            linkStackText = `<div class="stack">${linkStackText}</div>`
        }
        const li = document.createElement('li');
        li.id = index;

        const text = typeof item.text === 'object' ? `<pre>${this._syntaxHighlight(item.text)}</pre>` : item.text;
        li.innerHTML = `
            <div>
                <div class="listtitle ${item.type}">
                    <div class="title">${item.time} ${item.title}</div><div class="close" data-index=${index}></div>
                </div>
                <div class="body" style="user-select: text;">${linkStackText}${text || ''}${item.obj ? "<pre>" + this._syntaxHighlight(item.obj) + "</pre>" : ''}</div>
            </div>
        `

        this._infopanellist.children[1].appendChild(li);

        this.update();
    }

    update() {
        if (this._notifysList.size > 0) {
            this._notifipanel.style.visibility = 'visible';
        } else {
            this._notifipanel.style.visibility = 'hidden';
            this._infopanellist.classList.remove('open');
        }
    }

    headerSizeMoveSart(e) {
        const target = e.target;

        const mouseMove = (e) => {
            let newLeft = e.pageX;
            let tSize = document.body.clientWidth - newLeft;
            if (tSize < 320) tSize = 320;
            if (tSize > 620) tSize = 620;
            target.parentNode.style.width = tSize + 'px';
        }
        const mouseUp = () => {
            if (target) { target.style.backgroundColor = 'transparent'; }

            document.removeEventListener('mousemove', mouseMove);
            document.removeEventListener('mouseup', mouseUp);
        };

        document.addEventListener('mousemove', mouseMove);
        document.addEventListener('mouseup', mouseUp);

        return false;
    }

    _syntaxHighlight(json) {
        try {
            if (typeof json === 'object') json = JSON.stringify(json, undefined, 2);
            json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
                let cls = 'number';
                if (/^"/.test(match)) {
                    if (/:$/.test(match)) {
                        cls = 'key';
                    } else {
                        cls = 'string';
                    }
                } else if (/true|false/.test(match)) {
                    cls = 'boolean';
                } else if (/null/.test(match)) {
                    cls = 'null';
                }
                return `<span class="${cls}">${match}</span>`;
            });

        } catch (error) {
            return '';
        }
    }

    _getNotifiButton() {
        if (!this.notifyContainer) {
            this.notifyContainer = document.createElement('div');
            this.notifyContainer.classList.add('notifi_container');
            const html = `
            <div class="notifipanel bottom open" style="visibility: hidden;">
                <div class="btn-open">
                </div>
                <div class="infopanel">
                    <div class="info"></div>
                    <div class="close"></div>
                </div>
            </div>
            <div class="infopanellist">
                <div class="ctrl">
                    <div class="btn-control" id="ntf-close">Свернуть</div>
                    <div class="btn-sep"></div>
                    <div class="btn-control" id="ntf-clear">Очистить</div>
                </div>
                <ul>
                </ul>
                <div class="sizer"></div>
            </div>
            `;
            this.notifyContainer.innerHTML = html;

            document.body.appendChild(this.notifyContainer);

        }
        return this.notifyContainer;
    }

    _getId() {
        return (
            Number(String(Math.random()).slice(2)) +
            Date.now() +
            Math.round(performance.now())
        ).toString(36)
    }
}