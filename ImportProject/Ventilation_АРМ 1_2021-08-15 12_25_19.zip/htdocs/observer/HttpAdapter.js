import { ServerAdapterBase } from "./ServerAdapterBase.js"

export class HttpAdapter extends ServerAdapterBase {
    constructor(id, isMain) {
        super(id, isMain);
        this.ackSequenceNumber = 0;
    }

    processSingle(options, callback) {
        this.asyncRequest(options.headers, options.timeout).then(response => {
            if (response && response.code === 0) {
                callback && callback(response);
            } else {
                this.postError(response, callback);
            }
        }).catch(function (e) {
            if (e !== 'this adapter was disposed') {
                console.log(e); // "oh, no!"
            }
        });
    }

    processIntervalStart(options, callback) {
        this.createInterval(this.publishInterval.bind(this), options, callback);
    }

    processIntervalRequest(options, callback) {
        this.createInterval(this.repeatRequest.bind(this), options, callback);
    }

    repeatRequest(data, callback) {
        const { headers, timeout } = data;
        this.asyncRequest(headers, timeout).then(response => {
            if (response && response.code === 0) {
                callback && callback(response);
            } else {
                this.postError(response, callback);
            }
        })
    }

    postError(answer, callback) {
        this._isbusy = false;
        super.postError(answer, callback);
    }

    createInterval(intervalMethod, options, callback) {
        if (!this.watchers) { return };
        let intervalHandler = options.method;
        const timerInstance = {
            intervalMethod,
            options,
            callback,
            timer: setInterval(intervalMethod, options.interval, options, callback)
        }
        this.watchers[intervalHandler] = timerInstance;
    }

    stopInterval(options) {
        const { method } = options;
        this.ackSequenceNumber = 0;
        if (this.watchers && this.watchers[method] !== undefined) {
            clearInterval(this.watchers[method].timer);
        }
    }

    changeInterval(method, newInterval) {
        const { intervalMethod, options, callback } = this.watchers[method];
        this.stopInterval({ method });
        newInterval && (options.interval = newInterval);
        this.createInterval(intervalMethod, options, callback);
    }

    restartIntervals() {
        this.watchers && Object.keys(this.watchers).forEach(method => {
            const { options, callback } = this.watchers[method];
            this.stopInterval(options, callback);
            this.sendRequest(options, callback);
        });
    }

    publishInterval(data, callback) {
        if (this._isbusy)
            return;
        this._isbusy = true;
        const { sessionId } = data.headers.body;
        const pack = {
            ackSequenceNumber: this.ackSequenceNumber,
            subscriptionId: this.subscriptionId,
            sessionId
        };
        const headers = {
            body: {
                ...pack,
            },
            url: data.headers.url,
        };
        this.asyncRequest(headers, data.timeout).then(answer => {
            if (answer && answer.code === 0) {
                this._isbusy = false;
                if (answer.sequenceNumber > this.ackSequenceNumber || this.ackSequenceNumber != undefined && answer.sequenceNumber != undefined) {
                    this.ackSequenceNumber = answer.sequenceNumber;
                    callback && callback(answer);
                } else if (data.updateTrend) {
                    callback && callback(answer);
                }
            } else {
                this.postError(answer, callback);
            }
            data = answer = null;
        }).catch(error => {
            this._isbusy = false;
            console.log(error);
        });
    }


    async fetchData(obj, timeout) {
        const controller = new AbortController();
        const countDown = setTimeout(() => {
            controller.abort();
        }, timeout || 30000);
        if (typeof obj.body == 'object') {
            obj.body = JSON.stringify(obj.body);
        }
        return await fetch(obj.url, {
            method: obj.method || "POST", // *GET, POST, PUT, DELETE, etc.
            mode: "cors", // no-cors, cors, *same-origin
            cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
            credentials: "same-origin", // include, *same-origin, omit
            headers: obj.headers,
            redirect: "follow", // manual, *follow, error
            referrer: "no-referrer", // no-referrer, *client
            body: obj.body, // body data type must match "Content-Type" header
            signal: controller.signal
        }).then(data => {
            clearTimeout(countDown);
            return data;
        }).catch(err => {
            if (err.name === 'AbortError') {
                return undefined;
            }
            else {
                console.log(err);
            }
        });
    }

    async asyncRequest(obj, timeout) {
        if (this.inited) {
            return await this.fetchData(obj, timeout).then(response => {
                if (response && response.status === 200) {
                    if (!this.isConnected) {
                        this.resetTimeout();
                    }
                    return response.json();
                } else if (response && response.status === 500) {
                    return response.json();
                } else {
                    this.postError(response);
                    return response;
                }
            }).catch(err => { return { code: 10, err: err.toString() } });;
        }
        else {
            this.dispose();
            return Promise.reject("this adapter was disposed");
        }

    }
}