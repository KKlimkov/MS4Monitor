﻿export class ErrorProcessor {

    static ProcessError(response, callback) {
        let item;
        switch (response.code) {
            case 10:
                item = {
                    type: 'error',
                    time: new Date().toLocaleString(),
                    title: "client parse error",
                    text: response.err,
                }
                break;
            case 2149515265:
            case 2149515269:
                callback && callback(response);
                break;
            case 2147943726:
                item = {
                    type: 'error',
                    time: new Date().toLocaleString(),
                    title: 'Ошибка входа',
                    text: 'Неверное имя пользователя или пароль.'
                };
                callback && callback(response);
                break;
            case 2159411200:
                item = {
                    type: 'error',
                    time: new Date().toLocaleString(),
                    title: '2159411200',
                    text: 'запрос не может быть разобран парсером JSON'
                };
                break;
            case 2151809024:
                item = {
                    type: 'error',
                    time: new Date().toLocaleString(),
                    title: '2151809024', text: 'передан недействительный Id параметра/выборки'
                };
                break;
            case 0x800C0000:
            case -2146697216: //
                const event = new CustomEvent('ms_message');
                event.data = { event: 'mplcReload' };
                window.dispatchEvent(event);
                break;
            case 2153119744:
                item = {
                    type: 'error',
                    time: new Date().toLocaleString(),
                    title: '2153119744 Ошибка подключения', text: 'Превышено разрешенное число подключений к серверу'
                };
                break;
            case 2149515264:
            case 0x801F0000: // в Login переданы неверные учетные данные
                callback && callback(response);
                break;
            case -2146762752:
            case 0x800B0000:
                item = {
                    type: 'warning',
                    time: new Date().toLocaleString(),
                    title: 'визуализация недоступна в этом проекте',
                    text: response.errorText
                };
                callback && callback(response);
                break;
            case -2139815936:
                item = {
                    type: "error",
                    time: new Date().toLocaleString(),
                    title: "метод запроса не опознан",
                    text: response,

                };
                break;
            default:
                const title = response.codeDescription !== undefined ? response.codeDescription : 'undefined error';
                const text = response.errorText !== undefined ? response.errorText : response;
                item = {
                    type: 'error',
                    time: new Date().toLocaleString(),
                    title: title,
                    text: text
                };
        }
        item && $ns.add(item);
    }
}