import { ServerAdapterBase } from "./ServerAdapterBase.js"
import { Constants as C } from "./methods.js"

export class WorkerAdapter extends ServerAdapterBase {
    constructor(id) {
        super(id);
        this.workerInstance = new Worker("./observer/WorkerInstance.js");
        this.workerInstance.onmessage = (e) => {
            const ans = e.data;
            const id = ans.method + (ans.id || "");
            if (ans.data && ans.data.code === 0) {
                if (!this.isConnected) {
                    this.resetTimeout();
                }
                this.watchers[id].callback
                    && this.watchers[id].callback(ans.data);
            } else if (ans.methodType !== C.intervalStart
                && ans.data === undefined) {
                this.postError(ans.data, this.watchers[id].callback);
                this.watchers[id].callback
                    && this.watchers[id].callback(ans.data);
            } else {
                this.postError(ans.data, this.watchers[id].callback);
            }
            if (ans.methodType === C.single) {
                delete this.watchers[id];
            }
        }
    }

    post(options, callback) {
        const handle = options.method + (options.id || "");
        this.watchers[handle] = { options, callback };
        this.workerInstance.postMessage(options);
    }

    processSingle(options, callback) {
        const salt = (~~Math.floor(Math.random() * 1e8)).toString(16)
        options.id = salt;
        this.post(options, callback);
    }

    processIntervalStart(options, callback) {
        options.subscriptionId = this.subscriptionId;
        this.post(options, callback);
    }

    stopInterval(options) {
        const { method } = options;
        this.workerInstance.postMessage({
            method,
            methodType: C.intervalStop,
        });
    }

    processIntervalRequest(options, callback) {
        this.post(options, callback);
    }

    changeInterval(method, newInterval) {
        const { options, callback } = this.watchers[method];
        this.stopInterval(options, callback);
        newInterval && (options.interval = newInterval);
        this.post(options, callback);
    }

    restartIntervals() {
        this.watchers && Object.keys(this.watchers).forEach(method => {
            const { options, callback } = this.watchers[method];
            if (options.headers && options.headers.body && this.sessionId)
                options.headers.body.sessionId = this.sessionId;
            this.stopInterval(options, callback);
            this.post(options, callback);
        });
    }

    continue() {
        this.workerInstance.postMessage({ methodType: C.continue });
    }

    dispose() {
        this.workerInstance.terminate();
        super.dispose();
    }
}