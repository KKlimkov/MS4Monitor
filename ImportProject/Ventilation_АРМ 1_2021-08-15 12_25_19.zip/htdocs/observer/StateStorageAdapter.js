export class StateStorageAdapter {

    constructor() {

    }

    saveItemState(itemKey, stateMap) {
        const projectKey = $sw.serverState.currentState.projectId;
        const userKey = $sw.serverState.UserData.user || "default";

        let stateHolder = {}, itemsStates = {}, storedStates = {};

        let curProjState = this.getFromStorage(projectKey);
        if (curProjState) {
            stateHolder = { ...curProjState };
        }
        if (stateHolder[userKey]) {
            itemsStates = stateHolder[userKey]
        }
        if (itemsStates[itemKey]) {
            let oldStateMap = itemsStates[itemKey];
            let notChangedKeys = Object.keys(oldStateMap).filter(x => typeof stateMap[x] === 'undefined');
            notChangedKeys.forEach(x => storedStates[x] = oldStateMap[x])
        }

        itemsStates[itemKey] = { ...storedStates, ...stateMap };
        stateHolder[userKey] = itemsStates;

        this.saveToStorage(projectKey, stateHolder)
    }

    saveToStorage(key, object) {
        if (true/*store in browser flag*/) {

            return this.saveToBrowserStorage(key, object);
        } else {
            //getFromServerStorage()
        }
    }

    saveToBrowserStorage(key, object) {
        let str = JSON.stringify(object);
        window.localStorage.setItem(key, str);
    }

    /*
    saveToServer
    */



    getItemState(itemKey) {
        const projectKey = $sw.serverState.currentState.projectId;
        const userKey = $sw.serverState.UserData.user || "default";

        let curProjState = this.getFromStorage(projectKey);
        let itemsState = curProjState && curProjState[userKey];
        return itemsState && itemsState[itemKey];
    }

    getFromStorage(key) {
        if (true/*store in browser flag*/) {
            return this.getFromBrowserStorage(key);
        } else {
            //getFromServerStorage()
        }
    }

    getFromBrowserStorage(key) {
        let value = window.localStorage.getItem(key)
        return value && JSON.parse(value);
    }

    hasItemState(itemKey) {
        return !!this.getItemState(itemKey);
    }
}

/*
getFromServer
*/



/*  STORAGE LEVELS

    project Id: {
        user's || userList's: {
            elementOriginPath's (as key for uniq element in scheme) : {
                attribute : value,
                objectAttribute (complex attribute fields) : {
                    objectKeys (selected objectKeys, only chosen to store) : value ,
                    ...
                },
                ...
            },
            ...
        },
        ...
    }
*/
