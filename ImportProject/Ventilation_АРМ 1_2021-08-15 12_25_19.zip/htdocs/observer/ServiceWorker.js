"use strict";
import { Constants as C, methods as M } from "./methods.js"
import { ItemSubscription } from './ItemSubscription.js';
import { ServerAdapterFactory } from './ServerAdapterFactory.js';
/**
 * @class ServiceWorker
 * @classdesc Класс для общения HMI с сервером
 **/

export class ServiceWorker {
    constructor() {
        const { location, urlMap, haveReserv } = this.SetLocation();
        this.serverState = {
            LoginData: {},
            UserData: {},
            LoginTime: {},
            currentState: {},
            urlMap,
            location,
            haveReserv,
        };
        this.ServerAdapter = ServerAdapterFactory.GetAdapterInstance("main item adapter", 0, true);
        this.ServerAdapter.location = location;
        const ssid = Number(sessionStorage.getItem('sessionId'));
        if (ssid > 0) {
            this.serverState.sessionId = ssid;
        }

        this.ServerAdapter.sessionId = this.serverState.sessionId;
        this.ItemSubscription = new ItemSubscription(this.ServerAdapter);
    }

    get sessionId() {
        return this.serverState.sessionId;
    }

    set sessionId(value) {
        sessionStorage.setItem('sessionId', value);
        this.serverState.sessionId = value;
        this.ServerAdapter.sessionId = value;
    }

    async StartWatchState() {
        const options = {
            methodType: C.intervalRequest,
            method: M.GetState,
            interval: 5000,
            timeout: 5000,
        }
        this.ServerAdapter.sendRequest(options, this.GetStateCallback.bind(this));
    }

    /** * Получить текущее состояние сервера
    *     @async
    *     @param {string} url адрес сервера
    *     @return {promise} промис
    * */
    async GetState(url) {
        return await new Promise(resolve => {
            const options = {
                methodType: C.single,
                method: M.GetState,
                url,
                timeout: 5000
            };
            this.ServerAdapter.sendRequest(options, data => resolve(data));
        });
    }

    GetStateCallback(data) {
        if (!data) return;
        if (!data.isMaster && this.serverState.haveReserv) {
            const event = new CustomEvent('ms_message');
            event.data = { event: 'serverChange' };
            window.dispatchEvent(event);
            return;
        } else if (this.serverState.currentState.projectId != data.projectId) {
            const event = new CustomEvent('ms_message');
            event.data = { event: 'projectReload' };
            window.dispatchEvent(event);
            return;
        } else if (this.serverState.currentState.projectSessionId != data.projectSessionId) {
            const event = new CustomEvent('ms_message');
            event.data = { event: 'reconnect' };
            window.dispatchEvent(event);
            return;
        } else if (data.sessionId === undefined) {
            const event = new CustomEvent('ms_message');
            event.data = { event: 'sessionInvalid' };
            window.dispatchEvent(event);
        }
        this.serverState.currentState = data;
    }

    /** 
     * Получить текущего пользователя
     * @async
     * @return {promise}
     * */
    async GetLoginData() {
        const options = {
            methodType: C.single,
            method: M.GetLoginData,

        };
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => {
                this.serverState.LoginData = data;
                if (data.session)
                    this.serverState.UserData = data.session;
                this.serverState.LoginTime = this.serverState.UserData ? this.serverState.UserData.serverTime : 0;
                sessionStorage.setItem('serverState.LoginTime', this.serverState.LoginTime);
                //this.serverState.UserData = {
                //    code: data.code,
                //    groups: data.currentOperatorGroups,
                //    user: data.currentOperator,
                //    startMnemoscheme: data.startMnemoscheme,
                //    sessionId: data.sessionId,
                //    serverTime: this.serverState.LoginTime
                //}
                resolve(data);
                data = null;
            });
        });
    }

    /**
     * Вход в систему
     * @param {any} user user имя пользователя
     * @param {any} pass pass пароль пользователя
     * @return {promise}
     */

    async Login(user, pass, relogin, newPass) {
        const options = {
            methodType: C.single,
            method: M.Login,
            pack: {
                login: user,
                password: pass,
            }
        }
        if (typeof newPass !== 'undefined') {
            options.pack.newPassword = newPass;
        }
        if (relogin) {
            options.pack.reuseSession = true;
        }
        return new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => {
                if (!relogin || data && data.code === 0) {
                    this.serverState.UserData = data;
                    this.serverState.LoginTime = this.serverState.UserData ? this.serverState.UserData.serverTime : 0;
                    sessionStorage.setItem('serverState.LoginTime', this.serverState.LoginTime);
                }
                resolve(data);
            })
        });
    }
    /**
     * Выход из системы
     * @return {promise}
     * */
    async Logout() {
        const options = {
            methodType: C.single,
            method: M.Logout,
        };
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => resolve(data));
        });
    }
    /**
     * Отправка лога истории действий
     * @param {any} itemId ID элемента
     * @param {number} objectId ID объекта
     * @param {string} text текст действия
     * @param {string} itemName
     * @return {promise}
     */
    async ReportAction(itemId, objectId, text, itemName) {
        const time = new Date().getTime();
        const pack = {
            data: {
                itemId,
                objectId,
                text,
                time,
                itemName
            },
        }
        const options = {
            methodType: C.single,
            method: M.ReportAction,
            pack,
        };
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => resolve(data));
        });
    }

    async GetReserveNetworkState() {
        let baseOptions = {
            methodType: C.single,
            method: M.GetState,
        }
        const urlMap = this.serverState.urlMap;
        const calcNetworkState = this.CalcNetworkState.bind(this);
        return await this.PromiseBunch(baseOptions, urlMap, calcNetworkState)
    }

    async PromiseBunch(baseOptions, urlMap, callback) {
        return await Promise.all(urlMap.map(url => {
            const options = {
                ...baseOptions,
                url
            };
            return Promise.race([
                new Promise(resolve => this.ServerAdapter.sendRequest(options, data => resolve({ url, data }))),
                new Promise(resolve => setTimeout(resolve, 1000)),
            ])
        })).then(dataMap => callback(dataMap))
            .catch(err => console.log(err));
    }

    CalcNetworkState(stateMap) {
        if (stateMap.length > 0) {
            let mainPool = [];
            stateMap.forEach(state => {
                if (state && state.data && state.data.isMaster) {
                    mainPool.push(state.url);
                }
            });
            return mainPool;
        }
        return null;
    }

    SetLocation() {
        let haveReserv,
            redundancyPool,
            urlMap,
            mainPool =
                this.mainPoolBase =
                window._globalParams.MainIP
                    .split(",")
                    .map(str => str.trim());

        if (window._globalParams.RedundancyIP) {
            redundancyPool =
                this.redundancyPoolBase =
                window._globalParams.RedundancyIP
                    .split(",")
                    .map(str => str.trim());
            haveReserv = true;
            urlMap = mainPool.concat(redundancyPool);
        }
        const hostname = mainPool[0];
        return {
            location: {
                hostname,
                port: window._globalParams.WebPort,
            },
            urlMap,
            haveReserv
        };
    }

    async GetReserveUrl() {
        return await this.GetReserveNetworkState().then(masters => {
            if (masters && masters.length > 0) {
                if (masters.length === 1) {
                    return masters[0];
                } else return this.GetBestUrl(masters);
            }
            return null;
        });
    }


    GetBestUrl(mastersPool) {
        const hostname = this.serverState.location.hostname;
        const curSubNet = this.mainPoolBase.includes(hostname)
            ? this.mainPoolBase
            : this.redundancyPoolBase;
        const subNetMasters = mastersPool.filter(url => curSubNet.includes(url));
        if (subNetMasters.length > 0) {
            const first = subNetMasters.shift();
            subNetMasters.push(first);
            return subNetMasters[0];
        } else {
            return mastersPool[0];
        }
    }


    async Redirect(initialState) {
        if (!this.serverState.haveReserv) return Promise.reject();
        this.ServerAdapter.constructor.stopAdapters();
        let state = "";
        while (state !== "connected") {
            var promise = await this.GetReserveUrl().then(async url => {
                if (url == null) {
                    state = "trymore";
                    await new Promise(resolve => setTimeout(resolve, 100));
                    return;
                }
                return await this.GetState(url).then(data => {
                    if (data && data.isMaster && data.code === 0) {
                        state = "connected";
                        this.serverState.location.hostname = url;
                        this.ServerAdapter.location.hostname = url;
                        this.ServerAdapter.resetTimeout();
                        this.serverState.currentState = data;
                    } else {
                        state = "trymore";
                    }
                    return data;
                });
            });
        };
        if (!initialState) {
            if ($pm.hasPermissions) {
                const event = new CustomEvent('ms_message');
                event.data = {
                    event: 'switchuser',
                    username: window._globalParams.DefaultUser,
                };
                window.dispatchEvent(event);
            } else {
                this.ServerAdapter.constructor.restartAdapters();
            }
        }
        if (document.location.hostname !== this.serverState.location.hostname) {
            let item = {
                type: 'info',
                time: new Date().toLocaleString(),
                title: "Соединение установлено",
                text: `Подключение к ${this.serverState.location.hostname} успешно установлено`
            };
            $ns.add(item);
        }

        return promise;
    }
}