﻿import { ServerAdapterFactory } from './ServerAdapterFactory.js';
import { Constants as C, methods as M } from './methods.js';
/**
 * 
 * */
export class trendWorker {

    constructor(id, type) {
        this.ServerAdapter = ServerAdapterFactory.GetAdapterInstance(id, type);
        this.ServerAdapter.reSubscribe = this.reSubscribe.bind(this);
        this.location = window._globalParams.location;
        this.isBusy = false;
    }

    async CreateDataSubscription() {
        const pack = {
            requestedPublishingInterval: 100,
            requestedLifetimeInterval: 60000,
            maxNotificationsPerPublish: 0,
            maxSize: 1000
        };
        const options = {
            method: M.CreateDataSubscription,
            methodType: C.single,
            pack
        }
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => {
                this.ServerAdapter.subscriptionId = data.subscriptionId;
                resolve(data);
            });
        });
    }


    async CreateMonitoredDataItems(items, subId) {
        if (!items) return;
        this.requestId = 0;
        if (items.length > 0) {
            let ssid = subId || this.ServerAdapter.subscriptionId;
            this.SubPack = {
                subscriptionId: ssid,
                items
            };
            this.storeItems(items);
            const options = {
                method: M.CreateMonitoredDataItems,
                methodType: C.single,
                pack: this.SubPack,
            };
            return await new Promise(resolve => {
                this.ServerAdapter.sendRequest(options,
                    data => resolve(data));
            });
        }
    }

    storeItems(items) {
        if (this.itemsContainer === undefined) {
            this.itemsContainer = [];
            this.itemsContainer.push(...items);
        } else {
            let filtered = this.itemsContainer.filter(elem => !items.find(item => elem.itemId === item.itemId))
            this.itemsContainer = filtered.concat(items);
        }
    }


    StartWatch() {
        let options = {
            methodType: C.intervalStart,
            method: M.PublishData,
            interval: window._globalParams.UpdateInterval,
            updateTrend: true
        };
        this.ServerAdapter.sendRequest(options, answer => {
            if (answer.recs) {
                let element;
                for (let index = 0; index < answer.recs.length; index++) {
                    element = answer.recs[index];
                    this.LinkUp(element);
                }
                element = null;
            } else {
                this.UpdateTime(answer.serverTime);
            }
            answer = null;
        });
    }

    StopWatch() {
        const options = {
            methodType: C.intervalStop,
            method: M.PublishData
        };
        this.ServerAdapter.sendRequest(options);
    }

    async reSubscribe() {
        const item = {
            type: 'error',
            time: new Date().toLocaleString(),
            title: 'Передан недействительный код подписки тренда',
            text: '2150105088'
        };
        $ns.add(item);
        this.isBusy = true;
        this.StopWatch();
        return await this.CreateDataSubscription()
            .then(response => this.CreateMonitoredDataItems(this.itemsContainer, response.subscriptionId)
                .then(() => this.onRestore()));
    }

    onRestore() {
        this.StartWatch();
        const item = {
            type: 'info',
            time: new Date().toLocaleString(),
            title: 'Подписка тренда восстановлена',
            text: '2150105088 resolved'
        };
        $ns.add(item);
    }

    async getAsyncArchiveData(startTime, endTime, resampleInterval, items) {
        this.storage = [];
        const subscriptionId = this.ServerAdapter.subscriptionId;
        const parameters = {
            startTime,
            endTime,
            resampleInterval,
            returnBounds: true,
            subscriptionId
        };
        const pack = {
            parameters,
            data: items
        };
        const options = {
            methodType: C.single,
            method: M.HistoryReadRawAsync,
            pack
        };
        return await new Promise((resolve) => {
            this.ServerAdapter.sendRequest(options, data => {
                this.publishHistoryData(data).then(storage => resolve(storage));
            });
        });
    }
    async publishHistoryData(item) {
        let options = {
            methodType: C.single,
            method: M.PublishHistoryData,
            pack: item
        }
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => {
                if (data.code) {
                    switch (data.code) {
                        case 0x80320000: //запрос в обработке, но не готов
                            resolve(this.publishHistoryData(item));
                            break;
                        case 0x802A0000: //запрос был удален, нужно отправить полученный requestId
                            if (data.requestId > item.requestId) {
                                item.requestId = data.requestId;
                                resolve(this.publishHistoryData(item));
                            }
                            resolve(this.storage);
                            break;
                        case 0x00A60000: //будут еще пакеты с данными
                            this.storage.push(data.data);
                            item.requestId = data.requestId + 1;
                            resolve(this.publishHistoryData(item));
                            break;
                        case 0x80840000:
                        case 0x804A0000: //нет запрашиваемого subscriptionId
                        default:
                            resolve(this.storage);
                    }
                } else {
                    this.storage.push(data.data);
                    resolve(this.storage);
                }
            });
        });
    }

    async getArchiveItems(item) {
        const { taskId, itemId, path } = item;
        const items = [{ taskId, itemId, path }];
        if (typeof item.type !== 'undefined') items['type'] = item.type;
        const pack = {
            items
        };
        const options = {
            methodType: C.single,
            method: M.GetArchiveItems,
            pack
        };
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => {
                resolve({ ...data.items[0], ...options.pack.items[0] });
            });
        });
    }

    async HistoryReadRaw(startTime, endTime, resampleInterval, item) {
        const pack = {
            parameters: {
                startTime,
                endTime,
                returnBounds: true,
                returnFirstLastValue: (endTime == 0 && startTime == 0),
                resampleInterval: resampleInterval
            },
            data: [item]
        };
        const options = {
            methodType: C.single,
            method: M.HistoryReadRaw,
            pack
        };
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, answer => {
                resolve(answer.data);
            });
        });
    }

    async DeleteMonitoredDataItems(monitoredItemId) {
        if (!monitoredItemId) return;
        const pack = {
            items: [monitoredItemId],
            subscriptionId: this.ServerAdapter.subscriptionId,
        };
        let options = {
            methodType: C.single,
            method: M.DeleteMonitoredDataItems,
            pack
        };
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => {
                resolve(data);
            });
        });
    }
}