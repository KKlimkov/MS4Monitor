import { Permissions } from './../generated/permissions.js';

export class PermissionsManager {
    constructor() {
        this.hasPermissions = true;
        this.global = Permissions.globalPermissions || {};
        this.elementsPermissions = Permissions.elementsPermissions || {};
        this.objectsPermissions = Permissions.objectsPermissions || {};
        this.windowsPermissions = Permissions.windowsPermissions || {};
        this.operatorsRoles = Permissions.operatorsRoles || {};
        this.operatorsMnemos = Permissions.operatorsMnemos || {};
        this.logActionTry = Permissions.logActionTry || {};
        this.emptyPermConst = "0000";
        this.allRoleConst = "_All";
        this.permissionTypes = {
            Action: "Действие",
            Control: "Управление",
            OpenWindow: "Открытие окна",
            ChangeUsers: "Смена пользователя",
            ChangeSelfPassword: "Изменение пароля",
            JournalAck: "Квитирование сообщения",
            JournalGroupAck: "Групповое квитирование сообщений",
            JournalUseFilters: "Использование фильтров в журнале",
            JournalPrint: "Печать сообщений",
            JournalSave: "Экспорт сообщений",
            TrendAddPens: "Добавление перьев",
            TrendDeletePens: "Удаление перьев",
            TrendChangePens: "Изменение настройки перьев, изменение шкалы",
            TrendSave: "Экспорт графика",
            TrendPrint: "Печать графика",
            DataTableEdit: "Редактирование ячеек таблицы",
            DataTableFilter: "Использование фильтров в таблице",
        }

        this.rtObjectRights = {};
        this.rtWindowsRights = {};
        this.rtElementsRights = {};
    }

    openUserWindow(customWin) {
        if (this.hasPermissions) {
            const permit = this.checkOpenWindowRights(customWin);
            //                                                /\
            //стартовые окна не могут быть экземплярами, поэтому контекст не обязателен
            if (!permit) {
                const item = {
                    type: 'error',
                    time: new Date().toLocaleString(),
                    title: 'Нет прав на заданное окно', text: 'Нет прав на открытие заданного стартового окна. Проверьте настройки прав для данного пользователя'
                };
                $ns.add(item);
                return false;
            }
        }
        const frame = document.getElementById($WinDefs.constructor.mainFrame);
        frame.openWindow($WinDefs.winDef[customWin]);
        return true;
    }

    checkCurrentWindow() {
        const firstWin = document.getElementById($WinDefs.constructor.mainFrame).firstChild;
        if (firstWin) {
            const curWin = firstWin.id;
            return this.checkOpenWindowRights(curWin, firstWin);
        }
    }

    getStartWindow() {
        if (Object.keys(this.operatorsMnemos).length > 0) {
            let intersec = this.getUsersIntersec(this.operatorsMnemos);
            if (intersec && intersec.length === 1) return this.operatorsMnemos[intersec[0]];
            if (intersec && intersec.length > 1) {
                //если пользователь состоит в нескольких группах 
                //и для этих групп заданы стартовые окна
                //вернем первое разрешенное окно из списка групп
                for (let i = 0; i < intersec.length; i++) {
                    const startMnemo = this.operatorsMnemos[intersec[i]];
                    if (this.checkOpenWindowRights(startMnemo)) {
                        return startMnemo;
                    }
                }
            }
        }
    }

    //for silent mode, where we dont have confirmation and action based opening
    checkOpenWindowRights(winId, context) {
        const entry = this.getEntryFromWindowType(winId, "OpenWindow", context);
        return this.checkAllow(entry);
    }

    setOperatorRoles(operator, roles) {
        this.currentOp = operator;
        if (typeof (roles) !== 'undefined' && roles.length > 0) {
            if (typeof roles[0] === 'string') {
                this.operatorsRoles[operator] = roles;
            } else if (roles[0] !== null && typeof roles[0] === 'object') {
                this.operatorsRoles[operator] = roles.map(x => x.name);
            }
        }
        this.changeUsersList(operator);
        //this.saveRtRights()
    }

    setRtRights(data) {
        if (typeof data.rights === 'object') {
            this.resetRtRights();
            this.addToRTStore(data.rights,
                (objId, rights) => this.rtObjectRights[objId] = rights);
        }
    }

    saveRtRights() {
        this.saveRight("rtElementsRights", this.rtElementsRights);
        this.saveRight("rtWindowsRights", this.rtWindowsRights);
        this.saveRight("rtObjectRights", this.rtObjectRights);
    }

    saveRight(key, rightObj) {
        if (typeof rightObj === 'object') {
            $ss.saveToStorage(key, rightObj);
        }
    }

    restoreRights() {
        this.rtObjectRights = $ss.getFromStorage("rtObjectRights") || {};
        this.rtWindowsRights = $ss.getFromStorage("rtWindowsRights") || {};
        this.rtElementsRights = $ss.getFromStorage("rtElementsRights") || {};
    }

    resetRtRights() {
        this.rtObjectRights = {};
        this.rtWindowsRights = {};
        this.rtElementsRights = {};
        this.saveRtRights();
    }

    addToRTStore(object, addFunc, stopSignal = false, ...args) {
        let keys = Object.keys(object);
        for (let i = 0; i < keys.length; i++) {
            const key = keys[i];
            const objectEntry = object[key];

            let rights = stopSignal ? objectEntry : objectEntry.rights;
            if (typeof rights === 'object'
                && Object.keys(rights).length > 0) {
                addFunc(key, rights, ...args);
            }
            if (stopSignal) continue;
            //права окон
            if (typeof objectEntry.windows === 'object'
                && Object.keys(objectEntry.windows).length > 0) {

                this.addToRTStore(objectEntry.windows,
                    (winName, rights, objId) => this.addWindowRtRights(winName, rights, objId),
                    false,
                    key);
            }
            //права контролов            
            else {
                let copyObjEntry = { ...objectEntry }
                delete copyObjEntry.rights;
                if (Object.keys(copyObjEntry).length > 0) {
                    this.addToRTStore(copyObjEntry,
                        (controlName, rights, winName, objId) => this.addControlRtRights(controlName, rights, winName, objId),
                        true,
                        key,
                        ...args);
                }
            }
        }
    }

    addWindowRtRights(winName, rights, objId) {
        let winId = $pr.getWindowIdByName(winName, objId);
        this.rtWindowsRights[winId] = rights;
    }

    addControlRtRights(elementName, rights, winName, objId) {
        let winId = $pr.getWindowIdByName(winName, objId);

        if (typeof winId !== 'undefined') {
            if (typeof this.rtElementsRights[winId] !== 'undefined') {
                let temp = this.rtElementsRights[winId];
                this.rtElementsRights[winId] = { ...temp, [elementName]: rights };
            } else {
                this.rtElementsRights[winId] = { [elementName]: rights };
            }
        }
    }

    getStoredPermission(element, winTypeId, usersList, permType) {
        const rtRights = this.rtElementsRights[winTypeId];
        if (typeof rtRights !== "undefined") {
            return false;
        }
        return element.getPermission(usersList, permType);
    }

    getElementPermission(element, winId) {
        const rtRights = this.rtElementsRights[winId];
        if (typeof rtRights !== "undefined") {
            let elementName = element.elname;
            let elementRights = rtRights[elementName];
            if (typeof elementRights !== "undefined") {
                return elementRights;
            }
        }
        const permContainer = this.elementsPermissions[winId];
        if (typeof permContainer !== "undefined") {
            let elementId = element.id;
            let elementRights = permContainer[elementId];
            if (typeof elementRights !== "undefined") {
                return elementRights;
            }
        }
    }

    getWindowPermission(typeId) {
        let rtRights = this.rtWindowsRights[typeId]
        let dtRights = this.windowsPermissions[typeId];
        return typeof rtRights !== "undefined" ? rtRights : dtRights;
    }

    getObjectPermission(objectId) {
        let rtRights = this.rtObjectRights[objectId];
        let dtRights = this.objectsPermissions[objectId];
        return typeof rtRights !== "undefined" ? rtRights : dtRights;
    }

    changeUsersList(operator) {
        if (!operator) {
            operator = this.currentOp;
        }
        let roles = this.operatorsRoles && new Set(this.operatorsRoles[operator]);
        if (typeof (roles) !== 'undefined' && roles.size > 0) {
            roles.add(operator);
            roles.add(this.allRoleConst);
            this.usersList = Array.from(roles);
        } else {
            this.usersList = [operator, this.allRoleConst];
        }
    }

    getParentWindow(element) {
        let temp = element;
        while (temp && temp.nodeName !== "MS-WINDOW") {
            temp = temp.parentNode;
        }
        return temp;
    }

    getObjectId(typeId, context) {
        let objId = Number($WinDefs.winDef[typeId] && $WinDefs.winDef[typeId].objectid);
        if (!objId && context) {
            objId = $sw.ItemSubscription._getParentParam(context, 'objectid');
        }
        return objId;
    }

    controlEnable(childs) {
        if (typeof childs !== 'undefined' && childs.length > 0) {
            childs.forEach(ch => {
                if (typeof ch.setPermission === 'function') {
                    let onlyMS = ch.childNodes.length > 0
                        ? Array.from(ch.childNodes).filter(ch => ch.nodeName.startsWith("MS"))
                        : [];
                    //dont disable containers, 
                    //it possibly contains special allow                        
                    if (onlyMS.length > 0) {
                        this.controlEnable(onlyMS);
                    } else {
                        let entry = this.getEntryFromElement(ch, "Control");
                        let disable = !this.checkAllow(entry);
                        ch.setControlDisable(disable);
                    }
                }
            });
        }
    }

    checkEnable(element) {
        return this.checkAllow(this.getEntryFromElement(element, "Control"));
    }

    getEntryFromElement(element, permType) {
        const parentWin = this.getParentWindow(element);
        const windowTypeId = parentWin && parentWin.typeid;

        let result = this.getStoredPermission(element, windowTypeId, this.usersList, permType);
        if (result) {
            return result;
        }

        const windowId = parentWin && parentWin.id;
        let node = element;
        let rightsMask = 0;
        let reducedUsers = {};
        do {
            const elPerm = this.getElementPermission(node, windowId);
            if (typeof elPerm !== 'undefined')
                rightsMask = this.getCombinedRights(rightsMask, reducedUsers, elPerm[permType], this.usersList);

            if (windowTypeId) {
                const elTypePerm = this.getElementPermission(node, windowTypeId);
                if (typeof elTypePerm !== 'undefined')
                    rightsMask = this.getCombinedRights(rightsMask, reducedUsers, elTypePerm[permType], this.usersList);
            }
            
            if (node.id == windowId) break;
            node = node.parentNode;
        } while (node.id != windowId);

        const winPerms = this.getWindowPermission(windowId);
        if (typeof (winPerms) !== 'undefined')
            rightsMask = this.getCombinedRights(rightsMask, reducedUsers, winPerms[permType], this.usersList);

        const winTypePerms = this.getWindowPermission(windowTypeId);
        if (typeof (winTypePerms) !== 'undefined')
            rightsMask = this.getCombinedRights(rightsMask, reducedUsers, winTypePerms[permType], this.usersList);

        const objectId = this.getObjectId(windowTypeId, element);
        if (typeof (objectId) !== 'undefined')
            rightsMask = this.getCombinedObjectRights(rightsMask, reducedUsers, objectId, permType);
        
        const globalPerm = this.global[permType];
        if (typeof (globalPerm) !== 'undefined')
            rightsMask = this.getCombinedRights(rightsMask, reducedUsers, globalPerm, this.usersList);
        
        result = this.reduceEntries(rightsMask);
        element.setPermission(this.usersList, permType, result);
        return result;
    }

    getEntryFromWindowType(typeId, permType, context, objectId) {
        let rightsMask = 0;
        let reducedUsers = {};
        const winTypePerms = this.getWindowPermission(typeId);
        if (typeof (winTypePerms) !== 'undefined')
            rightsMask = this.getCombinedRights(rightsMask, reducedUsers, winTypePerms[permType], this.usersList);

        if (typeof (objectId) !== 'undefined')
            rightsMask = this.getCombinedObjectRights(rightsMask, reducedUsers, objectId, permType);
        
        const globalPerm = this.global[permType];
        if (typeof (globalPerm) !== 'undefined')
            rightsMask = this.getCombinedRights(rightsMask, reducedUsers, globalPerm, this.usersList);
        
        return this.reduceEntries(rightsMask);
    }

    getCombinedObjectRights(rightsMask, reducedUsers, objectId, permType) {
        const objPerm = this.getObjectPermission(objectId);
        if (typeof (objPerm) !== 'undefined') {
            rightsMask = this.getCombinedRights(rightsMask, reducedUsers, objPerm[permType], this.usersList);

            const objParent = objPerm.parentId;
            if (typeof (objParent) !== 'undefined')
                rightsMask = this.getCombinedObjectRights(rightsMask, reducedUsers, objParent, permType);
        }
        return rightsMask;
    }

    getEntryFromObject(objectId, permType) {
        let reducedUsers = {}
        let rightsMask = this.getCombinedObjectRights(0, reducedUsers, objectId, permType);
        
        const globalPerm = this.global[permType];
        if (typeof (globalPerm) !== 'undefined') {
            rightsMask = this.getCombinedRights(rightsMask, reducedUsers, globalPerm, this.usersList);
        }
        return this.reduceEntries(rightsMask);
    }

    /*from perms list exract users intersected with current users list */
    getUsersIntersec(perms) {
        return typeof (perms) !== 'undefined'
            && Object.keys(perms).filter(x => this.usersList.includes(x));
    }

    getCombinedRights(rightsMask, reducedUsers, rights, users) {
        if (typeof (rights) === 'undefined')
            return rightsMask;
        return users.reduce((acc, cur) => {
            if (!reducedUsers.hasOwnProperty(cur) && rights.hasOwnProperty(cur)) {
                reducedUsers[cur] = true;
                return acc | rights[cur];
            } else
                return acc;
        }, rightsMask);
    }

    reduceEntries(...entries) {
        let reducedEntry = entries.reduce((acc, cur) => acc | cur, 0).toString(2);
        /*adding leading zeros for normalize length*/
        return "0000".substr(reducedEntry.length) + reducedEntry;
    }

    resolveOpenWindow(context, windId, objectId, callback) {
        const optype = "OpenWindow";
        const entryForWindow = this.getEntryFromWindowType(windId, optype, context, objectId);
        const entryForContext = this.getEntryFromElement(context, optype);
        const result = this.reduceEntries(parseInt(entryForContext, 2), parseInt(entryForWindow, 2));
        this.resolveAction(context, result, optype, callback);
    }

    resolveControl(context, optypeDesc, callback, options) {
        const optype = optypeDesc === "Action" ? "Control" : optypeDesc;
        let entry = this.getEntryFromElement(context, optype);
        return this.resolveAction(context, entry, optype, callback, options);
    }

    resolveAction(context, entry, optype, callback, options) {
        const { customText, customDialogText, uid = 0, cancel, forced = false } = options || {};
        if (this.checkAllow(entry)) {
            if (this.Confirmation(entry) && !forced) {
                if (this.getLogActionTryFlag() && this.WriteLog(entry)) {
                    this.reportAction(context, optype, customText, true);
                }
                return $confirm(
                    this.executeOperation.bind(this, context, entry, optype, callback, customText),
                    customDialogText || this.getPermissionText(optype),
                    uid,
                    cancel);
            } else {
                return this.executeOperation(context, entry, optype, callback, customText);
            }
        }
    }

    executeOperation(context, entry, optype, callback, customText) {
        if (this.WriteLog(entry)) {
            this.reportAction(context, optype, customText);
        }
        return callback && callback();
    }

    getLogActionTryFlag() {
        let intersec = this.getUsersIntersec(this.logActionTry);
        if (intersec.length === 1) return this.logActionTry[intersec[0]];
        else {
            //если пользователь состоит в нескольких группах 
            //и флаг логировать попытки действий true хотя бы в одной, то логируем
            return intersec.reduce((acc, cur) => this.logActionTry[cur] || acc, false);
        }
    }

    reportAction(context, optype, customText, logActionTry) {
        const wind = this.getParentWindow(context);
        const windId = wind && wind.typeid;
        const objId = this.getObjectId(windId, context);
        const tmp = Object.keys(context.actions)[0] ? context.actions[Object.keys(context.actions)[0]] : null;
        const message = tmp && tmp.parameters ? tmp.parameters.message : null;

        if (typeof customText === "undefined") {
            const permname = this.getPermissionText(optype);
            customText = message ? message : `${permname}: ${context.elname}`;
        }
        if (logActionTry) {
            customText = "Попытка действия: " + customText;
        }

        $sw.ReportAction(context.id, objId, customText, context.elname);
    }


    getPermissionText(optype) {
        const result = this.permissionTypes[optype];
        if (typeof result === "undefined") return optype;
        return result;
    }

    checkAllow(entry) {
        return this.Enable(entry) && !this.Disable(entry);
    }

    Enable(entry) {
        return !!(entry && entry[3] === "1");
    }

    Disable(entry) {
        return !!(entry && entry[2] === "1");
    }

    Confirmation(entry) {
        return !!(entry && entry[1] === "1");
    }

    WriteLog(entry) {
        return !!(entry && entry[0] === "1");
    }
}