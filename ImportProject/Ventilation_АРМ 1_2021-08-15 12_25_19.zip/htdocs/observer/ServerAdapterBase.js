import { ErrorProcessor } from "./ErrorProcessor.js"
export class ServerAdapterBase {
    constructor(id, isMain) {
        this.id = id;
        this.isMain = isMain;
        this.methods = window._methods.getMethod;
        this.offlineMode = window._globalParams.OfflineMode;
        this.watchers = Object.create(null);
        this.methodTypeHandlers = Object.create(null)
        this.methodTypeHandlers = Object.freeze({
            single: this.processSingle.bind(this),
            intervalStart: this.processIntervalStart.bind(this),
            intervalStop: this.stopInterval.bind(this),
            intervalRequest: this.processIntervalRequest.bind(this),
            continue: this.continue.bind(this),
        })
        ServerAdapterBase.addWorker(this, id);
        this.timeoutCounter = 0;
        this.inited = true;
    }

    set location(value) {
        ServerAdapterBase._location = value
    }

    get location() {
        return ServerAdapterBase._location;
    }

    static addWorker(adapter, id) {
        if (typeof ServerAdapterBase.activeWorkers === 'undefined') {
            ServerAdapterBase.activeWorkers = new Map();
        }
        if (ServerAdapterBase.activeWorkers.has(id)) {
            ServerAdapterBase.activeWorkers.delete(id);
        }
        ServerAdapterBase.activeWorkers.set(id, adapter);
    }

    static stopAdapters() {
        if (typeof ServerAdapterBase.activeWorkers !== 'undefined') {
            ServerAdapterBase.activeWorkers.forEach(x => x.stopIntervals());
        }
    }

    static restartAdapters() {
        if (typeof ServerAdapterBase.activeWorkers !== 'undefined') {
            ServerAdapterBase.activeWorkers.forEach(x => x.restartIntervals());
        }
    }

    sendRequest(options, callback) {
        const { pack, method, url } = options;
        const headers = {
            url: `//${url || this.location.hostname}:${this.location.port}` + this.methods(method),
            body: {
                ...pack,
                sessionId: this.sessionId
            }
        };
        options = {
            ...options,
            headers,
        };
        this.methodTypeHandlers[options.methodType](options, callback);
    }

    postError(answer, callback) {
        if (this.timeoutCounter > 3 && !this.offlineMode && this.isMain) {   //Отслеживаем подключение только в основном потоке
            const event = new CustomEvent('ms_message');
            event.data = { event: 'connectionLost' };
            window.dispatchEvent(event);
            this.isConnected = false;
        }
        if (answer && answer.code) {
            this.errorPrecursor(answer, callback);
        } else {
            this.timeoutCounter++;
        }
    }

    resetTimeout() {
        this.timeoutCounter = 0;
        if (!this.isConnected) {
            this.isConnected = true;
            const event = new CustomEvent('ms_message');
            event.data = { event: 'connectRestore' };
            window.dispatchEvent(event);
        }
    }

    set sessionId(value) {
        ServerAdapterBase.sessionId = value;
    }

    get sessionId() {
        return ServerAdapterBase.sessionId;
    }

    stopIntervals() {
        this.watchers && Object.keys(this.watchers).forEach(method => {
            this.stopInterval({ method });
        });
    }

    errorPrecursor(answer, callback) {
        switch (answer.code) {
            case 2150105088: // 0x80280000
                if (!this.busyResub && this.watchers != undefined) {
                    this.busyResub = true;
                    this.reSubscribe().then(() => { this.busyResub = false }).catch(() => { this.busyResub = false });
                }
                break;
            case 2149908480://0x80250000 sessionId invalid   
                ServerAdapterBase.stopAdapters();
                const event = new CustomEvent('ms_message');
                if ($pm.hasPermissions) {
                    event.data = {
                        event: 'switchuser',
                        username: window._globalParams.DefaultUser,
                    };
                } else {
                    event.data = {
                        event: 'sessionInvalid',
                    };
                }
                window.dispatchEvent(event);
                break;
            case 0x80320000: //ошибки тренда 
            case 0x802A0000:
            case 0x00A60000:
            case 0x80840000:
            case 0x804A0000:
                return callback && callback(answer)
            default:
                ErrorProcessor.ProcessError(answer, callback)
        }
        callback = answer = null;
    }

    dispose() {
        this.inited = false;
        if (this.watchers) {
            Object.keys(this.watchers).forEach(el => {
                clearInterval(this.watchers[el].timer);
            });
        }
        delete this.watchers;
        ServerAdapterBase.activeWorkers.delete(this.id);
    }

    continue() { }

    reSubscribe() { }
}