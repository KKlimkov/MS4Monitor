﻿export class PathResolver {
    constructor() {
        this.windMap = {};
        this.createObjectTree();
    }

    getWindowIdByPath(path) {
        let paths = path.split('.');
        let node = this.objTree;
        for (let i = 0; i < paths.length; i++) {
            const part = paths[i];
            if (part === "Ресурсы" || part === "Окна")
                continue;

            if (typeof node[part] !== 'undefined') {
                node = node[part];
            } else {
                $ns.add({
                    type: 'warning',
                    time: new Date().toLocaleString(),
                    title: 'Окно не найдено',
                    text: `Окно по пути "${path}" не найдено`
                });
                return;
            }
        }
        return node;
    }

    getWindowIdByName(winName, objId) {
        let objWinds = this.windMap[objId];
        if (typeof objWinds !== 'undefined') {
            return objWinds[winName];
        }
    }

    getObjectIdByPath(path) {
        let paths = path.split('.');
        let node = this.objTree;
        let objId = 0;
        for (let i = 0; i < paths.length; i++) {
            const part = paths[i];
            if (part === "Ресурсы" || part === "Окна")
                continue;
            if (typeof node[part] !== 'undefined') {
                if (typeof node[part].ID !== 'undefined') {
                    objId = node[part].ID;
                }
                node = node[part];
            }
        }
        return objId
    }

    createObjectTree() {
        this.getVm().then(() => {
            if (typeof this.vmInfo === 'object' && this.vmInfo !== null) {
                let rawObjTree = Object.values(this.vmInfo.projectTree)
                    .find(obj => obj.TranslitedName === 'ObjectRoot');
                if (rawObjTree)
                    this.objectRootName = rawObjTree.Name;
                let rawSytemTree = Object.values(this.vmInfo.projectTree)
                    .find(obj => obj.TranslitedName === 'SystemRoot');

                this.objTree = {
                    ...this.getChilds(rawObjTree, $WinDefs.winMap),
                    ...this.getChilds(rawSytemTree, $WinDefs.winMap)
                };
            }
        });
    }

    getChilds(treeEl, windMap) {
        if (typeof treeEl !== 'undefined') {
            if (Array.isArray(treeEl.Childs) && treeEl.Childs.length > 0) {
                let result = {};
                for (let i = 0; i < treeEl.Childs.length; i++) {
                    const  child = treeEl.Childs[i];
                    if (   child.Type === 'Object'
                        || child.Type === 'ObjectInstance'
                        || child.Type === 'Controller') {

                        result[child.Name] = {
                            ...this.getWindows(child, windMap),
                            ...this.getChilds(child, windMap)
                        };
                    };
                }
                if (treeEl.Type === "Folder") {
                    return {
                        [treeEl.Name]: result,
                    }
                }
                return result;
            } else if (treeEl.Type === 'Object'
                || treeEl.Type === 'ObjectInstance'
                || treeEl.Type === 'Controller') {
                return this.getWindows(treeEl, windMap);
            }
        }
    }

    getWindows(element, windMap) {
        let result = { ID: element.ID };
        if (   element.Type === 'Object'
            || element.Type === 'Controller') {
            if (typeof windMap[element.ID] !== 'undefined') {
                let tempMap = windMap[element.ID];
                this.windMap[element.ID] = { ...tempMap };
                result = {
                    ...result,
                    ...tempMap
                };
            }
        } else if (element.Type === 'ObjectInstance') {
            if (typeof this.vmInfo.types !== 'undefined') {
                let type = this.vmInfo.types.find(x => x.Name === element.STType);
                let tempMap = type.Windows;
                this.windMap[element.ID] = { ...tempMap };
                result = {
                    ...result,
                    ...tempMap
                }
            }
        }
        return result;
    }

    async getVm() {
        if (typeof this.vmInfo === 'undefined') {
            await this.loadVm().then(data => this.vmInfo = data);
        }
        return this.vmInfo;
    }

    async loadVm() {
        return await new Promise(resolve => {
            this._loadJSON('VMInfo.json', (data) => {
                try {
                    var vmInfo = JSON.parse(data);
                } catch (e) {

                }
                resolve(vmInfo);
            })
        });
    }

    _loadJSON(filename, callback) {
        const xobj = new XMLHttpRequest();
        xobj.overrideMimeType('application/json');
        xobj.open('GET', filename, true);
        xobj.onreadystatechange = function () {
            if (xobj.readyState == 4 && xobj.status == '200') {
                callback(xobj.responseText);
            }
        };
        xobj.send(null);
    }

}