﻿import { ServerAdapterFactory } from './ServerAdapterFactory.js'
import { Constants as C, methods as M } from "./methods.js"

export class journalWorker {

    constructor(id, type) {
        this.options = {
            updatePeriod: 1000,
            interval: 1000,
            maxSize: 1000
        };
        this.tryCount = 0;
        this.ItemsContainer = {};
        this.ServerAdapter = ServerAdapterFactory.GetAdapterInstance(id, type);
        this.ServerAdapter.reSubscribe = this.reSubscribe.bind(this);

    }

    async Subscribe() {
        const pack = {
            requestedPublishingInterval: this.options.interval,
            requestedLifetimeInterval: 0,
            maxNotificationsPerPublish: 0,
            maxSize: 1000
        };
        let options = {
            methodType: C.single,
            method: M.CreateEventSubscription,
            pack,
        };
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => {
                this.ServerAdapter.subscriptionId = data.subscriptionId;
                resolve(data)
            })
        });
    }

    async CreateMonitoredEvents(items, subId) {
        if (items.length > 0) {
            return await new Promise(resolve => {
                const pack = {
                    subscriptionId: subId || this.ServerAdapter.subscriptionId,
                    items
                };
                this.ItemsContainer = items;
                const options = {
                    methodType: C.single,
                    method: M.CreateMonitoredEvents,
                    pack,
                }
                this.ServerAdapter.sendRequest(options, data => resolve(data));
            });
        }
    }

    async RefreshEvents() {
        const pack = {
            subscriptionId: this.ServerAdapter.subscriptionId
        };
        const options = {
            methodType: C.single,
            method: M.RefreshEvents,
            pack,
        }
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => resolve(data));
        });
    }

    async AcknowledgeEvents(items, comment) {
        if (items.length > 0) {
            const pack = {
                subscriptionId: this.ServerAdapter.subscriptionId
            };
            const recs = [];
            for (let i = 0; i < items.length; i++) {
                recs.push({ eventId: items[i], comment: comment });
            }
            pack['recs'] = recs;
            const options = {
                methodType: C.single,
                method: M.AcknowledgeEvents,
                pack,
            };
            return await new Promise(resolve => {
                this.ServerAdapter.sendRequest(options, data => resolve(data));
            });
        }
    }

    GetArchivedEvents() {

    }

    StartWatch() {
        const options = {
            methodType: C.intervalStart,
            method: M.PublishEvents,
            interval: this.options.updatePeriod,
        };
        this.ServerAdapter.sendRequest(options, data => {
            this.upData(data)
            this.ServerAdapter.continue()
        });
    }

    StopWatch() {
        const options = {
            methodType: C.intervalStop,
            method: M.PublishEvents,
        }
        this.ServerAdapter.sendRequest(options);
    }

    async reSubscribe() {
        const item = {
            type: 'error',
            time: new Date().toLocaleString(),
            title: 'Передан недействительный код подписки журнала',
            text: '2150105088'
        };
        $ns.add(item);
        this.StopWatch();
        return await this.Subscribe().then(response =>
            this.CreateMonitoredEvents(this.ItemsContainer, response.subscriptionId)
                .then(() => this.onRestore()));
    }

    onRestore() {
        this.StartWatch()
        const item = {
            type: 'info',
            time: new Date().toLocaleString(),
            title: 'Подписка журнала восстановлена',
            text: '2150105088 resolved'
        };
        $ns.add(item);
    }

    getAsyncArchiveData(params, items) {

    }
    async getArchivedEvents(pack) {
        pack.timeout = 30;
        const options = {
            methodType: C.single,
            method: M.GetArchivedEvents,
            timeout: 30000,
            pack,
        }
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => resolve(data));
        });
    }

    async DeleteMonitoredEvents(monitoredItemId) {

        const pack = {
            items: [monitoredItemId],
            subscriptionId: this.ServerAdapter.subscriptionId
        };
        const options = {
            methodType: C.single,
            method: M.DeleteMonitoredEvents,
            pack,
        }
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => resolve(data));
        });
    }
}