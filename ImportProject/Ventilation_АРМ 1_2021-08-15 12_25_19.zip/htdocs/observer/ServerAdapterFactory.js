import { WorkerAdapter } from "./WorkerAdapter.js"
import { HttpAdapter } from "./HttpAdapter.js"

export class ServerAdapterFactory {

    static GetAdapterInstance(id, type = 0, isMain = false) {
        switch (type) {
        case 0: //main process
            return new HttpAdapter(id, isMain);
        case 1: // worker process
            return new WorkerAdapter(id);
        }
    }
}