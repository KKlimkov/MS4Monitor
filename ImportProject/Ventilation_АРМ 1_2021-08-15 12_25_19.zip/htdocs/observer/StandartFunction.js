export class StandartFunctions {

    constructor(){
        this.StandartFunctionsErrors = {
            DIV_0: () => { throw new Error("division by zero"); },
            LOG_0: () => { throw new Error("out of range"); }
        }
    }

    static ABS(a) {
        return Math.abs(a);
    };

    static ADD(a, b) {
        return a + b;
    };

    static SUB(a, b) {
        return a - b;
    };

    static MOD(a, b) {
        return a % b;
    };

    static DIV_REAL_REAL(a, b) {
        return this.DIV(a, b);
    };
    //Исправить
    static DIV_INT_INT(a, b) {
        return Math.round(this.DIV(a, b));
    };

    static MUL(a, b) {
        return a * b;
    };

    DIV(a, b) {
        if (b === 0) {
            this.StandartFunctionsErrors.DIV_0();
        };
        return a / b;
    };


    static SHL_LWORD(a, b) {
        return a << b;
    };

    static SHL_DWORD(a, b) {
        return a << b;
    };

    static SHL_WORD(a, b) {
        return a << b;
    };

    static SHL_BYTE(a, b) {
        return a << b;
    };

    static SHR_LWORD(a, b) {
        return a >>> b;
    };

    static SHR_DWORD(a, b) {
        return a >>> b;
    };

    static SHR_WORD(a, b) {
        return a >>> b;
    };

    static SHR_BYTE(a, b) {
        return a >>> b;
    };
    //need change
    static ROR_LWORD(val, shift) {
        return (val >> shift) | (val << (64 - shift));
    };

    static ROR_DWORD(val, shift) {
        return (val >> shift) | (val << (32 - shift));
    };

    static ROR_WORD(val, shift) {
        return ((val >> shift) | (val << (32 - shift))) & 0xFFFF;
    };

    static ROR_BYTE(val, shift) {
        return ((val >> shift) | (val << (8 - shift))) & 0xFF;
    };
    //need change
    static ROL_LWORD(val, shift) {
        return (val << shift) | (val >> (64 - shift));
    };

    static ROL_DWORD(val, shift) {
        return (val << shift) | (val >> (32 - shift));
    };

    static ROL_WORD(val, shift) {
        return ((val << shift) | (val >> (16 - shift))) & 0xFFFF;
    };

    static ROL_BYTE(val, shift) {
        return ((val << shift) | (val >> (8 - shift))) & 0xFF;
    };

    static OR_PARAMS_LWORD(a, b) {
        return a | b;
    };
    static OR_PARAMS_BOOL(a, b) {
        return a | b;
    };

    static AND_PARAMS_LWORD(a, b) {
        return a & b;
    };
    static AND_PARAMS_BOOL(a, b) {
        return a & b;
    };

    static XOR_PARAMS_LWORD(a, b) {
        return a ^ b;
    };
    static XOR_PARAMS_BOOL(a, b) {
        return a ^ b;
    };
    //LWORD ??? уточнить 
    static NOT_LWORD(a) {
        return 0xffffffffffffffff - a;
    };
    static NOT_DWORD(a) {
        return 0xffffffff - a;;
    };
    static NOT_WORD(a) {
        return 0xffff - a;
    };
    static NOT_BYTE(a) {
        return 0xff - a;
    };
    static NOT_BOOL(a) {
        return !a;
    };

    static MAX(a, b) {

        return a >= b ? a : b;
    };

    static MIN(a, b) {

        return a <= b ? a : b;
    };

    static LIMIT(mn, IN1, mx) {
        if (mn > IN1)
            return mn;
        if (mx < IN1)
            return mx;
        return IN1;

    };

    static GT(a, b) {
        return a > b ? 1 : 0;
    };
    static GE(a, b) {
        return a >= b ? 1 : 0;
    };
    static EQ(a, b) {
        return a = b ? 1 : 0;
    };
    static LE(a, b) {
        return a <= b ? 1 : 0;
    };
    static LT(a, b) {
        return a < b ? 1 : 0;
    };
    static NE(a, b) {
        return a != b ? 1 : 0;
    };

    static ADD_TIME_OF_DAY(a, b) {
        return a + b;
    };
    static ADD_TIME_OF_DAY_TIME(in1, in2) {
        return in1 + in2;
    }
    static ADD_DATE_AND_TIME_TIME(in1, in2) {
        return in1 + in2;
    }
    static SUB_TIME(in1, in2) {
        return in1 - in2;
    }
    static SUB_DATE_DATE(in1, in2) {
        return in1 - in2;
    }
    static SUB_TIME_OF_DAY_TIME(in1, in2) {
        return in1 - in2;
    }
    static SUB_TIME_OF_DAY_TIME_OF_DAY(in1, in2) {
        return in1 - in2;
    }
    static SUB_DATE_AND_TIME_TIME(in1, in2) {
        return in1 - in2;
    }
    static SUB_DATE_AND_TIME_DATE_AND_TIME(in1, in2) {
        return in1 - in2;
    }
    static MUL_TIME_ANY_NUM(in1, in2) {
        return in1 * in2;
    }
    static DIV_TIME_ANY_NUM(in1, in2) {
        return in1 / in2;
    }
    static CONCAT_PARAMS_ANY_STRING(str1, str2) {
        return str1 + str2;
    }
    static CONCAT_DATE_TIME_OF_DAY(in1, in2) {
        return in1 + in2;
    }
    /* 
                ADD_TIME_OF_DAY_TIME    = ADD,\n"
    "           ADD_DATE_AND_TIME_TIME  = ADD,\n"
    "           SUB_TIME            = SUB,\n"
    "           SUB_DATE_DATE           = SUB,\n"
    "           SUB_TIME_OF_DAY_TIME    = SUB,\n"
    "           SUB_TIME_OF_DAY_TIME_OF_DAY = SUB,\n"
    "           SUB_DATE_AND_TIME_TIME = SUB,\n"
    "           SUB_DATE_AND_TIME_DATE_AND_TIME = SUB,\n"
    "           MUL_TIME_ANY_NUM        = MUL,\n"
    "           DIV_TIME_ANY_NUM        = DIV,\n"
    "           CONCAT_PARAMS_ANY_STRING = CONCAT,\n"
    "           CONCAT_DATE_TIME_OF_DAY = ADD,\n"
    */
    static MUX(k, IN1, IN2) {
        if (k === 0) return IN1;
        if (k === 1) return IN2;
        return 0;
    };
    static MOVE(a) {
        return a;
    };
    static SEL(G, IN1, IN2) {
        return G ? IN2 : IN1;
    };

    static BYTE_BCD_TO_USINT(bcd) {
        var n = 0;
        var m = 1;
        for (var i = 0; i < bcd.length; i += 1) {
            n += (bcd[bcd.length - 1 - i] & 0x0F) * m;
            n += ((bcd[bcd.length - 1 - i] >> 4) & 0x0F) * m * 10;
            m *= 100;
        }
        return n;
    };

    /*"           BYTE_BCD_TO_USINT   = BYTE_BCD_TO_USINT,\n"
    "           WORD_BCD_TO_UINT    = WORD_BCD_TO_UINT,\n"
    "           DWORD_BCD_TO_UDINT  = DWORD_BCD_TO_UDINT,\n"
    "           LWORD_BCD_TO_ULINT  = LWORD_BCD_TO_ULINT,\n"
    "           USINT_TO_BCD_BYTE   = USINT_TO_BCD_BYTE,\n"
    "           UINT_TO_BCD_WORD    = UINT_TO_BCD_WORD,\n"
    "           UDINT_TO_BCD_DWORD  = UDINT_TO_BCD_DWORD,\n"
    "           ULINT_TO_BCD_LWORD  = ULINT_TO_BCD_LWORD,\n"
    "       
    */
    static REAL_TO_INT(d) {
        return Math.round(d);
    };

    static TIME_TO_REAL(a) {
        return a;
    }

    static REAL_TO_TIME(t) {
        return new Date().setMilliseconds(t);
    }

    static TIME_TO_TOD(t) {
        return new Date(t);
    }

    static TOD_TO_TIME(t) {
        return t.getMilliseconds();
    }

    static TIME_TO_DT(t) {
        return new Date(t).getTime();
    }

    static TIME() {
        return Date.now();
    }
    static GET_TIME(d) {
        return d.getTime();
    }

    /*
    "         
    "           DT_TO_DATE          = FILETIME.DT_TO_DATE,\n"
    "           DT_TO_TOD           = FILETIME.DT_TO_TOD,\n"
    "           TIME_TO_TOD         = FILETIME.TIME_TO_TOD,\n"
    "           TOD_TO_TIME         = function(time) return time end,\n"
    "           TIME                = FILETIME.GetSysTimeMs,\n"
    "           GET_TIME            = FILETIME.GetTime,\n"
    "           GET_UTC_TIME        = FILETIME.GetTime,\n"
    "           GET_LOCAL_TIME      = FILETIME.GetLocalTime,\n"
    
    "           DATE_TO_DWORD       = FILETIME.DATE_TO_DWORD,\n"
    "           DT_TO_DWORD         = FILETIME.DT_TO_DWORD,\n"
    "           DATE_TO_UDINT       = FILETIME.DATE_TO_DWORD,\n"
    "           DT_TO_UDINT         = FILETIME.DT_TO_DWORD,\n"
    "           DWORD_TO_DATE       = FILETIME.DWORD_TO_DATE,\n"
    "           DWORD_TO_DT         = FILETIME.DWORD_TO_DT,\n"
    "           UDINT_TO_DATE       = FILETIME.DWORD_TO_DATE,\n"
    "           UDINT_TO_DT         = FILETIME.DWORD_TO_DT,\n"
    "           
    
    
    */
    static TRUNC(x) {
        return x < 0 ? Math.ceil(x) : Math.floor(x);
    };
    static SQRT(a) {
        return Math.sqrt(a);
    };
    static LN(a) {
        if (a === 0) {
            this.StandartFunctionsErrors.LOG_0();
        }
        return Math.log(a);
    };
    static LOG(a) {
        return Math.log(a) / Math.LN10;
    };
    static EXP(a) {
        return Math.exp(a);
    };
    static SIN(x) {
        return Math.sin(x);
    };
    static COS(x) {
        return Math.cos(x);
    };
    static TAN(x) {
        return Math.tan(x);
    };
    static ASIN(x) {
        return Math.asin(x);
    };
    static ACOS(x) {
        return Math.acos(x);
    };
    static ATAN(x) {
        return Math.atan(x);
    };
    static EXPT(x, y) {
        return Math.pow(x, y);
    };

    static LEN(str) {
        return str.length;
    };
    //Функция возвращает L первых символов строки 
    static LEFT(str, l) {
        return str.substr(0, l);
    };
    //Функция возвращает L последних символов строки
    static RIGHT(str, l) {
        return str.slice(-l);
    };
    //Функция возвращает L символов из строки str, начиная  с P-го символа: 
    static MID(str, p, l) {
        return str.substr(p, l);
    };
    static INSERT(str1, str2, p) {
        var strTmp1 = this.LEFT(str1, p);
        var strTmp2 = str1.substring(p);
        return strTmp1 + str2 + strTmp2;
    };

    static DELETE(str, p, l) {
        var strTmp1 = this.LEFT(str, p);
        var strTmp2 = str.substring(p + l);
        return strTmp1 + strTmp2;
    };
    static REPLACE(str1, str2, l, p) {
        return this.INSERT(this.DELETE(str1, p, l - p), str2, p);
    };
    static FIND(s, w) {
        return s.indexOf(w);
    };
    static TO_BOOL(w) {
        return w === 0 ? false : true;

    };
    static BOOL_TO_BYTE(b) {
        return ~~b;
    };
    static TO_STRING(str) {
        return str.toString();
    }

    static GetBit(num, pos) {
        return ((num >> pos) & 0x1);
    }

    static SetBit(num, pos) {
        return ((0x1 << pos) | num);
    }

    static TO_BYTE(b) {
        var round = Round(b);
        return round & 0xFF;
    };

    static TO_WORD(b) {
        var round = Round(b);
        return round & 0xFFFF;
    };

    static TO_SINT(b) {
        var round = Round(b);
        return round & 0xFF;
    };

    static TO_INT(b) {
        var round = Round(b);
        return round & 0xFFFF;
    };

    static TO_LINT(b) {
        var round = Round(b);
        return round;
    };

    static TO_DINT(b) {
        var round = Round(b);
        return round & 0xFFFFFFFF;
    };

    static TO_DWORD(b) {
        var round = Round(b);
        return (round & 0xFFFFFFFF) >>> 0;
    };

    static TO_LWORD(b) {
        var round = Round(b);
        return round;
    };

    static TO_REAL(b) {
        return Number(b);
    };

    static TO_LREAL(b) {
        return Number(b);
    };

    /*
     
    "           
    "           TO_BYTE             =   StandardFunctionsC.TO_BYTE,"
    "           TO_WORD             =   StandardFunctionsC.TO_WORD,"
    "           TO_DWORD            =   StandardFunctionsC.TO_DWORD,"
    
    "           TO_STRING           = tostring,\n"
    
    "           GetBit              = StandardFunctionsC.GetBit,"
    "           SetBit              = StandardFunctionsC.SetBit,"
    
    "           
    "           CopyTable           = CopyTable\n"
    */
    static ADJUST_TO_TYPE(a, b) {
        return a;
    };

    static ADJUST_TO_TYPE_REAL(a, b) {
        return a;
    };

    static CopyTable(out) {
        out = out || {};

        for (var i = 1; i < arguments.length; i++) {
            var obj = arguments[i];

            if (!obj)
                continue;

            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    if (typeof obj[key] === 'object')
                        deepExtend(out[key], obj[key]);
                    else
                        out[key] = obj[key];
                }
            }
        }

        return out;
    };

    static LOWER_BOUND(a, b) {
        return 1;
    };

    static UPPER_BOUND(a, b) {
        if (b <= 1)
            return a.length;
        else {
            for (var i = 1; i < b; i++)
                a = a[0];
            return a.length;
        }
    };

    Round(b) {
        if (b === true) return 1;
        if (b === false) return 0;
        return Number((b).toFixed());
    }

}