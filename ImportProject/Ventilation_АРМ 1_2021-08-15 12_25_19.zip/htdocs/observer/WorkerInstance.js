async function fetchData(obj){
    var controller = new AbortController();
    setTimeout(()=>{
        controller.abort();
    }, 3000)
    if (typeof obj.body == 'object') {
        obj.body = JSON.stringify(obj.body);
    }
    return await fetch(obj.url, {
        method: obj.method || "POST", // *GET, POST, PUT, DELETE, etc.
        mode: "cors", // no-cors, cors, *same-origin
        cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
        credentials: "same-origin", // include, *same-origin, omit
        headers: obj.headers,
        redirect: "follow", // manual, *follow, error
        referrer: "no-referrer", // no-referrer, *client
        body: obj.body, // body data type must match "Content-Type" header
        signal: controller.signal,
    })
    .catch(err => {        
        if(err.name == 'AbortError'){
            return undefined;
        }
        else{
            console.log(err)
        }
    });
}

async function asyncRequest(obj) {
    return await fetchData(obj).then(response => {
        if (response) {            
            return response.json();
        } else {
            return response;
        }
    });
}

ackSequenceNumber = 0;
subscriptionId = 0;
timers = {};
isReady = true;
msgStore = [];
onmessage = function (e) {
    const data = e.data;
    switch (data.methodType) {
        case "single":
            sendSingleRequest(data)
            break
        case "intervalStart":
            subscriptionId = data.subscriptionId;
            createInterval(publishInterval, data)
            break
        case "intervalStop":
            clearInterval(timers[data.method])
            ackSequenceNumber = 0;
            break
        case "intervalRequest":
            createInterval(repeatRequest, data)
            break
        case "continue":
            isReady = true
            break
    }
}

function post(request, answer) {
    let pack = {
        methodType: request.methodType,
        method: request.method,
        id: request.id,
        data: answer,
    }
    postMessage(pack);
    pack = null;
}

async function sendSingleRequest(data) {
    post(data, await asyncRequest(data.headers));
}

function createInterval(intervalMethod, data) {
    let intervalHandler = data.method
    let resp = data.method == "PublishEvents" ? eventsRespondent : itemsRespondent
    timers[intervalHandler] = setInterval(intervalMethod, data.interval, data, resp);
}

async function repeatRequest(data) {
    let headers = data.headers;
    asyncRequest(headers).then(ans => {
        post(data, ans);
        ans = data = null;
    })
}
async function publishInterval(data, respond) {
    const pack = {
        ackSequenceNumber: ackSequenceNumber,
        subscriptionId: subscriptionId,
        sessionId: data.headers.body.sessionId,
    };
    let headers = {
        body: pack,
        url: data.headers.url,
    }

    asyncRequest(headers).then(answer => {
        if (answer && answer.code === 0) {
            if (answer.sequenceNumber > ackSequenceNumber || !ackSequenceNumber) {
                ackSequenceNumber = answer.sequenceNumber;
            } 
            if (answer.recs || answer.deleted) {
                respond(data, answer);
            } else if (data.updateTrend) {
                post(data, answer);
            }
        } else post(data, answer);
        data = answer = null;
    })
}

function eventsRespondent(request, answer) {
    if (isReady) {
        post(request, journalProcessor(answer))
        isReady = false
    } else {
        msgStore.push(answer)
    }
}

function journalProcessor(answer) {
    if (msgStore.length > 0) {
        let res = msgStore.reduceRight(journalReducer, answer)
        answer = {
            ...answer,
            ...res
        }
        msgStore = [];
    }
    return answer
}

function journalReducer(acc, curr) {
    return {
        recs: curr.recs ? acc.recs.concat(curr.recs) : recs = acc.recs,
        deleted: curr.deleted ? acc.deleted.concat(curr.deleted) : acc.deleted
    }
}

function itemsRespondent(request, answer) {
    post(request, itemProcessor(answer))
}

function itemProcessor(answer) {
    return answer;
}