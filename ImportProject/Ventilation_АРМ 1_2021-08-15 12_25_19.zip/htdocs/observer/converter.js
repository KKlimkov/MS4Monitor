"use strict";
/**
 * @class Converter
 * @classdesc Конвертер
 */
import { getFormattedValue, interpolate, CustomConvertError, getIntervalTime, toBool } from '../lib/utils.js';
import { DataTypes } from './../generated/datatypes.js';

export class Converter {
    /**
     * Приведение значений к согласию
     * @param {any} el элемент
     * @param {any} value значение
     * @param {string} sourceType тип источника
     * @param {string} sourceId ID источника
     * @return {any} результат конвертации
     */
    static convert(el, value, sourceType, sourceId) {
        let res;
        this._idConvert = {
            targetId: el.ItemId,
            sourceId: sourceId
        };
        const convert = el.Convertations;
        if (convert && Object.keys(convert).length > 0) {
            const format = convert.ValueFormat ? convert.ValueFormat.trim() : '';
            if (convert.Points) {
                convert.Points.sort((a, b) => Number(a.Source.value) - (b.Source.value));

                if (convert.InterpolateSource && convert.InterpolateTarget) {
                    this._updatePoints(convert);
                    const calcValue = this._interpolation.call(convert, value);
                    res = format ? getFormattedValue(format, calcValue, null, this._idConvert) : calcValue;

                } else if (!convert.InterpolateSource && !convert.InterpolateTarget) {
                    res = convert.DefaultValue.value;
                    const i = convert.Points.findIndex(el => el.Source.value.toString() === value.toString());
                    if (i >= 0) {
                        const calcValue = convert.Points[i].Target.value;
                        res = format ? getFormattedValue(format, calcValue, null, this._idConvert) : calcValue;
                    }

                } else if (convert.InterpolateSource && !convert.InterpolateTarget) {
                    res = convert.DefaultValue.value;
                    for (let i = 0; i < convert.Points.length; i++) {
                        const element1 = convert.Points[i];
                        const element2 = convert.Points[i + 1];
                        if (Number(element1.Source.value) <= Number(value) && (element2 === undefined || Number(element2.Source.value) > Number(value))) {
                            const calcValue = element1.Target.value;
                            res = format ? getFormattedValue(format, calcValue, null, this._idConvert) : calcValue;
                        }
                    }
                }
            } else if (typeof convert.Bit !== "undefined") {
                res = this._toBool(Number.parseInt(value) & (1 << convert.Bit));
            } else {
                res = format ?
                    getFormattedValue(format, value, null, this._idConvert) :
                    this._getDataTypesValue(value, sourceType, sourceId);
            }
        } else {
            if (el.el && el.el.localName === 'ms-text' && el.PropertyPath.toLowerCase() === 'text') {
                const isDateToString = (
                    window._enums.Types[sourceType] &&
                    window._enums.Types[sourceType].type === 'date' &&
                    el.DataType.toLowerCase() === 'string'
                );
                el.el.sourceDateObj = isDateToString ? { type: sourceType, value: value } : null;
            }
            res = Converter[sourceType]
                ? Converter[sourceType](value, el.DataType || sourceType)
                : this._getDataTypesValue(value, sourceType, sourceId, el);
        }
        if (res != null && typeof res === 'object' && res.type === 'customConvertError') {
            $ns.add(res.err);
            // res = res.result;
        }
        return res;
    }

    static _getDataTypesValue(value, sourceType, sourceId, el = {},) {
        const dataType = el.DataType, sourcepath = el.SourcePath;
        if (sourceType === dataType || typeof dataType === 'undefined') {
            return value;
        }
        let res = value;
        const dTStruct = DataTypes.dataTypes[sourceType];
        if (typeof dTStruct !== 'undefined' && dTStruct.DataType === "EnumeratedType" &&
            window._enums.Types[dataType] && window._enums.Types[dataType].type === 'string') {

            if (typeof dTStruct.Indexes !== 'undefined') {
                let index = dTStruct.Indexes.indexOf(+value);
                if (index !== -1) {
                    res = dTStruct.DisplayValues[index];
                    if (typeof res !== 'undefined')
                        return res;
                    else res = dTStruct.Values[index];
                    if (typeof res !== 'undefined')
                        return res;
                    else res = value
                }
            }

            return new CustomConvertError(res, this._getErrMessage(value, sourceType));
        } else if (typeof dTStruct !== 'undefined' && dTStruct.DataType === "StructureType"
            && dataType.toLowerCase() === 'string') {
            let tmpVal = value;
            if (sourcepath && typeof tmpVal === 'object') {
                const p = sourcepath.split('.');
                const tp = dTStruct.Fields[p[1]];
                if (tp) {
                    tmpVal = Converter.convert(el, value, tp, sourceId);
                }
            }
            try {
                res = JSON.stringify(tmpVal.value || tmpVal);
            } catch (err) {
                const message = `${this._getItemId()} ${err.message}`;
                $ns.add({ type: 'error', time: new Date().toLocaleString(), title: err.name, text: message });
                return {};
            }

        } else if (typeof dTStruct !== 'undefined' && dTStruct.DataType === "ArrayType" &&
            (dataType.toLowerCase() === 'string' || (dTStruct && dTStruct.DataType === 'StructureType'))) {

            try {
                res = JSON.stringify(value.value);
            } catch (err) {
                const message = `${this._getItemId()} ${err.message}`;
                $ns.add({ type: 'error', time: new Date().toLocaleString(), title: err.name, text: message });
                return [];
            }

        }
        return res;
    }

    static _getItemId() {
        return `${this._idConvert.sourceId ? `FROM id="${this._idConvert.sourceId}" ` : ``}${this._idConvert.targetId ? `TO id="${this._idConvert.targetId}":` : ``}<br>`;
    }

    static _getErrMessage(value, type) {
        return `${this._getItemId()} Значение "${value}" не может быть преобразовано в тип "${type}"`;
    }

    static _updatePoints(convert) {
        convert.sourcePoints = [];
        convert.targetPoints = [];
        for (let i = 0, l = convert.Points.length; i < l; i++) {
            const src = convert.Points[i].Source.value;
            const target = convert.Points[i].Target.value;
            convert.sourcePoints.push(src);
            convert.targetPoints.push(target);
        }
    }

    static _interpolation(variable) {
        if (typeof (variable) === "string")
            variable = Number(variable);
        if (variable < this.sourcePoints[0]) {
            return this.targetPoints[0];
        } else if (variable >= this.sourcePoints[this.sourcePoints.length - 1]) {
            return this.targetPoints[this.targetPoints.length - 1];
        }
        for (var i = 0, l = this.sourcePoints.length - 1; i < l; i++) {
            if (this.sourcePoints[i] <= variable && variable < this.sourcePoints[i + 1]) {
                return interpolate.call(this, variable, i);
            }
        }
        return this.DefaultValue.value;
    }

    // logical
    static BOOL(value, type) {
        type = window._enums.Types[type] ? window._enums.Types[type].type : null;
        let res;
        switch (type) {
            case 'string':
                res = this._toBool(value).toString();
                break;
            case 'number': case 'wordNumber': case 'date':
                res = value ? 1 : 0;
                break;
            case 'boolean':
                res = this._toBool(value);
                break;
            default:
                res = value;
        }
        return res;
    }

    // float
    static REAL(value, type) {
        return this._convert(value, type);
    }

    static LREAL(value, type) {
        return this._convert(value, type);
    }

    // signed integers
    static DINT(value, type) {
        return this._convert(value, type);
    }

    static INT(value, type) {
        return this._convert(value, type);
    }

    static LINT(value, type) {
        return this._convert(value, type);
    }

    static SINT(value, type) {
        return this._convert(value, type);
    }

    // unsigned integers
    static UDINT(value, type) {
        return this._convert(value, type);
    }

    static UINT(value, type) {
        return this._convert(value, type);
    }

    static ULINT(value, type) {
        return this._convert(value, type);
    }

    static USINT(value, type) {
        return this._convert(value, type);
    }

    // date-time
    static DATE(value, type) {
        return this._convert(value, type, window._enums.SourceTypes.date);
    }

    static DATE_AND_TIME(value, type) {
        return this._convert(value, type, window._enums.SourceTypes.dt);
    }

    static TIME(value, type) {
        return this._convert(value, type, window._enums.SourceTypes.time);
    }

    static TIME_OF_DAY(value, type) {
        return this._convert(value, type, window._enums.SourceTypes.tod);
    }

    // other
    static DWORD(value, type) {
        return this._convert(value, type, window._enums.SourceTypes.dword);
    }

    static LWORD(value, type) {
        return this._convert(value, type, window._enums.SourceTypes.lword);
    }

    static WORD(value, type) {
        return this._convert(value, type, window._enums.SourceTypes.word);
    }

    static BYTE(value, type) {
        return this._convert(value, type, window._enums.SourceTypes.byte);
    }

    static STRING(value, type) {
        return this._convert(value, type, window._enums.SourceTypes.string);
    }

    static _convert(value, type, sourceType = false) {
        if (typeof window._enums.Types[type] === 'undefined' && typeof DataTypes.dataTypes[type] === 'undefined') return;
        let res = value;
        if (typeof value === 'object' && value !== null && type.toLowerCase() === 'string' && value.value) {
            try {
                if (Array.isArray(value.value)) {
                    res = value.value.toString();
                } else {
                    res = JSON.stringify(value.value);
                }
                return res;
            } catch (err) {
                const message = `${this._getItemId()} ${err.message}`;
                $ns.add({ type: 'error', time: new Date().toLocaleString(), title: err.name, text: message });
                if (value.value instanceof Array) return [];
                return {};
            }
        }

        if (typeof value === 'object' && value !== null && typeof value.value === 'object' && value.value !== null
            && typeof value.value.Value !== 'undefined' && window._enums.Types[type]) {
            value = value.value.Value;
        }

        const descType = window._enums.Types[type] ? window._enums.Types[type].type : DataTypes.dataTypes[type];
        switch (descType) {
            case 'number': case 'wordNumber':
                res = this._getValueOfNumberType(value, type);
                break;
            case 'string':
                if (value === null) return value;
                if (!value) return value; // fix: разобраться с этим.
                res = sourceType && window._enums.Types[sourceType].type === 'date' ?
                    this._getValueOfDateType(value, sourceType) :
                    value.toString();
                break;
            case 'boolean':
                if (sourceType && window._enums.Types[sourceType].type === 'wordNumber') {
                    value = this._getLastSymbol(value);
                }
                res = this._toBool(value);
                break;
            case 'date':
                res = this._getTimestamp(value, type);
                break;
            default:
                const dTStruct = DataTypes.dataTypes[type];
                if (typeof dTStruct !== 'undefined' && dTStruct.DataType === "EnumeratedType") {
                    let val, ind;
                    if (typeof dTStruct.DisplayValues !== 'undefined') {
                        ind = dTStruct.DisplayValues.indexOf(value);
                        val = dTStruct.Indexes[ind];
                        if (typeof val !== 'undefined') return val;
                    }
                    if (typeof dTStruct.Values !== 'undefined') {
                        ind = dTStruct.Values.indexOf(value);
                        val = dTStruct.Indexes[ind];
                        if (typeof val !== 'undefined') return val;
                    }
                    let intVal = parseInt(value);
                    if (!isNaN(intVal))
                        return intVal;

                    return new CustomConvertError(value, this._getErrMessage(value, type));
                }
                if (dTStruct &&
                    (dTStruct.DataType === "StructureType" || dTStruct.DataType === "ArrayType") &&
                    sourceType && window._enums.Types[sourceType].type === 'string') {
                    try {
                        res = JSON.parse(value);
                    } catch (err) {
                        const message = `${this._getItemId()} ${err.message}`;
                        $ns.add({ type: 'error', time: new Date().toLocaleString(), title: err.name, text: message });
                        if (dTStruct.DataType === "StructureType") return {};
                        if (dTStruct.DataType === "ArrayType") return [];
                    }
                }
                break;
        }
        return res;
    }

    static _getLastSymbol(value) {
        const binValue = value.toString(2);
        return binValue[binValue.length - 1];
    };

    static _value2DATE(value) {
        return window._df.dateFormat(new Date(value), 'dd.MM.yyyy');
    }

    static _value2TOD(value) {
        return window._df.dateFormat(new Date(value), 'HH:mm:ss', true);
    }

    static _value2TIME(value) {
        return getIntervalTime(value);
    }

    static _value2DT(value) {
        return window._df.dateFormat(new Date(value), 'dd MM yyyy HH:mm:ss');
    }

    static _getTimestamp(value, type) {
        let numValue;
        const { min, max } = window._enums.Types[type].description;
        if (value instanceof Date) {
            numValue = value.getTime();
        } else {
            numValue = parseInt(Number(value));
            if (isNaN(numValue)) {
                const match = value.split(/[^\d]/);
                const dt = `${match[2]}-${match[1]}-${match[0]}T${match[3]}:${match[4]}:${match[5]}+03:00`
                numValue = new Date(dt).getTime();
                if (!numValue){
                    numValue = new Date(value).getTime();
                }
            }
        }
        if (isNaN(numValue)) {
            return new CustomConvertError(NaN, this._getErrMessage(value, type));
        }
        if (numValue > max) {
            numValue = max;
        }
        if (numValue < min) {
            numValue = min;
        }
        return numValue;
    }

    static _getValueOfDateType(value, type) {
        let res;
        const { descType } = window._enums.Types[type].description;
        const numValue = this._getTimestamp(value, type);
        switch (descType) {
            case 'date':
                res = this._value2DATE(numValue);
                break;
            case 'tod':
                res = this._value2TOD(numValue);
                break;
            case 'time':
                res = this._value2TIME(numValue);
                break;
            default: res = this._value2DT(numValue);
                break;
        }
        return res;
    }

    static _getValueOfNumberType(value, type) {
        let numValue = Number(value);
        if (isNaN(numValue) && typeof value === 'string') {
            numValue = this._toBool(value);
            numValue = Number(value);
        }
        if (isNaN(numValue)) {
            return new CustomConvertError(NaN, this._getErrMessage(value, type));
        }
        const { isInteger } = window._enums.Types[type].description;
        return isInteger ?
            this._getIntegerNumber(parseInt(numValue, 10), type) :
            this._getFloatNumber(numValue, type);
    }

    static _getIntegerNumber(value, type) {
        let res;
        const { min, max } = window._enums.Types[type].description;

        if (min === 0) {
            if (Math.abs(value) > max) {
                let { maxNumber } = window._enums.Types[type].description;
                value = value % maxNumber;
                if (value < 0) {
                    value = maxNumber - Math.abs(value);
                }
            } else if (value < 0) {
                const maxSourceNumber = this._getMaxSourceNumber(value);
                value = maxSourceNumber - Math.abs(value);
            }
            res = value;
        } else {
            let { maxNumber } = window._enums.Types[type].description;
            value = value % maxNumber;
            if (value > max) {
                res = value - maxNumber;
            } else if (value < min) {
                res = maxNumber - Math.abs(value);
            } else {
                res = value;
            }
        }
        return res;
    }

    static _getMaxSourceNumber(value) {
        let exp;
        const DEGREE = {
            BYTE: 8,
            WORD: 16,
            DWORD: 32,
            LWORD: 64
        };
        const binValue = Math.abs(value).toString(2);
        const expValue = binValue.length;
        if (expValue <= DEGREE.BYTE) {
            exp = DEGREE.BYTE;
        } else if (expValue > DEGREE.BYTE && expValue <= DEGREE.WORD) {
            exp = DEGREE.WORD;
        } else if (expValue > DEGREE.WORD && expValue <= DEGREE.DWORD) {
            exp = DEGREE.DWORD;
        } else if (expValue > DEGREE.DWORD) {
            exp = DEGREE.LWORD;
        }
        return Math.pow(2, exp);
    }

    static _getFloatNumber(value, type) {
        let res;
        const { min, max, minPrecision, maxPrecision } = window._enums.Types[type].description;
        if (value > max) {
            res = max;
        } else if (value < min) {
            res = min;
        } else {
            res = value;
            // if (value % 1 !== 0 && (value > -1 && value < 1)) {
            //     if (value > maxPrecision) {
            //         res = maxPrecision;
            //     }
            //     if (value < minPrecision) {
            //         res = minPrecision;
            //     }
            // } else {
            //     res = value;
            // }
        }
        return res;
    };

    /**
     * Конвертировать string в bool
     * @param {string} value значение для конвертирования
     * @return {bool} конвертированное значение
     */
    static _toBool(value) {
        if (value) {
            if (typeof value === 'boolean') {
                return value;
            } else {
                if (value.toLowerCase) {
                    value = value.toLowerCase().trim();
                }
                switch (value) {
                    case "true": case "yes": case "1": return true;
                    case "false": case "no": case "0": case null: return false;
                    default: return Boolean(value);
                }
            }
        } else {
            return false;
        }
    }
}