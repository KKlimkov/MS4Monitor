import { ActionFactory } from './../actions/ActionFactory.js';
import { Links } from './../generated/links.js';
import { Type } from './../generated/actions.js';
import { Converter } from './converter.js';
import { TaskManager } from './../screentask/TaskManager.js';
import { DataTypes } from './../generated/datatypes.js';
import { Constants as C, methods as M } from "./methods.js";
/**
 * @class ItemSubscription
 * @classdesc Обработчик связей в проекте
 */
export class ItemSubscription {
    constructor(serverAdapterInstance) {
        this.SubPack = {
            "subscriptionId": 2,
            "items": []
        };
        this.ackSequenceNumber = 0;
        this.sendTimestamp = 0;
        this.Links = new Links();
        this.WinDefs = window._windefs;
        this.Type = new Type();
        this.Obsetrver = {};
        this.observerIndex = 1;
        this.ServerParam = {};
        this.ItemsContainer = new Map();
        this.location = window._globalParams.location;
        this.ServerAdapter = serverAdapterInstance;
        this.ServerAdapter.reSubscribe = this.reSubscribe.bind(this);
    }

    async AddWindows(wins) {
        let allItems = [];
        for (let i = 0; i < wins.length; i++) {
            const WinItem = wins[i];
            const msWin = WinItem.window;
            const Id = msWin.id, TypeId = msWin.typeid;
            let Items = [];
            const Links = this.Links.windows[Id];
            let subLinks;
            if (Id != TypeId) {
                subLinks = this.Links.windows[TypeId];
            }

            if (!Links && !subLinks) {
                if ($pm.hasPermissions && window.__rootWin != msWin) {
                    $pm.controlEnable(msWin.childNodes);
                }
                if (WinItem.window.afterInitialize) WinItem.window.afterInitialize();
                continue;
            }

            this.SubPack.subscriptionId = this.ServerAdapter.subscriptionId;
            if (subLinks && subLinks.length > 0) {
                var Items2 = this._LinkCreator(subLinks, msWin);
            }
            const Items1 = this._LinkCreator(Links, msWin);

            if (Items1 && Items1.length > 0) {
                Items = Items.concat(Items1);
            }
            if (Items2 && Items2.length > 0) {
                Items = Items.concat(Items2);
            }

            if (Items.length > 0) {
                allItems = allItems.concat(Items);
            }
            if ($pm.hasPermissions && window.__rootWin != msWin) {
                $pm.controlEnable(msWin.childNodes);
            }
            if (WinItem.window.afterInitialize) WinItem.window.afterInitialize();
        }
        if (this.SubPack.subscriptionId) {
            if (allItems.length > 0) {
                this.CreateMonitoredDataItems(allItems).then(() => this.StartWatch());
            } else {
                this.StartWatch();
            }
        }

    }
    CreateTaskManager() {
        if (!this.TaskManager) {
            this.TaskManager = new TaskManager();
            window.$TaskManager = this.TaskManager;
            if (this.TaskManager.hasTasks) {
                this.TaskManager.start();
            }
        }
    }
    RemoveWindow(WinItem) {
        const msWin = WinItem.window;
        const Id = msWin.id, TypeId = msWin.typeid;
        const Links = this.Links.windows[Id];

        const subLinks = Id != TypeId ? this.Links.windows[TypeId] : null;

        if (!Links && !subLinks) { return; }
        this._LinkDestructor(Links, msWin);
        if (subLinks && subLinks.length > 0) {
            this._LinkDestructor(subLinks, msWin);
        }

        delete msWin.windowTriggers;
        delete msWin.eventListener;
    }

    async AddWindow(WinItem) {
        const msWin = WinItem.window;
        if ($pm.hasPermissions) {
            $pm.controlEnable(msWin.childNodes);
        }

        const Id = msWin.id, TypeId = msWin.typeid;
        const Links = this.Links.windows[Id];
        if (Id != TypeId) {
            var subLinks = this.Links.windows[TypeId];
        }
        if (!Links && !subLinks) { return; }

        this.SubPack.subscriptionId = this.ServerAdapter.subscriptionId;

        if (subLinks && subLinks.length > 0) {
            var Items2 = this._LinkCreator(subLinks, msWin);
        }
        const Items1 = this._LinkCreator(Links, msWin);

        let Items;
        if (Items2 && Items2.length > 0) {
            Items = Items1.concat(Items2);
        } else {
            Items = Items1;
        }
        this.CreateMonitoredDataItems(Items);
        if (msWin.afterInitialize) msWin.afterInitialize();
    }

    RunScreenTask() {
        this.CreateTaskManager();
        if (this.Links.windows[0]) {
            this.SubPack.subscriptionId = this.ServerAdapter.subscriptionId;
            const ScreenTaskItems = this._LinkCreator(this.Links.windows[0], window.__rootWin);
            this.CreateMonitoredDataItems(ScreenTaskItems);
        }
    }

    async DeleteMonitoredDataItems(items) {
        const SubPack = {
            items: Array.isArray(items) ? items : [items],
            subscriptionId: this.ServerAdapter.subscriptionId,
        };

        let options = {
            methodType: C.single,
            method: M.DeleteMonitoredDataItems,
            pack: SubPack
        };
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => resolve(data));
        });
    }

    async CreateMonitoredDataItems(items, subsId) {
        if (items.length > 0) {
            this.SubPack.items = items;
            this.SubPack.subscriptionId = subsId || this.SubPack.subscriptionId;
            let options = {
                pack: this.SubPack,
                method: M.CreateMonitoredDataItems,
                methodType: C.single,
            }
            items.forEach(item =>
                this.ItemsContainer.set(item.clientHandle, item)
            )
            return await new Promise(resolve => {
                this.ServerAdapter.sendRequest(options, data => {
                    if (data.items) {
                        data.items.forEach(el => {
                            if (el.statusCode === 0 && this.Obsetrver[el.clientHandle]) {
                                this.Obsetrver[el.clientHandle].monitoredItemId = el.monitoredItemId;
                            }
                        });
                    }
                    resolve(data);
                });
            });
        }
    }

    async CreateDataSubscription() {
        const pack = {
            requestedPublishingInterval: 100,
            requestedLifetimeInterval: 120000,
            maxNotificationsPerPublish: 0,
            maxSize: 1000
        };
        let options = {
            method: M.CreateDataSubscription,
            methodType: C.single,
            pack
        }
        return await new Promise(resolve => {
            this.ServerAdapter.sendRequest(options, data => {
                this.ServerAdapter.subscriptionId = data.subscriptionId;
                resolve(data);
            });
        });
    }

    GetInstanceFields(action) {
        let objectid = action.ObjectId
            ? action.ObjectId
            : this._getParentParam(action.context, 'objectid');
        let taskid = (Number(action.TaskId) != -1 || typeof (action.TaskId) != 'undefined')
            ? action.TaskId
            : this._getParentParam(action.context, 'taskid');
        let outerpath = this._getOuterPath(action.context) + (action.OuterPath || '');

        return { objectid, taskid, outerpath };
    }

    isTyped(element) {
        let result = (typeof (element.typed) !== 'undefined' && !!element.typed)
            || (element.getAttribute && element.getAttribute('typed') === "true")
            || (element.nodeName === 'MS-SVG' && element.getAttribute('outerpath') !== null);

        return result;
    }

    _getParentParam(msWin, param, findUntyped) {
        let w = msWin;
        let retVal = null, retValUntyped = null;
        param = param || param.toLowerCase();
        while (w && w.getAttribute && (retVal == null || Number(retVal) === 0)) {
            if (this.isTyped(w)) {
                //while (w.parentNode && this.isTyped(w.parentNode)) {
                //    w = w.parentNode;
                //}
                retVal = w.getAttribute(param);
            } else if (findUntyped && (retValUntyped == null || Number(retValUntyped) === 0))
                retValUntyped = w.getAttribute(param);
            w = w.parentNode;
        }
        if (findUntyped && (retVal == null || Number(retVal) === 0))
            return Number(retValUntyped);
        else
            return Number(retVal);
    }

    _getOuterPath(msWin) {
        let w = msWin;
        let retVal = [];
        while (w && w.getAttribute) {
            if (this.isTyped(w)) {
                do {
                    let path = w.getAttribute("outerpath");
                    if (path !== null && typeof path !== "undefined") {
                        retVal.push(path);
                    }
                    w = w.parentNode;
                } while (w && this.isTyped(w));
            }
            w = w.parentNode;
        }
        return retVal.reduceRight((acc, cur) => acc + cur, "")
    }

    _LinkDestructor(Links, msWin) {
        if (!Links) { return []; }
        for (let index = 0; index < Links.length; index++) {
            const el = Links[index];
            switch (el.Source.Type) {
                case 'server':
                    const sourceId = el.Source.ItemId == "0" ? this._getParentParam(msWin, "objectid") : Number(el.Source.ItemId);
                    const items = this.Links.Items[sourceId + '/' + el.Source.DataType] || this.Links.Items[sourceId + '/' + el.Source.DataType + '/' + el.Source.PropertyPath];
                    if (items) {
                        items.server.Targets.forEach(win => {
                            if (win.el == msWin) {
                                delete win.el;
                            } else if (win.el && !win.el.isConnected) {
                                win.el = null;
                                delete win.el;
                            } else {
                                for (let index = 0; index < msWin.childNodes.length; index++) {
                                    const element = msWin.childNodes[index];
                                    if (win.el == element) {
                                        delete win.el;
                                    }
                                }
                            }
                        });
                    }
                    break;
                default:
                    break;
            }
        }
    }
    /**
     * Создание связей при инициализации
     * @param {array} Links массив связей текущего окна 
     * @param {HTMLElement} msWin текущее окно
     * @return {array} параметры сервера, на которые нужно подписаться
     */
    _LinkCreator(Links, msWin) {
        if (!Links) { return []; }
        const upLinks = [];
        const Id = msWin ? msWin.typeid : null;
        const Items = [];
        for (let index = 0; index < Links.length; index++) {
            let el = JSON.parse(JSON.stringify(Links[index]));
            switch (el.Source.Type) {
                case 'server':
                    const sourceId = el.Source.ItemId = el.Source.ItemId == "0" ? this._getParentParam(msWin, "objectid") : Number(el.Source.ItemId);
                    const taskId = el.Source.TaskNumber = el.Source.TaskNumber == "-1" ? this._getParentParam(msWin, "taskid") : Number(el.Source.TaskNumber);
                    let basePropPath = el.Source.PropertyPath;
                    let propertyPath = el.Source.PropertyPath = this._getOuterPath(msWin) + basePropPath;

                    const items = this.Links.Items[sourceId + '/' + el.Source.DataType] || this.Links.Items[sourceId + '/' + el.Source.DataType + '/' + el.Source.PropertyPath];
                    if (items) {
                        if (msWin) {
                            el.Targets.forEach(element => {
                                const linkEl = msWin.id === element.ItemId ? msWin : msWin.querySelector(`[id='${element.ItemId}']`);
                                if (linkEl) {
                                    element.el = linkEl; // linkEl.msWin = msWin;                                    
                                }
                                else {
                                    if (element.ItemId == msWin.typeid) {
                                        element.el = msWin; // msWin.msWin = msWin;
                                    }
                                }
                            });
                        }
                        if (items.server.Source) {
                            el.Targets.forEach(target => {
                                if (items.server.Source.value !== undefined) {
                                    // установка значения по умолчанию
                                    // на линках внутри клиента
                                    if (target.Type === 'client' || target.Type === 'trend') {
                                        upLinks.push({
                                            type: el.Source.Type,
                                            target: target,
                                            value: items.server.Source.value,
                                            datatype: el.Source.DataType,
                                            sourceId: el.Source.ItemId
                                        });
                                    }
                                }
                                if (target.Type === 'action') {
                                    const control = this.SetAction(target, msWin);
                                    if (!control.actions[target.ActionId]) {
                                        if (msWin) {
                                            const act = JSON.parse(JSON.stringify(this.Type.type[target.ItemId].actions[target.ActionId]));
                                            control.actions[target.ActionId] = new ActionFactory(act, control);
                                        }
                                    }
                                    const sId = el.Source.PropertyPath ? sourceId + '/' + el.Source.DataType + '/' + el.Source.PropertyPath : sourceId + '/' + el.Source.DataType;
                                    let sValue;
                                    if (this.ServerParam[sId]) {
                                        sValue = this._convert(target, this.ServerParam[sId].value, "STRING", el.Source.ItemId);
                                    } else {
                                        sValue = this._convert(el.Source, el.Source.DefaultValue, el.Source.DataType, el.Source.ItemId);
                                    }
                                    this.UpdateAction(control, target, sValue);
                                }
                                if (target.Type === 'trigger') {
                                    const sId = el.Source.PropertyPath ? sourceId + '/' + el.Source.DataType + '/' + el.Source.PropertyPath : sourceId + '/' + el.Source.DataType;
                                    let sValue;
                                    if (this.ServerParam[sId]) {
                                        sValue = this.ServerParam[sId].value;
                                    } else {
                                        sValue = this._convert(el.Source, el.Source.DefaultValue, el.Source.DataType, el.Source.ItemId);
                                    }

                                    target.el = msWin;
                                    this.setTrigger(target, sValue, el.Source.DataType);
                                    // this.setTrigger(msWin, target, items.server.Source.value, el.Source.DataType);
                                }
                                if (target.Type === 'trend' && target.PropertyPath.indexOf('DataSource') !== -1) {
                                    if (!Array.isArray(items.server.Source.value)) {
                                        target.el.addDataSource({
                                            "taskId": el.Source.TaskNumber || 0,
                                            "itemId": Number(el.Source.ItemId),
                                            "path": el.Source.PropertyPath,
                                            "type": el.Source.DataType,
                                            "dataSourceId": "MPLCDataSource",
                                            'usesCounts': 1
                                        }, target.PropertyPath);
                                    } else {
                                        target.el.onStringPenChanged(target.PropertyPath, items.server.Source.value);
                                    }
                                }
                            });
                        }

                        const els = items.server.Targets.filter(t => typeof t.el !== "undefined"
                            || (t.Type !== "client" && t.Type !== "trigger"));

                        items.server.Targets = el.Targets.concat(els);

                    } else {
                        if (Id) {
                            el.Targets.forEach(element => {
                                let linkEl = msWin.id === element.ItemId ? msWin : msWin.querySelector(`[id='${element.ItemId}']`);
                                if (linkEl) {
                                    element.el = linkEl; // linkEl.msWin = msWin;
                                    if (element.el.nodeName == "MS-WINDOW" || element.el.nodeName == 'MS-SVG'
                                        && element.el.hasAttribute('outerpath')
                                        && linkEl != msWin) {
                                        el.Source.PropertyPath = this._getOuterPath(element.el) + basePropPath;
                                    }
                                } else {
                                    if (element.ItemId == msWin.typeid) {
                                        element.el = msWin; // msWin.msWin = msWin;
                                    }
                                }
                                if (element.Type === 'action') {
                                    const control = this.SetAction(element, msWin);
                                    if (!control.actions[element.ActionId]) {
                                        this.createAction(control, element.ActionId);
                                    }
                                    const sId = el.Source.PropertyPath ? sourceId + '/' + el.Source.DataType + '/' + el.Source.PropertyPath : sourceId + '/' + el.Source.DataType;
                                    let sValue;
                                    if (this.ServerParam[sId]) {
                                        sValue = this.ServerParam[sId].value;
                                    } else {
                                        sValue = this._convert(el.Source, el.Source.DefaultValue, el.Source.DataType, el.Source.ItemId);
                                    }
                                    this.UpdateAction(control, element, sValue);
                                }
                                if (element.Type === 'trigger') {
                                    el.Targets.forEach(target => {
                                        target.el = msWin;
                                        // this.setTrigger(msWin, target, el.Source.DefaultValue, el.Source.DataType);
                                    });
                                } else if (element.Type === 'trend' && element.PropertyPath.indexOf('DataSource') !== -1) {
                                    element.el.addDataSource({
                                        "taskId": taskId || 0,
                                        "itemId": sourceId,
                                        "path": el.Source.PropertyPath,
                                        "type": el.Source.DataType,
                                        "dataSourceId": "MPLCDataSource",
                                        'usesCounts': 1
                                    }, element.PropertyPath);
                                }
                            });
                        }

                        const linkKey = `${sourceId}/${el.Source.DataType}${el.Source.PropertyPath ? '/' + el.Source.PropertyPath : ''}`

                        if (this.Links.Items[linkKey]) {
                            let targets = this.Links.Items[linkKey].server.Targets;
                            this.Links.Items[linkKey].server.Targets = el.Targets.concat(targets)
                        } else {
                            this.Links.Items[linkKey] = { 'server': el };
                        }

                        this.Obsetrver[this.observerIndex] = el.Source;
                        // const index = this.Obsetrver.push(el.Source);

                        Items.push({
                            "taskId": taskId || 0,
                            "itemId": Number(sourceId),
                            "path": el.Source.PropertyPath,
                            "type": el.Source.DataType,
                            "dataSourceId": "MPLCDataSource",
                            "clientHandle": this.observerIndex,
                            'usesCounts': 1
                        });
                        this.observerIndex++;

                    }
                    break;
                case 'client':
                    // let key;
                    let sourceEl;
                    if (Id) {
                        if (msWin.typeid == el.Source.ItemId) {
                            // key = msWin.id;
                            el.Source.el = msWin;
                            if (
                                typeof el.Source.el[el.Source.PropertyPath.toLowerCase()] === 'undefined' &&
                                el.Source.el.getAttribute(el.Source.PropertyPath.toLowerCase()) === null &&
                                el.Source.PropertyPath.indexOf('.') < 0
                            ) {
                                const v = Converter._convert(el.Source.DefaultValue, el.Source.DataType);
                                el.Source.el[el.Source.PropertyPath.toLowerCase()] = v;
                            }
                            sourceEl = msWin;
                        } else {
                            // key = msWin.id + '/' + el.Source.ItemId;
                            sourceEl = msWin.id === el.Source.ItemId ? msWin : msWin.querySelector(`[id='${el.Source.ItemId}']`);
                            if (sourceEl) {
                                sourceEl.pId = msWin.id;
                                sourceEl.msWin = msWin;
                            } else break;
                        }

                        el.Targets.forEach(element => {
                            if (element.ItemId == "0") {
                                element.ItemId = this._getParentParam(msWin, "objectid");
                                if (element.TaskNumber == -1) {
                                    element.TaskNumber = this._getParentParam(msWin, "taskid");
                                    element.PropertyPath = this._getOuterPath(msWin) + element.PropertyPath;
                                }
                            }
                            if (msWin && element.ItemId == msWin.typeid) {
                                element.el = msWin;
                            } else {
                                const linkEl = msWin.id === element.ItemId ? msWin : msWin.querySelector(`[id='${element.ItemId}']`);
                                if (linkEl) {
                                    element.el = linkEl;
                                    if (element.Type === "trend" && element.PropertyPath.indexOf('DataSource') !== -1 && el.Source.DataType === "STRING") { //стринговое перо, клиентский параметр
                                        element.el.addDataSource({
                                            "taskId": el.Source.TaskNumber || 0,
                                            "itemId": el.Source.ItemId,
                                            "path": el.Source.PropertyPath,
                                            "type": el.Source.DataType,
                                            "dataSourceId": "MPLCDataSource",
                                            'usesCounts': 1
                                        }, element.PropertyPath);
                                    }
                                } else {
                                    if (element.ItemId == msWin.typeid) {
                                        element.el = msWin; // msWin.msWin = msWin;
                                    }
                                }
                            }
                        });
                    } else {
                        // key = el.Source.ItemId;
                        sourceEl = document.querySelector(`[id='${el.Source.ItemId}']`);
                        if (!sourceEl) {
                            console.log('stop!');
                        }
                    }

                    let PropertyPath = el.Source.PropertyPath.toLowerCase();
                    const pathpnt = PropertyPath.split('.');
                    if (pathpnt.length > 1) {
                        el.Targets.forEach(element => {
                            element.SourcePath = el.Source.PropertyPath;
                        });
                        PropertyPath = pathpnt[0];
                    }
                    if (el.Source.PropertyPath == "PanelDataSource") {
                        let realSourceDataType = el.Targets[0].DataType;
                        if (sourceEl && typeof sourceEl.setPdsType === 'function') {
                            sourceEl.setPdsType(realSourceDataType);
                        }
                    }
                    if (sourceEl.Links[PropertyPath]) {
                        if (sourceEl.Links[PropertyPath].Source.DataType !== el.Source.DataType) {
                            for (const iterator of el.Targets) {
                                iterator.SourceDataType = el.Source.DataType;
                            }
                        }
                        sourceEl.Links[PropertyPath].Targets = sourceEl.Links[PropertyPath].Targets.concat(
                            el.Targets
                        );
                    } else {
                        sourceEl.Links[PropertyPath] = el;
                    }
                    if (sourceEl && sourceEl.AddLinkCallback) {
                        sourceEl.AddLinkCallback(PropertyPath, this.LinkUp.bind(this));
                        let srcVal = sourceEl[PropertyPath] || sourceEl.getAttribute(PropertyPath);
                        if (pathpnt.length > 1) {
                            for (let i = 1; i < pathpnt.length; i++) {
                                if (srcVal === undefined) {
                                    $ns.add({ type: 'error', time: new Date().toLocaleString(), title: "Ошибка параметра", text: `Невозможно получить параметр ${el.Source.ItemId}/${el.Source.PropertyPath}` });
                                    break;
                                }
                                srcVal = srcVal[pathpnt[i]];
                            }
                        }
                        el.Targets.forEach(target => {
                            // установка значения по умолчанию
                            // на линках внутри клиента
                            if (target.Type === 'client' && typeof srcVal !== 'undefined' && srcVal !== null) {
                                upLinks.push({
                                    type: el.Source.Type,
                                    sourceP: el.Source.PropertyPath,
                                    target: target,
                                    value: srcVal,
                                    datatype: el.Source.DataType,
                                    sourceId: el.Source.ItemId
                                });
                            } else if (target.Type === 'svg' && typeof srcVal !== 'undefined') {
                                if (el.Source.ItemId == target.ItemId && target.el.setSvgParams) {
                                    target.el.setSvgParams(target.PropertyPath, srcVal);
                                } else {
                                    const pp = target.PropertyPath.split(':');
                                    if (pp.length > 1) {
                                        const pr = pp[0] === 'svg' ? [...pp, el.Source.PropertyPath].slice(1) : pp.slice(1);
                                        target.el[pp[0].toLowerCase()](pr, this._convert(target, srcVal, el.Source.DataType, el.Source.ItemId));
                                    }
                                }
                            } else if (target.Type === 'action' && typeof srcVal !== 'undefined' && srcVal !== null) {
                                if (!target.el.actions[target.ActionId]) {
                                    this.createAction(target.el, target.ActionId);
                                }
                                // target.el.actions[target.ActionId][target.PropertyPath] = srcVal;
                                this.UpdateAction(target.el, target, srcVal);
                            } else if (target.Type == 'trigger') {
                                target.el = msWin;
                            }
                        });
                        if (srcVal === undefined && typeof el.Source.DefaultValue !== 'undefined' && el.Targets[0].Type !== 'server') {
                            upLinks.push({
                                type: el.Source.Type,
                                sourceP: el.Source.PropertyPath,
                                target: el.Source,
                                value: el.Source.DefaultValue,
                                datatype: el.Source.DataType,
                                sourceId: el.Source.ItemId
                            });
                        }
                    }
                    break;
                case 'action':
                    const control = this.SetAction(el.Source, msWin);
                    el.Targets.forEach(element => {
                        if (element.ItemId == "0") {
                            element.ItemId = this._getParentParam(msWin, "objectid");
                            if (element.TaskNumber == -1) {
                                element.TaskNumber = this._getParentParam(msWin, "taskid");
                                element.PropertyPath = this._getOuterPath(msWin) + element.PropertyPath;
                            }
                        }
                        const linkEl = msWin.id === element.ItemId ? msWin : msWin.querySelector(`[id='${element.ItemId}']`);
                        if (linkEl) {
                            element.el = linkEl; // linkEl.msWin = msWin;
                        } else {
                            if (element.ItemId == msWin.typeid) {
                                element.el = msWin; // msWin.msWin = msWin;
                            }
                        }

                    });

                    if (control.actions[el.Source.ActionId].operation) {
                        el.Targets[0].Operation = control.actions[el.Source.ActionId].operation;
                    }
                    control.actions[el.Source.ActionId].AddLinkCallback(el.Source.PropertyPath, this.LinkUp.bind(this, control, el));

                    // control.msWin = msWin;
                    break;
                case 'screentask':
                    //fix: надо проверить и привести к новой модели

                    this.CreateTaskManager();
                    el.Targets.forEach(element => {
                        let linkEl = msWin.id === element.ItemId ? msWin : msWin.querySelector(`[id='${element.ItemId}']`);
                        if (linkEl) {
                            element.el = linkEl; // linkEl.msWin = msWin;
                        } else {
                            if (element.ItemId == msWin.typeid) {
                                element.el = msWin; // msWin.msWin = msWin;
                            }
                        }
                        if (element.Type == 'action') {
                            const control = this.SetAction(element, msWin);
                            if (!control.actions[element.ActionId]) {
                                this.createAction(control, element.ActionId);
                            }
                            const sValue = this.TaskManager.tasks.generatedTask.getValue(el.Source) || el.Source.DefaultValue;
                            this.UpdateAction(control, element, sValue);
                        } else if (element.Type === 'trigger') {
                            el.Targets.forEach(target => {
                                target.el = msWin;
                            });
                        } else {
                            const sValue = this.TaskManager.tasks.generatedTask.getValue(el.Source);
                            if (sValue !== undefined && element !== 'server') {
                                const c = this._convert(element, sValue, el.Source.DataType, element.ItemId);
                                upLinks.push({
                                    type: el.Source.Type,
                                    target: element,
                                    value: c,
                                    datatype: element.DataType,
                                    sourceId: element.ItemId
                                });
                            }
                        }
                    });

                    this.TaskManager.tasks.generatedTask.AddLinkCallback(el.Source.PropertyPath, this.LinkUp.bind(this, null, el));
                    break;
                case 'reference':
                    el.Targets.forEach(element => {
                        const linkEl = msWin.id === element.ItemId ? msWin : msWin.querySelector(`[id='${element.ItemId}']`);
                        linkEl[element.PropertyPath.toLowerCase()] = el.Source.DefaultValue;
                    });
                    break;
                case 'trend':
                    break;
                case 'object':
                case 'template':
                    if (Id) {
                        el.Targets.forEach(element => {
                            if (element.ItemId == "0") {
                                element.ItemId = this._getParentParam(msWin, "objectid");
                                if (element.TaskNumber == -1) {
                                    element.TaskNumber = this._getParentParam(msWin, "taskid");
                                    element.PropertyPath = this._getOuterPath(msWin) + element.PropertyPath;
                                }
                            }

                            if (msWin && element.ItemId == msWin.typeid) {
                                element.el = msWin;
                            } else {
                                const linkEl = msWin.id === element.ItemId ? msWin : msWin.querySelector(`[id='${element.ItemId}']`);
                                if (linkEl) {
                                    element.el = linkEl; // linkEl.msWin = msWin;
                                } else {
                                    if (element.ItemId == msWin.typeid) {
                                        element.el = msWin; // msWin.msWin = msWin;
                                    }
                                }
                            }
                            if (element.el) {
                                if (element.el[element.PropertyPath.toLowerCase()] !== el.Source.DefaultValue) {
                                    element.el[element.PropertyPath.toLowerCase()] = el.Source.DefaultValue;
                                }
                            }
                        });
                    }
                    break;
                default:
                    console.log(`Неизвестный тип связи: ${el.Source.Type}`);
                    break;
            }
        }
        const valCache = {};
        const sortUpLinks = upLinks.sort((a, b) => {
            if (a.type === 'server' && a.type > b.type) {
                return -1;
            } else {
                return 1;
            }
        });
        sortUpLinks.forEach(el => {
            if (el.target.Type === "trend") {
                if (el.target.PropertyPath.indexOf("DataSource") > -1)
                    el.target.el.onStringPenChanged(el.target.PropertyPath, el.value);
                else
                    el.target.el.changePenAttribute(el.target.PropertyPath, this._convert(el.target.el, el.value, el.target.DataType, el.target.ItemId));
            } else {
                if (!el.sourceP || el.sourceP.indexOf("PanelDataSource") === -1) {
                    let val = null;
                    if (typeof valCache[`${el.sourceId}/${el.sourceP}`] !== 'undefined') {
                        val = valCache[`${el.sourceId}/${el.sourceP}`];
                    } else if (el.type === 'client') {
                        const srcEl = msWin.id == el.sourceId ? msWin : msWin.querySelector(`[id='${el.sourceId}']`);
                        if (srcEl) {
                            const sp = el.sourceP.split('.');
                            val = srcEl;
                            for (let i = 0; i < sp.length && val != null; i++) {
                                val = typeof val[sp[i]] === 'undefined' ? val[sp[i].toLowerCase()] : val[sp[i]];
                            }
                        }
                        if (val == null)
                            val = el.value;
                    } else {
                        val = el.value;
                    }
                    this._operation(el.target, val, el.datatype, null, el.sourceId);
                    valCache[`${el.target.ItemId}/${el.target.PropertyPath}`] = val;
                }
            }
        });
        return Items;
    }

    SetAction(el, msWin) {
        const types = this.Type.type;
        let control = msWin.id === el.ItemId ? msWin : msWin.querySelector(`[id='${el.ItemId}']`);
        if (control == null && msWin.typeid === el.ItemId) { control = msWin; }
        if (!control.actions[el.ActionId]) {
            let cTypes = this.getActionTypes(types, msWin.id, el.ActionId)
                || this.getActionTypes(types, msWin.typeid, el.ActionId);
            if (cTypes) {
                cTypes = JSON.parse(JSON.stringify(cTypes));
                control.actions[el.ActionId] = new ActionFactory(cTypes.actions[el.ActionId], control);
            }
        }
        return control;
    }

    getActionTypes(types, id, actionId) {
        if (typeof types[id] !== 'undefined'
            && typeof types[id].actions !== 'undefined'
            && typeof types[id].actions[actionId] !== 'undefined') {
            return types[id];
        }
        else return false;
    }

    UpdateAction(control, element, sValue) {
        let elActions = control.actions[element.ActionId];
        if (typeof elActions !== 'undefined') {
            if (typeof elActions[element.PropertyPath] !== 'undefined') {
                if (typeof elActions[element.PropertyPath].value !== 'undefined') {
                    elActions[element.PropertyPath].value = sValue;
                } else {
                    elActions[element.PropertyPath] = sValue;
                }
            } else if (elActions.parameters) {
                if (typeof elActions.parameters[element.PropertyPath] !== 'undefined') {
                    elActions.parameters[element.PropertyPath] = sValue;
                    elActions.UpdateParameters(element.PropertyPath, sValue);
                }
            }
        }        
    }

    StartWatch() {
        let options = {
            methodType: C.intervalStart,
            method: M.PublishData,
            interval: _globalParams.UpdateInterval
        };
        this.ServerAdapter.sendRequest(options,
            data => {
                if (data.recs) {
                    data.recs.forEach(rec => {
                        this.LinkUp(rec);
                    });
                }
            });
    }

    StopWatch() {
        let options = {
            methodType: C.intervalStop,
            method: M.PublishData
        };
        this.ServerAdapter.sendRequest(options);
    }

    async reSubscribe() {
        const item = {
            type: 'error',
            time: new Date().toLocaleString(),
            title: 'Передан недействительный код подписки',
            text: '2150105088'
        };
        $ns.add(item);
        this.StopWatch();
        return await this.CreateDataSubscription()
            .then(response => this.CreateMonitoredDataItems([...this.ItemsContainer.values()], response.subscriptionId))
            .then(() => this.onRestore());
    }

    onRestore() {
        this.StartWatch();
        const item = {
            type: 'info',
            time: new Date().toLocaleString(),
            title: 'Подписка восстановлена',
            text: '2150105088 resolved'
        };
        $ns.add(item);
    }

    _WriteData(pack) {
        let options = {
            pack,
            method: M.WriteData,
            methodType: C.single
        }
        this.ServerAdapter.sendRequest(options);
    }
    /**
     * Связывание параметров
     * @param {HTMLElement} element контекст
     * @param {any} linkUp коллбек
     * @param {any} value значение
     * @param {any} attrName название атрибута
     * @param {any} itemIndex номер
     * @param {string} operation операция
     * @param {bool} forced вынужденно
     */
    LinkUp(element, linkUp, value, attrName, itemIndex, operation, forced) {
        let triggers = [];
        let links = null;
        let sId;
        if (linkUp) {
            links = { value: linkUp };
        } else if (typeof value !== 'undefined') {
            links = this.Links.Items[element];
        } else {
            if (!this.Obsetrver[element.clientHandle]) return;
            const item = this.Obsetrver[element.clientHandle];
            if (item.value && item.Type !== "server" && item.value == element.value) return;
            item.value = element.value;
            sId = item.PropertyPath ? item.ItemId + '/' + item.DataType + '/' + item.PropertyPath : item.ItemId + '/' + item.DataType;
            links = this.Links.Items[sId];
            if (!this.ServerParam[sId]) {
                this.ServerParam[sId] = item;
            } else {
                this.ServerParam[sId].value = item.value;
            }
            value = element.value;
        }
        if (links) {
            const res = [];
            for (let key in links) {
                let forRemove = false;
                for (let index = 0; index < links[key].Targets.length; index++) {
                    const el = links[key].Targets[index];
                    const stackKey = `${links[key].Source.ItemId}/${links[key].Targets[index].ItemId}`;
                    if (window.stack.has(stackKey)) {
                        window.stack.get(stackKey).c++;
                    } else {
                        window.stack.set(stackKey, {
                            s: links[key].Source.ItemId,
                            t: links[key].Targets[index].ItemId,
                            c: 1
                        });
                    }
                    if (operation) {
                        for (var prop in operation) {
                            el[prop] = operation[prop];
                        }
                    }
                    if (((el.el && !el.el.isConnected) || el.el === null) && el.els === undefined) {
                        delete links[key].Targets[index].el;
                        delete links[key].Targets[index];
                        forRemove = true;
                        continue;
                    }
                    const propptr = links[key].Source.PropertyPath.split('.');
                    if (attrName && attrName != links[key].Source.PropertyPath.toLowerCase() && propptr.length === 1) { break; }
                    switch (el.Type) {
                        case 'screentask':
                            this.CreateTaskManager();
                            this.TaskManager.tasks.generatedTask.postMessage(el, this._convert(el, value, links[key].Source.DataType, links[key].Source.ItemId));
                            break;
                        case 'svg':
                        case 'client': {
                            const target = this.GetComponent(el, itemIndex, false);
                            if (!target) continue;
                            const propertyPath = el.PropertyPath.split(':');
                            itemIndex = typeof itemIndex === 'undefined' ? el.ItemIndex : itemIndex;
                            let srcVal = value;
                            if (el.SourcePath) {
                                const sp = el.SourcePath.split('.');
                                if (sp.length > 1) {
                                    for (let i = 1; i < sp.length; i++) {
                                        if (srcVal[itemIndex]) {
                                            srcVal = typeof srcVal[itemIndex][sp[i]] === 'undefined' ? srcVal[itemIndex][sp[i].toLowerCase()] : srcVal[itemIndex][sp[i]];
                                        } else {
                                            srcVal = typeof srcVal[sp[i]] === 'undefined' ? srcVal[sp[i].toLowerCase()] : srcVal[sp[i]];
                                        }
                                    }
                                }
                                if (srcVal === undefined) break;
                            }
                            const DataType = el.SourceDataType != undefined ? el.SourceDataType : links[key].Source.DataType;

                            if (target && target.addDataSource) {
                                if (el.PropertyPath.indexOf('DataSource') !== -1) {
                                    target.addDataSource({
                                        "taskId": el.TaskNumber || 0,
                                        "itemId": 0,
                                        "path": value,
                                        "type": el.DataType,
                                        "dataSourceId": "MPLCDataSource",
                                        'usesCounts': 1
                                    }, el.PropertyPath);
                                    target.onStringPenChanged(el.PropertyPath, value);
                                } else {
                                    if (el.PropertyPath.indexOf('.') != -1) {
                                        target.changePenAttribute(el.PropertyPath, this._convert(el, value, DataType, links[key].Source.ItemId));
                                    }
                                }
                            }
                            if (propertyPath.length > 1) {
                                if (links[key].Source.ItemId == target.id && target.setSvgParams) {
                                    target.setSvgParams(el.PropertyPath, srcVal);
                                } else {
                                    const pr = propertyPath[0] === 'svg' ? [...propertyPath, links[key].Source.PropertyPath].slice(1) : propertyPath.slice(1);
                                    // const pr = propertyPath.slice(1);
                                    target[propertyPath[0].toLowerCase()](pr, this._convert(el, srcVal, DataType, links[key].Source.ItemId));
                                }
                            } else if (propptr.length > 1 && (value && value.value && value.value[propptr[1]])) {
                                const pth = el.SourcePath.split('.')[1];
                                const result = this._operation(el, value.value[pth], DataType, itemIndex, links[key].Source.ItemId, attrName);
                                if (result == -1) {
                                    delete links[key].Targets[index];
                                    forRemove = true;
                                }
                            } else {
                                const result = this._operation(el, srcVal, DataType, itemIndex, links[key].Source.ItemId, attrName);
                                if (result == -1) {
                                    delete links[key].Targets[index];
                                    forRemove = true;
                                    // continue;
                                }
                            }
                            break;
                        }
                        case 'server': {
                            let servItem = el.ItemId;
                            servItem = el.PropertyPath ? el.ItemId + '/' + el.DataType + '/' + el.PropertyPath : el.ItemId + '/' + el.DataType;
                            if (el.HasBackward && (typeof this.ServerParam[servItem] === 'undefined' || typeof this.ServerParam[servItem].value === 'undefined')) break;
                            // if (el.HasBackward && !el.Inited) { el.Inited = true; break; }
                            let refVal = value;
                            if (el.SourcePath && el.SourcePath.includes('.')) {
                                const path = el.SourcePath.split('.');
                                path.splice(0, 1);
                                while (path.length > 0) {
                                    refVal = refVal[path[0]];
                                    path.splice(0, 1);
                                }
                            }
                            const setValue = this._convert(el, refVal, links[key].Source.DataType, links[key].Source.ItemId);

                            if (setValue != null && typeof setValue === 'object' && setValue.type === 'customConvertError') break;
                            if (typeof this.ServerParam[servItem] === 'undefined') { this.ServerParam[servItem] = el; }
                            const comp = forced ? false
                                : this.CompareValue(this.ServerParam[servItem].DataType, this.ServerParam[servItem].value, setValue);
                            if (this.ServerParam[servItem] && comp && el.Operation === "move") { break; }
                            let packValue = setValue;
                            if (typeof setValue === 'object' && typeof setValue.value === 'object') {
                                packValue = setValue.value;
                            }
                            const pack = {
                                "taskId": el.TaskNumber || 0,
                                "dataSourceId": "MPLCDataSource",
                                "itemId": Number(el.ItemId),
                                "path": el.PropertyPath,
                                "operation": el.Operation,
                                "type": el.DataType,
                                "usesCounts": 1,
                                "value": packValue
                            };
                            this.ServerParam[servItem].value = this.CloneValue(this.ServerParam[servItem].DataType, setValue);
                            this.sendTimestamp++;
                            res.push(pack);
                            break;
                        }
                        case 'action': {
                            let control = this.GetComponent(el, itemIndex, false);
                            if (!control) break;
                            let _refVal = value;
                            if (el.SourcePath && el.SourcePath.includes('.')) {
                                const path = el.SourcePath.split('.');
                                path.splice(0, 1);
                                while (path.length > 0) {
                                    _refVal = _refVal[path[0]];
                                    path.splice(0, 1);
                                }
                            }
                            const sourceDateType = typeof _refVal === 'string' ? "STRING" : links[key].Source.DataType;
                            const sValue = this._convert(el, _refVal, sourceDateType, links[key].Source.ItemId);
                            if (!control.actions[el.ActionId]) {
                                this.createAction(control, el.ActionId);
                            }
                            this.UpdateAction(control, el, sValue);
                            break;
                        }
                        case 'trend': {
                            const target = this.GetComponent(el, itemIndex, false);
                            if (target) {
                                if (el.PropertyPath.indexOf("DataSource") === -1)
                                    target.changePenAttribute(el.PropertyPath, this._convert(el, value, links[key].Source.DataType, links[key].Source.ItemId));
                                else if ((links[key].Source.DataType === "STRING") || (linkUp && linkUp.Source.DataType === "STRING") || target.nodeName === "MS-CHART") { //только стринговое перо будет меняться отсюда
                                    target.onStringPenChanged(el.PropertyPath, value);
                                }
                            } else {
                                delete links[key].Targets[index];
                                forRemove = true;
                            }
                            break;
                        }
                        case 'trigger':
                            // this.setTrigger(el, value, links[key].Source.DataType);
                            triggers.push({
                                el: el,
                                value: value,
                                dt: links[key].Source.DataType
                            })
                            break;
                    }
                    if (window.stack.get(stackKey).c > 1) {
                        window.stack.get(stackKey).c--;
                    } else {
                        window.stack.delete(stackKey);
                    }
                }
                // удаление не действительных связей
                if (forRemove) {
                    let i = links[key].Targets.length;
                    while (i--) {
                        if (links[key].Targets[i] === undefined) {
                            links[key].Targets.splice(i, 1);
                        }
                    }
                    if (links[key].Targets.length === 0) {
                        if (element) {
                            this.DeleteMonitoredDataItems(this.Obsetrver[element.clientHandle].monitoredItemId).then(data => {
                                delete this.Obsetrver[element.clientHandle];
                                delete this.Links.Items[sId];
                                this.ItemsContainer.delete(element.clientHandle);
                            });
                        }
                        return false;
                    }
                }

            }
            if (triggers.length > 0) {
                for (let i = 0; i < triggers.length; i++) {
                    const el = triggers[i];
                    this.setTrigger(el.el, el.value, el.dt);
                }
                triggers = null;
            }
            if (res.length > 0) {
                this._WriteData({ recs: res });
            }
            return true;
        }
    }

    /**
     * Создать действие
     * @param {HTMLElement} control элемент-владелец действия
     * @param {number} ActionId ID действия
     */
    createAction(control, ActionId) {
        const types = this.Type.type;
        let msWin = control.msWin;
        if (!msWin) {
            msWin = control;
            while (msWin.nodeName !== 'MS-WINDOW') {
                msWin = msWin.parentElement;
            }
        }
        let act = types[msWin.id] && types[msWin.id].actions[ActionId] ? types[msWin.id].actions[ActionId] : types[msWin.typeid].actions[ActionId];
        act = JSON.parse(JSON.stringify(act));
        control.actions[ActionId] = new ActionFactory(act, control);
    }

    /**
     * Сравнение двух значений
     * @param {any} val1 первое значение
     * @param {any} val2 второе значение
     * @return {bool} результат сравнения
     */
    CompareValue(dataType, val1, val2) {
        let ret;
        switch (DataTypes.dataTypes[dataType].DataType) {
            case 'StructureType':
            case 'ArrayType':
                ret = JSON.stringify(val1) == JSON.stringify(val2);
                break;

            default:
                ret = val1 == val2;
        }
        return ret;
    }
    CloneValue(dataType, val) {
        let ret;
        switch (DataTypes.dataTypes[dataType].DataType) {
            case 'StructureType':
            case 'ArrayType':
                ret = JSON.parse(JSON.stringify(val));
                break;

            default:
                ret = val;
        }
        return ret;
    }
    /**
     * Получить элемент по связи
     * @param {any} item связь
     * @return {HTMLElement} элемент
     */
    GetComponent(item, itemIndex, tryFind) {
        if (item.els !== undefined && itemIndex !== undefined && item.els[itemIndex] !== undefined)
            return item.els[itemIndex];

        if (!item.el && tryFind) {
            item.el = document.getElementById(item.ItemId);
            if (!item.el) {
                return;
            }
            return item.el;
        }
        return item.el;
    }
    /**
     * Получить действие по связи
     * @param {any} item связь
     * @return {HTMLElement} действие
     */
    GetAction(item) {
        return document.querySelector(`[id='${item.ItemId}']`).actions[item.ActionId];
    }

    _convert(el, value, sourceType, sourceId) {
        return Converter.convert(el, value, sourceType, sourceId);
    }

    setTrigger(target, value, DataType) {
        if (target.el && target.el.windowTriggers) {
            let trgSensCount = 0;
            let condHash = '';
            target.el.windowTriggers[target.ConditionId].ConditionSet.forEach(e => {

                if (e.ConditionFields.hasOwnProperty(target.ParameterId)) {
                    if (typeof e.ConditionFields[e.ConditionFields.value] === 'string' && DataType !== "STRING") {
                        e.ConditionFields[e.ConditionFields.value] = Converter["STRING"](e.ConditionFields[e.ConditionFields.value], DataType)
                    }
                    if (typeof e.ConditionFields[e.ConditionFields.operand] === 'string' && DataType !== "STRING") {
                        e.ConditionFields[e.ConditionFields.operand] = Converter["STRING"](e.ConditionFields[e.ConditionFields.operand], DataType)
                    }
                    e.ConditionFields[target.ParameterId] = value;
                }

                const operand = e.ConditionFields[e.ConditionFields.operand];
                const val = e.ConditionFields[e.ConditionFields.value];
                condHash += `${operand}/${val}/`;
                switch (e.ConditionFields.comparer) {
                    case 'Equal':
                        trgSensCount += Number(operand == val);
                        break;
                    case 'NotEqual':
                        trgSensCount += Number(operand != val);
                        break;
                    case 'More':
                        trgSensCount += Number(operand > val);
                        break;
                    case 'MoreEqual':
                        trgSensCount += Number(operand >= val);
                        break;
                    case 'Less':
                        trgSensCount += Number(operand < val);
                        break;
                    case 'LessEqual':
                        trgSensCount += Number(operand <= val);
                        break;
                    case 'Contains':
                        if (operand.toString().indexOf(value.toString()) > 0) { trgSensCount++; }
                        break;

                }
            });
            if (!target.el.windowTriggers.TriggerActivity) { target.el.windowTriggers.TriggerActivity = {}; }
            const tId = target.el.windowTriggers[target.ConditionId].TriggerId;
            if (trgSensCount == target.el.windowTriggers[target.ConditionId].ConditionSet.length && target.el.windowTriggers.TriggerActivity[tId] != condHash) {
                target.el.windowTriggers.TriggerActivity[tId] = condHash;
                const ta = target.el.windowTriggers[target.ConditionId].TriggerActions.split(',');
                target.el.CallActionManager(ta, { currentTarget: target.el });
            } else {
                delete target.el.windowTriggers.TriggerActivity[tId];
            }
        }
    }

    /**
     * Выполнение операции
     * @param {element} el элемент
     * @param {any} value значение
     * @param {string} sourceType тип данных
     * @param {number} itemIndex индекс (для элемента массива)
     * @param {number} sourceId ID источника
     * @return {number} успешность операции
     */
    _operation(el, value, sourceType, itemIndex, sourceId, attrName) {
        const target = this.GetComponent(el, itemIndex, true);
        let val;
        if (!target) {
            $ns.add({ type: 'error', time: new Date().toLocaleString(), title: "Ошибка операции", text: `Элемент с id ${el.ItemId} не найден` });
            return -1;
        }
        switch (typeof value) {
            case 'object':
                val = value && !value.dataType && !value.value ? { dataType: el.DataType, value: JSON.parse(JSON.stringify(value)) } : value;
                break;
            default:
                val = value;
                break;
        }
        const sVal = this._convert(el, val, sourceType, sourceId);
        if (sVal != null && typeof sVal === 'object' && sVal.type === 'customConvertError') return;

        switch (el.Operation) {
            case 'move':
                target.SetParameter(el.PropertyPath.toLowerCase(), sVal, true, itemIndex, null, attrName);
                break;
            case 'add':
                target.SetParameter(el.PropertyPath.toLowerCase(), target[el.PropertyPath.toLowerCase()] + sVal, true, itemIndex, null, attrName);
                break;
            case 'sub':
                target.SetParameter(el.PropertyPath.toLowerCase(), target[el.PropertyPath.toLowerCase()] - sVal, true, itemIndex, null, attrName);
                break;
            case 'mul':
                target.SetParameter(el.PropertyPath.toLowerCase(), target[el.PropertyPath.toLowerCase()] * sVal, true, itemIndex, null, attrName);
                break;
            case 'div':
                target.SetParameter(el.PropertyPath.toLowerCase(), target[el.PropertyPath.toLowerCase()] / sVal, true, itemIndex, null, attrName);
                break;
            case 'impulse':
                const delay = 500; //такт задачи экрана в будущем
                target.SetParameter(el.PropertyPath.toLowerCase(), true, true, itemIndex);
                setTimeout(() => target.SetParameter(el.PropertyPath.toLowerCase(), false, true, itemIndex, null, attrName), delay);
                break;
            default:
                target.SetParameter(el.PropertyPath.toLowerCase(), sVal, true, itemIndex, null, attrName);
        }
    }
}
