"use strict";
export class Methods {
    constructor(prefix) {
        this.prefix = prefix ? prefix : '';
        this.getMethod = function (method) {
            return `${prefix}/Methods/${methods[method]}`;
        }
    }
}
export const Constants = Object.freeze({
    single: "single",
    intervalStart: "intervalStart",
    intervalStop: "intervalStop",
    intervalRequest: "intervalRequest",
    continue: "continue",
})
export const methods = {
    WriteData: "WriteData",
    PublishData: "PublishData",
    PublishEvents: "PublishEvents",
    GetState: "GetState",
    GetLoginData: "GetLoginData",
    Login: "Login",
    Logout: "Logout",
    LogMessage: "LogMessage",
    CreateMonitoredDataItems: "CreateMonitoredDataItems",
    DeleteMonitoredDataItems: "DeleteMonitoredDataItems",
    CreateMonitoredEvents: "CreateMonitoredEvents",
    CreateDataSubscription: "CreateDataSubscription",
    DeleteDataSubscription: "DeleteDataSubscription",
    CreateEventSubscription: "CreateEventSubscription",
    DeleteMonitoredEvents: "DeleteMonitoredEvents",
    HistoryReadRaw: "HistoryReadRaw",
    HistoryReadRawAsync: "HistoryReadRawAsync",
    PublishHistoryData: "PublishHistoryData",
    GetArchiveItems: "GetArchiveItems",
    GetArchivedEvents: "GetArchivedEvents",
    RefreshEvents: "RefreshEvents",
    AcknowledgeEvents: "AcknowledgeEvents",
    CallPOU: "CallPOU",
    ReportAction: "ReportAction",
    GetTableData: "GetTableData",
    DeleteTableData: "DeleteTableData",
    InsertTableData: "InsertTableData",
    UpdateTableData: "UpdateTableData"
}