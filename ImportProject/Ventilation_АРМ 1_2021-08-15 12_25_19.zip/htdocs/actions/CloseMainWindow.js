﻿import { Action } from './Action.js';
/**
 * @class CloseMainWindow
 * @extends Action
 * @classdesc Действие Закрыть основное окно
 * 
 * */
export class CloseMainWindow extends Action {
    execute() {
        window.close();
    }
}