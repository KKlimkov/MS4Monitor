﻿import { Action } from './Action.js';
import { toBool } from '../lib/utils.js';
/**
 * @class OpenUrl
 * @extends Action
 * @classdesc Действие Открыть адрес
 * Открыть любой адрес
 * */
export class OpenUrl extends Action {
    execute() {
        if (this._openNew === true) {
            window.open(this._address, '_blank');
        } else {
            if (this._frameId) {
                document.getElementById(this._frameId).datasource = this._address;
            } else {
                window.open(this._address, '_self');
            }
        }
    }

    get Address() {
        return this._address || '';
    }
    set Address(v) {
        this._address = v;
    }

    get OpenNew() {
        return typeof this._openNew === 'boolean' ? this._openNew : false;
    }
    set OpenNew(v) {
        this._openNew = toBool(v);
    }

    get FrameId(){
        return this._frameId;
    }
    set FrameId(v){
        this._frameId = v;
    }

}