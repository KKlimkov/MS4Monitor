﻿/**
 * @class Action
 * @classdesc Базовый класс для действий
 * */
export class Action {
    /**
     * @constructor
     * @param {object} options параметры действия
     * @param {HTMLElement} context элемент-владелец действия
     */
    constructor(options, context) {
        this.prop_link = {};
        for (let option in options) {
            this[option] = options[option];
        }
        this.context = context;
    }
    /**
     * @virtual
     * Выполнение действия
     * */
    execute() {
    }
    /**
     * Деструктор
     * */
    destroy() {
        if (this.context) {
            delete this.context;
        }
        for (const key in this.prop_link) {
            delete this.prop_link[key];
        }
    }

    /**
     * Функция получения значения параметра из контекста события 
     * @param {*} val если значение содержит $event то необходимо извлечь значение
     * @param {HTMLElement} context контекст события
     * @return {any} полученное значение
     */
    calcParam(val, context) {
        let value;
        if (typeof val === 'string' && val[0] === '$' && context) {
            const param = val.split('.')[1];
            switch (param) {
                case 'x':
                case 'y':
                    if (typeof context[param] !== 'undefined') {
                        value = context[param];
                    } else if (context.type == 'mapclick' || context.type == 'markerclick') {
                        value = context.detail[param];
                    }
                    break;
                case 'mouselb':
                    value = context.buttons === 1;
                    break;
                case 'mousemb':
                    value = context.buttons === 4;
                    break;
                case 'key':
                    value = context.key;
                    break;
                case 'keycode':
                    value = context.keyCode;
                    break;
                case 'cellvalue':
                    value = context.detail.cellvalue;
                    break;
                case 'row':
                    value = context.detail.row;
                    break;
                case 'column':
                    value = context.detail.fild;
                    break;
                case 'rowvalue':
                    value = context.detail.rowvalue;
                    break;
                case 'rawrowvalue':
                    value = context.detail.rawrowvalue;
                    break;
                case 'markertype':
                    value = context.detail.markerType;
                    break;
                case 'markerdata':
                    value = context.detail.item;
                    break
            }
        } else {
            value = val;
        }
        return value;
    }
    /**
     * 
     * @param {HTMLElement} element
     * @param {any} linkUp
     * @param {any} value
     * @param {any} attrName
     * @param {any} itemIndex
     */
    LinkUp(element, linkUp, value, attrName, itemIndex) {
        if (this.prop_link[attrName]) {
            this.prop_link[attrName](value, attrName, itemIndex);
        }
    }

    UpdateParameters(PropertyPath, value) {
        this.parameters[PropertyPath] = value;
    }

    AddLinkCallback(property, callback) {
        this.prop_link[property.toLowerCase()] = callback;
    }
}