import { Alert } from './Alert.js';
import { SetParameterValue } from './SetParameterValue.js';
import { EnterFullscreen } from './EnterFullscreen.js';
import { ExitFullscreen } from './ExitFullscreen.js';
import { OpenUrl } from './OpenUrl.js';
import { OpenWindow } from './OpenWindow.js';
import { OpenDialog } from './OpenDialog.js';
import { Backward } from './Backward.js';
import { Forward } from './Forward.js';
import { CloseWindow } from './CloseWindow.js';
import { CallEvent } from './CallEvent.js';
import { CallMethod } from './CallMethod.js';
import { CallPOU } from './CallPOU.js';
import { Logout } from './Logout.js';
import { SwitchUser } from './SwitchUser.js';
import { OpenPrintDialog } from './OpenPrintDialog.js';
import { AlertAction as ShowTaskBar } from './ShowTaskBar.js';
import { Impulse } from './Impulse.js';
import { CloseMainWindow } from './CloseMainWindow.js';
import { OpenMarkerWindow } from './OpenMarkerWindow.js';

/**
 * @class ActionFactory
 * @classdesc Фабрика действий
 * */
export class ActionFactory {
    /**
     * @constructor
     * @param {object} options параметры действия
     * @param {HTML} context элемент-владелец действия
     */
    constructor(options, context) {
        switch (options.type) {
            case 'Alert':
                return new Alert(options, context);
            case 'SetParameterValue':
                return new SetParameterValue(options, context);
            case 'EnterFullScreen':
                return new EnterFullscreen(options, context);
            case 'ExitFullScreen':
                return new ExitFullscreen(options, context);
            case 'OpenUrl':
                return new OpenUrl(options, context);
            case 'OpenWindow':
                return new OpenWindow(options, context);
            case 'OpenDialog':
                return new OpenDialog(options, context);
            case 'Forward':
                return new Forward(options, context);
            case 'Backward':
                return new Backward(options, context);
            case 'CloseWindow':
                return new CloseWindow(options, context);
            case 'CallEvent':
                return new CallEvent(options, context);
            case 'CallPOU':
                return new CallPOU(options, context);
            case 'Logout':
                return new Logout(options, context);
            case 'OpenPrintDialog':
                return new OpenPrintDialog(options, context);
            case 'ShowStatus':
                return new ShowTaskBar(options, context);
            case 'CallMethod':
                return new CallMethod(options, context);
            case 'SwitchUser':
                return new SwitchUser(options, context);
            case 'Impulse':
                return new Impulse(options, context);
            case 'CloseMainWindow':
                return new CloseMainWindow(options, context);
            case 'OpenMarkerWindow':
                return new OpenMarkerWindow(options, context);
            default:
                return null;
        }
    }
}