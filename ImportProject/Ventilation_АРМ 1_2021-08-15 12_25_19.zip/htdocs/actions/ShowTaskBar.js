﻿import { Action } from './Action.js';
/**
 * @deprecated
 * */
export class AlertAction extends Action {
    execute() {

    }
}