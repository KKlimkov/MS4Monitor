﻿import { Action } from './Action.js';
import { Constants as C, methods as M } from '../observer/methods.js'
/**
 * @class CallPOU
 * @extends Action
 * @classdesc Действие Вызвать программу
 * Вызвать ФБ в задаче объекта
 * */
export class CallPOU extends Action {

    async execute(context, execAsync) {
        const targetContext = context.target || context.currentTarget;
        const programId = this.ProgramId === "0"
            ? $sw.ItemSubscription._getParentParam(targetContext, 'objectid')
            : Number(this.ProgramId);
        const taskId = this.TaskId === -1
            ? $sw.ItemSubscription._getParentParam(targetContext, 'taskid')
            : this.TaskId;
        const outerPath = this.ProgramId === "0"
            ? $sw.ItemSubscription._getOuterPath(targetContext)
            : "";
        if (!this.IsScreenTask) {
            const pack = {
                recs: [{
                    itemId: programId,
                    outParams: this._calcResaultParam(this.Results),
                    params: this._calcParam(this.parameters, context),
                    path: outerPath + this.Path,
                    taskId: taskId
                }]
            };
            const enoIndex = this.Results.findIndex((el) => {
                return el.name === 'EnO';
            })
            const options = {
                methodType: C.single,
                method: M.CallPOU,
                pack,
            };
            const proc = data => {
                if (data.recs && data.recs.length > 0 && data.recs[0].outParams) {
                    if (enoIndex > -1 && data.recs[0].outParams[enoIndex] === null) {
                        $ns.add({
                            type: 'error',
                            time: new Date().toLocaleString(),
                            title: 'Call POU ERROR',
                            text: `Program ID: ${this.ProgramId}`,
                            obj: this.parameters
                        });
                        if (data.recs[0].outParams[enoIndex] === null) return;
                    }
                    for (let i = 0; i < data.recs[0].outParams.length; i++) {
                        const el = data.recs[0].outParams[i];
                        if (this.prop_link[this.Results[i].name.toLowerCase()]) {
                            let val;
                            switch (typeof el) {
                                case 'object':
                                    val = el && !el.dataType && !el.value
                                        ? { dataType: this.Results[i].type,
                                            value: JSON.parse(JSON.stringify(el)) }
                                        : '';
                                    break;
                                default:
                                    val = el;
                                    break;
                            }
                            this.prop_link[this.Results[i].name.toLowerCase()](val);
                        }
                    }
                }
            }
            if (!execAsync) {
                await new Promise(resolve => {
                    $sw.ServerAdapter.sendRequest(options, data => resolve(proc(data)));
                });
            } else {
                $sw.ServerAdapter.sendRequest(options, proc);
            }
        } else {
            if ($TaskManager) {
                $TaskManager.tasks.generatedTask.postMessageCallPOU(this.Path, this.parameters, this)
            }
        }
    }

    _calcResaultParam(param) {
        for (let i = 0; i < param.length; i++) {
            const el = param[i];
            if (el.hasOwnProperty('value')) {
                el.name = el.value;
                delete el.value;
            }
        }
        return param;
    }

    _calcParam(param, context) {
        let res = [];
        const cond = typeof this.conditions === 'object' && Array.isArray(this.conditions);
        for (const key in param) {
            if (!cond || (cond && this.isConditionParam(param))) {
                res.push({ name: key, value: this.calcParam(param[key], context) })
            }
        }
        return res;
    }

    isConditionParam(param) {
        return this.conditions.reduce((acc, cond) => acc || cond.Value.type === param || cond.Operand.type === param, false);
    }
}