import { Action } from './Action.js';
/**
 * @class CloseWindow
 * @extends Action
 * @classdesc Действие Закрыть окно
 * Закрыть всплывающее окно (событие должно принадлежать закрываемому окну)
 * */
export class CloseWindow extends Action {
    execute() {
        let parentWindow = this.context;
        while (!parentWindow.closeWin)
            parentWindow = parentWindow.parentElement;
        parentWindow.closeWin();
    }
}