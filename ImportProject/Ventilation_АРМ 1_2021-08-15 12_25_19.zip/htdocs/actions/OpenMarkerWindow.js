﻿import { Action } from './Action.js';
import { toBool } from '../lib/utils.js';

/**
 * @class OpenMarkerWindow
 * @extends Action
 * @classdesc Действие Открыть всплывающее окно маркера
 * */
export class OpenMarkerWindow extends Action {
    execute(context) {
        if (!this.WindowID) {
            $ns.add({
                type: 'warning',
                time: new Date().toLocaleString(),
                title: 'Окно не найдено',
                text: `Окно не найдено`
            });
            return;
        }

        this.continueExecution(context);
    }

    continueExecution(context) {
        let options = this.getOptions();
        let id = context.detail.id;
        const targetContext = context.target || context.currentTarget;
        if (!context.detail.popupOpened) {
            let marker = targetContext.openMarkerWindow(id, options);
            let { msWin = null } = targetContext.getPopupModels(marker);
            this.addToMarkerPool(context.detail.id);
            if (msWin !== null && typeof this.parameters !== 'undefined') {
                Object.entries(this.parameters).forEach(entry => {
                    let val = typeof entry[1] === 'string' && entry[1].includes("$event")
                        ? this.calcParam(entry[1], context)
                        : entry[1];
                    msWin.SetParameter(entry[0].toLowerCase(), val, true);
                });
            }
        }
    }

    getOptions() {
        let options = {
            width: this._width,
            height: this._height,
            canclose: this._canClose,
            sizetocontent: this._sizeToContent,
            closeonnewwindow: this._closeOnNewWindow,
            closeonlostfocus: this._closeOnLostFocus,
            windowid: this.WindowID,
        };
        return options;
    }

    UpdateParameters(PropertyPath, value) {
        if (this.markerWindow) {
            this.markerWindow.SetParameter(PropertyPath.toLowerCase(), value);
        } else {
            this.parameters[PropertyPath] = value;
        }
    }

    addToMarkerPool(id) {
        if (typeof this.markersPool === 'undefined') {
            this.markersPool = new Set();
        }
        this.markersPool.add(id);
    }

    getMarkerWindows() {
        if (typeof this.markersPool !== 'undefined') {
            let ids = Array.from(this.markersPool);
            let mapNode = this.context;
            if (typeof mapNode !== 'undefined') {
                var markerWindows = ids.map(id => mapNode.currentMarkers[id])
                    .map(markerEntry => markerEntry.marker._popup)
                    .filter(pop => typeof pop != 'undefined' && pop !== null);
            }
        }
        return markerWindows || [];
    }

    get WindowID() {
        return typeof this._WindowID === 'undefined' ? '' : this._WindowID;
    }
    set WindowID(value) {
        if (value.toString().includes('.')) {
            this._WindowID = $pr.getWindowIdByPath(value);
            if (typeof $WinDefs.winDef[this._WindowID] !== 'undefined'
                && $WinDefs.winDef[this._WindowID].objectid === '0') {
                this.ObjectId = $pr.getObjectIdByPath(value);
            }
        } else {
            this._WindowID = value;
        }
    }

    get CanClose() {
        return this._canClose;
    }
    set CanClose(v) {
        this._canClose = toBool(v);
        let popups = this.getMarkerWindows();
        for (let i = 0; i < popups.length; i++) {
            let pop = popups[i];
            if (this._canClose) {
                pop._closeButton.style.display = 'block';
                let frame = pop._contentNode.firstChild;
                this.context.setCloseButton(pop, { width: frame.width, height: frame.height }, this.getOptions());
            } else {
                pop._closeButton.style.display = 'none';
            }
        }
    }

    get Width() {
        return this._width;
    }
    set Width(v) {
        this._width = v;
        this.updateMarkers();
    }

    get Height() {
        return this._height;
    }
    set Height(v) {
        this._height = v;
        this.updateMarkers();
    }

    get SizeToContent() {
        return this._sizeToContent;
    }
    set SizeToContent(v) {
        this._sizeToContent = v;
        this.updateMarkers();
    }

    updateMarkers() {
        let stc = Number(this._sizeToContent);
        let popups = this.getMarkerWindows();
        let options = this.getOptions();

        for (let i = 0; i < popups.length; i++) {
            let pop = popups[i];
            let frame = pop._contentNode.firstChild;
            if (stc !== 0) {
                frame._backWidth = this._width;
                frame._backHeight = this._height;
            }
            frame.sizetocontent = stc;

            this.context.setCloseButton(pop, { width: frame._msWin.width, height: frame._msWin.height }, options);
        }
    }

    get objectId() {
        return this._ObjectId;
    }
    set objectId(v) {
        this._ObjectId = Number(v);
    }



    get CloseOnNewWindow() {
        return this._closeOnNewWindow;
    }
    set CloseOnNewWindow(v) {
        this._closeOnNewWindow = toBool(v);
    }

    get CloseOnLostFocus() {
        return this._closeOnLostFocus;
    }

    set CloseOnLostFocus(v) {
        this._closeOnLostFocus = toBool(v);
    }

    destroy() {

    }
}
