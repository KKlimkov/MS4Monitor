﻿import { Action } from './Action.js';
/**
 * @class CallEvent
 * @extends Action
 * @classdesc Действие Вызов события
 * Вызвать пользовательское событие (у библиотечного элемента)
 * */
export class CallEvent extends Action {
    execute(context) {
        if (typeof this.context.msWin === 'undefined') {
            let ms = this.context.parentElement;
            while (ms.nodeName !== 'MS-WINDOW') {
                ms = ms.parentElement;
            }
            this.context.msWin = ms;
        }
        let element = this.context.msWin;

        if (this.isUserEvent) {

            let params = element.getAttribute(this.Role)
            if (params == null && $WinDefs.winDef[element.id]) {
                params = $WinDefs.winDef[element.id][this.Role];
            }
            if (params == null) {
                element = element.querySelectorAll(`[${this.Role}]`);
                if (element === null || element.length === 0) { return; }
                element = element[0];
                params = element.getAttribute(this.Role);
            }
            if (!params) {
                params = element.querySelector(`[id="${this.eventContainer}"]`).actionlist[this.Role];
            }
            if (typeof params == 'string') {
                params = JSON.parse(params);
            }
            element.CallActionManager(params || [], context);
        } else {
            if (element.id != this.eventContainer) {
                element = element.querySelector(`[id="${this.eventContainer}"]`);
            }
            if (element) {
                const params = element.actionlist[this.Role];
                element.CallActionManager(params || []);
            }
        }

    }
}