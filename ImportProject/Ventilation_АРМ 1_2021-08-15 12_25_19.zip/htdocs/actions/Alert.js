﻿import { Action } from './Action.js';
/**
 * @class Alert
 * @extends Action
 * @classdesc Действие Показать сообщение
 * 
 * */
export class Alert extends Action {		
	execute(context) {
		const value = this.calcParam(this.Message.value, context);
		window._allert(value);
	}       
}