﻿import { Action } from './Action.js';
/**
 * @class CallMethod
 * @extends Action
 * @classdesc Действие Вызвать метод
 * Вызвать метод у Тренда или Журнала
 * */
export class CallMethod extends Action {
    execute() {
        if (typeof document.getElementById(this.ElementId)[this.MethodName] !== 'function') return;
        document.getElementById(this.ElementId)[this.MethodName](this.parameters);
    }
}