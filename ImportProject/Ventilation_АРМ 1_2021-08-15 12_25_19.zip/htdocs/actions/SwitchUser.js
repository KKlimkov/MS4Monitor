﻿import { Action } from './Action.js';
import { md5 } from '../lib/md5.js';
/**
 * @class Logout
 * @extends Action
 * @classdesc Действие Сменить пользователя
 * Сменить пользователя без завершения сессия, обновления страницы и перехода на стартовую мнемосхему
 * */
export class SwitchUser extends Action {
    execute() {
        const event = new CustomEvent('ms_message');
        // if (!this.UserName && window._globalParams.DefaultUser) {
        //     event.data = { event: 'switchuser', username: window._globalParams.DefaultUser, password: "" };
        // } else {
            event.data = { event: 'switchuser', username: this._username, password: this._password };
        // }
        window.dispatchEvent(event);
    }

    get Username() {
        return this._username || '';
    }
    set Username(value) {
        this._username = value;
    }
    
    
    get Password() {
        return this._password || '';
    }
    set Password(value) {
        // fix определение нешифрованного пароля пришедшего по связи
        if (!$sw.serverState.LoginData.disableHashPassword && value && value.length !== 32) {
            const toMd5 = new md5();
            this._password = toMd5.md5(value);
        } else {
            this._password = value;
        }
    }
}