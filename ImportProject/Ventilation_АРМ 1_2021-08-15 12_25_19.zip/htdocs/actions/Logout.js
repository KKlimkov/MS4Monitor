﻿import { Action } from './Action.js';
/**
 * @class Logout
 * @extends Action
 * @classdesc Действие Завершить сессию
 * Разлогиниться из системы
 * */
export class Logout extends Action {
    execute() {
        const event = new CustomEvent('ms_message');
        event.data = { event: 'logout' };
        window.dispatchEvent(event);
    }
}