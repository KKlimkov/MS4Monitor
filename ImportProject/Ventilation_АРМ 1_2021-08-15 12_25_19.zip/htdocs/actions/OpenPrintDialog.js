﻿import { Action } from './Action.js';
/**
 * @class OpenPrintDialog
 * @extends Action
 * @classdesc Действие Открыть окно печати
 * Вызвать окно печати (работает как Ctrl+P, на текущем открытом окне)
 * */
export class OpenPrintDialog extends Action {
    execute() {
        if (window.ipc && window.clientPrinter) {
            window.ipc.get().send('server', 'print');
        } else {
            window.print();
        }
    }
}