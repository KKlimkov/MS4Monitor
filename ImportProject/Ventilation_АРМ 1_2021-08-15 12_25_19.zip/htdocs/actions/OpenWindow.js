﻿import { Action } from './Action.js';
/**
 * @class OpenWindow
 * @extends Action
 * @classdesc Действие Открыть окно
 * */
export class OpenWindow extends Action {
    execute(context) {
        if (!this.WindowID) {
            $ns.add({
                type: 'warning',
                time: new Date().toLocaleString(),
                title: 'Окно не найдено',
                text: `Окно не найдено`
            });
            return;
        }

        if ($pm.hasPermissions) {
            const targetContext = context.target || context.currentTarget;
            $pm.resolveOpenWindow(targetContext, this.WindowID, this.ObjectId, this.continueExecution.bind(this, this.context));
        } else {
            this.continueExecution();
        }
    }
    continueExecution() {

        if (this.OpenNew == true) {
            window.open(`?${this.WindowID}`, '_blank');
        } else {
            let frame;
            if (this.FrameId)
                frame = document.getElementById(this.FrameId);
            else
                frame = document.querySelector("ms-frame");

            let windDef = $WinDefs.winDef[this.WindowID];

            const { objectid, taskid, outerpath } = windDef.objectid === '0' ?
                $sw.ItemSubscription.GetInstanceFields(this) : windDef;
            let windModel = {
                ...windDef,
                ...(objectid ? { objectid } : {}),
                ...(taskid ? { taskid } : {}),
                ...(outerpath ? { outerpath } : {}),
            }
            const win = frame.openWindow(windModel);
            if (this.parameters) {
                for (const key in this.parameters) {
                    win.SetParameter(key.toLowerCase(), this.parameters[key]);
                }
            }
        }
    }

    get WindowID() {
        return typeof this._WindowID === 'undefined' ? '' : this._WindowID;
    }
    set WindowID(value) {
        if (value.toString().includes('.')) {
            this._WindowID = $pr.getWindowIdByPath(value);
            if (typeof $WinDefs.winDef[this._WindowID] !== 'undefined'
                    && $WinDefs.winDef[this._WindowID].objectid === '0') {
                this.ObjectId = $pr.getObjectIdByPath(value);
            }
        } else {
            this._WindowID = value;
        }
    }
}