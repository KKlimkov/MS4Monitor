import { Action } from './Action.js';
import { MSPopUpWindow } from '../controls/popup_window/popup_window.js';
import { toBool } from '../lib/utils.js';
/**
 * @class OpenDialog
 * @extends Action
 * @classdesc Действие Открыть всплывающее окно
 * */
export class OpenDialog extends Action {
    execute(context) {
        if (!this.WindowID) {
            $ns.add({
                type: 'warning',
                time: new Date().toLocaleString(),
                title: 'Окно не найдено',
                text: `Окно не найдено`
            });
            return;
        }

        if ($pm.hasPermissions) {
            const targetContext = context.target || context.currentTarget;
            $pm.resolveOpenWindow(targetContext, this.WindowID, this.ObjectId, this.continueExecution.bind(this, context));
        } else {
            this.continueExecution(context);
        }
    }

    continueExecution(context) {
        // p1 - это переменная куда захоронили экземпляр MSPopUpWindow
        // незабыть его уничтожить афтер клосе

        const targetContext = context.target || context.currentTarget;

        let originPath;
        if (typeof targetContext.getOriginPath === 'function') {
            originPath = targetContext.getOriginPath() + "/" + context.actionId;
        } else {
            originPath = "/" + context.actionId;
        }
        const windowsByPath = $WinService.windowsByPath(originPath);
        if (windowsByPath.length > 0) {
            this.dialog = windowsByPath[0];
        }
        if (this.dialog) {
            if (this.dialog.isConnected && !this.CloseWithRoot) {
                this.dialog._upWindow();
                return;
            }
            if (this.dialog.isConnected) {
                this.dialog.close();
                this.dialog = null;
                if (!this._NoDuplicatesAllowed) return;
            }
            delete this.dialog;
        }
        this.evtContext = context;
        if (this.evtContext && this.evtContext.cancelable) this.evtContext.needClickIgnode = true;
        const a = new MSPopUpWindow();
        a.dragable = true;
        a.modal = false;
        a.title = this.Text;
        a.height = this.Height;
        a.width = this.Width;
        a.minimized = this._CanMinimize;
        a.mini = !this.IsVisible;
        a.closable = this._CanClose;
        a.resize = this._CanResize;
        a.titlefontcolor = this.HeaderFontColor;
        a.titlecolor = this.HeaderBackgroundColor;
        a.bordercolor = this.BorderColor;
        a.borderthickness = this.BorderThickness;
        a.borderstyle = this.BorderStyle;
        a.boundsrestricted = this.BoundsRestricted;
        a.opacity = this.Opacity;
        a.sizetocontent = this._sizetocontent;
        a.opendialogpoint = this.OpenDialogPoint;
        a.offsetx = this.X;
        a.offsety = this.Y;
        a.context = context;
        a.shadowcolor = this.ShadowColor;
        a.shadowsize = this.ShadowSize;
        a.isenabled = this.IsEnabled;
        a.originPath = originPath;
        //a.onclose = this.destroy.bind(this)  //Bug 20496: В экземпляре объекта не отображается значение в тексте после повторного открытия окна

        if (this._NoDuplicatesAllowed) {
            const i = $WinService.windows.findIndex(el => { return el._msWin.id == this.WindowID; });
            if (i > -1) {
                $WinService.windows[i].close();
            }
        }
        const b = $WinService.addWindow(a);
        if (!b) return;
        const winModel = $WinDefs.winDef[this.WindowID];

        const { objectid, taskid, outerpath } = winModel.objectid === '0' ?
            $sw.ItemSubscription.GetInstanceFields(this) : winModel;

        let modelKeys = {
            ...winModel,
            id: this.WindowID,
            dockstyle: 3,
            ...(winModel.backgroundcolor ? {} : { backgroundcolor: "rgb(245,240,245)" }),
            ...(objectid ? { objectid } : {}),
            ...(taskid ? { taskid } : {}),
            ...(outerpath ? { outerpath } : {}),
        }

        this.msWin = a.openWindow(modelKeys);
        if (this._x === undefined && winModel.x != 0) {
            a.x = Number(winModel.x);
        }
        this.msWin.SetParameter('x', 0)
        if (this._y === undefined && winModel.y != 0) {
            a.y = Number(winModel.y);
        }
        this.msWin.SetParameter('y', 0);
        for (const key in this.parameters) {
            switch (key) {
                case 'ScaleX':
                case 'ScaleY':
                case 'X':
                case 'Y':
                    break;
                default:
                    this.msWin.SetParameter(key.toLowerCase(), this.calcParam(this.parameters[key], context));
            }
        }
        this.dialog = b;
        this.dialog._upWindow();
        const keys = Object.keys(this.prop_link);
        for (let index = 0; index < keys.length; index++) {
            if (keys[index].toLowerCase() in this.msWin) {
                this.msWin.AddLinkCallback(keys[index].toLowerCase(), this.LinkUp.bind(this));
            }
        }
    }

    get WindowID() {
        return typeof this._WindowID === 'undefined' ? '' : this._WindowID;
    }
    set WindowID(value) {
        if (value.toString().includes('.')) {
            this._WindowID = $pr.getWindowIdByPath(value);
            if (typeof $WinDefs.winDef[this._WindowID] !== 'undefined'
                && $WinDefs.winDef[this._WindowID].objectid === '0') {
                this.ObjectId = $pr.getObjectIdByPath(value);
            }
        } else {
            this._WindowID = value;
        }
    }

    get CanMinimize() {
        return this._CanMinimize;
    }
    set CanMinimize(v) {
        this._CanMinimize = v;
        if (this.dialog) { this.dialog.minimized = v; }
    }

    get CanResize() {
        return this._CanResize;
    }
    set CanResize(v) {
        this._CanResize = v;
        if (this.dialog) { this.dialog.resize = v; }
    }

    get CanClose() {
        return this._CanClose;
    }
    set CanClose(v) {
        this._CanClose = v;
        if (this.dialog) { this.dialog.closable = v; }
    }

    get IsVisible() {
        return this._IsVisible !== undefined ? this._IsVisible : true;
    }
    set IsVisible(v) {
        this._IsVisible = v;
        if (this.dialog) { this.dialog.mini = !toBool(v); }
    }

    get HeaderBackgroundColor() {
        return this._HeaderBackgroundColor;
    }
    set HeaderBackgroundColor(v) {
        this._HeaderBackgroundColor = v;
        if (this.dialog) { this.dialog.titlecolor = v; }
    }

    get HeaderFontColor() {
        return this._HeaderFontColor || this.parameters.HeaderFontColor;
    }
    set HeaderFontColor(v) {
        this._HeaderFontColor = v;
        if (this.dialog) { this.dialog.titlefontcolor = v; }
    }

    get BorderColor() {
        return this._BorderColor ? this._BorderColor : this.parameters.BorderColor || 'Gray';
    }
    set BorderColor(v) {
        this._BorderColor = v;
        if (this.dialog) { this.dialog.bordercolor = v; }
    }

    get BorderThickness() {
        return this._borderthickness || this.parameters.BorderThickness || 1;
    }
    set BorderThickness(v) {
        this._borderthickness = v;
        if (this.dialog) { this.dialog.borderthickness = v; }
    }

    get BorderStyle() {
        return this._borderstyle ? this._borderstyle : 0;
    }
    set BorderStyle(v) {
        this._borderstyle = v;
        if (this.dialog) { this.dialog.borderstyle = v; }
    }

    get Text() {
        return this._text;
    }
    set Text(v) {
        this._text = v;
        if (this.dialog) { this.dialog.title = v; }
    }

    get Width() {
        return this._width ? this._width : 200;
    }
    set Width(v) {
        this._width = v;
        if (this.dialog) { this.dialog.width = v; }
    }

    get Height() {
        return this._height ? this._height : 300;
    }
    set Height(v) {
        this._height = v;
        if (this.dialog) { this.dialog.height = v; }
    }

    get Opacity() {
        return this._opacity ? this._opacity : this.parameters.Opacity || 100;
    }
    set Opacity(v) {
        this._opacity = v;
        if (this.dialog) { this.dialog.opacity = v; }
    }

    get SizeToContent() {
        return this._sizetocontent ? this._sizetocontent : 3;
    }
    set SizeToContent(v) {
        this._sizetocontent = v;
    }

    get OpenDialogPoint() {
        return typeof this._opendialogpoint !== 'undefined' ? this._opendialogpoint : 3;
    }
    set OpenDialogPoint(v) {
        this._opendialogpoint = v;
        if (this.dialog) { this.dialog.opendialogpoint = v; }
    }

    get ObjectId() {
        return this._ObjectId;
    }
    set ObjectId(v) {
        this._ObjectId = Number(v);
    }

    get X() {
        return this._x !== undefined ? this._x : (Number(this.calcParam(this.parameters.X, this.evtContext)) || 0);
    }
    set X(v) {
        this._x = v;
    }

    get Y() {
        return this._y !== undefined ? this._y : (Number(this.calcParam(this.parameters.Y, this.evtContext)) || 0);
    }
    set Y(v) {
        this._y = v;
    }

    get CloseWithRoot() {
        return typeof this._CloseWithRoot !== 'undefined' ? this._CloseWithRoot : false;
    }
    set CloseWithRoot(v) {
        this._CloseWithRoot = toBool(v);
    }

    get ShadowSize() {
        return typeof this._shadowsize !== 'undefined' ? this._shadowsize : this.parameters.ShadowSize || 3;
    }
    set ShadowSize(v) {
        this._shadowsize = v;
        if (this.dialog) { this.dialog.shadowsize = v; }
    }

    get ShadowColor() {
        return typeof this._shadowcolor !== 'undefined' ? this._shadowcolor : this.parameters.ShadowColor || 'rgba(35, 39, 76, 0.5)';
    }
    set ShadowColor(v) {
        this._shadowcolor = v;
        if (this.dialog) { this.dialog.shadowcolor = v; }
    }

    get IsEnabled() {
        return typeof this._isenabled !== 'undefined' ? this._isenabled : true;
    }
    set IsEnabled(v) {
        this._isenabled = v;
        if (this.dialog) { this.dialog.isenabled = v; }
    }

    get NoDuplicatesAllowed() {
        return this._NoDuplicatesAllowed;
    }
    set NoDuplicatesAllowed(v) {
        this._NoDuplicatesAllowed = toBool(v);
    }

    get BoundsRestricted() {
        return this._BoundsRestricted;
    }
    set BoundsRestricted(v) {
        this._BoundsRestricted = toBool(v);
    }

    UpdateParameters(PropertyPath, value) {
        if (this.msWin) {
            this.msWin.SetParameter(PropertyPath.toLowerCase(), value);
        } else {
            this.parameters[PropertyPath] = value;
        }
    }

    destroy() {
        if (this.dialog && this.CloseWithRoot) {
            if (this.context) delete this.context;
            if (this.msWin) delete this.msWin;
            if (this.evtContext) { delete this.evtContext.currentTarget; delete this.evtContext };
            $WinService.removeWindow(this.dialog);
            delete this.dialog;
        }
    }
}
