﻿import { Action } from './Action.js';
/**
 * @class Impulse
 * @extends Action
 * @classdesc Действие Выдать импульс
 * 
 * */
export class Impulse extends Action {		
    execute(context) {
        for(const link in this.prop_link){
            this.prop_link[link](true, null, null, {Operation:"impulse"}, true);
        }
    }       
}