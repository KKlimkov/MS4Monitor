﻿import { Action } from './Action.js';

/**
 * @class SetParameterValue
 * @extends Action
 * @classdesc Действие Установить параметр
 * Установить значение из источника в приемник
 * */
export class SetParameterValue extends Action {
    execute(context) {
        for (let link in this.prop_link) {
            const value = this.calcParam(this.Source.value, context);
            const opt = this.Operation ? { Operation: this.Operation } : null;
            this.prop_link[link](value, null, null, opt, true);
        }
    }

    get Operation() {
        return this._Operation || 0;
    }
    set Operation(v) {
        this._Operation = window._enums.HMIOperation[v];
    }
}