"use strict";
import { ServiceWorker } from './observer/ServiceWorker.js';
import { MSPopUpWindow } from './controls/popup_window/popup_window.js';
import { WinDefs } from './generated/windefs.js';
import { md5 } from './lib/md5.js';
import { NotifyService } from './notofiService.js';
import { WindowService } from './winService.js'
import { Permissions } from './generated/permissions.js';
import { PermissionsManager } from './observer/PermissionsManager.js';
import { StateStorageAdapter } from './observer/StateStorageAdapter.js';
import { PathResolver } from './observer/PathResolver.js';

import { toBool } from './lib/utils.js';
/***
 * @global
 * @class mainWorker
 * @classdesc Главный класс
 * */

export class mainWorker {
    constructor() {
        if (!window._globalParams.RedundancyIP) {
            window._globalParams.WebPort = document.location.port;
            window._globalParams.location.port = document.location.port;
            // if (window._globalParams.WebPort == 80) {
            //     window._globalParams.WebPort = 8043;
            //     window._globalParams.location.port = 8043;
            // }
            window._globalParams.location.hostname = document.location.hostname;
            window._globalParams.MainIP = document.location.hostname;
        }

        document.body.parentNode.style.overflow = 'hidden';
        window.stack = new Map();
        window.$WinDefs = new WinDefs();
        window.$ns = new NotifyService(window._globalParams.LogLevel);
        window.$WinService = new WindowService();
        window.$sw = this.sw = new ServiceWorker();
        window.$pm = this.pm = new PermissionsManager();
        window.$ss = new StateStorageAdapter();
        window.$pr = new PathResolver();


        if (window.ipc) {
            this.ipc = window.ipc.get();
            this.ipc.on('client', (event, ...arg) => {
                switch (arg[0]) {
                    case 'session':
                        this.sw.sessionId = arg[1].data.sessionId;
                        //this.sw.serverState.UserData = arg[1].userData;
                        //this.sw.serverState.LoginTime = this.serverState.UserData ? this.serverState.UserData.serverTime : 0;
                        //sessionStorage.setItem('serverState.LoginTime', this.serverState.LoginTime);
                        this.start(this.sw.sessionId);
                        break;
                    case 'logout':
                        this.logout({
                            sendEvent: false
                        });
                        break;
                }
            })
            if (Permissions.disableOsRights) {
                const collect = Object.keys(Permissions.disableOsRights).map(e => Permissions.disableOsRights[e])
                if (collect.length > 0 && collect.reduce((a, b) => a || b)) {
                    const error = this.ipc.sendSync('server', 'WinBlock.CADon');
                }
            }
        }

        // $ns.add({type:'warning',time: new Date().toLocaleString(),title:'test warning',text:'warning bla bla bla'});
        // $ns.add({type:'error',time: new Date().toLocaleString(),title:'test error',text:'error bla bla bla'});
        // $ns.add({type:'info',time: new Date().toLocaleString(),title:'test info',text:'info bla bla bla'});

        this.popup = document.getElementById('service-popup');

        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams && urlParams.keys().next().value) {
            if ($WinDefs.winDef[Number(urlParams.keys().next().value)]) {
                this.customStatWin = Number(urlParams.keys().next().value);
            }
            this.tUser = urlParams.get('user')
            if (!this.sw.serverState.LoginData.disableHashPassword) {
                const toMd5 = new md5();
                if (urlParams.get('password')) {
                    this.tPass = toMd5.md5(urlParams.get('password'));
                }
            }
        }

        this._events();
        this._windows = [];
        if (!window._globalParams.OfflineMode) {
            if (this.ipc) {
                this.windowId = this.ipc.sendSync('server', 'getId');
                window.savePath = this.ipc.sendSync('server', 'getSavePath');
                window.PrinterName = this.ipc.sendSync('server', 'getPrinerName');
                window.clientPrinter = this.ipc.sendSync('server', 'ClientPrinter');
                if (this.windowId == 1) {
                    this.start();
                }
            } else {
                this.start();
            }
        }
        window.$confirm = this.confirm.bind(this);
        window._allert = this.allert;
        window.onresize = () => {
            if (window.__rootWin) {
                window.__rootWin.width = window.innerWidth;
                window.__rootWin.height = window.innerHeight;
                this._rootFrame.width = window.innerWidth;
                this._rootFrame.height = window.innerHeight;
                this._rootFrame._calcSize();
                this.calcScale(window.__rootWin);
            }
        }

        window.onpopstate = e => {
            if (!this.mainFrameEl) this.mainFrameEl = document.querySelector(`[id="${WinDefs.mainFrame}"]`);
            if (e.state !== null && e.state.obj) {
                this.mainFrameEl.openWindow(e.state.obj, true);
            }
        }

        document.body.addEventListener('contextmenu', e => {
            if (e.preventDefault != undefined)
                e.preventDefault();
            if (e.stopPropagation != undefined)
                e.stopPropagation();
        });
        document.addEventListener("keydown", function (e) {
            if (!e.altKey && !e.shiftKey && !e.ctrlKey && e.which === window._enums.ButtonKeyCode.FULL_SCREEN) {
                e.preventDefault();
                if (!window.eRemote) {
                    document.documentElement.requestFullscreen();
                }
            }
        });

        document.addEventListener('mouseover', this.toolTipShow.bind(this));
        document.addEventListener('mouseout', this.toolTipHide.bind(this));

        this.zoom();
    }
    zoom() {
        if (window._globalParams && toBool(window._globalParams.DisableScale)) {
            document.addEventListener('keydown', (event) => {
                if (event.ctrlKey && (event.which === 61 || event.which === 107 || event.which === 173 || event.which === 109 || event.which === 187 || event.which === 189)) {
                    event.preventDefault();
                }
            }, { passive: false });

            document.addEventListener('mousewheel', (event) => {
                if (event.ctrlKey) {
                    event.preventDefault();
                }
            }, { passive: false });
        }
    }

    start(sessionId) {
        const event = new CustomEvent('ms_message');
        event.data = { event: 'start' };
        if (typeof sessionId !== 'undefined') {
            event.data.sessionId = sessionId;
        }
        window.dispatchEvent(event);
    }

    _events() {
        window.addEventListener('ms_message', (message) => {
            const data = message.data;
            switch (data.event) {
                case 'start':
                    this.setPopupText("Подключение к серверу...");
                    this.wrk = false;
                    this.tryStart = setInterval(() => {
                        if (this.wrk) { return; }
                        this.wrk = true;
                        Promise.race([
                            new Promise(reject => setTimeout(reject, 5000)),
                            this.sw.GetState()])
                            .then(data => {
                                if ((!data || data.code !== 0) || (!data.isMaster && this.sw.serverState.haveReserv)) {
                                    this.sw.Redirect(true).then(() => this.processGetLoginData())
                                        .catch(err => this.wrk = false);
                                } else if ((data && data.code === 0) && (data.isMaster || !this.sw.serverState.haveReserv)) {
                                    this.sw.serverState.currentState = data;
                                    if (document.location.hostname !== this.sw.serverState.location.hostname) {
                                        $ns.add({
                                            type: 'info',
                                            time: new Date().toLocaleString(),
                                            title: "Соединение установлено",
                                            text: `Подключение к ${this.sw.serverState.location.hostname} успешно установлено`
                                        });
                                    }
                                    this.processGetLoginData(data.sessionId);
                                } else {
                                    this.wrk = false;
                                }
                            }).catch(err => this.wrk = false);
                    }, 1000);
                    break;
                case 'windowStart':
                    if (this.sw.ServerAdapter.subscriptionId) {
                        this.sw.ItemSubscription.AddWindow(data);
                    } else {
                        this._windows.push(data);
                    }
                    const a = document.querySelector('ms-window');
                    if (a.id == message.data.window.id) {
                        // const sf = document.getElementById(Links.mainFrame);
                        // if(message.data.window.firstChild.nodeName=='MS-WINDOW') message.data.window.firstChild.remove();
                        window.__rootWin = message.data.window;
                        this._rootFrame = window.__rootWin.querySelector('ms-frame');
                        window.__rootWin.borderthickness = 0;
                        window.__rootWin.firstChild.borderthickness = 0;
                        window.__rootWin.setAttribute("root", "");
                        window.__rootWin.width = window.innerWidth;
                        window.__rootWin.height = window.innerHeight;
                        this._rootFrame.width = window.innerWidth;
                        this._rootFrame.height = window.innerHeight;
                        this.calcScale(message.data.window);
                        this.setGlobalEvents()
                        if (window._globalParams.OfflineMode) {
                            this.startPreview();
                        }
                    }
                    break;
                case 'windowRemove':
                    this.sw.ItemSubscription.RemoveWindow(data);
                    break;
                case 'logout':
                    this.logout();
                    break;
                case 'switchuser':
                    if (!this.switchUserInProgress) {
                        this.switchUserInProgress = true;
                        this.switchuser(message.data.username, message.data.password)
                            .then(() => {
                                this.switchUserInProgress = false;
                            }).catch(() => {
                                this.switchUserInProgress = false;
                            });
                    }
                    break;
                case "serverChange":
                case 'connectionLost':
                    if (!this.popup.isvisible) {
                        this.setPopupText("Нет подключения к серверу...");
                        this.popup.isvisible = true;
                    }
                    if (this.sw.serverState.haveReserv) {
                        this.initRedirect();
                    }
                    break;
                case 'sessionInvalid':
                    if (!this.loginChangeInProcess) {
                        this.loginChangeInProcess = true;
                        this.sw.Login("", "", true).then(data => {
                            document.cookie = `sessionId=${data.sessionId}; expireDate=0;`;
                            this.sw.sessionId = Number(data.sessionId);
                            this.sw.ServerAdapter.constructor.restartAdapters();
                            this.loginChangeInProcess = false;
                        });
                    }
                    break;
                case 'connectRestore':
                    this.popup.isvisible = false;
                    break;
                case 'reconnect':
                case 'projectReload':
                    // перезагрузка проекта с сервера, при изменении конфигурации проекта 
                    this.reloadPage();
                    break;
                case "mplcReload":
                    if (this.sw.serverState.haveReserv) {
                        this.initRedirect();
                    } else {
                        if (!this.popup.isvisible) {
                            this.setPopupText("Перезагрузка...");
                            this.popup.isvisible = true;
                        };
                        setTimeout(() => this.reloadPage(), 5000);
                    }
                    break;
            }
        });
    }

    async processGetLoginData(sessionId) {
        await this.sw.GetLoginData().then(data => {
            this.disableSelectUser = (this.sw.serverState.LoginData.disableSelectUser === true || this.sw.serverState.LoginData.operators.length == 0) &&
                this.sw.serverState.LoginData.needLogin ? true : false;
            if (typeof sessionId !== 'undefined' && data.sessionId === sessionId && data.session) {
                if (data.needLogin === false) {
                    this.pm.hasPermissions = false;
                }
                //else {
                //    this.pm.restoreRights();
                //}

                this.afterLogin(data.session);
            } else {
                if ((!this.sw.serverState.LoginData.operators || this.sw.serverState.LoginData.operators.length == 0) && !this.disableSelectUser) {
                    this.pm.hasPermissions = false;
                    this.forcedLogin('', '');
                } else {
                    if (!this.sw.serverState.currentState.currentOperator || !data.session) {
                        if (data.defaultUser) {
                            this.forcedLogin(data.defaultUser, '', false);
                        } else if (this.tUser) {
                            this.forcedLogin(this.tUser, this.tPass || '', false);
                            delete this.tUser;
                            delete this.tPass;
                        } else {
                            this.login(false, this.disableSelectUser);
                        }
                    } else {
                        this.afterLogin(data.session);
                    }
                }
            }
            clearInterval(this.tryStart);
            window._globalParams.DefaultUser = data.defaultUser;
            this.wrk = false;
        }).catch(error => {
            console.log('error', error);
            this.wrk = false;
        });
    }

    setPopupText(value) {
        const text = this.popup.getElementsByClassName("text")[0];
        const image = this.popup.getElementsByClassName("img")[0];
        text.innerText = value;
        image.style.visibility = 'inherit';
    }

    initRedirect() {
        if (!this.serverChangeInProcess) {
            this.wrk = false;
            this.setPopupText("Подключение к резервному узлу...")
            this.serverChangeInProcess = true;
            this.sw.Redirect().then(() => {
                this.serverChangeInProcess = false;
                this.popup.isvisible = false;
            });
        }
    }

    reloadPage() {
        this.sw.ItemSubscription.StopWatch();
        const uri = location.toString();
        if (uri.indexOf("?") > 0) {
            const clean_uri = uri.substring(0, uri.indexOf('?'));
            window.history.replaceState({}, document.title, clean_uri);
        }
        location.reload(true);
    }

    allert(text) {
        const popup = new MSPopUpWindow();
        popup.dragable = false;
        popup.modal = true;
        popup.minimized = false;
        popup.title = "Информация";
        popup.closable = false;
        popup._popup.style.width = 'auto';
        popup.innerHTML = `
        <form class="noselect Login" style="display: flex; flex-direction: column;" autocomplete="off">
            <span>${text}</span>
            <div style="text-align: center;">
                <button id="confirmOk" style="margin-top:32px;height:34px;width:100px;">Ок</button>
            </div>
        </form>
        `;
        document.body.appendChild(popup);
        popup.querySelector('#confirmOk').onclick = e => {
            e.preventDefault();
            popup.querySelector('#confirmOk').onclick = null;
            popup.isvisible = false;
            popup.remove();
        }
        popup.isvisible = true;
        popup._upWindow();
    }

    confirm(callback, ...args) {
        if (!this.confirmPopup) { this.confirmPopup = {} }
        if (args[1] && this.confirmPopup[args[1]]) {
            this.confirmPopup[args[1]].callback.push(callback);
            return;
        }
        const uid = `f${(~~(Math.random() * 1e8)).toString(16)}`;
        let title = args ? args[0] : '';
        let confirmPopup = new MSPopUpWindow();
        confirmPopup.dragable = false;
        confirmPopup.modal = true;
        confirmPopup.minimized = false;
        confirmPopup.title = "Подтвердите операцию";
        confirmPopup.closable = false;
        confirmPopup._popup.style.width = 'auto';
        confirmPopup.innerHTML = `
        <form class="noselect Login" style="display: flex; flex-direction: column;" autocomplete="off">
            <span>${title}</span>
            <div>
                <button ok data-uid="${uid}" style="margin-top:32px;height:34px;width:100px;margin-right:16px;">Ок</button>
                <button cancel data-uid="${uid}" style="margin-top:32px;height:34px;width:100px;">Отмена</button>
            </div>
        </form>
        `;
        document.body.appendChild(confirmPopup);
        confirmPopup.uid = uid;

        confirmPopup.querySelector('[ok]').onclick = e => {
            if (e) { e.preventDefault(); e.stopPropagation(); }
            const popup = this.confirmPopup[confirmPopup.uid].popup;
            const callbackLocal = this.confirmPopup[confirmPopup.uid].callback;
            popup.isvisible = false;
            callbackLocal.forEach(element => {
                element();
            });
            confirmPopup.querySelector('[ok]').onclick = null;
            confirmPopup.remove();
            delete this.confirmPopup[confirmPopup.uid];
            confirmPopup = null;
        }

        confirmPopup.querySelector('[cancel]').onclick = e => {
            e.preventDefault();
            e.stopPropagation();
            if (args[2]) args[2]();
            const popup = this.confirmPopup[confirmPopup.uid].popup;
            popup.isvisible = false;
            confirmPopup.querySelector('[cancel]').onclick = null;
            confirmPopup.remove();
            delete this.confirmPopup[confirmPopup.uid];
            confirmPopup = null;
        }
        confirmPopup.default = confirmPopup.querySelector('[ok]').onclick;

        this.confirmPopup[uid] = { popup: confirmPopup, callback: [callback] };

        confirmPopup.isvisible = true;
        confirmPopup._upWindow();

        this.confirmPopup.isvisible = true;
        return uid;
    }

    async login(relogin, disableSelectUser) {
        if (relogin) {
            await this.sw.GetLoginData();
        }
        this.popup.isvisible = false;
        if (!this.docLoginForm) {
            const loginForm = new MSPopUpWindow();
            loginForm.dragable = false;
            loginForm.modal = true;
            loginForm.minimized = false;
            loginForm.title = "Вход в систему";
            loginForm.closable = false || relogin;
            loginForm._popup.style.width = 'auto';

            let options = '';
            let tryLoginUri = false;
            const uri = new URLSearchParams(document.location.search)
            const usr = uri.get('user') ? uri.get('user') : '';
            const pass = uri.get("password") ? uri.get("password") : '';
            if (!this.endTryLoginUri && typeof usr === 'string' && usr) {
                tryLoginUri = true;
                this.endTryLoginUri = true;
            }
            if (disableSelectUser) {
                options = `<input type="text" name="operator" value="${usr}">`
            } else {
                for (let index = 0; index < this.sw.serverState.LoginData.operators.length; index++) {
                    const element = this.sw.serverState.LoginData.operators[index];
                    const value = element.login.replace(/\"/g, '&quot;');
                    options += `<option value="${value}"${usr == value ? ' selected' : ''}>${element.login}</option>`
                }
                options = `<select name="operator">
                    ${options}
                </select>`

            }

            loginForm.innerHTML = `<div style="display:flex; flex-direction: row;">
                <form class="noselect Login" style="display: flex; flex-direction: column;margin: 20px;" autocomplete="off">
                <label>Пользователь</label>
                ${options}
                <label style="margin-top: 17px;">Пароль</label>
                <input type="password" name="pass" value="${pass}">
                <div id="loginError" style="display: none;width: 300px;margin-top: 10px;color: red;">Неверный пароль. Проверьте раскладку клавиатуры или клавишу CapsLock.</div>
                <div id="chPass" style="display: none; flex-direction: column;">
                    <div id="newPass" style="width: 300px;margin-top: 10px;color: red;">Необходимо сменить пароль.</div>
                    <label style="margin-top: 17px;">Новый пароль</label>
                    <input type="password" name="newPass" value="">
                    <label style="margin-top: 17px;">Повторить пароль</label>
                    <input type="password" name="reNewPass" value="">
                    <div id="newPassError" style="display:none;width:300px;margin-top:10px;color:red;"></div>
                </div>
                <button style="margin-top: 32px; height: 34px;">Войти</button>
            </form>
            <div id="passInfo" style="display:none;flex-direction: column;border-left: 1px solid gray;padding: 20px;">
                <span>Информация</span>
                <pre style="background-color:lightgray;padding:10px;border: 1px solid;height:100%;margin-bottom:0;"></pre>
                <button id="passCancel" class="btnInfo" style="margin-top: 32px; min-height: 34px;">Отмена</button>
            <div>
            </div>
            `;
            loginForm.querySelector('#passCancel').onclick = e => {
                e.preventDefault();
                this.LoginFormChangePassword.style.display = 'none';
                this.docLoginForm.querySelector('#passInfo').style.display = 'none';
                const form = this.docLoginForm.querySelector('form');
                form.elements.operator.disabled = false;
                form.elements.pass.disabled = false;
                this._chSendPass = false;
                if (this._passInfo) delete this._passInfo;
            }

            loginForm.onsubmit = e => {
                e.preventDefault();
                const form = loginForm.querySelector('form');
                const login = form.elements.operator.value;
                let pass = '';
                if (this.sw.serverState.LoginData.disableHashPassword) {
                    pass = form.elements.pass.value;
                } else {
                    const toMd5 = new md5();
                    if (form.elements.pass.value) {
                        pass = toMd5.md5(form.elements.pass.value);
                    }
                }
                if (this._chSendPass) {
                    const newPass = form.elements.newPass.value;
                    const reNewPass = form.elements.reNewPass.value;
                    if (this._passInfo && this._passInfo.passwordMinSize > 0 && !newPass) {
                        const err = loginForm.querySelector('#newPassError')
                        err.innerText = 'Новый пароль не указан';
                        err.style.display = '';
                        return false;
                    } else if (newPass !== reNewPass) {
                        const err = loginForm.querySelector('#newPassError')
                        err.innerText = 'Пароли не совпадают';
                        err.style.display = '';
                        return false;
                    }
                    this.forcedLogin(login, pass, relogin, newPass);
                } else {
                    this.forcedLogin(login, pass, relogin);
                }
                if (this._passInfo) delete this._passInfo;
                return false;
            }
            loginForm._close.onclick = () => {
                this.docLoginForm.close();
                this.docLoginForm.remove();
                this.docLoginForm = undefined;
            }
            this.docLoginForm = document.body.appendChild(loginForm);
            this.LoginFormChangePassword = this.docLoginForm.querySelector('div#chPass');
            this.LoginFormWarning = this.docLoginForm.querySelector('#loginError');
            this.docLoginForm._upWindow();
            if (tryLoginUri) {
                loginForm.onsubmit();
            }
        }

    }

    async forcedLogin(login, pass, relogin, newPass) {
        return await this.sw.Login(login, pass, relogin, newPass).then(data => {
            // если data не вернулась то показать сообщенеи об ошибке логина
            if (typeof data === 'undefined' || data.code === 2149515264) {
                if (this.docLoginForm) {
                    this.LoginFormWarning.style.display = 'block';
                    data.errorText ? data.errorText.includes("Wrong password")
                        ? this.LoginFormWarning.innerHTML = "Неверный пароль. Проверьте раскладку клавиатуры или клавишу CapsLock"
                        : this.LoginFormWarning.innerHTML = data.errorText
                        : this.LoginFormWarning.innerHTML = data.codeDescription;
                } else {
                    $ns.add({ type: 'warning', time: new Date().toLocaleString(), title: 'Смена пользователя', text: `Ошибка входа пользователя "${login}". Неверный пароль.` });
                }
                return data;
            } else if (typeof data === 'undefined' || data.code === 2153119744) {
                return data;
            } else if (data.code === 2149515265 || data.code === 2149515269) { //OpcUa_BadUserAccessDenied_PasswordExpired, OpcUa_BadUserAccessDenied_NeedChangePassword
                this.LoginFormChangePassword.style.display = "flex";
                this.docLoginForm.querySelector('#passInfo').style.display = "flex";
                this._passInfo = this.generateInfoPassword(login);
                this.docLoginForm.querySelector('pre').innerHTML = this._passInfo.text;
                const form = this.docLoginForm.querySelector('form');
                form.elements.operator.disabled = true;
                form.elements.pass.disabled = true;
                form.elements.newPass.focus();
                this._chSendPass = true;
                return data;
            } else if (data.code != 0) {
                if (this._chSendPass) {
                    const err = this.docLoginForm.querySelector('#newPassError')
                    err.innerText = data.errorText;
                    err.style.display = '';
                }
                console.log(data.code.toString(16));
                return data;
            }
            if (window.ipc && data.groups.length > 0 && Permissions.disableOsRights) {
                let command;
                const collect = data.groups.map(el => { return Permissions.disableOsRights[el] });
                if (collect.length > 0 && collect.reduce((a, b) => a || b)) {
                    command = 'WinBlock.CADon';
                } else {
                    command = 'WinBlock.CADoff';
                }
                const error = this.ipc.sendSync('server', command);
                if (error) {
                    $ns.add({ type: 'error', time: new Date().toLocaleString(), title: 'Блокировка доступа к системе', text: error });
                }
            }
            document.cookie = `sessionId=${data.sessionId}; expireDate=0;`;
            this.sw.serverState.UserData.user = login;
            this.sw.sessionId = Number(data.sessionId);

            if (this.docLoginForm) {
                this.docLoginForm.remove();
                this.docLoginForm = undefined;
                this._chSendPass = false;
            }
            this.pm.setRtRights(data);
            if (!relogin) {
                this.afterLogin(data);
            } else {
                this.sw.ServerAdapter.constructor.restartAdapters();
                let roles = data.currentOperatorGroups || data.groups;
                this.pm.setOperatorRoles(login, roles);
                //если окно дозволено, то выставляем активность
                //если запрещено, то нужно открыть стартовое окно пользователя
                if (this.pm.checkCurrentWindow()) {
                    const event = new CustomEvent('ms_message');
                    event.data = { event: 'afterswitch' };
                    window.dispatchEvent(event);
                } else {
                    let pmStart = this.pm.getStartWindow()
                        || data.startMnemoscheme || WinDefs.startWindow;
                    this.pm.openUserWindow(pmStart);
                }
            }
        }).catch(error => {
            console.log('error', error);
        });
    }

    generateInfoPassword(login) {
        let passwordMinSize = 0;
        let passwordNonRepeatingCount = 0;
        let passwordIsComplex = false;
        let passwordExpirationTime = 0;
        let sessionTime = 0;

        const index = this.sw.serverState.LoginData.operators.findIndex(el => el.login === login);
        const operatorGroup = this.sw.serverState.LoginData.operators[index];
        const groups = this.sw.serverState.LoginData.groups;

        for (const iterator of groups) {
            const i = operatorGroup.groups.indexOf(iterator.name);
            if (i > -1) {
                passwordMinSize = iterator.passwordMinSize > passwordMinSize ? iterator.passwordMinSize : passwordMinSize;
                passwordNonRepeatingCount = iterator.passwordNonRepeatingCount > passwordNonRepeatingCount ? iterator.passwordNonRepeatingCount : passwordNonRepeatingCount;
                passwordIsComplex = iterator.passwordIsComplex || passwordIsComplex;
                passwordExpirationTime = (iterator.passwordExpirationTime <= passwordExpirationTime || passwordExpirationTime === 0) && iterator.passwordExpirationTime > 0 ? iterator.passwordExpirationTime : passwordExpirationTime;
                sessionTime = (iterator.sessionTime <= sessionTime || sessionTime === 0) && iterator.sessionTime > 0 ? iterator.sessionTime : sessionTime;
            }
        }
        sessionTime > 0 && (sessionTime = window._df.dateFormat(new Date(sessionTime), 'HH:mm:ss', true));
        passwordExpirationTime > 0 && (passwordExpirationTime = window._df.dateFormat(new Date(passwordExpirationTime), 'HH:mm:ss', true));
        let text = `Длительность сессии: ${sessionTime}<br>`;
        text += `Минимальная длина пароля: ${passwordMinSize}<br>`;
        text += `Количество неповторяемых паролей: ${passwordNonRepeatingCount}<br>`;
        text += `Срок действия пароля: ${passwordExpirationTime}<br>`;
        text += `Использовать сложный пароль ${passwordIsComplex ? 'Да' : 'Нет'}`;
        return {
            text: text,
            passwordMinSize: passwordMinSize,
            passwordNonRepeatingCount: passwordNonRepeatingCount,
            passwordIsComplex: passwordIsComplex,
            passwordExpirationTime: passwordExpirationTime,
            sessionTime: sessionTime
        };
    }

    afterLogin(data) {
        if (this.ipc && this.windowId == 1) {
            this.ipc.send('server', 'session', {
                data: data,
                login: this.sw.serverState.UserData.user,
                userData: this.sw.serverState.UserData
            });
        }
        let user = data.user;
        let roles = data.groups;

        this.sw.sessionId = Number(data.sessionId);
        this.sw.serverState.LoginTime = data.serverTime;
        this.pm.setOperatorRoles(user, roles);

        const pmStart = this.pm.getStartWindow() || data.startMnemoscheme;
        const startMnemo = this.customStatWin || pmStart || WinDefs.startWindow;
        this.customStatWin = null;
        if (startMnemo) {
            if (!this.pm.openUserWindow(startMnemo)) {
                this.login(false, this.disableSelectUser);
                return;
            }
        }
        this.SetState();
        if (this.docLoginForm) {
            this.docLoginForm.remove();
            this.docLoginForm = undefined;
        }
    }

    logout(option) {
        if (!option) option = { sendEvent: true }
        this.sw.ItemSubscription.StopWatch();
        this.sw.Logout()
            .then(_ => {
                const clean_uri = location.protocol + "//" + location.host + location.pathname;
                window.history.replaceState({}, document.title, clean_uri);
                if (this.ipc && (!option || option.sendEvent)) this.ipc.send('server', 'logout');
                let test = document.location.href.includes("test");
                document.location.href = `//${document.location.host}/${test ? "test" : ""}`;
            }).catch(error => {
                console.log('error', error);
                location.reload(true);
            });
    }

    async switchuser(login, pass) {
        if (login) {
            await this.forcedLogin(login, pass, true);
        } else {
            await this.login(true, this.disableSelectUser);
        }
    }

    calcScale(msWin) {
        let scale, scaleH, scaleW;
        const sh = Number(msWin.height);
        const sw = Number(msWin.width);
        scaleH = window.innerHeight / sh;
        scaleW = window.innerWidth / sw;

        scale = scaleH < scaleW ? scaleH : scaleW;

        window.__scale = {
            x: scale,
            y: scale
        };

        if (msWin.parentNode.tagName == "MS-FRAME") {
            msWin.parentNode.style.transform = `scale(${scale})`;
            msWin.parentNode.style.transformOrigin = '0 0';
        } else {
            if (scale === 1) {
                if (msWin.style.transform !== '') {
                    msWin.style.transform = '';
                }
            } else {
                msWin.style.transform = `scale(${scale})`;
                msWin.style.transformOrigin = '0 0';
            }
        }
    }

    setGlobalEvents() {
        const node = window.__rootWin;
        if (typeof node.actionlist === 'object') {
            node.removeListeners();
            let actionList = node._actionslist;
            for (const key in actionList) {
                if (actionList.hasOwnProperty(key)) {
                    document.addEventListener(key, node.CallActionManager.bind(node, actionList[key]), false);
                }
            }
        }
    }

    SetState() {
        this.sw.ItemSubscription.CreateDataSubscription()
            .then(data => this.onConnect(data));
    }


    onConnect(Obj) {
        if (Obj.subscriptionId) {
            this.sw.ItemSubscription.RunScreenTask();
            this.sw.ItemSubscription.AddWindows(this._windows);
            this._windows = [];
            this.sw.StartWatchState();
            this.popup.isvisible = false;
        }
        else {
            console.log(Obj);
        }
    }

    toolTipShow(event) {
        const target = event.target;
        let tooltipHtml = target.dataset.tooltip;
        let node = event.target.parentNode;
        while (!tooltipHtml && node && node.tagName !== "BODY") {
            tooltipHtml = node.dataset ? node.dataset.tooltip : null;
            if (node.nodeName === "MS-POPUP") {
                node = window.__rootWin;
            } else {
                node = node.parentNode;
            }
        }
        if (!tooltipHtml) return;

        let tmp = tooltipHtml.split('\n').join('</br>')

        this.toolTipHide();
        tooltipHtml = tmp
        this.tooltipElem = document.createElement('div');
        this.tooltipElem.className = 'tooltip';
        this.tooltipElem.innerHTML = tooltipHtml;

        document.body.append(this.tooltipElem);

        let coords = target.getBoundingClientRect();

        const scale = coords.width / target.width
        let left = (coords.left + (coords.width - this.tooltipElem.clientWidth) / 2);
        if (left < 0) left = 0;

        let top = coords.top - this.tooltipElem.offsetHeight - 5;
        if (top < 0) {
            top = coords.bottom + 5;
        }

        this.tooltipElem.style.left = left + 'px';
        this.tooltipElem.style.top = top + 'px';
    }
    toolTipHide() {
        if (this.tooltipElem) {
            this.tooltipElem.remove();
            this.tooltipElem = null;
        }
    }

    async startPreview() {
        this.popup.isvisible = false;
        this.pm.hasPermissions = false;
        const frame = document.getElementById($WinDefs.constructor.mainFrame);
        frame.openWindow($WinDefs.winDef[$WinDefs.constructor.startWindow]);
        await new Promise(resolve => setTimeout(resolve, 500))
            .then(() => {
                this.sw.ItemSubscription.AddWindows(this._windows);
                this._windows = [];
            });
    }
}