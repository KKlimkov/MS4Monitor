export class Type {
    constructor() {
        this.type = {
  "21273": {
    "actions": {
      "60646": {
        "WindowID": "36432",
        "CanClose": true,
        "CanMinimize": true,
        "CanResize": false,
        "HeaderBackgroundColor": "rgb(224,224,255)",
        "Text": "",
        "OpenDialogPoint": "3",
        "SizeToContent": 0,
        "BoundsRestricted": true,
        "NoDuplicatesAllowed": false,
        "TaskId": "0",
        "CloseWithRoot": true,
        "parameters": {
          "HeaderFontColor": "BLACK"
        },
        "type": "OpenDialog"
      },
      "60702": {
        "WindowID": "36654",
        "CanClose": true,
        "CanMinimize": true,
        "CanResize": false,
        "HeaderBackgroundColor": "rgb(224,224,255)",
        "Text": "",
        "OpenDialogPoint": "3",
        "SizeToContent": 0,
        "BoundsRestricted": true,
        "NoDuplicatesAllowed": false,
        "TaskId": "0",
        "CloseWithRoot": true,
        "parameters": {
          "HeaderFontColor": "BLACK"
        },
        "type": "OpenDialog"
      },
      "60868": {
        "WindowID": "36870",
        "CanClose": true,
        "CanMinimize": true,
        "CanResize": false,
        "HeaderBackgroundColor": "rgb(224,224,255)",
        "Text": "",
        "OpenDialogPoint": "3",
        "SizeToContent": 0,
        "BoundsRestricted": true,
        "NoDuplicatesAllowed": false,
        "TaskId": "0",
        "CloseWithRoot": true,
        "parameters": {
          "HeaderFontColor": "BLACK"
        },
        "type": "OpenDialog"
      },
      "61047": {
        "WindowID": "37305",
        "CanClose": true,
        "CanMinimize": true,
        "CanResize": false,
        "HeaderBackgroundColor": "rgb(224,224,255)",
        "Text": "",
        "OpenDialogPoint": "3",
        "SizeToContent": 0,
        "BoundsRestricted": true,
        "NoDuplicatesAllowed": false,
        "TaskId": "0",
        "CloseWithRoot": true,
        "parameters": {
          "HeaderFontColor": "BLACK"
        },
        "type": "OpenDialog"
      },
      "61102": {
        "WindowID": "36214",
        "CanClose": true,
        "CanMinimize": true,
        "CanResize": false,
        "HeaderBackgroundColor": "rgb(224,224,255)",
        "Text": "",
        "OpenDialogPoint": "3",
        "SizeToContent": 0,
        "BoundsRestricted": true,
        "NoDuplicatesAllowed": false,
        "TaskId": "0",
        "CloseWithRoot": true,
        "parameters": {
          "HeaderFontColor": "BLACK"
        },
        "type": "OpenDialog"
      },
      "61172": {
        "WindowID": "37691",
        "CanClose": true,
        "CanMinimize": true,
        "CanResize": false,
        "HeaderBackgroundColor": "rgb(224,224,255)",
        "Text": "",
        "OpenDialogPoint": "3",
        "SizeToContent": 0,
        "BoundsRestricted": true,
        "NoDuplicatesAllowed": false,
        "TaskId": "0",
        "CloseWithRoot": true,
        "parameters": {
          "HeaderFontColor": "BLACK"
        },
        "type": "OpenDialog"
      },
      "61240": {
        "WindowID": "38113",
        "CanClose": true,
        "CanMinimize": true,
        "CanResize": false,
        "HeaderBackgroundColor": "rgb(224,224,255)",
        "Text": "",
        "OpenDialogPoint": "3",
        "SizeToContent": 0,
        "BoundsRestricted": true,
        "NoDuplicatesAllowed": false,
        "TaskId": "0",
        "CloseWithRoot": true,
        "parameters": {
          "HeaderFontColor": "BLACK"
        },
        "type": "OpenDialog"
      },
      "61305": {
        "WindowID": "38495",
        "CanClose": true,
        "CanMinimize": true,
        "CanResize": false,
        "HeaderBackgroundColor": "rgb(224,224,255)",
        "Text": "",
        "OpenDialogPoint": "3",
        "SizeToContent": 0,
        "BoundsRestricted": true,
        "NoDuplicatesAllowed": false,
        "TaskId": "0",
        "CloseWithRoot": true,
        "parameters": {
          "HeaderFontColor": "BLACK"
        },
        "type": "OpenDialog"
      },
      "61366": {
        "WindowID": "38791",
        "CanClose": true,
        "CanMinimize": true,
        "CanResize": false,
        "HeaderBackgroundColor": "rgb(224,224,255)",
        "Text": "",
        "OpenDialogPoint": "3",
        "SizeToContent": 0,
        "BoundsRestricted": true,
        "NoDuplicatesAllowed": false,
        "TaskId": "0",
        "CloseWithRoot": true,
        "parameters": {
          "HeaderFontColor": "BLACK"
        },
        "type": "OpenDialog"
      },
      "61430": {
        "WindowID": "39405",
        "CanClose": true,
        "CanMinimize": true,
        "CanResize": false,
        "HeaderBackgroundColor": "rgb(224,224,255)",
        "Text": "",
        "OpenDialogPoint": "3",
        "SizeToContent": 0,
        "BoundsRestricted": true,
        "NoDuplicatesAllowed": false,
        "TaskId": "0",
        "CloseWithRoot": true,
        "parameters": {
          "HeaderFontColor": "BLACK"
        },
        "type": "OpenDialog"
      },
      "61494": {
        "WindowID": "39129",
        "CanClose": true,
        "CanMinimize": true,
        "CanResize": false,
        "HeaderBackgroundColor": "rgb(224,224,255)",
        "Text": "",
        "OpenDialogPoint": "3",
        "SizeToContent": 0,
        "BoundsRestricted": true,
        "NoDuplicatesAllowed": false,
        "TaskId": "0",
        "CloseWithRoot": true,
        "parameters": {
          "HeaderFontColor": "BLACK"
        },
        "type": "OpenDialog"
      }
    }
  }
}}
}