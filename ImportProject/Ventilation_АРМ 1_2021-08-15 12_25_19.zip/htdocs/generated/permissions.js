'use strict';
 export class Permissions { 
}