'use strict';
 export class Links { 
constructor(){
this.obj={} 
 this.windows =  
 {
  "41241": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "42122",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "42447",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "45067": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "45093",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "46027",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "48722": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "49603",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "49877",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "50496": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "50522",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "50899",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "53730": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "53756",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "54236",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "55543": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "55672",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "56059",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "56066": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "56195",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "56623",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "35054": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "35054",
          "ItemId": "34885",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "35054",
        "PropertyPath": "Avariya_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "35054",
          "ItemId": "34885",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "35054",
        "PropertyPath": "Vidimostj_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "true",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "opened",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "35054",
          "ItemId": "34885",
          "PropertyPath": "Otkrit",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "35054",
        "PropertyPath": "Otkrit_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "transition",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "35054",
          "ItemId": "34885",
          "PropertyPath": "Perehod",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "35054",
        "PropertyPath": "Perehod_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "heating",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "35054",
          "ItemId": "34885",
          "PropertyPath": "Progrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "35054",
        "PropertyPath": "Progrev_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "35054",
          "ItemId": "34991",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "35054",
        "PropertyPath": "Tekst_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34885",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34885",
        "PropertyPath": "Otkrit",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34885",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34885",
        "PropertyPath": "Progrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34885",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34885",
        "PropertyPath": "Perehod",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34885",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34885",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34885",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34885",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "26288": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "26288",
          "ItemId": "26119",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26288",
        "PropertyPath": "Avariya_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "26288",
          "ItemId": "26119",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26288",
        "PropertyPath": "Vidimostj_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "true",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "opened",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "26288",
          "ItemId": "26119",
          "PropertyPath": "Otkrit",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26288",
        "PropertyPath": "Otkrit_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "true",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "heating",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "26288",
          "ItemId": "26119",
          "PropertyPath": "Progrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26288",
        "PropertyPath": "Progrev_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "transition",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "26288",
          "ItemId": "26119",
          "PropertyPath": "Perehod",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26288",
        "PropertyPath": "Perehod_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "26288",
          "ItemId": "26225",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26288",
        "PropertyPath": "Tekst_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "26119",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26119",
        "PropertyPath": "Otkrit",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "26119",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26119",
        "PropertyPath": "Progrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "26119",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26119",
        "PropertyPath": "Perehod",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "26119",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26119",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "26119",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26119",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "26858": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "26858",
          "ItemId": "26806",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26858",
        "PropertyPath": "Avariya",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "26858",
          "ItemId": "26806",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26858",
        "PropertyPath": "Vidimostj",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "true",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "open",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "26858",
          "ItemId": "26806",
          "PropertyPath": "Otkrit",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26858",
        "PropertyPath": "Otkrit",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "26858",
          "ItemId": "26759",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26858",
        "PropertyPath": "Tekst_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "26858",
          "ItemId": "26806",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26858",
        "PropertyPath": "Passiv_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "26806",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26806",
        "PropertyPath": "Otkrit",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "26806",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26806",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "26806",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26806",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "26806",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "26806",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "32853": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm_heatExchanger",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32853",
          "ItemId": "32765",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32853",
        "PropertyPath": "Avariya_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32853",
          "ItemId": "32765",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32853",
        "PropertyPath": "Vidimostj_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "true",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32853",
          "ItemId": "32765",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32853",
        "PropertyPath": "IndikatorZnachenie_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32853",
          "ItemId": "32765",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32853",
        "PropertyPath": "IndikatorNalichie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32853",
          "ItemId": "32765",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32853",
        "PropertyPath": "IndikatorPodpisj_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Производительность",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32853",
          "ItemId": "32765",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32853",
        "PropertyPath": "IndikatorStolbik_1",
        "DataType": "REAL",
        "Type": "client",
        "DefaultValue": "65",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32853",
          "ItemId": "32765",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32853",
        "PropertyPath": "Ogranichenie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive_heatExchanger",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32853",
          "ItemId": "32765",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32853",
        "PropertyPath": "Passiv_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "hasAir_heatExchanger",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32853",
          "ItemId": "32765",
          "PropertyPath": "Potoki_vozduha",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32853",
        "PropertyPath": "Potoki_vozduha_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "heating_heatExchanger",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32853",
          "ItemId": "32765",
          "PropertyPath": "Provorot",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32853",
        "PropertyPath": "Provorot_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32853",
          "ItemId": "32712",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32853",
        "PropertyPath": "Tekst_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "32765",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32765",
        "PropertyPath": "Potoki_vozduha",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "hasAir_heatExchanger",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "32765",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32765",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "32765",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32765",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "32765",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32765",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "32765",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32765",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "32765",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32765",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "32765",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32765",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "32765",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32765",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Производительность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "32765",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32765",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "32765",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32765",
        "PropertyPath": "Provorot",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "32278": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Avariya_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Vidimostj_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "true",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "IndikatorZnachenie_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "IndikatorNalichie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "IndikatorPodpisj_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "IndikatorStolbik_1",
        "DataType": "REAL",
        "Type": "client",
        "DefaultValue": "65",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterHeaterLouvers_33",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Moschnostj1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Moschnostj1_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterHeaterLouvers_66",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Moschnostj2",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Moschnostj2_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterHeaterLouvers_100",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Moschnostj3",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Moschnostj3_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "softStart_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Myagkij_start",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Myagkij_start_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterHeaterPump_started",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Nasos_zapuschen",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Nasos_zapuschen_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "noWater_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Net_vodi",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Net_vodi_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Ogranichenie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Passiv_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "heat_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Progrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Progrev_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31815",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Tekst_sos",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "32089",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Tekst_sost2",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31709",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Tekst_poyasnenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "overheat_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Peregrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Peregrev1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm_nasos",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "AvariyaNasosa",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "AvariyaNasosa1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "underheating_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Nedogrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Nedogrev1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "cranking_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "32278",
          "ItemId": "31877",
          "PropertyPath": "Provorot",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "32278",
        "PropertyPath": "Provorot1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Net_vodi",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Nasos_zapuschen",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Progrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Myagkij_start",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Moschnostj1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Moschnostj2",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Moschnostj3",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Peregrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Nedogrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Provorot",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:nasos:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "AvariyaNasosa",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "31877",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "31877",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "33841": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm_waterCooler",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Avariya_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerPump_alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Avariya_nasosa",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Avariya_nasosa_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Vidimostj_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "true",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "IndikatorZnachenie_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "IndikatorNalichie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "IndikatorPodpisj_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "IndikatorStolbik_1",
        "DataType": "REAL",
        "Type": "client",
        "DefaultValue": "65",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerLouvers_0",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Moschnostj0",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Moschnostj0_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerLouvers_33",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Moschnostj1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Moschnostj1_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerLouvers_66",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Moschnostj2",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Moschnostj2_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerLouvers_100",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Moschnostj3",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Moschnostj3_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerPump_started",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Nasos_zapuschen",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Nasos_zapuschen_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerPump_stopped",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Nasos_ostanovlen",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Nasos_ostanovlen_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerPump_passive",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Nasos_passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Nasos_passiv_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerPump_no",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Net_nasosa",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Net_nasosa_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Ogranichenie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive_waterCooler",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33250",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Passiv_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33568",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Tekst_sost_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33356",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Tekst_sost2",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "33841",
          "ItemId": "33674",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33841",
        "PropertyPath": "Tekst__poyasnenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Moschnostj0",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Moschnostj1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Moschnostj2",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Moschnostj3",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Net_nasosa",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Nasos_zapuschen",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Nasos_ostanovlen",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Avariya_nasosa",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Nasos_passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "33250",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "33250",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "30702": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Avariya_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Vidimostj_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "IndikatorZnachenie_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "IndikatorNalichie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "IndikatorPodpisj_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "IndikatorStolbik_1",
        "DataType": "REAL",
        "Type": "client",
        "DefaultValue": "65",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "power_0_3",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "Moschnostj1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Moschnostj1_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "power_1_0",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "Moschnostj3",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Moschnostj3_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "power_0_6",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "Moschnostj2",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Moschnostj2_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Ogranichenie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive_electricHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Passiv_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "starting_electricHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "Progrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Progrev_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "stopping_electricHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "Produvka",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Produvka_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30406",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Tekst_sost",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30569",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Tekst_poyasnenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "st_electricHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "30702",
          "ItemId": "30463",
          "PropertyPath": "Predprogrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30702",
        "PropertyPath": "Predprogrev1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "Progrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "Produvka",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "Moschnostj1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "Moschnostj2",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "Moschnostj3",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "Predprogrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "30463",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "30463",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "34514": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34329",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "Avariya_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34329",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "Vidimostj_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "true",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "run",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34329",
          "PropertyPath": "Zapusk",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "Zapusk_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34329",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "IndikatorZnachenie_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34329",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "IndikatorNalichie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34329",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "IndikatorPodpisj_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34329",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "IndikatorStolbik_1",
        "DataType": "REAL",
        "Type": "client",
        "DefaultValue": "65",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34329",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "Ogranichenie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34329",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "Passiv_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34329",
          "PropertyPath": "CvetPara",
          "DataType": "HMI.SolidColorType",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "CvetPara_1",
        "DataType": "HMI.SolidColorType",
        "Type": "client",
        "DefaultValue": "rgb(136,187,221)",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34276",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "Tekst_sost",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "34514",
          "ItemId": "34435",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34514",
        "PropertyPath": "Tekst_poyasnenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34329",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34329",
        "PropertyPath": "Zapusk",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34329",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34329",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34329",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34329",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34329",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34329",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34329",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34329",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34329",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34329",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34329",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34329",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34329",
          "PropertyPath": "svg:color:fill",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34329",
        "PropertyPath": "CvetPara",
        "DataType": "HMI.SolidColorType",
        "Type": "client",
        "DefaultValue": "TRANSPARENT",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34329",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34329",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "34329",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "34329",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "29967": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "MotorAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "AvariyaDvigatelj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "AvariyaDvigatelj_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "RotorAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "AvariyaNetVrascheniya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "AvariyaNetVrascheniya_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "Vidimostj_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "true",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Running",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "Zapuschen",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "Zapuschen_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "InverterAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "InverterAvariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "InverterAvariya_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoInverter",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "InverterNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "InverterNalichie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "IndikatorZnachenie_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "IndikatorNalichie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "IndikatorPodpisj_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "IndikatorStolbik_1",
        "DataType": "REAL",
        "Type": "client",
        "DefaultValue": "65",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "Ogranichenie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Starting",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "Raskrutka",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "Raskrutka_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Stopping",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29739",
          "PropertyPath": "Tormozhenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "Tormozhenie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29845",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "Tekst_sost",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "29967",
          "ItemId": "29683",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29967",
        "PropertyPath": "Tekst_poyasnenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "Zapuschen",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "Raskrutka",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "Tormozhenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "AvariyaDvigatelj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "InverterNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "InverterAvariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "29739",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "29739",
        "PropertyPath": "AvariyaNetVrascheniya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "28686": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "MotorAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "AvariyaDvigatelj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "AvariyaDvigatelj_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "RotorAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "AvariyaNetVrascheniya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "AvariyaNetVrascheniya_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "Vidimostj_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "true",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Running",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "Zapuschen",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "Zapuschen_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "InverterAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "InverterAvariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "InverterAvariya_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoInverter",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "InverterNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "InverterNalichie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "IndikatorZnachenie_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "IndikatorNalichie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "IndikatorPodpisj_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "IndikatorStolbik_1",
        "DataType": "REAL",
        "Type": "client",
        "DefaultValue": "65",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "Ogranichenie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Starting",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "Raskrutka",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "Raskrutka_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Stopping",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28348",
          "PropertyPath": "Tormozhenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "Tormozhenie_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28454",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "Tekst_sost",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "28686",
          "ItemId": "28560",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28686",
        "PropertyPath": "Tekst_poyasnenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "Zapuschen",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "Raskrutka",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "Tormozhenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "AvariyaDvigatelj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "InverterNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "InverterAvariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "28348",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "28348",
        "PropertyPath": "AvariyaNetVrascheniya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "21273": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "opened_recirculation",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60606",
          "PropertyPath": "Otkrit",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36486",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60606",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60606",
        "PropertyPath": "Otkrit",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "heat_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60606",
          "PropertyPath": "Progrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36484",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60606",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60606",
        "PropertyPath": "Progrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "transition",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60606",
          "PropertyPath": "Perehod",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36483",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60606",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60606",
        "PropertyPath": "Perehod",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60606",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36482",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60606",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60606",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60606",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36485",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60606",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60606",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "opened_recirculation",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60662",
          "PropertyPath": "Otkrit",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36714",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60662",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60662",
        "PropertyPath": "Otkrit",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "heat_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60662",
          "PropertyPath": "Progrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36712",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60662",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60662",
        "PropertyPath": "Progrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "transition",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60662",
          "PropertyPath": "Perehod",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36711",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60662",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60662",
        "PropertyPath": "Perehod",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60662",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36710",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60662",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60662",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60662",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36713",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60662",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60662",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "open",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60829",
          "PropertyPath": "Otkrit",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36920",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60829",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60829",
        "PropertyPath": "Otkrit",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60829",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36918",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60829",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60829",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60829",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36919",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60829",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60829",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60829",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36921",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60829",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60829",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "60829",
          "PropertyPath": "svg:AvaryBorder:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "60829",
        "PropertyPath": "Obschaya_avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "hasAir_heatExchanger",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "Potoki_vozduha",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37370",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61002",
        "PropertyPath": "Potoki_vozduha",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "hasAir_heatExchanger",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37367",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61002",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37167",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61002",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37372",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61002",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37368",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61002",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm_heatExchanger",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37365",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61002",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive_heatExchanger",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37371",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61002",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37373",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61002",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Производительность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37366",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61002",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "heating_heatExchanger",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "Provorot",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37369",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61002",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61002",
        "PropertyPath": "Provorot",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "open",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61063",
          "PropertyPath": "Otkrit",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36264",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61063",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61063",
        "PropertyPath": "Otkrit",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61063",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36262",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61063",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61063",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61063",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36263",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61063",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61063",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61063",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36265",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61063",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61063",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "noWater_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Net_vodi",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37805",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Net_vodi",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterHeaterPump_started",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Nasos_zapuschen",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37794",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Nasos_zapuschen",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "heat_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Progrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37806",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Progrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "softStart_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Myagkij_start",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37797",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Myagkij_start",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterHeaterLouvers_33",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Moschnostj1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37802",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Moschnostj1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterHeaterLouvers_66",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Moschnostj2",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37803",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Moschnostj2",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterHeaterLouvers_100",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Moschnostj3",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37804",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Moschnostj3",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37798",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37445",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37800",
        "PropertyPath": "",
        "DataType": "REAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37799",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37793",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37796",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37801",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "overheat_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Peregrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37809",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Peregrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "underheating_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Nedogrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37808",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Nedogrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "cranking_waterHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Provorot",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37810",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Provorot",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm_nasos",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "AvariyaNasosa",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37807",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:nasos:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "AvariyaNasosa",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37795",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61118",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61118",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerLouvers_0",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Moschnostj0",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38222",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Moschnostj0",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerLouvers_33",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Moschnostj1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38223",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Moschnostj1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerLouvers_66",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Moschnostj2",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38224",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Moschnostj2",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerLouvers_100",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Moschnostj3",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38225",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Moschnostj3",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerPump_no",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Net_nasosa",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38226",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Net_nasosa",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerPump_started",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Nasos_zapuschen",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38213",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Nasos_zapuschen",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerPump_stopped",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Nasos_ostanovlen",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38214",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Nasos_ostanovlen",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerPump_alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Avariya_nasosa",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38212",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Avariya_nasosa",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "waterCoolerPump_passive",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Nasos_passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38217",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Nasos_passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38218",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37891",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38220",
        "PropertyPath": "",
        "DataType": "REAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38219",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm_waterCooler",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38211",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive_waterCooler",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38216",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38221",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38215",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61188",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61188",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "starting_electricHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "Progrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38582",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "Progrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "stopping_electricHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "Produvka",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38583",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "Produvka",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "power_0_3",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "Moschnostj1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38577",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "Moschnostj1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "power_0_6",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "Moschnostj2",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38578",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "Moschnostj2",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "power_1_0",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "Moschnostj3",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38579",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "Moschnostj3",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38584",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38305",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38585",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38580",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38575",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive_electricHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38581",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38587",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "st_electricHeater",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "Predprogrev",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38586",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "Predprogrev",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38576",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61256",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61256",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "run",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "Zapusk",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38865",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61321",
        "PropertyPath": "Zapusk",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38866",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61321",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38663",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61321",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38870",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61321",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38867",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61321",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38863",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61321",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38868",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61321",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "CvetPara",
          "DataType": "HMI.SolidColorType",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38871",
        "PropertyPath": "",
        "DataType": "HMI.SolidColorType",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "svg:color:fill",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61321",
        "PropertyPath": "CvetPara",
        "DataType": "HMI.SolidColorType",
        "Type": "client",
        "DefaultValue": "rgb(113,188,255)",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38869",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61321",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38864",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61321",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61321",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Running",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "Zapuschen",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39480",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "Zapuschen",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Starting",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "Raskrutka",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39478",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "Raskrutka",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Stopping",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "Tormozhenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39479",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "Tormozhenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "MotorAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "AvariyaDvigatelj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39473",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "AvariyaDvigatelj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoInverter",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "InverterNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39475",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "InverterNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "InverterAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "InverterAvariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39476",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "InverterAvariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39481",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39231",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39483",
        "PropertyPath": "",
        "DataType": "REAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39482",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39484",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39477",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "RotorAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "AvariyaNetVrascheniya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39474",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61382",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61382",
        "PropertyPath": "AvariyaNetVrascheniya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Running",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "Zapuschen",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39204",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "Zapuschen",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Starting",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "Raskrutka",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39202",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "Raskrutka",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Stopping",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "Tormozhenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39203",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "Tormozhenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "MotorAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "AvariyaDvigatelj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39197",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "AvariyaDvigatelj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoInverter",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "InverterNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39199",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "InverterNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "InverterAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "InverterAvariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39200",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "InverterAvariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "HasNoBar",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "IndikatorNalichie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39205",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "IndikatorNalichie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "IndikatorZnachenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38955",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:power_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "IndikatorZnachenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "60 %",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "IndikatorStolbik",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39207",
        "PropertyPath": "",
        "DataType": "REAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:inner:width",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "IndikatorStolbik",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "65",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Constraint",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "Ogranichenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39206",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:Bar:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "Ogranichenie",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "IndikatorPodpisj",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39208",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:action_text:Content",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "IndikatorPodpisj",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "Мощность",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39201",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "RotorAlarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "AvariyaNetVrascheniya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39198",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "61446",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "61446",
        "PropertyPath": "AvariyaNetVrascheniya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "27385": [
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "alarm",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "27385",
          "ItemId": "27333",
          "PropertyPath": "Avariya",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "27385",
        "PropertyPath": "Avariya",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "invisible",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "27385",
          "ItemId": "27333",
          "PropertyPath": "Vidimostj_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "27385",
        "PropertyPath": "Vidimostj",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "true",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "open",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "27385",
          "ItemId": "27333",
          "PropertyPath": "Otkrit",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "27385",
        "PropertyPath": "Otkrit",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "TypeId": "27385",
          "ItemId": "27099",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "27385",
        "PropertyPath": "Tekst_1",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "passive",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "TypeId": "27385",
          "ItemId": "27333",
          "PropertyPath": "Passiv",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "27385",
        "PropertyPath": "Passiv_1",
        "DataType": "BOOL",
        "Type": "client",
        "DefaultValue": "false",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "27333",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "27333",
        "PropertyPath": "Otkrit",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "27333",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "27333",
        "PropertyPath": "Avariya",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "27333",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "27333",
        "PropertyPath": "Vidimostj_",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "27333",
          "PropertyPath": "svg:Element:class",
          "DataType": "STRING",
          "Type": "svg",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "27333",
        "PropertyPath": "Passiv",
        "DataType": "STRING",
        "Type": "client",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ],
  "36214": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36214",
          "PropertyPath": "Avariya",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36262",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "27385",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36214",
          "PropertyPath": "Vidimostj",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36263",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "27385",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36214",
          "PropertyPath": "Otkrit",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "В норме",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "Авария",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36214",
          "PropertyPath": "Tekst_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36264",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "27385",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36214",
          "PropertyPath": "Passiv_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36265",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "27385",
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "36432": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36432",
          "PropertyPath": "Avariya_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "В норме",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Авария",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36432",
          "PropertyPath": "Tekst_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36482",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "35054",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36432",
          "PropertyPath": "Vidimostj_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36485",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "35054",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36432",
          "PropertyPath": "Otkrit_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36486",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "35054",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36432",
          "PropertyPath": "Perehod_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36483",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "35054",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36432",
          "PropertyPath": "Progrev_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36484",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "35054",
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "36654": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36654",
          "PropertyPath": "Avariya_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "В норме",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Авария",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36654",
          "PropertyPath": "Tekst_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36710",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "26288",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36654",
          "PropertyPath": "Vidimostj_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36713",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "26288",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36654",
          "PropertyPath": "Otkrit_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36714",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "26288",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36654",
          "PropertyPath": "Progrev_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36712",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "26288",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36654",
          "PropertyPath": "Perehod_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36711",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "26288",
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "36870": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36870",
          "PropertyPath": "Avariya",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "В норме",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Авария",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36870",
          "PropertyPath": "Tekst_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36918",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "26858",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36870",
          "PropertyPath": "Vidimostj",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36919",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "26858",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36870",
          "PropertyPath": "Otkrit",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36920",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "26858",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "36870",
          "PropertyPath": "Passiv_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "36921",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "26858",
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "37305": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37305",
          "PropertyPath": "Avariya_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "в норме",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "авария",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37305",
          "PropertyPath": "Tekst_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37365",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32853",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37305",
          "PropertyPath": "Vidimostj_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37366",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32853",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37305",
          "PropertyPath": "IndikatorZnachenie_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37167",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "32853",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37305",
          "PropertyPath": "IndikatorNalichie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37367",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32853",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37305",
          "PropertyPath": "IndikatorPodpisj_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37373",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "32853",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37305",
          "PropertyPath": "IndikatorStolbik_1",
          "DataType": "REAL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37372",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TypeId": "32853",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37305",
          "PropertyPath": "Ogranichenie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37368",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32853",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37305",
          "PropertyPath": "Passiv_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37371",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32853",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37305",
          "PropertyPath": "Potoki_vozduha_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37370",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32853",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37305",
          "PropertyPath": "Provorot_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37369",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32853",
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "37691": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Avariya_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "В норме",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Авария",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Tekst_sos",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37793",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Vidimostj_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37795",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "IndikatorZnachenie_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37445",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "IndikatorNalichie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37798",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "IndikatorPodpisj_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37801",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "IndikatorStolbik_1",
          "DataType": "REAL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37800",
        "PropertyPath": "",
        "DataType": "REAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Moschnostj1_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37802",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Moschnostj2_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37803",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Moschnostj3_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37804",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Myagkij_start_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37797",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Nasos_zapuschen_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37794",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Net_vodi_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "В норме",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Нет воды",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Tekst_sost2",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Необходимо восстановить подачу воды!",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Tekst_poyasnenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37805",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Ogranichenie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37799",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Passiv_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37796",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Progrev_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37806",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Peregrev1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37809",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "AvariyaNasosa1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37807",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Nedogrev1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37808",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "37691",
          "PropertyPath": "Provorot1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37810",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "32278",
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "38113": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Avariya_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "в норме",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "авария",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Tekst_sost_",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38211",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Avariya_nasosa_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "в норме",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "авария",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Tekst_sost2",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Требуется диагностика насоса",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Tekst__poyasnenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38212",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Vidimostj_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38215",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "IndikatorZnachenie_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "37891",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "IndikatorNalichie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38218",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "IndikatorPodpisj_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38221",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "IndikatorStolbik_1",
          "DataType": "REAL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38220",
        "PropertyPath": "",
        "DataType": "REAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Moschnostj0_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38222",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Moschnostj1_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38223",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Moschnostj2_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38224",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Moschnostj3_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38225",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Nasos_zapuschen_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38213",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Nasos_ostanovlen_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38214",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Nasos_passiv_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38217",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Net_nasosa_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38226",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Ogranichenie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38219",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38113",
          "PropertyPath": "Passiv_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38216",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "33841",
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "38495": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Avariya_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "В норме",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Авария",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Tekst_sost",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Требуется диагностика",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Tekst_poyasnenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38575",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Vidimostj_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38576",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "IndikatorZnachenie_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38305",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "IndikatorNalichie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38584",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "IndikatorPodpisj_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38587",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "IndikatorStolbik_1",
          "DataType": "REAL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38585",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Moschnostj1_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38577",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Moschnostj3_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38579",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Moschnostj2_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38578",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Ogranichenie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38580",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Passiv_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38581",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Progrev_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38582",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Produvka_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38583",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38495",
          "PropertyPath": "Predprogrev1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38586",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "30702",
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "38791": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "Avariya_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "в норме",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "авария",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "Tekst_sost",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Требуется диагностика неполадок!",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "Tekst_poyasnenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38863",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "34514",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "Vidimostj_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38864",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "34514",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "Zapusk_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38865",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "34514",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "IndikatorZnachenie_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38663",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "34514",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "IndikatorNalichie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38866",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "34514",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "IndikatorPodpisj_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38869",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "34514",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "IndikatorStolbik_1",
          "DataType": "REAL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38870",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TypeId": "34514",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "Ogranichenie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38867",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "34514",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "Passiv_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38868",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "34514",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "38791",
          "PropertyPath": "CvetPara_1",
          "DataType": "HMI.SolidColorType",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38871",
        "PropertyPath": "",
        "DataType": "HMI.SolidColorType",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "34514",
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "39129": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "AvariyaDvigatelj_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39197",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "AvariyaNetVrascheniya_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39198",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "Vidimostj_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39201",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "Zapuschen_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39204",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "InverterAvariya_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39200",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "InverterNalichie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39199",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "IndikatorZnachenie_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38955",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "IndikatorNalichie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39205",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "IndikatorPodpisj_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39208",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "IndikatorStolbik_1",
          "DataType": "REAL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39207",
        "PropertyPath": "",
        "DataType": "REAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "Ogranichenie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39206",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "Raskrutka_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39202",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "Tormozhenie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39203",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "Tekst_sost",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38947",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Требуется диагностика!",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39129",
          "PropertyPath": "Tekst_poyasnenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "38948",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "29967",
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ],
  "39405": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "AvariyaDvigatelj_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39473",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "AvariyaNetVrascheniya_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39474",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "Vidimostj_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39477",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "Zapuschen_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39480",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "InverterAvariya_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39476",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "InverterNalichie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39475",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "IndikatorZnachenie_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39231",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "IndikatorNalichie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39481",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "IndikatorPodpisj_1",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39484",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "IndikatorStolbik_1",
          "DataType": "REAL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39483",
        "PropertyPath": "",
        "DataType": "REAL",
        "Type": "server",
        "DefaultValue": 0.0,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "Ogranichenie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39482",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "Raskrutka_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39478",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "Tormozhenie_1",
          "DataType": "BOOL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39479",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "Tekst_sost",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39223",
        "PropertyPath": "",
        "DataType": "STRING",
        "Type": "server",
        "DefaultValue": "",
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Convertations": {
            "InterpolateSource": false,
            "InterpolateTarget": false,
            "DefaultValue": {
              "value": "",
              "type": "static"
            },
            "SourceType": "boolean",
            "TargetType": "string",
            "Points": [
              {
                "Source": {
                  "value": false,
                  "type": "static"
                },
                "Target": {
                  "value": "",
                  "type": "static"
                }
              },
              {
                "Source": {
                  "value": true,
                  "type": "static"
                },
                "Target": {
                  "value": "Требуется диагностика",
                  "type": "static"
                }
              }
            ]
          },
          "Operation": "move",
          "OneTime": false,
          "ItemId": "39405",
          "PropertyPath": "Tekst_poyasnenie",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "39224",
        "PropertyPath": "",
        "DataType": "BOOL",
        "Type": "server",
        "DefaultValue": false,
        "TypeId": "28686",
        "TaskNumber": 0,
        "HasBackward": false
      }
    }
  ]
} 
  
this.Items = { 
 };} 
 } 
 