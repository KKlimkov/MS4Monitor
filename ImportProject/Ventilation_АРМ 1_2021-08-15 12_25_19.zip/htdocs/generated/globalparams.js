'use strict';
 export class GlobalParameters {
 static get globals(){ 
 return {
  "ProjectName": "Вентиляция",
  "MainIP": "127.0.0.1",
  "WebPort": 8043,
  "Language": "ru",
  "UpdateInterval": 100,
  "RequestServerPrefix": "",
  "RedundancyIP": null,
  "OfflineMode": false,
  "DialogHeaderSize": 20.0,
  "DialogFontSize": 12.0,
  "DialogFontName": "Arial",
  "DisableScale": true,
  "LogLevel": 3,
  "ControlCAD": false,
  "SaveEncodingCsv": "utf-8",
  "SaveStatePlace": "В HMI клиенте",
  "FlashInterval": 1000
}; }
}