'use strict';
 export class DataTypes { 
 static get dataTypes() { 
 return {
  "HMI.SolidColorType": {
    "DataType": "ElementaryType"
  },
  "HMI.GradientColorType": {
    "DataType": "ElementaryType"
  },
  "LREAL": {
    "DataType": "ElementaryType"
  },
  "BOOL": {
    "DataType": "ElementaryType"
  },
  "DINT": {
    "DataType": "ElementaryType"
  },
  "DWORD": {
    "DataType": "ElementaryType"
  },
  "DATE_AND_TIME": {
    "DataType": "ElementaryType"
  },
  "STRING": {
    "DataType": "ElementaryType"
  },
  "LINT": {
    "DataType": "ElementaryType"
  },
  "BYTE": {
    "DataType": "ElementaryType"
  },
  "HMI.RowStyle": {
    "Fields": {
      "RowHeight": "STRING",
      "BorderThickness": "LREAL",
      "BorderColor": "HMI.SolidColorType",
      "BackgroundColor": "HMI.GradientColorType",
      "BackgroundColorEven": "HMI.GradientColorType",
      "BackgroundColorFilter": "HMI.GradientColorType",
      "FontName": "STRING",
      "FontSize": "BYTE",
      "TextColor": "HMI.SolidColorType",
      "TextColorFilter": "HMI.SolidColorType",
      "FontItalic": "BOOL",
      "FontBold": "BOOL",
      "FontUnderlined": "BOOL"
    },
    "DataType": "StructureType"
  },
  "HMI.BorderStyleType": {
    "Values": [
      "Solid",
      "Dash",
      "Dot",
      "None"
    ],
    "DisplayValues": [
      "Непрерывный",
      "Пунктир",
      "Точка",
      "Нет"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "HMI.TileType": {
    "Values": [
      "No",
      "Tile",
      "Fill",
      "Center"
    ],
    "DisplayValues": [
      "Нет",
      "Мозаика",
      "Заполнение",
      "Центр"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "HMI.SaveStateType": {
    "Values": [
      "Default",
      "Yes",
      "No"
    ],
    "DisplayValues": [
      "По умолчанию",
      "Да",
      "Нет"
    ],
    "Indexes": [
      0,
      1,
      2
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "HMI.DockType": {
    "Values": [
      "Up",
      "Down",
      "Right",
      "Left"
    ],
    "DisplayValues": [
      "Верх",
      "Низ",
      "Право",
      "Лево"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "HMI.HorizontalAlignType": {
    "Values": [
      "Left",
      "Center",
      "Right"
    ],
    "DisplayValues": [
      "Лево",
      "Центр",
      "Право"
    ],
    "Indexes": [
      0,
      1,
      2
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "HMI.VerticalAlignType": {
    "Values": [
      "Top",
      "Center",
      "Bottom"
    ],
    "DisplayValues": [
      "Верх",
      "Центр",
      "Низ"
    ],
    "Indexes": [
      0,
      1,
      2
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "HMI.MouseCursorKinds": {
    "Values": [
      "Standard",
      "Pointer",
      "Crosshair",
      "Text",
      "NotAllowed",
      "Wait",
      "Help",
      "Move"
    ],
    "DisplayValues": [
      "Стандартный",
      "Рука",
      "Перекрестие",
      "Текст",
      "Запрет",
      "Ожидание",
      "Помощь",
      "Перемещение"
    ],
    "Indexes": [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "HMI.OrientationType": {
    "Values": [
      "Horizontal",
      "Vertical"
    ],
    "DisplayValues": [
      "Горизонтально",
      "Вертикально"
    ],
    "Indexes": [
      0,
      1
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "HMI.HorizontalAlignTypeExt": {
    "Values": [
      "Left",
      "Center",
      "Right",
      "Stretch"
    ],
    "DisplayValues": [
      "Лево",
      "Центр",
      "Право",
      "Растянуть"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "HMI.VerticalAlignTypeExt": {
    "Values": [
      "Top",
      "Center",
      "Bottom",
      "Stretch"
    ],
    "DisplayValues": [
      "Верх",
      "Центр",
      "Низ",
      "Растянуть"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "SizeType": {
    "Values": [
      "Pixel",
      "Relative"
    ],
    "DisplayValues": [
      "Абсолютно",
      "Относительно"
    ],
    "Indexes": [
      0,
      1
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "ProportionType": {
    "Values": [
      "No",
      "Width",
      "Height",
      "Min",
      "Max"
    ],
    "DisplayValues": [
      "Нет",
      "По ширине",
      "По высоте",
      "По минимальной стороне",
      "По максимальной стороне"
    ],
    "Indexes": [
      0,
      1,
      2,
      3,
      4
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "HMI.SizeToContentType": {
    "Values": [
      "RealSize",
      "SetSize",
      "Crop",
      "Scroll"
    ],
    "DisplayValues": [
      "Исходный размер",
      "Подогнать",
      "Обрезать",
      "Прокрутить"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  },
  "REAL": {
    "DataType": "ElementaryType"
  },
  "HMI.OpenDialogPoint": {
    "Values": [
      "ElementOffset",
      "PointerOffset",
      "WindowOffset",
      "Center"
    ],
    "DisplayValues": [
      "Смещение от элемента",
      "Смещение от указателя",
      "По заданным",
      "По центру"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "Colors": [],
    "DataType": "EnumeratedType"
  }
}
}
}