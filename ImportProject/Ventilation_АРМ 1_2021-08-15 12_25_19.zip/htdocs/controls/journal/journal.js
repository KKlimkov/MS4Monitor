﻿import { Basic } from '../basic.js';
import { journalWorker } from '../../observer/journalWorker.js';
import { Converter } from '../../observer/converter.js';
import { ObjectTree } from '../trend/objecttree.js';
import { Inputs } from '../../lib/inputs.js';
import { DataTypes } from '../../generated/datatypes.js';
import { MSToolbar } from '../trend/toolbar.js';
import { MSDateTimePicker } from '../dtpicker/dtpicker.js';
import { MSInterval } from '../interval/interval.js';
import { exportTextfile, genetateFileName, getUniqueNumber } from '../../lib/utils.js';
/**
 * @class MSJournal
 * @extends Basic
 * @classdesc Журнал
 * */
export class MSJournal extends Basic {
    enums(type) {
        if (!this._enums) {
            this._enums = {};
        }
        if (!this._enums[type]) {
            if (DataTypes.dataTypes[type] && DataTypes.dataTypes[type].DataType !== `ElementaryType`) {
                this._enums[type] = {};
                const en = DataTypes.dataTypes[type].DisplayValues;
                for (let i = 0; i < en.length; i++) {
                    const el = en[i];
                    this._enums[type][i] = el;
                    this._enums[type][el] = i;
                }
            }
        }
        return this._enums[type];
    }

    static get observedAttributes() {
        return super.observedAttributes.concat([
            'tablecolumns',
            'legendcolumns',
            'rowstyle',
            'headerrowstyle',
            'filters',
            'objectuid',
            'archiveid',
            'interval',
            'till',
            'updateperiod',
            'filtersbackgroundcolor',
            'toolbarbackgroundcolor',
            'fieldstyles',
            'legendbackgroundcolor',
            'limit',
            'showlegend',
            'showtoolbar',
            'autoscroll',
            'usearchive',
            'showfilter',
            'isglobal',
            'hasobjecttree',
            'askackcomment',
            'customFilters',
            'sortOrder',
            'usetimefilter',
            'statusbartextcolor'
        ]);
    }

    constructor() {
        super();
        if (typeof window.customElements.get('ms-dtpicker') === 'undefined') { window.customElements.define('ms-dtpicker', MSDateTimePicker); }
        if (typeof window.customElements.get('ms-interval') === 'undefined') { window.customElements.define('ms-interval', MSInterval); }
        if (!window.customElements.get('ms-toolbar', MSToolbar)) { window.customElements.define('ms-toolbar', MSToolbar); }
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `
            <style>
                @import "./controls/journal/style.css";
            </style>
            <div style="display:flex;flex-direction:column;width:100%;height:100%;">
                <ms-toolbar id='toolbar' style="display: flex; width: 100%; height: 30px; position: relative;"
                buttons='[{"method": "AcknowledgeAll", "class": "hmi-j--all", "tooltip": "Квитировать все", "type": "button"},
                {"method": "Download", "class": "hmi-j-export", "tooltip": "Экспорт", "type": "button"},
                {"method": "Print", "class": "hmi-j-print", "tooltip": "Печать", "type": "button"},
                {"type": "expander"},
                {"method": "setSeverity", "class": ["hmi-j-info","hmi-j-info"], "tooltip": ["Приоритет","Приоритет"], "type": "toggle"},
                {"method": "OpenObjectTree", "class": "hmi-j-tree", "tooltip": "Дерево объекта", "type": "button"},
                {"method": "_showTimeFiltr", "class": ["hmi-j-inerval_go","hmi-j-inerval_stop"], "tooltip": ["Включить фильтр по времени","Выключить фильтр по времени"], "type": "toggle"},
                {"method": "_goData", "class": "hmi-j-select-data", "tooltip": "Перейти к дате", "type": "button"},
                {"method": "_onLegendClick", "class": ["hmi-j-legend","hmi-j-legend"], "tooltip": ["Показать легенду","Скрыть легенду"], "type": "toggle"},
                {"method": "_onAutoPlayClick", "class": ["hmi-j-play", "hmi-j-pause"], "tooltip": ["Автопрокрутка", "Остановить автопрокрутку"], "type": "toggle"},
                {"method": "_onFilterClick", "class": ["hmi-j-filter","hmi-j-filter"], "tooltip": ["Показать фильтр","Скрыть фильтр"], "type": "toggle"},
                {"method": "ClearOptions", "class": "hmi-j-reset_settings", "tooltip": "Сброс", "type": "button"},
                {"method": "_goFirstPage", "class": "hmi-j-step-up", "tooltip": "К первой странице", "type": "button"},
                {"method": "_goLastPage", "class": "hmi-j-step-down", "tooltip": "К последней странице", "type": "button"}]'></ms-toolbar>
                <div style="flex-grow: 99; overflow: hidden;position: relative;">
                    <table class="jr" style="width:100%;border-collapse:separate;border-spacing:0px;table-layout:fixed;">
                        <thead><tr></tr></thead><tbody></tbody>
                    </table>
                </div>
                <div style="display:none;flex-grow:1;border-top: 1px solid rgba(35, 39, 76, 0.5);box-shadow: rgba(35, 39, 76, 0.5) 0px -2px 5px;overflow-y: auto;" id="footer"></div>
                <div style="display:none;flex-grow:1;border-top: 1px solid rgba(35, 39, 76, 0.5);box-shadow: rgba(35, 39, 76, 0.5) 0px -2px 5px; padding: 2px 10px;" id="status"></div>
            </div>`;
        this._start = false;
        this.mouseUp = this.mouseUp.bind(this);
        this.mouseMove = this.mouseMove.bind(this);

        this.mouseUpLegend = this.mouseUpLegend.bind(this);
        this.mouseMoveLegend = this.mouseMoveLegend.bind(this);

        this.needReCreate = true;

        this._loadDown = false;
        this._loadUp = false;

        this._autoscroll = true;
        this._askackcomment = true;
        this._first = true;
        this._select = { uid: '', td: null };
        this._recs = [];
        this._sources = [];
        this._sortRecs = [];
        this._customFilt = {};
        this._filters = [];
        this._clientHandle = 1;
        this._skip = 0;
        this._showLegend = false;

        this.style.display = 'flex';
        this.style.overflow = 'hidden'
        this.style.boxSizing = 'border-box';

        this._main = shadowRoot.querySelector('div');
        this._table = shadowRoot.querySelector('table');
        this._header = this._table.querySelector('thead tr');
        this._toolBar = shadowRoot.getElementById('toolbar');
        this._toolBar.height = 40;
        this._toolBar.context = this;

        this._scrollLeft = 0;
        this._scrollTop = 0;

        this._table.parentNode.onscroll = (e) => {
            e.preventDefault();
            if (this._table.parentElement.scrollLeft != this._scrollLeft) {
                this._scrollLeft = this._table.parentElement.scrollLeft;
            }

            if (this._table.parentElement.scrollTop != this._scrollTop) {

                const delta = this._table.parentElement.scrollTop - this._scrollTop;
                if (!this._autoscrollInit) { //&& this._recs.length >= this._limit
                    if (delta > 0) {
                        const a = this._table.offsetHeight - this._table.parentElement.offsetHeight - 20;
                        if (a <= this._scrollTop && !this._loadDown) {
                            this._loadDown = true;
                            this._onOneForwardClick();
                        }
                    } else {
                        if (this._table.parentElement.scrollTop < 20 && !this._loadUp) {
                            this._loadUp = true;
                            this._onOneBackClick();
                        }
                    }
                }
                this._scrollTop = this._table.parentElement.scrollTop;

                const translate = "translate(0," + this._scrollTop + "px)";

                this._header.parentNode.style.transform = translate;

                for (let index = 0; index < this._hs.length; index++) {
                    const element = this._hs[index];
                    element.sep.style.top = this._scrollTop + 'px';
                    const h = this._table.clientHeight - this._scrollTop < this._table.parentNode.clientHeight ? this._table.clientHeight - this._scrollTop : this._table.parentNode.clientHeight;
                    element.sep.style.height = h + 'px';
                }

                if (this._autoscroll && !this._autoscrollInit) {
                    this.SetParameter('autoscroll', !this._autoscroll, true);
                    this._updatePlayBtn();
                    this.updateStatusBar();
                }

            }
        }

        this._footer = shadowRoot.getElementById('footer');
        this._statusBar = shadowRoot.getElementById('status');

        this._body = shadowRoot.querySelector('tbody');
        this._body.onclick = this._onBodyClick.bind(this);
        this._body.ondblclick = this._onDblClick.bind(this);

        this._toolBar.setVisible(this._toolBar.elements["_onLegendClick"], false);
        this._toolBar.setVisible(this._toolBar.elements["_onFilterClick"], false);

        this._baseFilds = [
            { name: "EventType", type: "STRING" },
            { name: "Acked", type: "BOOL" },
            { name: "Active", type: "BOOL" },
            { name: "EventId", type: "STRING" },
            { name: "Time", type: "DATE_AND_TIME" },
            { name: "UpdateType", type: "INT" },
            { name: "TimeTicks", type: "LINT" },
            { name: "AlarmId", type: "INT" },
            { name: "AckedTime", type: "DATE_AND_TIME" }
        ];
        this._baseFildsDict = {
            EventType: 0,
            Ack: 1,
            Acked: 1,
            Active: 2,
            EventId: 3,
            Time: 4,
            UpdateType: 5,
            TimeTicks: 6,
            AlarmId: 7,
            AckedTime: 8
        };

        this.sw = new journalWorker("journal_" + getUniqueNumber());
        this.sw.upData = this._upData.bind(this);

        this._headerstyle = document.createElement('style');
        this._headerstyle.type = 'text/css';
        shadowRoot.appendChild(this._headerstyle);

        this._rowsstyle = document.createElement('style');
        this._rowsstyle.type = 'text/css';
        shadowRoot.appendChild(this._rowsstyle);
        this._loadMarks();
        this.afterSwitch = this.afterSwitch.bind(this);
        window.addEventListener("ms_message", this.afterSwitch);
        this.setPm();
    }
    setPm() {
        if ($pm.hasPermissions) {
            const ackAll = $pm.checkAllow($pm.getEntryFromElement(this, 'JournalGroupAck'))
            this._toolBar.setEnable(this._toolBar.elements["AcknowledgeAll"], ackAll);

            const print = $pm.checkAllow($pm.getEntryFromElement(this, 'JournalPrint'))
            this._toolBar.setEnable(this._toolBar.elements["Print"], print);

            const download = $pm.checkAllow($pm.getEntryFromElement(this, 'JournalSave'))
            this._toolBar.setEnable(this._toolBar.elements["Download"], download);

            const filters = $pm.checkAllow($pm.getEntryFromElement(this, 'JournalUseFilters'))
            this._toolBar.setEnable(this._toolBar.elements["_onFilterClick"], filters);
        }
    }
    setPmHeader() {
        if (!this._header) return;
        const els = this._header.querySelectorAll('span.hmi-j-filter');
        if ($pm.hasPermissions) {
            for (const el of els) {
                if ($pm.checkAllow($pm.getEntryFromElement(this, 'JournalUseFilters'))) {
                    el.classList.remove('disable');
                } else {
                    el.classList.add('disable');
                }
            }
        }
    }
    afterSwitch(message) {
        const data = message.data;
        switch (data.event) {
            case "afterswitch":
                this.setPm();
                this.setPmHeader();
                this.update()
                break;
        }
    }

    get askackcomment() {
        return this._askackcomment;
    }
    set askackcomment(value) {
        this._askackcomment = this._toBool(value);
    }

    get updateperiod() {
        return this.sw.options.updatePeriod;
    }
    set updateperiod(value) {
        this.sw.options.updatePeriod = Number(value);
        this.sw.options.interval = Number(value);
    }

    get interval() {
        return this._interval;
    }
    set interval(value) {
        this._interval = Number(value);
        if (this._usetimefilter) this.Update();
    }

    get tablecolumns() {
        return this._tablecolumns;
    }
    set tablecolumns(value) {
        let decarator = this.getAttribute('fieldstyles');
        try {
            decarator = JSON.parse(decarator);
        } catch (error) {
            decarator = {};
        }

        try {
            this._tablecolumns = JSON.parse(value).column;

            for (const key in decarator) {
                if (key != "Ack") {
                    const element = decarator[key];
                    const index = this._tablecolumns.findIndex(e => {
                        return e.field === key;
                    });
                    if (index < 0) {
                        this._tablecolumns.push({
                            "displayname": "",
                            "columnwidth": "*",
                            "field": key,
                            "fieldtype": element[Object.keys(element)[0]].FieldType,
                            "valueformat": "",
                            "sort": "0",
                            "sortposition": 0,
                            "visibility": false,
                            "horizontalalign": "1"
                        });
                    }
                }

            }
            this._mergeCol(this._tablecolumns);
        } catch (e) {
            this._tablecolumns = null;
        }
        this._calcHeader();
    }

    get filtersbackgroundcolor() {
        return this._filtersbackgroundcolor;
    }
    set filtersbackgroundcolor(value) {
        this._filtersbackgroundcolor = value;
        this._filterDivSet();
    }

    get legendbackgroundcolor() {
        return this._legendbackgroundcolor;
    }
    set legendbackgroundcolor(value) {
        this._legendbackgroundcolor = value;
        if (this._tableLegend) {
            this._tableLegend.style.backgroundColor = this._legendbackgroundcolor;
        }
    }

    get toolbarbackgroundcolor() {
        return this._toolbarbackgroundcolor;
    }
    set toolbarbackgroundcolor(v) {
        this._toolbarbackgroundcolor = v;
        this._toolBar.backgroundcolor = v;
    }

    get fieldstyles() {
        return this._fieldstyles;
    }
    set fieldstyles(value) {
        try {
            this._fieldstyles = JSON.parse(value);
        } catch (e) {
            this._fieldstyles = null;
        }
    }

    get showlegend() {
        return this._showLegend;
    }
    set showlegend(value) {
        this._showLegend = this._toBool(value);
        this.updateLegend();
    }

    get showtoolbar() {
        return this._showtoolbar;
    }
    set showtoolbar(value) {
        this._showtoolbar = this._toBool(value);
        this._toolBar.style.display = this._showtoolbar ? 'flex' : 'none';
    }

    get autoscroll() {
        return this._autoscroll;
    }

    set autoscroll(value) {
        this._autoscroll = this._toBool(value);
        this._updatePlayBtn();
    }


    get usearchive() {
        return this._usearchive;
    }
    set usearchive(value) {
        this._usearchive = this._toBool(value);
        if (this._usearchive) {
            this._calcHeader();
        } else {
            this._toolBar.setVisible(this._toolBar.elements["_showTimeFiltr"], false);
            const mark = this._header.querySelector('#mark');
            if (mark) {
                this._header.querySelector('#mark').remove();
            }
        }
    }

    get till() {
        this._till;
    }
    set till(value) {
        this._till = Number(value);
        if (this._usetimefilter) this.Update();
    }

    get usetimefilter() {
        return this._usetimefilter;
    }
    set usetimefilter(value) {
        this._usetimefilter = this._toBool(value);
        this._toolBar.setToggleState(this._toolBar.elements["_showTimeFiltr"], this._usetimefilter);
        this._toolBar.setEnable(this._toolBar.elements["_onAutoPlayClick"], !this._usetimefilter);
        if (this._usetimefilter && this._autoscroll) this._onAutoPlayClick();
        this.Update();
    }

    get customFilters() {
        return this._customFilt;
    }
    set customFilters(value) {
        this._customFilt = value;
        for (const key in this._customFilt) {
            const btn = this._header.querySelector(`th #${key}`);
            if (btn) {
                const th = btn.parentElement.parentElement;
                this._setThFilterStyle(th, btn);
            }
        }
        this.updateSeverityState();
    }

    get sortOrder() {
        return {
            index: this._cacheSort.index,
            forward: this._cacheSort.forward,
            id: this._cacheSort.id
        };
    }
    set sortOrder(value) {
        if (this._cacheSort && this._cacheSort.index === value.index) {
            this._cacheSort.forward = value.forward;
        } else {
            const elCont = this._header.querySelector(`th#${value.id}`);
            if (elCont == null)
                return;
            const el = document.createElement('div');
            elCont.firstChild.insertBefore(el, elCont.firstChild.firstChild);
            this._cacheSort = {
                index: value.index,
                forward: value.forward,
                id: value.id,
                el: el
            };
        }
        const ico = this._cacheSort.forward ? 'hmi-j-step-up' : 'hmi-j-step-down';
        this._cacheSort.el.className = `btn ${ico}`;
        this.update();
    }

    _calcHeader() {
        const bookmarks = this._usearchive ? '<th id="mark" style="width:20px"><div><span class="btn hmi-j-e-marker"></span></div></th>' : '';
        let h = `<th style="width:20px"></th>${bookmarks}`;
        this._hidePrintCol = this._usearchive ? [0, 1] : [0];
        let ih = this._usearchive ? 2 : 1;

        const fnSize = document.createElement('span');
        fnSize.style.fontSize = this.headerrowstyle.fontsize;
        fnSize.style.fontStyle = this._toBool(this.headerrowstyle.fontitalic) ? 'italic' : 'normal';
        fnSize.style.textDecoration = this._toBool(this.headerrowstyle.fontunderlined) ? 'underline' : '';
        fnSize.style.fontWeight = this._toBool(this.headerrowstyle.fontbold);
        fnSize.style.fontFamily = this.headerrowstyle.fontname;
        document.body.appendChild(fnSize);
        let size = this._usearchive ? 48 : 24;
        let stars = 0;
        for (const col of this._tablecolumns) {
            if (col.visibility) {
                if (col.columnwidth.toString().startsWith('*')) {
                    stars += col.columnwidth.split('*').length - 1;
                    continue;
                }
                const tSize = Number(col.columnwidth);
                if (Number.isNaN(tSize)) {
                    fnSize.innerText = col.displayname;
                    col.columnwidth = fnSize.getBoundingClientRect().width + (col.field === 'Ack' ? 10 : 40);
                    size += (col.columnwidth + 4);
                } else {
                    size += (tSize + 4);
                }
            }
        }
        const oneStar = ((this.getAttribute('width') - size - 2) / stars) - 4;
        document.body.removeChild(fnSize)

        for (let i = 0; i < this._tablecolumns.length; i++) {
            const el = this._tablecolumns[i];
            if (this._toBool(el.visibility)) {
                let btn = '';
                const fl = el.enablefilter ? ' class="btn hmi-j-filter"' : ''
                switch (el.fieldtype) {
                    case '':
                    case 'STRING':
                    case 'BOOL':
                    case 'BYTE':
                    case 'INT':
                    case 'DINT':
                    case 'DATE_AND_TIME':
                    case 'DATE':
                    case 'TIME':
                    case 'LREAL':
                        if (el.field === 'Ack') {
                            this._hidePrintCol.push(i + ih);
                            btn = `<span id='Acked' data-type="BOOL"${fl}></span>`
                            break;
                        }
                        btn = `<span id='${el.field}' data-type="${el.fieldtype}"${fl}></span>`
                        break;
                    default:
                        if (DataTypes.dataTypes[el.fieldtype]) {
                            btn = `<span id='${el.field}' data-type="ENUM" data-enum="${el.fieldtype}"${fl}></span>`
                        }
                }

                if (el.sort != 0) {
                    const i = this._baseFildsDict[el.field];
                    if (i > -1) {
                        this._cacheSort = {
                            index: i,
                            forward: Number(el.sort) === 1,
                            el: null,
                            field: el.field
                        };
                    }
                }

                const w = parseInt(el.columnwidth) ? parseInt(el.columnwidth) + 'px' : (el.columnwidth.split('*').length - 1) * oneStar;
                h += `<th align="center" style="width:${w};" id='${el.field}'><div><div>${el.displayname}</div>${btn}</div></th>`;
            }
            //ih++;
        }

        this._header.innerHTML = h;
        if (this._cacheSort) {
            const elt = this._header.querySelector(`#${this._cacheSort.field}`).firstChild;
            const el = document.createElement('div');
            el.className = !this._cacheSort.forward ? 'btn hmi-j-step-down' : 'btn hmi-j-step-up';
            this._cacheSort.el = el;
            elt.insertBefore(el, elt.firstChild);
        }
        this._header.onclick = this._onHeaderClick.bind(this);
        if (bookmarks) {
            this._header.querySelector('#mark').onclick = this._onMarksClick.bind(this);
        }
        this._hs = [];
        this.setPmHeader();
        window.requestAnimationFrame(() => {
            if (!this._table) return;
            let sep = this._table.parentNode.querySelectorAll('div#sp');
            if (sep.length > 0) {
                sep.forEach(element => {
                    element.remove();
                });
                this._hs = [];
            }
            let tw = 0;
            for (let i = 0; i < this._header.childNodes.length; i++) {
                const last = i === this._header.childNodes.length - 1 ? -2 : 0;
                const el = this._header.childNodes[i];
                const div = document.createElement('div');

                div.style.position = 'absolute';
                div.style.top = this._table.offsetTop;
                div.style.height = this._table.parentNode.clientHeight + 'px';
                div.style.left = (el.offsetLeft + el.clientWidth + last) + 'px';
                div.style.width = '4px';
                div.style.backgroundColor = 'transparent';
                div.style.cursor = 'col-resize';
                div.style.zIndex = 1;
                div.id = 'sp';
                this._table.parentNode.appendChild(div);

                const index = this._hs.push({ l: el.offsetLeft, w: el.clientWidth - 2, el: el, sep: div }) - 1;
                tw += el.clientWidth;
                el.style.width = (el.clientWidth - 2) + 'px';
                div._el = this._hs[index];
                div._index = index;

                div.onmousedown = this.headerSizeMoveSart.bind(this);
            }
            this._table.style.width = tw + 'px';

        });
    }

    legendSizeMoveStart(e) {
        this._legendSizeTarget = e.target;
        this._legendSizeTarget.style.backgroundColor = 'rgba(165, 42, 42, 0.19)';

        document.addEventListener('mousemove', this.mouseMoveLegend);
        document.addEventListener('mouseup', this.mouseUpLegend);
    }
    mouseMoveLegend(e) {
        const mainCoords = this.getCoords(this._main);
        const shiftY = mainCoords.top;
        const scale = mainCoords.height / this._main.offsetHeight;
        const newTop = (e.pageY - shiftY) / scale;
        const newHeight = newTop - this._footer.offsetTop;
        this._legendHeight = this._footer.offsetHeight - newHeight;
        this.resizeLegend();
    }
    mouseUpLegend(e) {
        if (this._legendSizeTarget) { this._legendSizeTarget.style.backgroundColor = 'transparent'; }

        document.removeEventListener('mousemove', this.mouseMoveLegend);
        document.removeEventListener('mouseup', this.mouseUpLegend);

        this._legendSizeTarget = null;

        return false;
    }

    headerSizeMoveSart(e) {
        this._headerSizetarget = e.target;
        this._headerSizetarget.style.backgroundColor = 'rgba(165, 42, 42, 0.19)';

        document.addEventListener('mousemove', this.mouseMove);
        document.addEventListener('mouseup', this.mouseUp);

        return false;
    }
    mouseMove(e) {
        const mainCoords = this.getCoords(this._main);
        const shiftX = mainCoords.left;
        const scale = mainCoords.width / this._main.clientWidth;

        //  вычесть координату родителя, т.к. position: relative
        let newLeft = (e.pageX - shiftX) / scale + this._scrollLeft // ;
        if (newLeft < (this._headerSizetarget._el.l + 22)) {
            newLeft = this._headerSizetarget._el.l + 22;
        }

        this._headerSizetarget.style.left = newLeft + 'px';
        this._headerSizetarget._el.w = newLeft - this._headerSizetarget._el.el.offsetLeft;
        this._headerSizetarget._el.el.style.width = this._headerSizetarget._el.w + 'px';
        let tw = 0;
        for (let index = 0; index < this._hs.length; index++) {
            const element = this._hs[index];
            tw += element.w;
        }
        this._table.style.width = tw + 'px';
    }

    mouseUp() {
        if (this._headerSizetarget) { this._headerSizetarget.style.backgroundColor = 'transparent'; }

        document.removeEventListener('mousemove', this.mouseMove);
        document.removeEventListener('mouseup', this.mouseUp);

        for (let index = 0; index < this._hs.length; index++) {
            const element = this._hs[index];
            element.sep.style.left = (element.el.offsetLeft + element.el.clientWidth) + 'px';
        }
        this._headerSizetarget = null;
    }

    getCoords(elem) {
        var box = elem.getBoundingClientRect();

        return {
            top: box.top,
            left: box.left,
            width: box.width,
            height: box.height
        };

    }

    get statusbartextcolor() {
        return this._statusBar.style.color;
    }
    set statusbartextcolor(value) {
        this._statusBar.style.color = value
    }

    get legendcolumns() {
        return this._legendcolumns;
    }
    set legendcolumns(value) {
        try {
            this._legendcolumns = JSON.parse(value).column;
            if (!Array.isArray(this._legendcolumns)) {
                this._legendcolumns = [this._legendcolumns];
            }
            this._toolBar.setVisible(this._toolBar.elements["_onLegendClick"], true);
            this._mergeCol(this._legendcolumns);
        } catch (e) {
            this._legendcolumns = null;
            this._toolBar.setVisible(this._toolBar.elements["_onLegendClick"], false);;
        }
    }

    get limit() {
        return this._limit || 100;
    }
    set limit(value) {
        const a = Number(value)
        this._limit = a > 100 ? a : 100;
    }

    get rowstyle() {
        return this._rowstyle;
    }
    set rowstyle(value) {
        try {
            this._rowstyle = JSON.parse(value);
        } catch (e) {
            this._rowstyle = null;
        }

        if (this._tableLegend) {
            this._tableLegend.style.fontFamily = this._rowstyle.fontname;
            this._tableLegend.style.fontSize = this._rowstyle.fontsize;
        }


        let style = '';
        if (this._rowstyle) {
            if (this._rowstyle.backgroundcolor) { style += `background-color:${this._rowstyle.backgroundcolor};` };
            if (this._rowstyle.bordercolor) { style += `border-color:${this._rowstyle.bordercolor};--main-c:${this._rowstyle.bordercolor};` };
            if (this._rowstyle.borderthickness) { style += `--main-s:solid none;--main-w:${this._rowstyle.borderthickness}px;border-width:${this._rowstyle.borderthickness}px;border-style: solid;` };
            if (this._rowstyle.fontbold) { style += `font-weight:${this._toBool(this._rowstyle.fontbold) ? 'bold' : 'normal'};` };
            if (this._rowstyle.fontitalic) { style += `font-style:${this._toBool(this._rowstyle.fontitalic) ? 'italic' : 'normal'};` };
            if (this._rowstyle.fontname) { style += `font-family:${this._rowstyle.fontname};` };
            if (this._rowstyle.fontsize) { style += `font-size:${this._rowstyle.fontsize}px;` };
            if (this._rowstyle.fontunderlined) { style += `text-decoration:${this._toBool(this._rowstyle.fontunderlined) ? 'underline' : 'none'};` };
            if (this._rowstyle.textcolor) { style += `color:${this._rowstyle.textcolor};` };

            if (Number(this._rowstyle.height)) {
                style += `height:${this._rowstyle.height}px;`;
            } else {
                style += `min-height:24px;height:24px;`;
            }

        }

        this._rowsstyle.innerHTML = `:host .jr tbody tr{${style}} :host .jr tbody tr td{border-width: var(--main-w);border-style: var(--main-s);border-color: var(--main-c);overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}`;

    }

    get headerrowstyle() {
        if (!this._headerrowstyle) {
            try {
                this._headerrowstyle = JSON.parse(this.getAttribute('headerrowstyle'));
            } catch (e) {
                this._headerrowstyle = null;
            }
        }
        return this._headerrowstyle;
    }
    set headerrowstyle(value) {
        try {
            this._headerrowstyle = JSON.parse(value);
        } catch (e) {
            this._headerrowstyle = null;
        }


        let style = '';
        if (this._headerrowstyle) {
            if (this._headerrowstyle.backgroundcolor) { style += `background-color:${this._headerrowstyle.backgroundcolor};` };
            if (this._headerrowstyle.bordercolor) { style += `border-color:${this._headerrowstyle.bordercolor};` };
            if (this._headerrowstyle.borderthickness) { style += `border-width:${this._headerrowstyle.borderthickness};border-style: solid;` };
            if (this._headerrowstyle.fontbold) { style += `font-weight:${this._toBool(this._headerrowstyle.fontbold) ? 'bold' : 'normal'};` };
            if (this._headerrowstyle.fontitalic) { style += `font-style:${this._toBool(this._headerrowstyle.fontitalic) ? 'italic' : 'normal'};` };
            if (this._headerrowstyle.fontname) { style += `font-family:${this._headerrowstyle.fontname};` };
            if (this._headerrowstyle.fontsize) { style += `font-size:${this._headerrowstyle.fontsize}px;` };
            if (this._headerrowstyle.fontunderlined) { style += `text-decoration:${this._toBool(this._headerrowstyle.fontunderlined) ? 'underline' : 'none'};` };
            if (this._headerrowstyle.textcolor) { style += `color:${this._headerrowstyle.textcolor};` };

            if (Number(this._headerrowstyle.height)) { style += `height:${this._headerrowstyle.height}px;` }

        }

        this._headerstyle.innerHTML = `:host .jr th{${style}overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}`;

    }

    get filters() {
        return this._filters;
    }
    set filters(value) {
        try {
            if (typeof value === 'string') {
                this._filters = JSON.parse(value).filter;
            } else {
                this._filters = value;
                if (this._filterDiv) {
                    this._filterDiv.firstChild.innerHTML = this._generateFilterList();
                }
            }
            if (typeof this._filters === 'object' && !Array.isArray(this._filters)) this._filters = [this._filters];
            this._toolBar.setVisible(this._toolBar.elements["_onFilterClick"], true);
        } catch (e) {
            this._filters = null;
            this._toolBar.setVisible(this._toolBar.elements["_onFilterClick"], false);
        }
    }

    get objectuid() {
        return this._objectuid;
    }
    set objectuid(value) {
        this._objectuid = Number(value);
        if (typeof value === 'string' && Number.isNaN(this._objectuid))
            this._objectuid = value;
            
        this._reMonitoredEvents();
    }

    get archiveid() {
        return this._archiveid;
    }
    set archiveid(value) {
        this._archiveid = Number(value);
    }

    get showfilter() {
        return this._showfilter;
    }
    set showfilter(value) {
        this._showfilter = this._toBool(value);
        this._onFilterClick(null, this._showfilter);
    }

    get isglobal() {
        return this._isglobal;
    }
    set isglobal(value) {
        this._isglobal = this._toBool(value);
    }

    get hasobjecttree() {
        return this._hasobjecttree;
    }
    set hasobjecttree(value) {
        this._hasobjecttree = this._toBool(value);
        this._toolBar.setVisible(this._toolBar.elements["OpenObjectTree"], this._hasobjecttree);
    }

    _mergeCol(colums, mergeType) {
        const compare = (name, type, ind) => {
            let i;
            if (name == 'Ack') {
                i = 1;
            } else {
                i = this._baseFildsDict[name];
            }

            if (i == undefined) {
                const t = type && DataTypes.dataTypes[type] && DataTypes.dataTypes[type].DataType === 'EnumeratedType' ? 'INT' : type;
                const newIndex = this._baseFilds.push({ name: name, type: t });
                if (ind != undefined) {
                    this._baseFildsDict[name] = colums[ind]['baseIndex'] = newIndex - 1;
                }
            } else {
                if (ind != undefined)
                    colums[ind]['baseIndex'] = this._baseFildsDict[name];
            }
        }
        if (mergeType) {
            for (const key in colums) {
                const element = colums[key];
                compare(key, element[Object.keys(element)[0]].FieldType);
            }
        } else {
            for (let ind = 0; ind < colums.length; ind++) {
                const element = colums[ind];
                if (typeof element.fieldtype != 'undefined') {
                    compare(element.field, element.fieldtype, ind);
                }
            }
        }
    }

    connectedCallback() {
        if (typeof this.saveStateFlag === 'undefined') {
            this.saveStateFlag = this.calcSaveState();
        }
        if (this.saveStateFlag) {
            this.updateItemState();
        }
        if (this._usetimefilter && this._autoscroll) this._onAutoPlayClick();
        this.updateStatusBar();
        this._start = true;
        this.Update();
        this.sw.Subscribe().then(this._createMonitoredEvents.bind(this)).then(this.sw.StartWatch.bind(this.sw));
    }

    async disconnectedCallback() {
        super.disconnectedCallback();
        for (let i = 0; i < this._hs.length; i++) {
            const el = this._hs[i];
            el.sep.onmousedown = null;
            el.sep = null
            el.el = null
        }
        this._hs = null;
        if (this._cacheSort && this._cacheSort.el) {
            this._cacheSort.el.remove();
            this._cacheSort.el = null;
            delete this._cacheSort.el;
        }
        this._body.onclick = null;
        this._body.ondblclick = null;
        this._body.innerHTML = ''
        this._body.remove();
        // this._body.children
        delete this._body;
        delete this._filterDiv;
        delete this._footer;
        delete this._header;
        delete this._toolBar;
        delete this._table;
        delete this._headerrowstyle;
        delete this._headerstyle;
        delete this._statusBar;
        delete this._main;
        delete this._rowsstyle;
        delete this._sortRecs;
        delete this._recs;
        delete this._tableLegend;
        window.removeEventListener("ms_message", this.afterSwitch);
        this.sw.StopWatch();
        if (this.monitoredItemId) { await this.sw.DeleteMonitoredEvents(this.monitoredItemId); delete this.monitoredItemId; }
        this.sw.ServerAdapter.dispose();
        this.mouseMove = null;
        this.mouseUp = null;
    }

    _getItemId() {
        let result = {};
        if (!this._isglobal) {
            if (this._objectuid === 0) {
                result.itemId = $sw.ItemSubscription._getParentParam(this, "objectid", true);
                result.taskId = $sw.ItemSubscription._getParentParam(this, "taskid", true);
            } else if (typeof this._objectuid === 'string') {
                result.itemId = 0;
                result.path = this._objectuid;
            } else {
                result.itemId = this._objectuid;
            }
        }
        return result;
    }

    _calcFilters() {
        if (!this._toolBar) return;
        const res = [];

        for (let i = 0; i < this._filters.length; i++) {
            const element = this._filters[i];
            if (this._toBool(element.enabled)) {
                res.push(element.condition);
            }
        }

        const active = res.length > 0;
        this._toolBar.setToggleState(this._toolBar.elements["_onFilterClick"], active);

        const obj_res = [];

        this._sources.forEach(el => {
            obj_res.push(`ItemId :> ${el}`);
        });
        if (obj_res.length > 0) {
            res.push(obj_res.join(' or '));
        }

        for (const key in this._customFilt) {
            if (this._customFilt.hasOwnProperty(key)) {
                const el = this._customFilt[key];
                switch (el.type) {
                    case 'STRING':
                        res.push(`${key} Contains "${el.value}"`);
                        break;
                    case 'BOOL':
                        res.push(`${key} == ${el.value}`);
                        break;
                    case 'ENUM':
                        let t = [];
                        for (let i = 0; i < el.value.length; i++) {
                            const e = el.value[i];
                            if (e) {
                                t.push(`${key} == ${i}`);
                            }
                        }
                        if (t.length > 0) res.push(t.join(' or '));
                        break;
                    case 'NUMBER':
                        if (el.value.min) { res.push(`${key} >= ${el.value.min}`); }
                        if (el.value.max) { res.push(`${key} <= ${el.value.max}`); }
                        break;
                    case 'DATE_AND_TIME':
                        if (el.value.min) { res.push(`${key} >= ${el.value.min * 10000 + 116444736000000000}`); }
                        if (el.value.max) { res.push(`${key} <= ${el.value.max * 10000 + 116444736000000000}`); }
                        break;
                }
            }
        }
        return res;
    }

    async _createMonitoredEvents() {
        let packet = {
            clientHandle: this._clientHandle++,
            fields: this._baseFilds,
            filter: this._calcFilters(),
            path: '',
            taskId: 0,
        }
        if (this._usearchive) {
            packet.useArchive = true;
        }

        packet = Object.assign(packet, this._getItemId())

        return await this.sw.CreateMonitoredEvents([packet])
            .then((data) => {
                this._busyMonitoredEvents = false;
                this.monitoredItemId = data.items[0].monitoredItemId;
                if (this.needReCreate) {
                    this.needReCreate = false;
                    this._reMonitoredEvents();
                    return;
                }
                if (this._usearchive) {
                    let start = 0, end = 0;
                    if (this._usetimefilter) {
                        start = this._till - this._interval;
                        end = this._till;
                    }
                    this._getArchived(start, end);

                } else {
                    this.sw.RefreshEvents();
                    this._recs = [];
                    this.update();
                }
            });
    }

    async _getArchived(timeStart, timeEnd, continuationPoint, inverse) {
        if (!this._start) return;
        if (typeof inverse == 'undefined') { inverse = true; }
        let packet = {
            inverse: inverse,
            endTime: timeEnd,
            fields: this._baseFilds,
            filter: this._calcFilters(),
            maxRecs: this._limit,
            maxSize: 0,
            path: '',
            startTime: timeStart,
        }
        if (typeof this._archiveid != 'undefined')
            packet.archiveId = this._archiveid;

        packet = Object.assign(packet, this._getItemId());

        if (continuationPoint) {
            packet['continuationPoint'] = continuationPoint;
        }

        return this.sw.getArchivedEvents(packet)
            .then(data => {
                if (data.code != 0) { console.log(data.code.toString(16)); return; }
                if (data.recs) {
                    if (continuationPoint) {
                        const ind = data.recs.findIndex(el => el[3] === continuationPoint);
                        if (ind > -1) data.recs.splice(ind, 1);
                    }
                    if (data.recs.length > 0) {
                        if (inverse) {
                            this._recs = data.recs;
                        } else {
                            this._recs = data.recs.reverse();
                        }

                        this.update();
                        if (inverse) {
                            this._table.parentElement.scrollTop = 0;
                        } else {
                            this._table.parentElement.scrollTop = this._table.parentElement.scrollHeight - this._table.parentElement.clientHeight;
                        }

                    } else {
                        this._recs = [];
                        this._table.parentElement.scrollTop = 0;
                        this.update();
                    }
                }
            }).catch(error => {
                console.log('error', error);
            });

    }

    _upData(ans) {
        if (typeof this._recs === 'undefined') return;
        let isChanged = false;
        const recs = ans.recs.sort((a, b) => a.fields[4] - b.fields[4]) || [];
        const del = ans.deleted || [];
        let shift = 0;
        for (let index = 0; index < recs.length; index++) {
            const element = recs[index];

            const i = this._recs.findIndex(item => {
                if (this._usearchive)
                    return item[3] === element.fields[3];
                else
                    return item[3].substr(13) === element.fields[3].substr(13);
            });
            switch (element.recType) {
                case 'Update':
                    if (this._usearchive) {
                        if (this._first && this._autoscroll) {

                            this._recs.splice(0, 0, element.fields);
                            if (this._recs.length > this.limit && this._usearchive) {
                                this._recs.pop();
                            }
                        } else {
                            this._skip++;
                        }
                    } else {
                        if (i < 0) {
                            this._recs.push(element.fields);
                        } else {
                            this._recs[i] = element.fields;
                        }
                    }

                    break;
                case 'UpdateArchive':
                    if (this._usearchive) {
                        if (i >= 0) {
                            this._recs[i] = element.fields;
                        } else if (this._autoscroll) {
                            if (this._recs.length > 0 && this._recs[0][4] <= element.fields[4]) {
                                this._recs.splice(0, 0, element.fields);
                                if (this._recs.length > this.limit) {
                                    this._recs.pop();
                                }
                            }
                        }
                    }
                    break;
                case 'Refresh':
                    if (i < 0) {
                        this._recs.push(element.fields);
                    } else {
                        this._recs[i] = element.fields;
                    }
                    break;
                case 'Acknowledge':
                    break;
            }
            isChanged = true;
        }

        this.updateStatusBar();

        for (let index = 0; index < del.length; index++) {
            const element = del[index];
            element.eventIds.forEach(el => {
                const i = this._recs.findIndex(item => {
                    if (this._usearchive)
                        return item[3] === el;
                    else
                        return item[3].substr(13) === el.substr(13);
                });
                if (i > -1) {
                    this._recs.splice(i, 1);
                }
            });
            isChanged = true;
        }
        if (isChanged) {
            let scroll = 0;

            if (shift) {
                scroll = this._table.parentElement.scrollTop;
            }

            this.update();

            if (shift) {
                const offset = this._body.firstChild.offsetHeight * shift;
                this._table.parentElement.scrollTop = scroll + offset;
            }

        }
    }


    /**
     * Renderer body table
     *
     * @memberof MSJournal
     */
    update() {
        if (!this._body) return;
        const status = MSJournal.status;
        let journalAck = true;
        if ($pm.hasPermissions) {
            journalAck = $pm.checkAllow($pm.getEntryFromElement(this, 'JournalAck'));
        }

        const hAlign =
        {
            0: 'left',
            1: 'center',
            2: 'right'
        }

        this.updateLegend();

        if (this._cacheSort && !this._usearchive) {
            if (this._cacheSort.index > -1) {
                this._baseFilds[this._cacheSort.index]
                this._sortRecs = Array.from(this._recs);
                this._sortRecs.sort((a, b) => {
                    const iA = typeof a[this._cacheSort.index] === 'string' ? a[this._cacheSort.index].toLowerCase() : a[this._cacheSort.index];
                    const iB = typeof b[this._cacheSort.index] === 'string' ? b[this._cacheSort.index].toLowerCase() : b[this._cacheSort.index];
                    if (iA < iB)
                        return -1;
                    if (iA > iB)
                        return 1;
                    return 0;
                });
            }
            if (!this._cacheSort.forward) { this._sortRecs.reverse(); }
        } else {
            this._sortRecs = this._recs;
        }
        if (this._sortRecs.length < this._body.childNodes.length) {
            const count = this._body.childNodes.length - this._sortRecs.length;
            for (let i = 0; i < count; i++) {
                this._body.lastChild.remove();
            }
        }

        const timeOffset = new Date().getTimezoneOffset() * 60000;

        for (let index = 0; index < this._sortRecs.length; index++) {
            let offset = 0;
            const tr = this._getRow(index);
            tr.removeAttribute("style");
            const element = this._sortRecs[index];

            const marker = this._getCol(tr, offset++);
            if (this._select.rec && (element[3] == this._select.rec[3])) {
                marker.innerHTML = this._marker();
            } else if (marker.innerHTML != '') {
                marker.innerHTML = '';
            }

            if (this._usearchive) {
                const bookmark = this._getCol(tr, offset++);
                bookmark.setAttribute('smark', '');
                if (this._bookmarks[element[3]]) {
                    bookmark.innerHTML = '<span align="center" style="pointer-events: none; font-size: medium;" class="btn hmi-j-f-marker"></span>';
                } else {
                    bookmark.innerHTML = '';
                }
            }

            if (this._usearchive && element[5] !== 1) { element[1] = true };

            for (let i = 0; i < this._tablecolumns.length; i++) {
                const col = this._tablecolumns[i];
                if (!col.visibility) continue;
                const td = this._getCol(tr, offset++);
                td.setAttribute('align', hAlign[col.horizontalalign]);
                switch (col.field) {
                    case 'Ack':
                        if (!element[col.baseIndex]) {

                            td.innerHTML = `<button class="ack" id="${element[3]}"${journalAck ? '' : ' disabled'}>квит</button></td>`;
                        } else {
                            if (col.valueformat) {
                                const val = element[8] !== 0 ? _df.dateFormat(element[8], col.valueformat) : '';
                                td.innerHTML = val;
                            } else if (td.innerHTML != '') {
                                td.innerHTML = '';
                            }
                        }
                        break;
                    case 'Icon':
                        const path = `_event_${element[0]}`;
                        const res = this.getResourceFromList(path)
                        if (path !== res) {
                            td.innerHTML = `<img src="resources/${res}" style="width: 20px;display: block;"></img>`;
                        }
                        break;
                    default:
                        if (typeof element[col.baseIndex] != 'undefined') {
                            let isDT = false;
                            switch (col.fieldtype) {
                                case 'DT':
                                case 'DATE_AND_TIME':
                                    if (!col.valueformat) col.valueformat = 'dd.MM.yyyy HH:mm:ss';
                                    //if (element[col.baseIndex]) element[col.baseIndex] -= timeOffset;
                                    isDT = true;
                                    break;
                                case 'DATE':
                                    if (!col.valueformat) col.valueformat = 'dd.MM.yyyy';
                                    //if (element[col.baseIndex]) element[col.baseIndex] -= timeOffset;
                                    isDT = true;
                                    break;
                                case 'TIME':
                                case 'TOD':
                                case 'TIME_OF_DAY':
                                    if (element[col.baseIndex]) element[col.baseIndex] += timeOffset;
                                    if (!col.valueformat) col.valueformat = 'HH:mm:ss';
                                    isDT = true;
                                    break;
                            }
                            if (isDT) {
                                const val = element[col.baseIndex] !== 0 ? _df.dateFormat(element[col.baseIndex], col.valueformat) : '';
                                td.innerHTML = val;
                            } else if (Object.keys(this.enums(col.fieldtype) || {}).length > 0) {
                                td.innerHTML = this.enums(col.fieldtype)[parseInt(element[col.baseIndex])];
                            } else {
                                let formatVal
                                if (col.valueformat) {
                                    try {
                                        formatVal = String.format(col.valueformat, element[col.baseIndex].toString());
                                    } catch (error) {
                                        formatVal = element[col.baseIndex];
                                    }
                                } else {
                                    formatVal = element[col.baseIndex];
                                }
                                td.innerHTML = formatVal;
                            }
                        }
                }
            }

            const filds = Object.keys(this._fieldstyles);
            if (!this._fieldstylesDict) this._fieldstylesDict = {};
            if (filds.length > 0) {
                for (let inf = 0; inf < filds.length; inf++) {
                    const filKey = filds[inf];
                    if (!this._fieldstylesDict[filKey]) {
                        this._fieldstylesDict[filKey] = this._baseFildsDict[filKey];
                    }
                    for (const k in this._fieldstyles[filKey]) {
                        if (this._fieldstyles[filKey].hasOwnProperty(k)) {
                            const el = this._fieldstyles[filKey][k];
                            const resault = Converter.convert(el, element[this._fieldstylesDict[filKey]], el.FieldType);
                            switch (k) {
                                case 'FontItalic':
                                    if (resault) {
                                        tr.style.fontStyle = "italic";
                                    }
                                    break;
                                case 'FontBold':
                                    if (resault) {
                                        tr.style.fontWeight = "bold";
                                    }
                                    break;
                                case 'FontUnderlined':
                                    if (resault) {
                                        tr.style.textDecoration = "underline";
                                    }
                                    break;

                                case 'TextColor':
                                    if (resault) {
                                        tr.style.color = resault;
                                    }
                                    break;
                                case 'FontSize':
                                    if (resault) {
                                        tr.style.fontSize = `${resault}px`;
                                    }
                                    break;
                                case 'FontName':
                                    if (resault) {
                                        tr.style.fontFamily = resault;
                                    }
                                    break;
                                case 'BackgroundColor':
                                    if (resault) {
                                        tr.style.backgroundColor = resault;
                                    }
                                    break;
                                case 'BorderColor':
                                    if (resault) {
                                        tr.style.setProperty('--main-c', resault);
                                    }
                                    break;
                                case 'BorderThickness':
                                    if (resault) {
                                        tr.style.setProperty('--main-w', resault);
                                    }
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
            }
            tr.id = element[3];

        }
        if (this._select.rec && this._select.rec[3]) {
            const el = this._body.querySelector(`[id="${this._select.rec[3]}"`);
            if (el) { this._select.td = el.firstChild; }
        }
        this.updateStatusBar();
        requestAnimationFrame(() => {
            if (this._table) this._table.parentElement.style.overflow = 'auto';
        });
    }

    _getRow(index) {
        if (this._body.children[index]) {
            return this._body.children[index];
        } else {
            const tr = document.createElement('tr');
            this._body.appendChild(tr);
            return tr;
        }
    }

    _getCol(row, index) {
        if (row.children[index]) {
            return row.children[index];
        } else {
            const td = document.createElement('td');
            row.appendChild(td);
            return td;
        }
    }

    updateLegend() {
        if (!this._legendcolumns) return;
        this._toolBar.setToggleState(this._toolBar.elements["_onLegendClick"], this._showLegend);
        if (this._showLegend) {
            this._footer.style.display = 'flex';
            let trsLegend = '';

            for (let i = 0; i < this._legendcolumns.length; i++) {
                const col = this._legendcolumns[i];
                if (col.visibility) {
                    let value = this._select.rec ? this._select.rec[col.baseIndex] : '';
                    let isDT = false;
                    switch (col.fieldtype) {
                        case 'DATE_AND_TIME':
                            if (!col.valueformat) col.valueformat = 'dd.MM.yyyy HH:mm:ss';
                            isDT = true;
                            break;
                        case 'DATE':
                            if (!col.valueformat) col.valueformat = 'dd.MM.yyyy';
                            isDT = true;
                            break;
                        case 'TIME':
                            if (!col.valueformat) col.valueformat = 'HH:mm:ss';
                            isDT = true;
                            break;
                        default:
                            if (Object.keys(this.enums(col.fieldtype) || {}).length > 0) {
                                value = this.enums(col.fieldtype)[parseInt(value)];
                            }
                    }
                    value = isDT && value != 0 ? _df.dateFormat(value, col.valueformat) : value;
                    let align;
                    switch (col.horizontalalign) {
                        default:
                        case "0":
                            align = 'style="text-align: left;"';
                            break;
                        case "1":
                            align = 'style="text-align: center;"';
                            break;
                        case "2":
                            align = 'style="text-align: right;"';
                            break;
                    }
                    if (col.field === 'Icon' && this._select.rec) {
                        const path = `_event_${this._select.rec[0]}`;
                        const res = this.getResourceFromList(path)
                        if (path !== res) {
                            value = `<img src="resources/${res}" style="width: 20px;"></img>`;
                        }
                    }
                    trsLegend += `<tr><td>${col.displayname}</td><td ${align}>${value}</td></tr>`;
                }
            }

            if (!this._tableLegend) {
                this._tableLegend = document.createElement('table');
                this._tableLegend.classList.add('legend');
                this._tableLegend.style.width = '100%';
                this._tableLegend.style.borderSpacing = '0';
                if (this._rowstyle) {
                    this._tableLegend.style.fontFamily = this._rowstyle.FontName;
                    this._tableLegend.style.fontSize = this._rowstyle.FontSize;
                }
                this._tableLegend.style.backgroundColor = this._legendbackgroundcolor;
                this._footer.innerHTML = `
                    <style> 
                        :host table.legend tr{height: 1.5em;}
                        :host table.legend td{border-top: 1px dashed #23274c21;}
                        :host table.legend td:first-child{width: max-content; white-space: nowrap;padding: 0 10px;}
                        :host table.legend td:last-child{width: 100%;}
                    </style>
                    <div style="position:absolute;left:0;right:0;height:5px;z-index:2;cursor:row-resize;"></div>
                `;
                this._tableLegendSeparator = this._footer.querySelector('div');
                this._tableLegendSeparator.onmousedown = this.legendSizeMoveStart.bind(this);
                this._footer.appendChild(this._tableLegend);
            }
            this._tableLegend.innerHTML = trsLegend;

            window.requestAnimationFrame(() => this.resizeLegend);

        } else {
            this._footer.style.display = 'none';
        }
    }
    resizeLegend() {
        const tHeight = this._legendHeight != null ? this._legendHeight : this.clientHeight / 2;
        if (tHeight > this._tableLegend.clientHeight) {
            this._table.parentNode.style.height = (this.clientHeight - 22 - this._tableLegend.clientHeight) + 'px';
        } else if (tHeight < 20) {
            this._footer.style.height = 20;
            this._table.parentNode.style.height = (this.clientHeight - 2) + 'px';
        } else {
            this._footer.style.height = tHeight;
            this._table.parentNode.style.height = (this.clientHeight - 22 - tHeight) + 'px';
        }
    }

    _marker() {
        return `<svg height="${this._rowstyle.fontsize}px" width="${this._rowstyle.fontsize}px" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><path d="M8 4 V28 L26 16 z"></path></svg>`;
    }
    _setThFilterStyle(th, btn, clear) {
        if (clear) {
            btn.classList.remove('active');
            th.style.color = '';
            th.style.backgroundColor = '';
        } else {
            btn.classList.add('active');
            th.style.color = this.headerrowstyle.textcolorfilter;
            th.style.backgroundColor = this.headerrowstyle.backgroundcolorfilter;
        }
        this.saveItemState({ customFilters: this._customFilt });
    }
    _setFilter(th, target, clearFilt, dispName, text) {
        if ($pm.hasPermissions) {
            const options = {
                cancel: () => {
                    this._customFilt = this._oldCustomFilt;
                },
                customText: `${this.elname}  ${!clearFilt ? `Включена фильтрация столбца ${dispName} : ${text}` : `Отключена фильтрация столбца ${dispName}`}`
            }
            $pm.resolveControl(this, "JournalUseFilters", () => {
                this._setThFilterStyle(th, target, clearFilt);
                this._reMonitoredEvents();
            }, options);
        } else {
            this._setThFilterStyle(th, target, clearFilt);
            this._reMonitoredEvents();
        }
    }
    _onHeaderClick(e) {
        if (e.target.tagName === "SPAN" && e.target.classList.contains('hmi-j-filter')) {
            const dispName = this._tablecolumns[this._tablecolumns.findIndex(el => el.baseIndex === this._baseFildsDict[e.target.id])].displayname;
            const th = e.target.parentNode.parentNode;
            const target = e.target;
            let val = this._customFilt[target.id] ? this._customFilt[target.id].value : '';
            const type = target.dataset.type;
            const inputNum = new Inputs(this._main);
            let clearFilt = false;
            if (this._customFilt) {
                this._oldCustomFilt = JSON.parse(JSON.stringify(this._customFilt));
            }
            switch (type) {
                case 'STRING':
                    inputNum.inputBoxText(e, 'Фильтр', val, (res) => {
                        if (res == null) return;
                        if (res == '') {
                            clearFilt = true;
                            delete this._customFilt[target.id];
                        } else {
                            this._customFilt[target.id] = { type: type, value: res };
                        }
                        this._setFilter(th, target, clearFilt, dispName, `содержит "${res}"`);
                    });
                    break;
                case 'BOOL':
                    const opt = [
                        { value: 'true', name: 'Да' },
                        { value: 'false', name: 'Нет' },
                        { value: 'all', name: 'Все' }
                    ]
                    inputNum.inputBoxSelect(e, 'Фильтр', opt, val, (res) => {
                        if (res == null) return;
                        if (res == '' || res == 'all') {
                            clearFilt = true;
                            delete this._customFilt[target.id];
                        } else {
                            this._customFilt[target.id] = { type: type, value: res };
                        }
                        this._setFilter(th, target, clearFilt, dispName, `равен "${res}"`);
                    });
                    break;
                case 'DATE_AND_TIME':
                case 'DATE':
                case 'TOD':
                case 'TIME':
                    inputNum.inputBoxDataRange(e, 'Фильтр', val, null, (res) => {
                        if (res == null) return;
                        let text = [];
                        if (typeof res.min !== 'number' && typeof res.max !== 'number') {
                            clearFilt = true;
                            delete this._customFilt[target.id];
                        } else {
                            this._customFilt[target.id] = { type: 'DATE_AND_TIME', value: res };
                            res.min !== undefined && text.push(`>= ${_df.dateFormat(res.min, 'dd.MM.yyyy HH:mm:ss')}`);
                            res.max !== undefined && text.push(`<= ${_df.dateFormat(res.max, 'dd.MM.yyyy HH:mm:ss')}`);
                        }
                        this._setFilter(th, target, clearFilt, dispName, text.join(', '));
                    });
                    break;
                case 'BYTE':
                case 'INT':
                case 'DINT':
                case 'LREAL':
                    const option = { min: _enums.Types[type].description.min, max: _enums.Types[type].description.max };
                    inputNum.inputBoxNumberRange(e, 'Фильтр', val, (res) => {
                        if (res == null) return;
                        const text = [];
                        if (typeof res.min !== 'number' && typeof res.max !== 'number') {
                            clearFilt = true;
                            delete this._customFilt[target.id];
                        } else {
                            this._customFilt[target.id] = { type: 'NUMBER', value: res };
                            res.min !== undefined && text.push(`>= ${res.min}`);
                            res.max !== undefined && text.push(`<= ${res.max}`);
                        }
                        this.updateSeverityState();
                        this._setFilter(th, target, clearFilt, dispName, text.join(', '));
                    }, option);
                    break;
                case 'ENUM':
                    const en = DataTypes.dataTypes[target.dataset.enum].DisplayValues;
                    inputNum.inputBoxEnum(e, 'Фильтр', en, val, null, (res) => {
                        let setFilt = false;
                        let stack;
                        const text = [];
                        for (const item of res) {
                            if (typeof stack === 'boolean') {
                                if (item !== stack) {
                                    setFilt = true;
                                    break;
                                }
                            } else {
                                stack = item;
                            }
                        }
                        if (!setFilt) {
                            clearFilt = true;
                            delete this._customFilt[target.id];
                        } else {
                            for (let i = 0; i < res.length; i++) {
                                if (res[i]) text.push(en[i]);
                            }
                            this._customFilt[target.id] = { type: 'ENUM', value: res };
                        }
                        this._setFilter(th, target, clearFilt, dispName, `равно ${text.join(', ')}`);
                    });
                    break;
                default:
                    console.log(type);
                    break;
            }
        } else if (!this._usearchive) {
            if (e.target.id !== '') {
                const i = this._baseFildsDict[e.target.id];
                if (this._cacheSort) {
                    if (this._cacheSort.index === i) {
                        this._cacheSort.forward = !this._cacheSort.forward;
                        const ico = this._cacheSort.forward ? 'hmi-j-step-up' : 'hmi-j-step-down';
                        this._cacheSort.el.className = `btn ${ico}`;
                    } else {
                        e.target.firstChild.insertBefore(this._cacheSort.el, e.target.firstChild.firstChild);
                        this._cacheSort.el.className = 'btn hmi-j-step-down';
                        this._cacheSort.index = i;
                        this._cacheSort.forward = true;
                    }
                    this._cacheSort.id = e.target.id;
                } else {
                    const el = document.createElement('div');
                    el.className = 'btn hmi-j-step-down';
                    e.target.firstChild.insertBefore(el, e.target.firstChild.firstChild);
                    this._cacheSort = {
                        index: i,
                        forward: true,
                        id: e.target.id,
                        el: el
                    };
                }
                this.saveItemState({
                    sortOrder: this.sortOrder
                });
                this.update();
            }
        }
    }

    setSeverity() {
        let val = this._customFilt['Severity'] ? this._customFilt['Severity'].value : '';
        let clearFilt = false;
        const dispName = 'Приоритет'
        const inputNum = new Inputs(this._main);
        const type = 'DINT';
        const th = this._main.querySelector('th#Severity')
        const target = this._main.querySelector('th#Severity span')
        const option = { min: _enums.Types[type].description.min, max: _enums.Types[type].description.max };
        inputNum.inputBoxNumberRange(null, 'Фильтр', val, (res) => {
            if (res == null) return;
            const text = [];
            if (typeof res.min !== 'number' && typeof res.max !== 'number') {
                clearFilt = true;
                delete this._customFilt['Severity'];
            } else {
                this._customFilt['Severity'] = { type: 'NUMBER', value: res };
                res.min !== undefined && text.push(`>= ${res.min}`);
                res.max !== undefined && text.push(`<= ${res.max}`);
            }
            this.updateSeverityState();
            if (th && target) {
                this._setFilter(th, target, clearFilt, dispName, text.join(', '));
            } else {
                this._reMonitoredEvents();
            }
            this.saveItemState({ customFilters: this._customFilt });
        }, option);
    }
    updateSeverityState() {
        const active = !this._customFilt['Severity'];
        this._toolBar.setToggleState(this._toolBar.elements["setSeverity"], !active);
    }

    _onDblClick(e) {
        if (e.target.tagName === 'TD' && e.target.attributes.smark) {
            const i = this._recs.findIndex(el => {
                return el[3] == e.target.parentNode.id;
            });
            if (i > -1) {
                if (this._bookmarks[this._recs[i][3]]) {
                    delete this._bookmarks[this._recs[i][3]];
                    e.target.innerHTML = '';
                } else {
                    this._bookmarks[this._recs[i][3]] = this._recs[i];
                    e.target.innerHTML = '<span align="center" style="pointer-events: none;font-size: medium;" class="btn hmi-j-f-marker"></span>';
                }
                this._saveMarks();
            }
        }
    }
    _saveMarks() {
        sessionStorage.setItem(`jr_${this.id}_bookmarks`, JSON.stringify(this._bookmarks));
    }
    _loadMarks() {
        this._bookmarks = JSON.parse(sessionStorage.getItem(`jr_${this.id}_bookmarks`)) || {};
    }

    _onBodyClick(e) {
        if (e.target.tagName == "BUTTON") {
            e.preventDefault();
            this._ackSingle(e);
        } else if (e.target.tagName === 'TD') {
            const i = this._recs.findIndex(el => {
                return el[3] == e.target.parentNode.id;
            });

            if (this._select.rec) {
                if (this._select.rec[3] !== this._recs[i][3]) {
                    this._select.td.innerHTML = '';
                    e.target.parentNode.firstChild.innerHTML = this._marker();
                    this._select = { rec: this._recs[i], td: e.target.parentNode.firstChild };
                }
            } else {
                e.target.parentNode.firstChild.innerHTML = this._marker();
                this._select = { rec: this._recs[i], td: e.target.parentNode.firstChild };
            }
            this.updateLegend();

        }
    }

    _genPermAckText(id, comment) {
        const recIndex = this._recs.findIndex(v => v[3] === id);
        const messageIndex = this._baseFildsDict["Message"];
        const dt = _df.dateFormat(this._recs[recIndex][4], 'dd.MM.yyyy HH:mm:ss');
        const text = `${this.elname} Квитировано : ${dt}${messageIndex === undefined ? '' : " " + this._recs[recIndex][messageIndex]}`;
        return text;
    }

    _ackSingle(e) {
        // нажата кнопка квит
        const btn = e.target;
        if (this._askackcomment) {
            const inputNum = new Inputs(this._main);
            inputNum.inputBoxText(e, 'Введите комментарий', '', (comment) => {
                if ($pm.hasPermissions) {
                    const options = { customText: this._genPermAckText(btn.id, comment) };
                    $pm.resolveControl(this, "JournalAck", this._ackApplay.bind(this, [btn.id], comment), options);
                } else {
                    this._ackApplay([btn.id], comment);
                }
            });
        } else {
            if ($pm.hasPermissions) {
                const options = { customText: this._genPermAckText(btn.id) };
                $pm.resolveControl(this, "JournalAck", this._ackApplay.bind(this, [btn.id], ''), options);
            } else {
                this._ackApplay([btn.id], '');
            }
        }
    }

    _onBookMarksClick(e) {
        if (e.target.tagName == 'BUTTON') {
            // удаление марки
            const el = this._body.querySelector(`[id="${e.target.parentNode.id}"]`);
            el.children[1].innerHTML = '';
            delete this._bookmarks[e.target.parentNode.id];
            e.target.parentNode.remove();
            this._saveMarks();
        } else if (e.target.attributes.bookmark) {
            // переход на марку
            this.getFromDate(null, this._bookmarks[e.target.id]);
        }

    }

    _onMarksClick(e) {
        e.preventDefault();
        if (!this._bookmarksDiv) {
            this._bookmarksDiv = document.createElement('div');

            this._bookmarksDiv.style.boxShadow = '0px 3px 10px rgba(35, 39, 76, 0.5)';
            this._bookmarksDiv.style.backgroundColor = this._filtersbackgroundcolor;
            this._bookmarksDiv.style.position = 'absolute';
            this._bookmarksDiv.style.zIndex = '2';
            this._bookmarksDiv.style.pointerEvents = 'all';

            this._header.querySelector('#mark').appendChild(this._bookmarksDiv);

            this._bookmarksDiv.onclick = this._onBookMarksClick.bind(this);
        }

        let lis = '';

        for (const key in this._bookmarks) {
            if (this._bookmarks.hasOwnProperty(key)) {
                const element = this._bookmarks[key];
                const time = _df.dateFormat(element[4]);
                lis += `
                <li bookmark class='bookmarksList' id="${key}">
                    <div style="flex:1; margin-right: 6px;">${time} ${this.enums('HMI.EventChangeType')[element[5]]}</div><button class="ack">Удалить</button>
                </li>
                `;
            }
        }
        this._bookmarksDiv.style.overflow = 'auto';
        this._bookmarksDiv.style.maxHeight = this._table.parentElement.clientHeight - this._header.clientHeight - 10;
        this._table.parentElement.clientHeight

        this._bookmarksDiv.innerHTML = `<ul>${lis}</ul>`;

        if (this._bookmarksDiv.style.display == 'block') {
            this._bookmarksDiv.style.display = 'none';
        } else {
            this._bookmarksDiv.style.display = 'block';
        }
    }

    _generateFilterList() {
        let lis = '';

        for (let i = 0; i < this._filters.length; i++) {
            const element = this._filters[i];
            lis += `
            <li>
                <input type="checkbox" data-index=${i} id="f_${i}" name="apply" value="${this._toBool(element.enabled)}" ${this._toBool(element.enabled) ? 'checked' : ''} ${element.candisable === false ? 'disabled' : ''}>
                <label ${element.candisable === false ? 'disabled' : ''} for="f_${i}">${element.displayname}</label>
            </li>
            `;
        }
        return lis;
    }

    OpenObjectTree(e) {
        if (!this._ObjectTree) {
            this._ObjectTree = new ObjectTree(this._sources, true);
        }
        this._ObjectTree.onUpdate = (newSources) => {
            this._sources = newSources;
            this._reMonitoredEvents();
        };


        if (!this._isglobal) {
            const { itemId } = this._getItemId()
            this._ObjectTree.rootitem = itemId;
        }

        this._ObjectTree.selected = this._sources;
        this._ObjectTree.Open();
    }

    _onFilterClick(e, isVisible) {
        if (e) e.preventDefault();
        if (!this._filterDiv) {
            const lis = this._generateFilterList();
            this._filterDiv = document.createElement('div');

            this._filterDiv.style.boxShadow = '0px 3px 10px rgba(35, 39, 76, 0.5)';
            this._filterDiv.style.position = 'absolute';
            this._filterDiv.style.zIndex = '2';
            this._filterDiv.innerHTML = `<ul>${lis}</ul>`;

            const inp = this._filterDiv.querySelector('ul');
            inp.onclick = this._onFilterSelectClick.bind(this);

            this._main.appendChild(this._filterDiv);
        }
        this._filterDivSet();

        if (typeof isVisible === 'boolean') {
            if (isVisible) {
                this._filterDiv.style.visibility = '';
            } else {
                this._filterDiv.style.visibility = 'hidden';
            }
        } else {
            const h = this._filterDiv.style.visibility !== 'hidden';
            if (h) {
                this._filterDiv.style.visibility = 'hidden';
            } else {
                this._filterDiv.style.visibility = '';
            }
        }
    }
    _filterDivSet() {
        if (this._filterDiv) {
            window.requestAnimationFrame(() => {
                if (!this._filterDiv) return;
                this._filterDiv.style.backgroundColor = this._filtersbackgroundcolor;

                const w = this._filterDiv.offsetWidth;
                const btn = this._toolBar.elements['_onFilterClick']
                if (btn.offsetLeft + w > Number(this.width)) {
                    this._filterDiv.style.left = `${Number(this.width) - w - 10}px`;
                } else {
                    this._filterDiv.style.left = `${btn.offsetLeft}px`;
                }


                this._filterDiv.style.top = `${btn.offsetTop + btn.offsetHeight}px`;

                const height = this.clientHeight - (btn.offsetTop + btn.offsetHeight);
                this._filterDiv.firstChild.style.maxHeight = `calc( ${height}px - 2em )`;
            })
        }
    }

    _onFilterSelectClick(e) {
        e.stopPropagation();
        const el = e.target;
        if (el.dataset.index === undefined) return;
        if ($pm.hasPermissions) {
            const options = {
                cancel: () => {
                    el.checked = !el.checked;
                },
                customText: `${this.elname} ${el.checked ? 'Включен фильтр' : 'Отключен фильтр'} "${this._filters[el.dataset.index].displayname}"`
            }
            $pm.resolveControl(this, "JournalUseFilters", this.applyFilter.bind(this, el), options);
        } else {
            this.applyFilter(el);
        }
    }
    applyFilter(el) {
        if (this._filters[el.dataset.index]) {
            this._filters[el.dataset.index].enabled = el.checked;
        }
        this.saveItemState({ filters: this._filters });
        this._reMonitoredEvents();
    }

    _reMonitoredEvents() {
        if (this._busyMonitoredEvents || typeof this.monitoredItemId === 'undefined') {
            this.needReCreate = true;
            return;
        };
        this._busyMonitoredEvents = true;
        this.sw.DeleteMonitoredEvents(this.monitoredItemId)
            .then(data => {
                if (data.code != 0) { this._busyMonitoredEvents = false; console.log(data.code.toString(16)); return; }
                this._createMonitoredEvents();
            }).catch(error => {
                console.log('error', error);
            });
        delete this.monitoredItemId;
    }

    AcknowledgeAll(e) {
        const res = [];
        for (let index = 0; index < this._body.childNodes.length; index++) {
            const element = this._body.childNodes[index];
            if (
                this._scrollTop <= element.offsetTop &&
                this._table.parentNode.clientHeight + this._scrollTop > element.offsetTop + element.clientHeight
            ) {
                const i = this._recs.findIndex(item => {
                    return item[3] === element.id;
                });
                if (i >= 0 && !this._recs[i][1]) {
                    const el = element.querySelectorAll('button.ack');
                    res.push({ rec: this._recs[i], els: el });
                }
            } else if (this._table.parentNode.clientHeight + this._scrollTop < element.offsetTop) {
                break;
            }

        }
        if (res.length > 0) {
            const ids = [];
            for (let index = 0; index < res.length; index++) {
                const element = res[index];
                ids.push(element.rec[3]);
            }
            const options = {
                customText: `Квитировано ${res.length} сообщений`
            }
            if (this._askackcomment) {
                const inputNum = new Inputs(this._main);
                inputNum.inputBoxText(e, 'Введите комментарий', '', (comment) => {
                    if ($pm.hasPermissions) {
                        $pm.resolveControl(this, "JournalGroupAck", this._ackApplay.bind(this, ids, comment, res), options);
                    } else {
                        this._ackApplay(ids, comment, res);
                    }
                });
            } else {
                if ($pm.hasPermissions) {
                    $pm.resolveControl(this, "JournalGroupAck", this._ackApplay.bind(this, ids, '', res), options);
                } else {
                    this._ackApplay(ids, '', res);
                }
            }

        }
    }

    _ackApplay(ids, comment, res) {
        if (comment == null) return;
        this.sw.AcknowledgeEvents(ids, comment)
            .then(data => {
                if (data.code != 0) { console.log(data.code.toString(16)); return; }
                if (data.recsStatus) {
                    if (data.recsStatus.length > 0) {
                        if (data.recsStatus[0] == 0) {
                            for (let index = 0; index < data.recsStatus.length; index++) {
                                const element = data.recsStatus[index];
                                if (element == 0 && res) {
                                    res[index].rec[1] = true;
                                    res[index].els.forEach(el => {
                                        el.remove();
                                        el = null;
                                    });
                                } else {
                                    // чтото пошло не так
                                }
                            }
                            this.update();
                        } else {
                            // что то пошло нетак
                        }
                    }
                }
            }).catch(error => {
                console.log('error', error);
            });
    }

    _onLegendClick(e) {
        if (e) e.preventDefault();
        this.SetParameter('showlegend', !this.showlegend, true);
        this.update();
    }

    _onOneForwardClick() {
        if (!this._usearchive) return;
        if (this._recs.length === 0 || !this._getArchived) return;
        const cp = { time: this._recs[this._recs.length - 1][6], eventId: this._recs[this._recs.length - 1][3], alarmId: this._recs[this._recs.length - 1][7] };
        const l = parseInt(this._limit / 100 * 10);

        let start = 0, end = 0;
        if (this._usetimefilter) {
            start = this._till - this._interval;
            end = this._till;
        }

        let packet = {
            inverse: true,
            endTime: end,
            fields: this._baseFilds,
            filter: this._calcFilters(),
            maxRecs: l,
            maxSize: 0,
            path: '',
            startTime: start,
            taskId: 0,
            continuationPoint: cp
        }

        packet = Object.assign(packet, this._getItemId());

        this.sw.getArchivedEvents(packet)
            .then(data => {
                if (data.code != 0) { console.log(data.code.toString(16)); this._loadDown = false; return; }
                if (data.recs) {
                    const ind = data.recs.findIndex(el => el[3] === cp.eventId);
                    if (ind > -1) data.recs.splice(ind, 1);
                    if (data.recs.length > 0) {
                        const offset = this._body.firstChild.offsetHeight * data.recs.length;
                        // this._table.style.overflow = 'hidden';
                        this._table.parentElement.scrollTop -= offset;
                        this._recs.splice(0, data.recs.length);
                        this._recs = this._recs.concat(data.recs);
                        this.update();
                        //    this._table.style.overflow = 'auto';
                    }
                }
                this._loadDown = false;
            }).catch(error => {
                this._loadDown = false;
                console.log('error', error);
            });

    }

    async getFromDate(date, startRec) {
        const date_utc = date;
        if (this._usetimefilter) {
            const start = this._till - this._interval;
            const end = this._till;
            const odt = date;
            if (odt < start || odt > end) return;
        }


        this._loadDown = true;
        this._loadUp = true;
        let intDate;
        if (date) {
            intDate = typeof date_utc == 'number' ? date_utc : date.getTime();
        }

        const l = parseInt(this._limit / 2);

        let start = 0, end = 0;
        if (this._usetimefilter) {
            start = this._till - this._interval;
            end = this._till;
        }

        let packet = {
            inverse: true,
            fields: this._baseFilds,
            filter: this._calcFilters(),
            maxRecs: l,
            maxSize: 0,
            path: "",
            startTime: start,
            taskId: 0
        }

        packet = Object.assign(packet, this._getItemId());
        let cp;
        if (startRec) {
            cp = { time: startRec[6], eventId: startRec[3], alarmId: startRec[7] };
            packet['continuationPoint'] = cp;
        } else {
            packet['endTime'] = intDate;
        }

        await this.sw.getArchivedEvents(packet)
            .then(data => {
                if (data.code != 0) { console.log(data.code.toString(16)); return; }
                if (cp) {
                    const ind = data.recs.findIndex(el => el[3] === cp.eventId);
                    if (ind > -1) data.recs.splice(ind, 1);
                }
                if (data.recs) {
                    this._recs = [];
                    if (data.recs.length > 0) {
                        this._table.parentElement.scrollTop = 0;
                        this._recs = data.recs;
                    }
                }
                packet.inverse = false;
                if (date_utc) {
                    packet.startTime = intDate;
                    packet.endTime = end;
                }
                return this.sw.getArchivedEvents(packet);
            }).then(data => {
                if (data.code != 0) { console.log(data.code.toString(16)); return; }
                if (data.recs) {
                    let recs = data.recs.reverse();
                    if (startRec) {
                        recs = recs.concat([startRec]);
                    }
                    this._recs = recs.concat(this._recs);
                    this.update();
                    if (this._body.childNodes.length > 0) {
                        const position = this._body.childNodes[0].offsetHeight * recs.length - (this._table.parentElement.offsetHeight / 2);
                        this._table.parentElement.scrollTop = position;
                    } else {
                        this._table.parentElement.scrollTop = 0;
                    }
                }
            }).then(() => {
                this._loadDown = false;
                this._loadUp = false;
            }).catch(error => {
                this._loadDown = false;
                this._loadUp = false;
                console.log('error', error);
            })
    }


    _onOneBackClick() {
        if (!this._usearchive) return;
        if (this._recs.length == 0 || !this._getArchived) { return; }
        const cp = { time: this._recs[0][6], eventId: this._recs[0][3], alarmId: this._recs[0][7] };
        const l = parseInt(this._limit / 100 * 10);

        let start = 0, end = 0;
        if (this._usetimefilter) {
            start = this._till - this._interval;
            end = this._till;
        }

        let packet = {
            inverse: false,
            endTime: end,
            fields: this._baseFilds,
            filter: this._calcFilters(),
            maxRecs: l,
            maxSize: 0,
            path: '',
            startTime: start,
            taskId: 0,
            continuationPoint: cp
        }

        packet = Object.assign(packet, this._getItemId());

        this.sw.getArchivedEvents(packet)
            .then(data => {
                if (data.code != 0) { console.log(data.code.toString(16)); this._loadUp; return; }
                if (data.recs) {
                    const ind = data.recs.findIndex(el => el[3] === cp.eventId);
                    if (ind > -1) data.recs.splice(ind, 1);
                    if (data.recs.length > 0) {
                        const offset = this._body.firstChild.offsetHeight * data.recs.length;
                        this._table.parentElement.scrollTop += offset;
                        this._recs.splice(this._recs.length - data.recs.length);
                        const recs = data.recs.reverse();
                        this._recs = recs.concat(this._recs);
                        this.update();
                    }
                }
                this._loadUp = false;
            }).catch(error => {
                this._loadUp = false;
                console.log('error', error);
            });
    }

    Download() {
        const fileName = genetateFileName('journal') + ".csv";
        if ($pm.hasPermissions) {
            const options = window.savePath ? {
                customText: `${this.elname} Сохранение сообщений в файл ${window.savePath}${fileName}`
            } : null;
            $pm.resolveControl(this, "JournalSave", this._Download.bind(this, fileName), options);
        } else {
            this._Download(fileName);
        }
    }
    _Download(fileName) {
        let header = '';

        for (let i = 0; i < this._tablecolumns.length; i++) {
            const element = this._tablecolumns[i];
            if (this._toBool(element.visibility)) {
                if (element.field != 'Icon' && element.field != 'Ack') {
                    header += `${element.displayname};`;
                }
            }
        }

        let row = header += '\n';

        for (let index = 0; index < this._recs.length; index++) {
            const element = this._recs[index];

            for (let i = 0; i < this._tablecolumns.length; i++) {
                const col = this._tablecolumns[i];
                switch (col.field) {
                    case 'Ack':
                        break;
                    case 'UpdateType':
                        row += `${this.enums(col.fieldtype)[element[col.baseIndex]]};`;
                        break;
                    case 'Icon':
                        break;
                    default:
                        if (typeof element[col.baseIndex] != 'undefined') {
                            let isDT = false;
                            switch (col.fieldtype) {
                                case 'DATE_AND_TIME':
                                    if (!col.valueformat) col.valueformat = 'dd.MM.yyyy HH:mm:ss';
                                    isDT = true;
                                    break;
                                case 'DATE':
                                    if (!col.valueformat) col.valueformat = 'dd.MM.yyyy';
                                    isDT = true;
                                    break;
                                case 'TIME':
                                    if (!col.valueformat) col.valueformat = 'HH:mm:ss';
                                    isDT = true;
                                    break;
                            }
                            if (isDT) {
                                const val = element[col.baseIndex] !== 0 ? _df.dateFormat(element[col.baseIndex], col.valueformat) : '';
                                row += `${val};`;
                            } else {
                                row += `${element[col.baseIndex] === null ? '' : element[col.baseIndex]};`;
                            }
                        } else {
                            row += `;`;
                        }
                }
            }
            row += '\n';
        }
        exportTextfile(row, fileName, true);
    }

    Print() {
        if ($pm.hasPermissions) {
            const options = window.clientPrinter ? {
                customText: `${this.elname} Печать сообщений на принтер ${window.PrinterName}`
            } : null;
            $pm.resolveControl(this, "JournalPrint", this._Print.bind(this), options);
        } else {
            this._Print();
        }
    }
    _Print() {
        const content = this._table.parentElement.innerHTML;
        const styles = this.shadowRoot.querySelectorAll('style');
        let stylesText = '';
        styles.forEach(st => {
            stylesText += st.innerText;
        });

        let hChild = '';
        this._hidePrintCol.forEach(ih => {
            hChild += ` th:nth-child(${ih + 1}),td:nth-child(${ih + 1}){display: none;} `
        });

        let html = `
        <style>${stylesText.replace(new RegExp(':host', 'g'), '')} th span {display:none;} ${hChild}</style>`;
        html += content;

        if (window.ipc && window.clientPrinter) {
            window.ipc.get().send('server', 'print', `data:text/html;charset=${charset},${html}`);
        } else {
            this._iframe = document.createElement('iframe');
            this._iframe.onload = () => {
                let printDocument = (this._iframe.contentWindow || this._iframe.contentDocument);
                if (printDocument.document) printDocument = printDocument.document;
                printDocument.querySelector('table').style.width = '100%'

                requestAnimationFrame(() => {
                    this._iframe.focus();
                    this._iframe.contentWindow.print();
                    this._iframe.remove();
                    this._iframe = null;
                });
            }
            this._iframe.srcdoc = html;
            document.body.appendChild(this._iframe);
        }

        return true;
    }

    updateStatusBar() {
        if (this._rowstyle) {
            this._statusBar.style.fontFamily = this._rowstyle.FontName;
            this._statusBar.style.fontSize = this._rowstyle.FontSize;
        }
        if (!this._autoscroll) {
            this._statusBar.style.display = 'block';
            if (this.usetimefilter) {
                const start = this._till - this._interval;
                const end = this._till;
                if (this._statusBar.querySelector('ms-interval#inter') == null)
                    this._statusBar.innerHTML = `
                        <div style="height:18px; display: flex;justify-content: space-between;">
                            <ms-dtpicker utc="true" id="left" datetimetype="1" size="40" isreadonly="false" datetime="${start}" style="width: 180px; border: 1px solid;position: unset;"></ms-dtpicker>
                            <ms-interval utc="true" id="inter" isreadonly="false" allownull="true" backgroundcolor="" datetime="${this._interval}" style="width:110px;border:1px solid;position: unset;"></ms-interval>
                            <ms-dtpicker utc="true" id="right" datetimetype="1" size="40" isreadonly="false" datetime="${end}" style="width: 180px; border: 1px solid;position: unset;"></ms-dtpicker>
                        </div>
                    `;
                const inter = this._statusBar.querySelector('ms-interval#inter');
                const right = this._statusBar.querySelector('ms-dtpicker#right');
                const left = this._statusBar.querySelector('ms-dtpicker#left');
                right.force = true;
                left.force = true;
                inter.force = true;
                left.datetime = start;
                right.datetime = end;
                inter.datetime = this._interval;

                inter.prop_link['datetime'] = (a, b, val, attrName) => {
                    if (attrName === 'datetime') {
                        this.SetParameter('interval', val);
                        left.datetime = this._till - val;
                    }
                }
                right.prop_link['datetime'] = (a, b, val, attrName) => {
                    if (attrName === 'datetime') {
                        this.SetParameter('till', val);
                        left.datetime = this._till - val;
                    }
                }
                left.prop_link['datetime'] = (a, b, val, attrName) => {
                    if (attrName === 'datetime') {
                        this.SetParameter('till', val + this._interval);
                        right.datetime = this._interval + val;
                    }
                }
            } else {
                if (this._usearchive && this._recs.length > 0) {
                    this._statusBar.style.backgroundColor = this._legendbackgroundcolor;
                    const tStart = _df.dateFormat(this._recs[0][4]);
                    const tEnd = _df.dateFormat(this._recs[this._recs.length - 1][4]);
                    this._statusBar.innerText = `Пропущено: ${this._skip} Отображаемый интервал: ${tStart} - ${tEnd}`;
                } else {
                    const tEnd = this._recs.length > 0 ? _df.dateFormat(this._recs[this._recs.length - 1][4]) : '';
                    this._statusBar.innerText = `Активных: ${this._recs.length} Время: ${tEnd}`;
                }
            }

        } else {
            if (this._usearchive) {
                this._skip = 0;
                this._statusBar.style.display = 'none';
            } else {
                this._statusBar.style.display = 'block';
                const tEnd = this._recs.length > 0 ? _df.dateFormat(this._recs[this._recs.length - 1][4]) : '';
                this._statusBar.innerText = `Активных: ${this._recs.length} Время первой: ${tEnd}`;
            }

        }

    }

    _onAutoPlayClick(e) {
        if (this._usetimefilter && !this._autoscroll) return;
        this._autoscrollInit = true;
        this.SetParameter('autoscroll', !this._autoscroll, true);
        if (this._autoscroll) {
            this._table.parentElement.scrollTop = 0;
        }
        this._updatePlayBtn();

        if (typeof this._interval !== 'undefined')
            this.updateStatusBar();
    }

    _updatePlayBtn() {
        this._toolBar.setToggleState(this._toolBar.elements["_onAutoPlayClick"], this._autoscroll);
        if (this._autoscroll) {
            if (this._usearchive) {
                this._getArchived(0, 0)
                    .then(() => {
                        window.requestAnimationFrame(() => {
                            this._autoscrollInit = false;
                        })
                    })
                    .catch(() => {
                        this._autoscrollInit = false;
                    });
            }
        }
    }

    _goFirstPage(e) {
        if (this._usearchive) {
            let start = 0, end = 0;
            if (this._usetimefilter) {
                start = this._till - this._interval;
                end = this._till;
            }
            this._getArchived(start, end);

        }
        this.updateStatusBar();
    }
    _goLastPage(e) {
        if (this._usearchive) {
            let start = 0, end = 0;
            if (this._usetimefilter) {
                start = this._till - this._interval;
                end = this._till;
            }
            this._getArchived(start, end, null, false);

        }
        this.updateStatusBar();
    }

    _showTimeFiltr(e) {
        this.SetParameter('usetimefilter', !this.usetimefilter);
        this.updateStatusBar();
    }

    _goData(e) {
        const inputDate = new Inputs(this._main);
        inputDate.inputBoxData(e, 'Перейти к дате', new Date(), val => {
            this.getFromDate(val);
        });
    }

    Update() {
        if (this._usearchive) {
            if (this._recs.length > 0) {
                let start = 0, end = this._recs[0][4];
                if (this._usetimefilter) {
                    start = this._till - this._interval;
                    end = this._till;
                }
                this._getArchived(start, end);
            } else {
                if (!this.needReCreate) {
                    let start = 0, end = 0;
                    if (this._usetimefilter) {
                        start = this._till - this._interval;
                        end = this._till;
                    }
                    this._getArchived(start, end);
                }
            }
        }
    }

    Clear() {
        this._reMonitoredEvents();
    }

    FirstPage() {
        this._goFirstPage();
    }
    PreviousPage() {
        const y = this._table.parentElement.scrollTop - this._table.parentNode.clientHeight;
        this._table.parentElement.scroll({
            top: y,
            left: this._table.parentElement.scrollLeft,
            behavior: 'smooth'
        });
    }
    NextPage() {
        const y = this._table.parentElement.scrollTop + this._table.parentNode.clientHeight;
        this._table.parentElement.scroll({
            top: y,
            left: this._table.parentElement.scrollLeft,
            behavior: 'smooth'
        });
    }
    LastPage() {
        this._goLastPage();
    }
    Acknowledge(e) {
        if ($pm.hasPermissions) {
            $pm.resolveControl(this, "JournalAck", this._Acknowledge.bind(this, e, true));
        } else {
            this._Acknowledge(e, true);
        }
    }
    _Acknowledge(e, force) {
        if (this._select.td) {
            if (
                this._scrollTop <= this._select.td.offsetTop &&
                this._table.parentNode.clientHeight + this._scrollTop > this._select.td.offsetTop + this._select.td.clientHeight
            ) {
                const i = this._recs.findIndex(item => {
                    return item[3] === this._select.rec[3];
                });
                if (i >= 0 && !this._recs[i][1]) {
                    const el = this._select.td.parentElement.querySelector('button.ack');
                    const res = {
                        rec: this._recs[i],
                        els: el
                    };
                    let comment = e.Kommentarij || '';
                    const ids = [this._recs[i][3]];
                    if (this._askackcomment && !force) {
                        const inputNum = new Inputs(this._main);
                        inputNum.inputBoxText(e, `Please enter comment for ${ids.length}(s)`, '', (comment) => {
                            this._ackApplay(ids, comment);
                        });
                    } else {
                        this._ackApplay(ids, comment);
                    }
                }
            }

        }

    }
    NextMessage() {
        if (this._select.td) {
            let i = this._sortRecs.findIndex(el => {
                return el[3] === this._select.rec[3];
            });
            if (i > 0) {
                i--;
                this._select.el = this._body.childNodes[i];
                this._select.rec = this._sortRecs[i];
                const offset = this._select.el.offsetTop - this._select.el.offsetHeight;
                if (offset < this._scrollTop || offset > (this._scrollTop + this._table.parentNode.clientHeight)) {
                    this._table.parentElement.scroll({
                        top: this._select.el.offsetTop - this._select.el.offsetHeight,
                        left: this._table.parentElement.scrollLeft,
                        behavior: 'smooth'
                    });
                }
                this.update();
            }
        }
    }
    PreviousMessage() {
        if (this._select.td) {
            let i = this._sortRecs.findIndex(el => {
                return el[3] === this._select.rec[3];
            });
            if (i < (this._sortRecs.length - 1)) {
                i++;
                this._select.el = this._body.childNodes[i];
                this._select.rec = this._sortRecs[i];
                const offset = this._select.el.offsetTop - this._select.el.offsetHeight;
                if (offset < this._scrollTop || offset + this._select.el.offsetHeight * 2 > (this._scrollTop + this._table.parentNode.clientHeight)) {
                    this._table.parentElement.scroll({
                        top: this._select.el.offsetTop + this._select.el.offsetHeight * 2 - this._table.parentElement.offsetHeight,
                        left: this._table.parentElement.scrollLeft,
                        behavior: 'smooth'
                    });
                }
                this.update();
            }
        }
    }
    ClearOptions() {
        this.saveItemState({ customFilters: undefined });
        this.saveItemState({ sortOrder: undefined });
        this.saveItemState({ filters: undefined });
        this._customFilt = {};
        const th = this._header.querySelectorAll('.active');
        for (let i = 0; i < th.length; i++) {
            const el = th[i];
            el.classList.remove('active');
            el.parentNode.parentNode.style.color = '';
            el.parentNode.parentNode.style.backgroundColor = '';
        }
        try {
            this._filters = JSON.parse(this.getAttribute('filters')).filter;
            if (typeof this._filters === 'object' && !Array.isArray(this._filters)) this._filters = [this._filters];
            if (this._filterDiv) {
                this._filterDiv.firstChild.innerHTML = this._generateFilterList();
            }
            this.updateSeverityState();
        } catch (error) {

        }
        this._reMonitoredEvents();
    }

    attributeChangedCallback(attrName, oldVal, newVal, itemIndex) {
        if (this.constructor.observedAttributes.indexOf(attrName) < 0) {
            const p = attrName.split('.');
            if (p.length > 1) {
                if (this[p[0]][p[1]][p[2]] != newVal) {
                    this[p[0]][p[1]][p[2]] = newVal;
                    if (p[0] === 'filters') {
                        if (this._filterDiv) {
                            this._filterDiv.firstChild.innerHTML = this._generateFilterList();
                        }
                        this._reMonitoredEvents();
                    }
                    if (this.prop_link[p[0]]) {
                        this.prop_link[p[0]](
                            this.pId ? this.pId + '/' + this.id : this.id,
                            this.Links[p[0]],
                            this._paneldatasource_data || attrName,
                            p[0],
                            itemIndex
                        );
                    }
                }
            }
        } else {
            super.attributeChangedCallback(attrName, oldVal, newVal);
        }
    }

    ShowLegend() {
        this._onLegendClick();
    }

    disableElement() {
        if (this._maskElement) return;

        const zIndex = parseInt(this.z || 1, 10);
        const maskElement = this.createMaskElement(zIndex);

        this.shadowRoot.appendChild(maskElement);
        this._maskElement = maskElement;
    }

}