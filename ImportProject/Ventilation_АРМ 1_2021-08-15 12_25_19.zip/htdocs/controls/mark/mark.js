﻿import { Basic } from '../basic.js';
/**
 * @class MSMark
 * @extends Basic
 * @classdesc Метка
 * */
export class MSMark extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'marks'
        ]);
    }

    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<div id="default-mark" style="font-size:10px; display: flex;">${this.localName}</div>`;
        this.style.justifyContent = 'center';
        this.style.alignItems = 'center';
        this.style.cursor = 'move';
        this.style.border = 'solid 1px black';
        this.style.outline = 'none';
        this._main = shadowRoot.querySelector('#default-mark');
        this._newMarkInfo = null;
        this._template = null;
        this._isEditMarks = false;
        this._contextParams = {
            contextMenuWidth: 180,
            contextMenuHeight: 25,
            commentWidth: 200,
            commentHeight: 28,
            koef: 1.5,
            oneElem: 1,
            twoElem: 2,
            contextMenu: 'contextMenu',
            comment: 'comment'
        }

        this.onmousedown = (evt) => {
            if (evt.which === window._enums.ButtonKeyCode.MOUSE_LEFT) {
                this._calcScale();
                this._startCoords = {
                    x: evt.clientX,
                    y: evt.clientY,
                    left: this.offsetLeft,
                    top: this.offsetTop
                }
                this._isEditMarks = true;
                this._createNewMark();
            }
        };
        this.marks = "{}";
    }

    get skinresource() {
        return this._skinresource;
    }
    set skinresource(value) {
        if (value) {
            this._main.innerText = '';
        }
        super.skinresource = value;
    }

    get resource() {
        return this._resource;
    }
    set resource(value) {
        if (value) {
            this._main.innerText = '';
        }
        super.resource = value;
    }

    set marks(marks) {
        if (typeof marks !== 'string') {
            return;
        }
        let parsedMarks;
        try {
            parsedMarks = JSON.parse(marks);
        } catch (err) {
            $ns.add({ type: 'error', time: new Date().toLocaleString(), title: err.name, text: err.message });
            return;
        }
        if (typeof parsedMarks !== 'object' || parsedMarks === null) {
            return;
        }
        this._marks = marks;
        const marksArr = Object.values(parsedMarks);
        if (!this._isEditMarks && marksArr.length) {
            this._renderAllMarks(marksArr);
        }
    }

    get marks() {
        return this._marks;
    }

    get template() {
        if (!this._template) {
            this._template = this.outerHTML.slice().replace(/ms-mark/gi, 'div');
        }
        return this._template;
    }

    _calcScale() {
        if (this._scale) {
            return;
        }
        if (this.parentElement) {
            const { width, height } = this.parentElement.getBoundingClientRect();
            const rangeWidth = parseFloat(this.parentElement.style.width);
            const rangeHeight = parseFloat(this.parentElement.style.height);
            this._scale = {
                x: width / rangeWidth,
                y: height / rangeHeight
            };
        } else {
            this._scale = window.__scale || { x: 1, y: 1 };
        }
    }

    _getNewMarkCoords({ offsetTop: top, offsetLeft: left, offsetWidth: width, offsetHeight: height }) {
        return {
            top,
            left,
            right: left + width,
            bottom: top + height
        };
    }

    _hasMarkCommentField(markId) {
        return window.commentMark && window.commentMark.dataset.id === markId;
    }

    _createElement(html) {
        const container = document.createElement(`template`);
        container.innerHTML = html;
        return container.content.children[0];
    }

    _onNewMarkMouseUp(newMark) {
        document.onmouseup = (evt) => {
            document.onmousemove = null;
            const coords = this._shiftNewMarkCoords(newMark);
            this._newMarkInfo = {
                id: Math.random().toString(16).slice(2, 7),
                message: `ПОЛЬЗОВАТЕЛЬ: `,
                left: coords.left,
                top: coords.top
            };
            this._setAttributesNewMark(newMark);
            this._refreshMarks();
            this._createNewElementOfEvent(newMark, this._contextParams.comment);
            document.onmouseup = null;
        };
    }

    _shiftNewMarkCoords({ offsetTop: top, offsetLeft: left }) {
        if ((left === this.offsetLeft && top === this.offsetTop) ||
            (Math.abs(left - this.offsetLeft) < this.offsetWidth &&
                Math.abs(top - this.offsetTop) < this.offsetHeight)) {
            left = this.offsetLeft + this.offsetWidth * this._contextParams.koef;
            top = this.offsetTop;
        }
        return { top, left };
    }

    _onNewMarkMouseMove(newMark) {
        document.onmousemove = (evt) => {
            const coords = {
                left: (this._startCoords.x - evt.clientX) / this._scale.x,
                top: (this._startCoords.y - evt.clientY) / this._scale.y,
            };
            const newCoords = this._calculateNewMarkCoords(coords, newMark);
            this._setAttributesNewMark(newMark, newCoords);
        }
    }

    _refreshMarks(markId = this._newMarkInfo.id, message = '') {
        const marks = JSON.parse(this.marks);
        if (message) {
            marks[markId].message = message;
        } else if (this._newMarkInfo) {
            marks[markId] = this._newMarkInfo;
            this._newMarkInfo = null;
        } else {
            delete marks[markId];
        }
        this.SetParameter('marks', JSON.stringify(marks));
    }

    _calculateNewMarkCoords(coords, newMark) {
        const limits = {
            top: 0,
            left: 0,
            right: newMark.parentElement.offsetWidth,
            bottom: newMark.parentElement.offsetHeight
        };
        const newCoords = {
            left: this._startCoords.left - coords.left,
            top: this._startCoords.top - coords.top
        };
        if (newCoords.left + newMark.offsetWidth > limits.right) {
            newCoords.left = limits.right - newMark.offsetWidth;
        }
        if (newCoords.left < limits.left) {
            newCoords.left = limits.left;
        }
        if (newCoords.top + newMark.offsetHeight > limits.bottom) {
            newCoords.top = limits.bottom - newMark.offsetHeight;
        }
        if (newCoords.top < limits.top) {
            newCoords.top = limits.top;
        }
        return newCoords;
    }

    _createNewMark(markInfo = null) {
        const newMark = this._createElement(this.template);
        newMark.removeAttribute('id');
        newMark.removeAttribute('marks');
        this._onNewMarkContextMenu(newMark);
        if (markInfo) {
            this._setAttributesNewMark(newMark, markInfo);
        } else {
            this._onNewMarkMouseMove(newMark);
            this._onNewMarkMouseUp(newMark);
        }
        this.parentElement.appendChild(newMark);
    }

    _setAttributesNewMark(newMark, markInfo = this._newMarkInfo) {
        if (markInfo.message) {
            markInfo.message = markInfo.message.replace(/,/g, '\n');
        }
        newMark.style.cursor = 'pointer';
        newMark.style.left = `${markInfo.left}px`;
        newMark.style.top = `${markInfo.top}px`;
        newMark.dataset.id = markInfo.id || 0;
        newMark.setAttribute('title', (markInfo.message || ''));
    }

    _onNewMarkContextMenu(newMark) {
        newMark.oncontextmenu = (evt) => {
            evt.stopPropagation();
            evt.preventDefault();
            this._calcScale();
            const coords = {
                left: evt.clientX,
                top: evt.clientY,
                isEvent: true
            };
            this._createNewElementOfEvent(newMark, this._contextParams.contextMenu, coords);
        };
    }

    _onContextMenuClick(menu, mark) {
        menu.onclick = (evt) => {
            const pressedElem = evt.target.closest('.context-menu-item');
            if (pressedElem) {
                this._processActionOnMenu(pressedElem.dataset.id, mark);
            }
            this._removeSubElement(this._contextParams.contextMenu);
        };
    }

    _processActionOnMenu(id, mark) {
        if (id === 'delete') {
            this._removeSubElement(this._contextParams.comment);
            this._refreshMarks(mark.dataset.id);
            this._removeCurrentMark(mark);
        } else if (id === 'comment') {
            this._createNewElementOfEvent(mark, this._contextParams.comment);
        }
    }

    _removeSubElement(...stringNames) {
        stringNames.forEach((stringName) => {
            if (window[`${stringName}Mark`]) {
                window[`${stringName}Mark`].blur();
                window[`${stringName}Mark`].onclick = null;
                window[`${stringName}Mark`].remove();
                window[`${stringName}Mark`] = null;
            }
        });
    }

    _calculateSubElementCoords({ top, left, right = left, bottom = top, isEvent = false }, itemsNumber, stringName) {
        const newCoords = {
            left: isEvent ? left : left,
            top: isEvent ? top : bottom
        };
        if (!isEvent) {
            if (this.parentElement.offsetWidth - (left + this._contextParams[`${stringName}Width`] * this._scale.x) < 0) {
                newCoords.left -= this._contextParams[`${stringName}Width`] + (left - right);
            }
            if (this.parentElement.offsetHeight - (bottom + this._contextParams[`${stringName}Height`] * itemsNumber * this._scale.x) < 0) {
                newCoords.top -= this._contextParams[`${stringName}Height`] * itemsNumber + (bottom - top);
            }
        }
        return newCoords;
    }

    _createNewElementOfEvent(newMark, stringName, coords = this._getNewMarkCoords(newMark)) {
        const isComment = this._hasMarkCommentField(newMark.dataset.id);
        const isContext = (stringName === this._contextParams.contextMenu);
        this._removeSubElement(stringName);
        let newCoords = this._calculateSubElementCoords(coords, (isContext && !isComment ? this._contextParams.twoElem : this._contextParams.oneElem), stringName);
        const element = this._createElement(this._getSubElementTemplate(newCoords, JSON.parse(this.marks)[newMark.dataset.id], stringName, isComment));
        (stringName === this._contextParams.contextMenu) ? document.body.appendChild(element) : this.parentElement.appendChild(element);
        window[`${stringName}Mark`] = element;
        this._onDocumentClick();
        this._onDocumentKeyDown(newMark);
        element.focus();
        if (isContext) {
            this._onContextMenuClick(element, newMark);
        }
    }

    _getSubElementTemplate(coords, markInfo, stringName, isComment) {
        const template = {
            contextMenu: `<ul class='context-menu-list' style='left:${coords.left}px; top:${coords.top}px;'>
                ${!isComment ?
                    `<li data-id='comment' class='context-menu-item'
                        style='width: ${this._contextParams.contextMenuWidth}px !important;
                        height: ${this._contextParams.contextMenuHeight}px !important;'
                    >
                        ${markInfo.message.includes('КОММЕНТАРИЙ') ?
                        `Редактировать комментарий` :
                        `Добавить комментарий`}
                    </li>` : ``}
                <li data-id='delete' class='context-menu-item'
                    style='width: ${this._contextParams.contextMenuWidth}px !important;
                    height: ${this._contextParams.contextMenuHeight}px !important;'
                >
                    Удалить метку
                </li>

            </ul>`,
            comment: `<input type='text' class='mark-new-comment'
                data-id='${markInfo.id}'
                placeholder='Введите комментарий...'
                style='left:${coords.left}px; top:${coords.top}px; width: ${this._contextParams.commentWidth}px !important;
                height: ${this._contextParams.commentHeight}px !important;'
            >`
        };
        return template[stringName];
    }

    _onDocumentKeyDown(mark) {
        document.onkeydown = (evt) => {
            if (evt.which === window._enums.ButtonKeyCode.ESC) {
                this._removeMarkElements();
            } else if (evt.which === window._enums.ButtonKeyCode.ENTER && (window.commentMark === document.activeElement)) {
                if (window.commentMark.value) {
                    this._editMarkMessage(mark);
                    this._removeMarkElements();
                } else {
                    this._warnCommentField();
                }
            }
        };
    }

    _editMarkMessage(mark) {
        const newMessage = this._getNewMessage();
        this._refreshMarks(mark.dataset.id, newMessage);
        mark.setAttribute('title', newMessage);
    }

    _getNewMessage() {
        const dateComment = new Date().toLocaleString().replace(/,/, '');
        return `ПОЛЬЗОВАТЕЛЬ: , КОММЕНТАРИЙ: ${window.commentMark.value}, ВРЕМЯ: (${dateComment})`;
    }

    _removeMarkElements() {
        this._removeSubElement(this._contextParams.contextMenu, this._contextParams.comment);
        document.onkeydown = null;
        document.onmousedown = null;
    }

    _onDocumentClick() {
        document.onmousedown = (evt) => {
            const comment = evt.target.closest('.mark-new-comment');
            if (evt.which === window._enums.ButtonKeyCode.MOUSE_LEFT) {
                if (!comment && !evt.target.closest('.context-menu-list')) {
                    this._removeMarkElements();
                } else if (comment) {
                    this._removeSubElement(this._contextParams.contextMenu);
                    const editedMark = this.parentElement.querySelector(`[data-id="${comment.dataset.id}"]`);
                    this._onDocumentKeyDown(editedMark);
                }
            }
        };
    }

    _warnCommentField() {
        window.commentMark.classList.add('new-comment-flash');
        const timerId = setTimeout(function () {
            window.commentMark.classList.remove('new-comment-flash');
            clearTimeout(timerId);
        }, 1200);
    }

    _removeCurrentMark(mark) {
        document.onkeydown = null;
        document.onmousedown = null;
        mark.oncontextmenu = null;
        mark.remove();
    }

    _renderAllMarks(marks) {
        marks.forEach((markInfo) => {
            this._createNewMark(markInfo);
        });
    }
}
