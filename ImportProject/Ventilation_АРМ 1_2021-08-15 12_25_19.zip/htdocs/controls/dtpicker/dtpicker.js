﻿'use strict';

import { MSText } from "../text/text.js";
/**
 * @class MSDateTimePicker
 * @extends MSText
 * @classdesc ДатаВремя
 * */
export class MSDateTimePicker extends MSText {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'datetime',
            'datetimetype',
            'timeformat',
            'dateformat',
            'isreadonly',
            'allownull',
            'value',
            'utc'
        ]);
    }

    constructor() {
        super();
        this.shadowRoot.innerHTML = `
            <style>
                .bgimg {
                    width: 34px;
                    background-origin: content-box;
                    background-position: center;
                    background-repeat: no-repeat;
                    background-size: 60%;
                    background-image: url('./styles/data_ico.svg');
                    border-left: 1px solid;
                }
                .bgimg:hover {
                    background-color: #00000021;
                }
            </style>
            <input data-id='dtinput' style="height:100%;width:100%;min-width:0px;background-color:transparent;border:0;text-align:center">
            <div class="bgimg" id='btnCal'></div>
        `;
        this.shadowRoot.getElementById('btnCal').onclick = this.showInput.bind(this);
        this._text = this.shadowRoot.querySelector('input');

        this._inputKeyDown = this._inputKeyDown.bind(this);
        this._onInputDTFocus = this._onInputDTFocus.bind(this);
        this._onInputDTBlur = this._onInputDTBlur.bind(this);
        this._onIncBtnMouseDown = this._onIncBtnMouseDown.bind(this);
        this._onIncBtnStop = this._onIncBtnStop.bind(this);
        this._onInputPaste = this._onInputPaste.bind(this);

        this.onfocus = e => this._text.focus();

        this._text.oncut = () => false;
        this._text.addEventListener('keydown', this._inputKeyDown);
        this._text.addEventListener('focus', this._onInputDTFocus);
        this._text.addEventListener('blur', this._onInputDTBlur);
        this._text.addEventListener('paste', this._onInputPaste);
        this._limits = {
            maxdd: 31,
            maxMM: 12,
            maxHH: 23,
            maxmm: 59,
            maxss: 59,
            maxfff: 999,
            maxyyyy: 2286,
            mindd: 1,
            minMM: 1,
            minHH: 0,
            minmm: 0,
            minss: 0,
            minfff: 0,
            minyyyy: 1970,
        };
        this._timeNames = {
            HH: 'Часы',
            mm: 'Мин.',
            ss: 'Сек.',
            fff: 'Милисек.',
        };
        this._dateNames = {
            dd: 'День',
            MM: 'Месяц',
            yyyy: 'Год',
            yy: 'Год'
        }
        this.timeformat = 'HH:mm:ss.fff';
        this.dateformat = 'dd.MM.yyyy';
        this._fullmask = this.dateformat + ' ' + this.timeformat;
        //this.utc = true;
        //this.setBaseParams();
        this._datetime = 0;
        this.isreadonly = true;
        this.textcolor = "BLACK";
        this._text.style.fontFamily = "Tahoma";
        this._text.style.fontSize = 12;
        this.style.justifyContent = 'center'; //this.texthorizontalalign = 1;
        this.style.textAlign = 'center';
        this.style.alignItems = '';
        this.borderthickness = 1;
        this.backgroundcolor = "rgb(208,208,208)";

    }

    get utc() {
        return this._utc || false;
    }
    set utc(value) {
        this._utc = this._toBool(value);
        // let dt = new Date(Number(this.datetime));
        // if (isNaN(dt.valueOf())) {
        //     return;
        // }
        // const strDT = window._df.dateFormat(dt, 'MM dd yyyy HH:mm:ss.fff', this._utc);
        // dt = new Date(strDT).getTime();
        // this._isEvent = true;
        // this.SetParameter('datetime', dt);
        // this._isEvent = false;
    }

    get allownull() {
        return this._allownull;
    }
    set allownull(value) {
        this._allownull = this._toBool(value);
    }

    get dateformat() {
        return this._dateformat;
    }
    set dateformat(value) {
        const correctFormat = this._getCorrectFormatDate(value);
        this._dateformat = correctFormat;
        if (typeof this._datetime !== 'undefined') this._update();
    }

    get timeformat() {
        return this._timeformat;
    }
    set timeformat(value) {
        const correctFormat = this._getCorrectFormatTime(value);
        this._timeformat = correctFormat;
        if (typeof this._datetime !== 'undefined') this._update();
    }

    get value() {
        return this._datetime;
    }
    set value(value) {
        this.datetime = Number(value);
    }

    get datetime() {
        return this._datetime;
    }
    set datetime(value) {
        this._datetime = value;
        this._update();
    }

    get datetimetype() {
        return this._datetimetype === undefined ? 3 : this._datetimetype;
    }
    set datetimetype(value) {
        this._datetimetype = window._enums.DateTimeType_Full[value];
        if (typeof this._datetime !== 'undefined') this._update();
    }

    get isreadonly() {
        return this._isreadonly;
    }
    set isreadonly(value) {
        this._isreadonly = this._toBool(value);
        this._text.disabled = this._isreadonly;

        if (this._isreadonly && this.datePopup) {
            this.datePopup.parentElement.remove();
            this.datePopup.remove();
            this.datePopup = null;
        }
    }

    get texthorizontalalign() {
        return this._horizontalalign;
    }
    set texthorizontalalign(value) {
        this._horizontalalign = value;
        this._text.style.textAlign = window._enums.AlignText[value];

    }

    attributeChangedCallback(attrName, oldVal, newVal) {
        if (oldVal != newVal) {
            this[attrName] = newVal;
            if (this.prop_link[attrName]) {
                this.prop_link[attrName](
                    this.pId ? this.pId + '/' + this.id : this.id,
                    this.Links[attrName],
                    newVal,
                    attrName,
                    this.ItemIndex
                );
            }
        }
    }

    saveClick(e) {
        e.preventDefault();
        let formatedValue = {};
        const formData = new FormData(this.datePopup);
        for (const pair of formData.entries()) {
            const [name, value] = pair;
            formatedValue[name] = Number(value);
        }
        formatedValue.MM = (formatedValue.MM === 0) ? 0 : formatedValue.MM - 1;
        this._setNewDateTime(formatedValue);
        this.datePopup.parentElement && this.datePopup.parentElement.remove();
        this.datePopup.remove();
        this.datePopup = null;
    }

    cancelClick(e) {
        e.preventDefault();
        this.datePopup.parentElement.remove();
        this.datePopup.remove();
        this.datePopup = null;
    }

    // подсказка формата при фокусе в инпут
    _showPlaceholder(value) {
        // const font = parseInt(this._text.style.fontSize);
        // this._text.offsetParent.style.fontSize = `${Math.floor(font / 1.1)}px`;
        // this._text.offsetParent.setAttribute('data-value', value);
        // this._text.offsetParent.style.overflow = 'visible';
        // this._text.offsetParent.classList.add('span-placeholder');
    }

    _hidePlaceholder() {
        // this._text.offsetParent.style.overflow = 'hidden';
        // this._text.offsetParent.style.fontSize = '';
        // this._text.offsetParent.classList.remove('span-placeholder');
    }

    _adjustValue(val, category, oldValue = null) {
        const min = this._limits[`min${category}`];
        const max = this._limits[`max${category}`];
        if (val < min) {
            val = oldValue ? oldValue : max;
        }
        if (val > max) {
            val = oldValue ? oldValue : min;
        }
        while (val.toString().length < category.length) {
            val = '0' + val;
        }
        return val;
    }

    _onInputBoxWheel(e) {
        e.preventDefault();
        if (this._isreadonly) return;
        let val = Number(e.target.value);
        const delta = -e.deltaY;
        val = delta > 0 ? val + 1 : val - 1;
        val = this._adjustValue(val, e.target.id);
        e.target.value = val;
        return false;
    }

    _onInputBoxChange(e) {
        if (this._isreadonly) return;
        let val = Number(e.target.value);
        val = this._adjustValue(val, e.target.id, e.target.dataset.oldValue);
        e.target.value = val;
        return false;
    }

    _onInputDTFocus(e) {
        this._text.dataset.oldValue = this._text.value;
        //if (e.target.dataset.id === 'dtinput') {
        this._showPlaceholder(this._fullmask);
        //}
    }

    _onInputPaste(evt) {
        evt.preventDefault();
        const pastedValue = evt.clipboardData.getData('Text');
        this._setValue(pastedValue);
    }

    _onInputDTBlur(e) {
        this._setValue(e.target.value);
        this._hidePlaceholder();
    }

    showInput(e) {
        if (this._isreadonly) {
            e.preventDefault();
            return false;
        }
        if (!this.datePopup) {
            this.datePopup = this._createDatePopup();
        } else {
            this.datePopup.parentElement.remove();
            this.datePopup.remove();
            this.datePopup = null;
            return;
        }

        const btnSave = this.datePopup.querySelector('button[id="save"]');
        btnSave.onclick = this.saveClick.bind(this);

        this.datePopup.style.userSelect = 'none';
        this.datePopup.onclick = (e) => {
            e.stopImmediatePropagation();
        }

        const incBtns = this.datePopup.querySelectorAll('button.incbtn');
        incBtns.forEach((btn) => {
            btn.onmousedown = this._onIncBtnMouseDown;
            btn.ontouchstart = this._onIncBtnMouseDown;
        });

        const btnCancel = this.datePopup.querySelector('button[id="cancel"]');
        btnCancel.onclick = this.cancelClick.bind(this);

        const inputs = this.datePopup.querySelectorAll('input');
        inputs.forEach((input) => {
            input.onwheel = this._onInputBoxWheel.bind(this);
            input.onchange = this._onInputBoxChange.bind(this);
            input.onfocus = this._onInputDTFocus.bind(this);
        });

        const win = window.__rootWin.getBoundingClientRect();

        const back = document.createElement('div');
        back.id = 'divCancel';
        back.style.position = 'absolute';
        back.style.display = 'flex';
        back.style.flexDirection = 'column';
        back.style.top = '0';
        back.style.left = '0';
        back.style.bottom = '0';
        back.style.right = '0';
        back.style.zIndex = '10003';
        back.appendChild(this.datePopup);
        back.onclick = this.cancelClick.bind(this);
        document.body.appendChild(back);

        const rect = this.datePopup.getBoundingClientRect();
        const baseRect = this.getBoundingClientRect();

        if (baseRect.left + rect.width > win.width) {
            this.datePopup.style.left = (win.width - rect.width) + 'px';
        } else {
            this.datePopup.style.left = (baseRect.left) + 'px';
        }
        if (baseRect.bottom + rect.height > win.height) {
            this.datePopup.style.top = (baseRect.top - rect.height) + 'px';
        } else {
            this.datePopup.style.top = (baseRect.bottom) + 'px';
        }
    }

    _onIncBtnMouseDown(evt) {
        evt.preventDefault();
        evt.target.onmouseup = this._onIncBtnStop;
        evt.target.ontouchend = this._onIncBtnStop;
        document.addEventListener('touchmove', this._onIncBtnStop);
        evt.target.onmouseleave = this._onIncBtnStop;
        this._intervalId = setInterval(() => {
            this._interv = true;
            this._changeBtnIncValue(evt.target);
        }, 100);
    }

    _onIncBtnStop(evt) {
        clearInterval(this._intervalId);
        evt.target.onmouseup = null;
        evt.target.ontouchend = null;
        document.removeEventListener('touchmove', this._onIncBtnStop);
        evt.target.onmouseleave = null;
        if (this._interv) {
            this._interv = false;
            return false;
        }
        this._changeBtnIncValue(evt.target);
    }

    _changeBtnIncValue(btn) {
        const input = btn.parentElement.querySelector('input');
        let val = Number(input.value);
        if (btn.id === 'up') {
            val += 1;
        } else {
            val -= 1;
        }
        val = this._adjustValue(val, input.id);
        input.value = val;
    }

    _createDatePopup() {
        const template = document.createElement('template');
        template.innerHTML = this._getTemplate();
        return template.content.children[0];
    }

    _getTemplate() {
        return `<form id="calend" class="form-calendar" style="margin:0;z-index:1001;left:153px;top:63px;"><div>
            ${this._getCalendarSections()}
            <div class="calendar-btns">
                <button id="save">Выбрать</button>
                <button id="cancel">Отмена</button>
            </div>
        </form>`;
    }

    _getCalendarSections() {
        const isDate = (this.datetimetype !== window._enums.DateTimeType_Full.Time_Type);
        const isTime = (this.datetimetype !== window._enums.DateTimeType_Full.Date_Type);
        const [dateObj, timeObj] = this._getCurrentDateObj(isDate, isTime);
        const dateHtml = isDate ? this._getDateTemplate(dateObj) : '';
        const timeHtml = isTime ? this._getTimeTemplate(timeObj) : '';
        return (this.datetimetype === window._enums.DateTimeType_Full.TimeDate_Type) ?
            (timeHtml + dateHtml) :
            (dateHtml + timeHtml);
    }

    _getDateTemplate(dateObj) {
        return `<div class="calendar">
            ${(Object.entries(dateObj).map((pair, i) => this._getInputTemplate(this._dateNames[pair[0]], pair))).join(' ')}
        </div>`;
    }

    _getTimeTemplate(timeObj) {
        return `<div class="calendar">
            ${(Object.entries(timeObj).map((pair, i) => this._getInputTemplate(this._timeNames[pair[0]], pair))).join(' ')}
        </div>`;
    }

    _getInputTemplate(name, [format, value]) {
        return `<div class="calendar__section">
            <span>${name}</span>
            <button type="button" id="up" class="incbtn">&#9652;</button>
            <input type="number" name="${format}" id="${format}" class="data_inp" value="${value}">
            <button type="button" id="down" class="incbtn">&#9662;</button>
        </div>`;
    }

    _getCurrentDateObj(isDate, isTime) {
        let formatedValue = [];
        formatedValue.push(isDate
            ? this._getFormatedObj(this._getFormatPatterns(this._dateformat))
            : {}
        );
        formatedValue.push(isTime
            ? this._getFormatedObj(this._getFormatPatterns(this._timeformat))
            : {}
        );
        return formatedValue;
    }

    _getFormatPatterns(str) {
        const token = /(d+)|(M+)|(y+)|(H+)|(m+)|(s+)|(f+)/g;
        const matches = str.match(token);
        return matches;
    }

    _getFormatedObj(formats) {
        let obj = {};
        let dt;
        let utc = false;
        if (this.attributes.sourceformat && this.attributes.sourceformat.value === 'TIME_OF_DAY') {
            utc = true;
        }
        if (this._datetime === undefined || this._datetime === 0 || this._datetime === '') {
            dt = window._df.dateFormat(new Date(), `${formats.join('-')}`, true);
        } else {
            dt = window._df.dateFormat(new Date(Number(this._datetime || 0)), `${formats.join('-')}`, utc);
        }
        let dtItems = dt.split('-');
        dtItems.forEach((item, i) => obj[formats[i]] = item);
        return obj;
    }

    _getCorrectFormatDate(value, toObj = false) {
        const token = /(d+)|(M+)|(y+)|(H+)|(m+)|(s+)|(f+)(h+)|(\d+)|(g+)|(o+)|(_+)/g;
        value = value.replace(/(d+)|(M+)|(y+)/g, (match, p1, p2, p3, index, srcStr) => {
            if (((index + match.length - 1) !== srcStr.length - 1) &&
                /(d+)|(M+)|(y+)/.test(srcStr[index + match.length])) {
                return match + '-';
            }
            return match;
        });
        const correctFormat = value.replace(
            token,
            (match, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, index, srcStr) => {
                if (p4 || p5 || p6 || p7 || p8 || p9 || p10 || p11 || p12) {
                    return '-';
                }
                let res = match;
                if (/y/.test(match)) {
                    res = 'yyyy';
                } else {
                    res = this._pad(match, 2);
                }
                return this._checkPattern(res, index, srcStr);
            });
        return correctFormat;
    }

    _getCorrectFormatTime(value) {
        const token = /(_+)|(g+)|(o+)|(\d+)|(h+)|(d+)|(M+)|(y+)|(H+)|(m+)|(s+)|(f+)/g;
        value = value.replace(/(H+)|(m+)|(s+)|(f+)/g, (match, p1, p2, p3, p4, index, srcStr) => {
            if (((index + match.length - 1) !== srcStr.length - 1) &&
                /(H+)|(m+)|(s+)|(f+)/.test(srcStr[index + match.length])) {
                return match + '-';
            }
            return match;
        });
        const correctFormat = value.replace(
            token,
            (match, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, index, srcStr) => {
                if (p1 || p2 || p3 || p4 || p5 || p6 || p7 || p8) {
                    return '-';
                }
                let res = match;
                if (/f/.test(match)) {
                    if (match.length >= 3) {
                        res = match.slice(0, 3);
                    } else {
                        res = this._pad(match, 3);
                    }
                } else {
                    res = this._pad(match, 2);
                }
                return this._checkPattern(res, index, srcStr);
            });
        return correctFormat;
    }

    _pad(match, n) {
        while (match.length < n) {
            match += match;
        }
        return match.slice(0, n);
    }

    _checkPattern(res, index, srcStr) {
        let searchStr = srcStr.slice(0, index);
        let idx = searchStr.indexOf(res[0]);
        return (idx === -1) ? res : '';
    }

    _setValue(val) {
        if (val === this._text.dataset.oldValue) return;
        let dtObj = {};
        if (!val || val.includes('_')) {
            this._text.value = this._text.dataset.oldValue;
            return;
        }
        const token = /(\d+)/g;
        const values = val.match(token);
        let patterns = this._getFormatPatterns(this._fullmask);
        patterns.forEach((pattern, i) => {
            dtObj[pattern] = values[i] ? values[i] : 0;
            if (pattern === 'MM') {
                if (dtObj['MM'] <= 12) {
                    dtObj['MM'] = (dtObj['MM'] == 0) ? dtObj['MM'] : dtObj['MM'] - 1;
                }
            }
        });
        this._setNewDateTime(dtObj);
    }

    _setNewDateTime(date) {
        let timestamp = new Date(
            date.yyyy || 1970,
            date.MM || 0,
            date.dd || 1,
            date.HH || 0,
            date.mm || 0,
            date.ss || 0,
            date.fff || 0,
        ).getTime();
        if (this.attributes.sourceformat &&
            this.attributes.sourceformat.value === 'TIME_OF_DAY') {

            let offset = (new Date().getTimezoneOffset()) * 60000;
            timestamp = timestamp - offset;
        }
        this._isEvent = true;
        this.SetParameter('datetime', timestamp, this.force);
        this._isEvent = false;
    }

    _update() {
        if (typeof this.datetimetype === 'undefined') { return; }
        if (typeof this._datetime === 'undefined' && this._allownull) { this._text.value = ''; return; }
        this.maskmap = {};
        switch (this.datetimetype) {
            case window._enums.DateTimeType_Full.Date_Type:
                this._fullmask = this._dateformat;
                break;
            case window._enums.DateTimeType_Full.DateTime_Type:
                this._fullmask = this._dateformat + ' ' + this._timeformat;
                break;
            case window._enums.DateTimeType_Full.TimeDate_Type:
                this._fullmask = this._timeformat + ' ' + this._dateformat;
                break;
            case window._enums.DateTimeType_Full.Time_Type:
                this._fullmask = this._timeformat;
                break;
        }
        let dt = new Date(Number(this._datetime));
        if (isNaN(dt.valueOf())) {
            dt = new Date(Number(0));
        }
        let utc = false;
        if (!this.prop_link['datetime']) {
            if (this.attributes.sourceformat) {
                if (this.attributes.sourceformat.value === 'TIME_OF_DAY') {
                    utc = true;
                }
            }
        } else if (this.attributes.sourceformat && this.attributes.sourceformat.value === 'TIME_OF_DAY') {
            utc = true;
        } else if (this.attributes.sourceformat && this.attributes.sourceformat.value === 'DATE_AND_TIME') {
            if (!this.utcCorr && !this._isEvent && this._datetime < 0) {
                utc = true;
                this.utcCorr = true;
            }
        }
        //true = 3 parameters (UTC)
        if (!this._allownull || (typeof this._datetime === 'number' && this._datetime !== 0)) {
            //dt = new Date(window._df.dateFormat(dt, 'MM dd yyyy HH:mm:ss.fff'));
            this._text.value = window._df.dateFormat(dt, this._fullmask, utc);

        }
    }

    _inputKeyDown(evt) {
        if (evt.ctrlKey || this._isreadonly) {
            return false;
        }
        if (evt.which === window._enums.ButtonKeyCode.DELETE) {
            evt.preventDefault();
            return false;
        }
        const input = evt.target;
        let index = input.selectionStart;
        const currentValue = input.value;
        if (evt.which === window._enums.ButtonKeyCode.BACKSPACE) {
            evt.preventDefault();
            if (input.selectionStart === input.selectionEnd) {
                if (index === 0) {
                    return;
                }
                if ((/\d/.test(currentValue[index - 1]))) {
                    input.value = currentValue.slice(0, index - 1) + '_' + currentValue.slice(index);
                }
                input.setSelectionRange(index - 1, index - 1);
            } else {
                const ind = input.selectionStart;
                let selectVal = currentValue.slice(input.selectionStart, input.selectionEnd);
                selectVal = selectVal.replace(/\d/g, '_');
                input.value = currentValue.slice(0, input.selectionStart) + selectVal + currentValue.slice(input.selectionEnd);
                input.setSelectionRange(ind, ind);
            }
        } else if (evt.key.length === 1) {
            evt.preventDefault();
            if (index === currentValue.length || !(/\d/.test(evt.key))) {
                return;
            }
            if ((!(/\d/.test(currentValue[index])) && currentValue[index] !== '_')) {
                input.setSelectionRange(index + 1, index + 1);
                return;
            }
            input.value = currentValue.slice(0, index) + evt.key + currentValue.slice(index + 1);
            index += (/\W/.test(currentValue[index + 1])) ? 2 : 1;
            input.setSelectionRange(index, index);
        } else if (evt.which === window._enums.ButtonKeyCode.RIGHT) {
            //input.setSelectionRange(index + 1, index + 1);
        } else if (evt.which === window._enums.ButtonKeyCode.LEFT) {
            //if (index === 0) {
            //    return;
            //}
            //input.setSelectionRange(index - 1, index - 1);
        } else if (evt.which === window._enums.ButtonKeyCode.ENTER) {
            this._onInputDTBlur({ target: { value: input.value } });
        }
    }

    disconnectedCallback() {
        if (this._text && this._text.oncut) this._text.oncut = null;
        this._text.removeEventListener('paste', this._onInputPaste);
        this._text.removeEventListener('keydown', this._inputKeyDown);
        this._text.removeEventListener('focus', this._onInputDTFocus);
        this._text.removeEventListener('blur', this._onInputDTBlur);
        super.disconnectedCallback();
        if (this.datePopup) {
            this.datePopup.parentElement.remove();
            this.datePopup.remove();
            this.datePopup = null;
            delete this.datePopup;
        }
    }
}
