﻿import { Basic } from '../basic.js';
import { toBool } from '../../lib/utils.js';
/**
 * @class MSDataTree
 * @extends Basic
 * @classdesc Дерево одиночного/множественного выбора
 */
export class MSDataTree extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'datasource',
            'sourcetype',
            'multiselect',
            'expanded',
            'idfield',
            'displayfield',
            'value',
            'values',
            'onapply',
            'rootitem',
            'autoselect',
            'filter',
            'filtercallback',
            'childrenfield'
        ]);
    }

    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<style>.tree { --main-tree-color: #94a5bd; --main-select-color: #aaa}</style>
        <style>
           @import "./controls/tree/tree.css";
        </style>
        <form class="tree"></form>`;
        this._idfield = 'ID';
        this._displayfield = 'Name';
        this._autoselect = true;
        this._onapplay = false;
        this._main = shadowRoot.querySelector('form');
        this._style = shadowRoot.querySelectorAll('style')[0];
        this._onClick = this._onClick.bind(this);
        this._onChange = this._onChange.bind(this);
        this._main.addEventListener('click', this._onClick);
        this._main.addEventListener('change', this._onChange);
        //
        this.datasource = "{}";
        this.sourcetype = this.getAttribute('sourcetype') || 0;
        this.expanded = true;
        this.inited = false;
    }

    afterInitialize() {
        if (this.inited)
            return;
        this.inited = true;
        this.update();
    }

    get expanded() {
        return this._expanded;
    }
    set expanded(v) {
        this._expanded = toBool(v);
    }

    get multiselect() {
        return this._multiselect;
    }
    set multiselect(v) {
        this._multiselect = toBool(v);
    }

    get autoselect() {
        return this._autoselect;
    }
    set autoselect(v) {
        this._autoselect = this._toBool(v);
    }

    get sourcetype() {
        return this._sourcetype;

    }
    set sourcetype(v) {
        if (this._sourcetype === Number(v)) return;
        this._sourcetype = Number(v);
        switch (this._sourcetype) {
            case 0: // ProjectTree
                this._loadJSON('VMInfo.json', (data) => {
                    try {
                        this._datasource = JSON.parse(data).projectTree;
                        this._createPath(this._datasource, 'Name');
                        this.update();
                        if (!this._multiselect || (this._tmpValues != this._values)) {
                            this._calcSelect();
                        }
                    } catch (e) {
                        this._datasource = [];
                    }
                });
                break;
            case 1: // object tree
                this._loadJSON('VMJournals.json', (data) => {
                    try {
                        this._datasource = JSON.parse(data).projectTree;
                        this._createPath(this._datasource, 'ID');
                        this.update();
                    } catch (e) {
                        this._datasource = [];
                    }
                });
                break;
            case 2: // CustomJson
                break;

        }
    }
    _createPath(data, field, path) {
        data.forEach(el => {
            el.ItemPath = path ? `${path}.${el[field]}` : el[field];
            if (el[this.childrenfield] && el[this.childrenfield].length > 0) {
                this._createPath(el[this.childrenfield], field, el.ItemPath);
            }
        });
    }

    get datasource() {
        return this._datasource;
    }
    set datasource(value) {
        try {
            this._datasource = JSON.parse(value.toString());
            if (this.inited) {
                this.update();
            }
        } catch (e) {
            this._datasource = [];
        }
    }

    get value() {
        return this._value;
    }
    set value(v) {
        this._value = v;
        this._calcSelect();
    }

    get values() {
        return this._values;
    }
    set values(v) {
        try {
            if (typeof v === 'string') {
                this._values = JSON.parse(v);
            } else {
                this._values = v;
            }
        } catch (e) {
            this._values = [];
        }
        if (!this._multiselect || (this._tmpValues != this._values)) {
            this._calcSelect();
        }
    }

    get onapply() {
        return this._onapplay;
    }
    set onapply(v) {
        this._onapplay = toBool(v);
    }

    get rootitem() {
        return this._rootitem;
    }
    set rootitem(v) {
        this._rootitem = v;
        this.update();
    }

    Apply() {
        this.SetParameter('values', this._tmpValues);
    }
    Cancel() {
        this._calcSelect();
    }
    ClearAll() {
        const checkbox = this._main.querySelectorAll('input[type="checkbox"]:checked');
        checkbox.forEach(el => {
            el.checked = false;
        });
        this._tmpValues = [];
        this.SetParameter('values', this._tmpValues);
    }
    SelectAll() {
        const checkbox = this._main.querySelectorAll('input[type="checkbox"]');
        checkbox.forEach(el => {
            el.checked = true;
            this._tmpValues.push(el.id);
        });
        this.SetParameter('values', this._tmpValues);
    }

    get idfield() {
        return this._idfield;
    }
    set idfield(v) {
        this._idfield = v;
    }

    get displayfield() {
        return this._displayfield;
    }
    set displayfield(v) {
        this._displayfield = v;
    }

    get filter() {
        return this._filter;
    }
    set filter(v) {
        try {
            if (typeof v === 'string') {
                this._filter = JSON.parse(v);
            } else {
                this._filter = v;
            }
        } catch (e) {
            this._filter = [];
        }
    }

    get childrenfield() {
        return this._childs || 'Childs';
    }
    set childrenfield(value) {
        this._childs = value;
    }

    get filtercallback() {
        return this._filtercallback;
    }
    set filtercallback(value) {
        this._filtercallback = value;
    }

    update() {
        if (!this._filter) this.filter = this.getAttribute('filter') || '';
        if (Array.isArray(this._datasource)) {
            if (this._rootitem) {
                const item = this.getObjects(this._datasource, this._idfield, this._rootitem);
                this._datasourcefiltred = item.obj;
                const data = item.obj;
                this._main.innerHTML = '';
                this._main.appendChild(this._genEl(data, item.path.join(',')));
            } else {
                this._datasourcefiltred = this._datasource;
                this._main.innerHTML = '';
                this._main.appendChild(this._genEl(this._datasource, ''));
            }
            this._main.querySelector('ul').style.display = '';
            const list = this._main.querySelectorAll('input[type="checkbox"]');

            list.forEach(el => {
                const path = el.dataset.path;
                const items = path && path.split('.');
                items && this._setEl(this._datasource, items, el);
            });

            this._calcSelect();
        } else {
            this._main.innerHTML = '';
        }
    }

    _setEl(dataset, path, el) {
        const target = dataset.find(e => {
            return e[this._idfield] == path[0];
        })
        if (target) {
            if (path.length > 1) {
                const items = path.slice(1);
                this._setEl(target[this.childrenfield], items, el);
            } else {
                target['__el'] = el;
            }
        }
    }

    _calcSelect() {
        if (!this._multiselect && this._value) {
            const sel = this._main.querySelector(`[for="${this._value}"]`);
            if (sel) {
                if (this._selectItem) {
                    this._selectItem.classList.remove('select');
                }
                this._selectItem = sel;
                this._selectItem.classList.add('select');
            }
        } else if (this._multiselect && this._values) {
            const inp = this._main.querySelectorAll('input[type="checkbox"]');
            inp.forEach(el => {
                el.checked = false;
            });
            this._values.forEach(id => {
                const el = this._main.querySelector(`[id="${id}"]`);
                if (el) {
                    el.checked = true;
                    if (this._autoselect) {
                        this._setValues(el.parentNode.parentNode, true);
                    }
                }
            });
        }
    }


    _genEl(ds) {
        let ul = document.createElement('ul');
        for (let index = 0; index < ds.length; index++) {
            const el = ds[index];
            let sub;
            if (el[this.childrenfield] && Array.isArray(el[this.childrenfield]) && el[this.childrenfield].length > 0) {
                sub = this._genEl(el[this.childrenfield]);
            }
            let checked = true;
            if (this._filtercallback && !sub) {
                checked = this._filtercallback(el);
            }
            if (checked && this._filter && Object.keys(this._filter).length > 0 && !sub) {
                checked = false;
                for (const key in this._filter) {
                    if (el.hasOwnProperty(key)) {
                        if (el[key] == this._filter[key]) {
                            checked = true;
                            break;
                        }
                    }
                }
            }
            if (checked) {
                let list = document.createElement("li");
                if (sub) {
                    let div = document.createElement("div");
                    let classAttr = document.createAttribute("class");
                    classAttr.value = `cl${this._expanded ? ' open' : ''}`;
                    div.setAttributeNode(classAttr);
                    list.appendChild(div);
                }
                let idField = el[this._idfield];

                let label = document.createElement("label");
                let forAtt = document.createAttribute("for");
                forAtt.value = el[this._idfield];
                label.setAttributeNode(forAtt);
                let chbox = document.createElement('input');
                chbox.setAttribute('type', 'checkbox');
                if (el.ItemPath) {
                    let dpAtt = document.createAttribute("data-path");
                    dpAtt.value = el.ItemPath;
                    chbox.setAttributeNode(dpAtt);
                }
                let nameAtt = document.createAttribute("name");
                nameAtt.value = `item${idField}`;
                let idAtt = document.createAttribute("id");
                idAtt.value = idField;
                chbox.setAttributeNode(nameAtt);
                chbox.setAttributeNode(idAtt);
                if (this._multiselect) {
                    label.appendChild(chbox)
                }
                let div = document.createElement('div');
                div.innerHTML = el[this._displayfield];
                label.appendChild(div);
                list.appendChild(label);
                if (typeof sub !== 'undefined' && sub !== '') {
                    list.appendChild(sub);
                }
                ul.appendChild(list);
            }
        }
        if (ul.childNodes.length == 0) return;
        if (!this._expanded) {
            ul.setAttribute('style', "display:none;");
        }
        return ul;
    }

    _loadJSON(filename, callback) {
        const xobj = new XMLHttpRequest();
        xobj.overrideMimeType('application/json');
        xobj.open('GET', filename, true);
        xobj.onreadystatechange = function () {
            if (xobj.readyState == 4 && xobj.status == '200') {
                callback(xobj.responseText);
            }
        };
        xobj.send(null);
    }


    disconnectedCallback() {
        this._filtercallback = null;
        super.disconnectedCallback();
        this._main.removeEventListener('click', this._onClick);
        this._main.removeEventListener('change', this._onChange);
    }

    getSiblings(elem) {

        var siblings = [];
        var sibling = elem.parentNode.firstChild;

        while (sibling) {
            if (sibling.nodeType === 1) {
                siblings.push(sibling);
            }
            sibling = sibling.nextSibling
        }

        return siblings;

    };

    getObjects(obj, key, val, path = []) {
        let objects = [];
        for (let i = 0; i < obj.length; i++) {
            const el = obj[i];
            path.push(el[this._idfield]);
            if (el[key] && el[key] == val) {
                objects.push(el);
                return { obj: objects, path: path, end: true };
            } else {
                if (el[this.childrenfield]) {
                    const ret = this.getObjects(obj[i][this.childrenfield], key, val, path)
                    if (ret.end) {
                        return { obj: ret.obj, path: path, end: true }
                    }
                }
            }
        }
    }

    _onChange(event) {
        const val = event.target.checked;
        const element = event.target.parentNode.parentNode;
        if (this._autoselect) {
            const ch = element.querySelectorAll('input[type="checkbox"]');
            ch.forEach(el => {
                el.checked = val;
                el.indeterminate = false;
            });

            this._setValues(element, val);
            const checkbox = this._main.querySelectorAll('input[type="checkbox"]:checked');
            this._tmpValues = [];
            checkbox.forEach(el => {
                let val = el.id;
                if (el.parentNode.parentNode.childNodes.length < 3) {
                    this._tmpValues.push(val);
                } else if (!this._autoselect) {
                    this._tmpValues.push(val);
                }
            });
        } else {
            const getSelected = (ds) => {
                let ret = [];
                ds.forEach(el => {
                    if (el.__el.checked) {
                        ret.push(el[this._idfield]);
                    } else if (el[this.childrenfield]) {
                        ret = ret.concat(getSelected(el[this.childrenfield]));
                    }
                });
                return ret;
            }
            this._tmpValues = getSelected(this._datasourcefiltred);
        }

        if (!this._onapplay) {
            this.SetParameter('values', this._tmpValues);
        }
    }

    _setValues(element, val) {
        if (element.parentNode.parentNode.nodeName === 'FORM') return;
        let count = 0, inde = 0;
        const sub = this.getSiblings(element);
        sub.forEach(el => {
            const e = el.querySelector('input[type="checkbox"]')
            count += Number(e.checked);
            inde += Number(e.indeterminate);
        });
        const curEl = element.parentNode.parentNode.querySelector('input[type="checkbox"]');

        if (sub.length === count) {
            curEl.indeterminate = false;
            curEl.checked = true;
        } else if (count === 0 && inde === 0) {
            curEl.checked = false;
            curEl.indeterminate = false;
        } else {
            curEl.checked = false;
            curEl.indeterminate = true;
        }

        this._setValues(element.parentNode.parentNode, val);
    }

    _onClick(event) {
        switch (event.target.nodeName) {
            case 'DIV':
                event.target.classList.toggle('open');
                const ul = event.target.parentNode.querySelector('ul');
                if (event.target.classList.contains('open')) {
                    ul.style.display = '';
                } else {
                    ul.style.display = 'none';
                }
                event.preventDefault();
                break;
            case 'LABEL':
                if (!this._multiselect) {
                    this.SetParameter('value', event.target.getAttribute('for'));
                    event.preventDefault();
                }
                break;
        }
    }
}