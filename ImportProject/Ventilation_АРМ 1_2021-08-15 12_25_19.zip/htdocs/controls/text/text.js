import { getFormattedValue } from '../../lib/utils.js';
import { Basic } from "../basic.js";
/**
 * @class MSText
 * @extends Basic
 * @classdesc �����
 * */
export class MSText extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'text',
            'fontname',
            'fontsize',
            'texthorizontalalign',
            'textverticalalign',
            'fontitalic',
            'fontbold',
            'fontmultiline',
            'fontunderlined',
            'textcolor',
            'valueformat',
            'overflow'
        ]);
    }

    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = '<div></div>';
        //if (!this.style.position) {
        //    this.style.position = 'absolute';
        //}
        this.style.display = 'flex';
        this.style.overflow = 'hidden';
        this._text = shadowRoot.querySelector('div');
        this._text.style.whiteSpace = 'nowrap';

        //from set base params
        this.style.justifyContent = 'center'; //this.texthorizontalalign = 1;
        this.style.textAlign = 'center';
        this.style.alignItems = 'center'; //this.textverticalalign = 1;
        this._text.style.fontFamily = "Tahoma";
        this._text.style.fontSize = 12;
        this._text.style.color = "rgb(80,80,80)";
        this.style.borderWidth = 0;
        this.style.backgroundColor = "Transparent";
    }

    get backgroundcolor() {
        return this._backgroundcolor;
    }

    set backgroundcolor(value) {
        super.backgroundcolor = value;
        this._calcBlockShadow();
    }

    get shadowsize() {
        return this._shadowsize;
    }
    set shadowsize(value) {
        value = parseInt(value, 10);
        if (value >= 0) {
            this._shadowsize = value;
            this._calcBlockShadow();
        }
    }

    get shadowcolor() {
        return this._shadowcolor;
    }
    set shadowcolor(value) {
        this._shadowcolor = value ? this._transformHexColor(value) : '';
        this._calcBlockShadow();
    }

    _calcBlockShadow() {
        if (!this._shadowsize || !this._shadowcolor) {
            this.style.boxShadow = '';
            this._text.style.textShadow = '';
            return;
        }
        if (!this.backgroundcolor || this.backgroundcolor.toLowerCase() === 'transparent') {
            this.style.boxShadow = '';
            this._text.style.textShadow = `
                ${this._shadowsize}px
                ${this._shadowsize}px
                1px
                ${this._shadowcolor}`;
        } else {
            this._text.style.textShadow = '';
            this.style.boxShadow = `
                ${this._shadowsize}px
                ${this._shadowsize}px
                1px 0
                ${this._shadowcolor}`;
        }
    }
    /**
     * ������ ��������
     * @type {string}
     */
    get valueformat() {
        return this._valueFormat;
    }
    set valueformat(format) {
        const value = (this._sourceValue !== undefined && this._sourceValue !== null) ? this._sourceValue : '';
        format = format.trim();
        if (format) {
            this._valueFormat = format;
            this._text.innerText = this._getDisplayValue(format, value);
        } else {
            this._valueFormat = '';
            this._text.innerText = this._sourceDateObj ?
                this._getDisplayValue(window._enums.DefaultDateFormat[this._sourceDateObj.type]) :
                value;
        }
    }
    /**
     * �����
     * @type {string}
     */
    get text() {
        return this._text.innerText;
    }
    set text(value) {
        if (value === undefined) return;
        this._sourceValue = value;
        this._text.innerText = this._valueFormat ? this._getDisplayValue(this._valueFormat) : value;
        this._detectScroll();
    }

    _detectScroll() {
        if (this._overflow || this._toBool(this.getAttribute('overflow'))) {
            this.hasVerticalScrollbar = this.scrollHeight > this.clientHeight;
            this.hasHorizontalScrollbar = this.scrollWidth > this.clientWidth;
            if (this.hasHorizontalScrollbar) {
                this._text.style.width = "100%";
            } else {
                this._text.style.width = "";
            }
            if (this.hasVerticalScrollbar) {
                this._text.style.height = "100%";
            } else {
                this._text.style.height = "";
            }
        }
    }

    _getDisplayValue(format, value = this._sourceValue) {
        return getFormattedValue(
            format,
            this._sourceDateObj ? this._sourceDateObj.value : value,
            this._sourceDateObj ? this._sourceDateObj.type : '',
            { sourceId: this.id, targetId: this.id }
        );
    }

    get sourceDateObj() {
        return this._sourceDateObj;
    }
    set sourceDateObj(timeObj) {
        this._sourceDateObj = timeObj;
    }
    /**
     * �����
     * @type {string}
     */
    get fontname() {
        return this._fontname;
    }
    set fontname(value) {
        this._fontname = value;
        this._text.style.fontFamily = value;
    }
    /**
     * ������ ������
     * @type {number}
     */
    get fontsize() {
        return this._fontSize;
    }
    set fontsize(value) {
        this._fontSize = value;
        this._text.style.fontSize = `${value}px`;
    }
    /**
     * �������������� ������������
     * @type {enum}
     */
    get texthorizontalalign() {
        return this._horizontalalign;
    }
    set texthorizontalalign(value) {
        this._horizontalalign = value;
        this.style.justifyContent = window._enums.AlignHorizontal[value];
        this.style.textAlign = window._enums.AlignText[value];

    }
    /**
     * ������������ ������������
     * @type {enum}
     */
    get textverticalalign() {
        return this._verticalalign;
    }
    set textverticalalign(value) {
        this._verticalalign = value;
        this.style.alignItems = window._enums.AlignVertical[value];
    }
    /**
     * ������
     * @type {bool}
     */
    get fontitalic() {
        return this._italic;
    }
    set fontitalic(value) {
        this._italic = value || false;
        this._text.style.fontStyle = this._toBool(value) ? 'italic' : 'normal';
    }
    /**
     * ������
     * @type {bool}
     */
    get fontbold() {
        return this._bold || false;
    }
    set fontbold(value) {
        this._bold = value;
        this._text.style.fontWeight = this._toBool(value) ? 'bold' : 'normal';
    }
    /**
     * ���������������
     * @type {bool}
     */
    get fontmultiline() {
        return this._multiline;
    }
    set fontmultiline(value) {
        this._multiline = value;
        this._text.style.whiteSpace = this._toBool(value) ? 'normal' : 'nowrap';
    }
    /**
     * ������������
     * @type {bool}
     */
    get fontunderlined() {
        return this._underline || false;
    }
    set fontunderlined(value) {
        this._underline = value;
        this._text.style.textDecoration = this._toBool(value) ? 'underline' : 'none';
    }
    /*
    get cornerradius(){
        return this._radius;
    }
    set cornerradius(value){
        this._radius = value;
        this.style.borderRadius = this._setValueUnit(value);
    }
    */
    /**
     * ���� ������
     * @type {string}
     */
    get textcolor() {
        return this._text.style.color;
    }
    set textcolor(value) {
        this._text.style.color = value;
    }
    /**
     * ����������� ���������
     * @type {bool}
     */
    get overflow() {
        return this._overflow;
    }
    set overflow(v) {
        this._overflow = this._toBool(v);
        this.style.overflow = this._overflow ? 'auto' : 'hidden';
        this._detectScroll();
    }

    disconnectedCallback() {
        if (this._text) {
            this._text.remove()
            delete this._text
        }
        super.disconnectedCallback()
        this.shadowRoot.innerHTML = ''
    }

}
