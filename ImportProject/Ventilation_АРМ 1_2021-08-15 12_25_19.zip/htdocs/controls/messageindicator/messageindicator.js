﻿import { Basic } from '../basic.js';
import { journalWorker } from '../../observer/journalWorker.js';
import { MSPopUpWindow } from '../popup_window/popup_window.js';
import { getUniqueNumber } from '../../lib/utils.js';

/**
 * @class MSMessageIndicator
 * @extends Basic
 * @classdesc Индикатор событий
 * */
export class MSMessageIndicator extends Basic {

    static get observedAttributes() {
        return super.observedAttributes.concat([
            'updateperiod',
            'hasmessages',
            'filters',
            'objectuid',
            'datasource'
        ]);
    }

    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<div style="display:none;position:absolute;font-size:1em;right:0;background:#ff0000ad;color:white;padding:0.1em 0.3em;margin:0.1em;border-radius:3px;"></div>`;

        //this.style.position = 'absolute';
        this.style.userSelect = 'none';
        this.style.display = 'flex';
        this.style.overflow = 'hidden'
        this.style.boxSizing = 'border-box';

        this._main = shadowRoot.querySelector('div');
        this.addEventListener('click', this._click.bind(this));

        this._baseFilds = [
            { name: 'EventId', type: 'STRING' }
        ];

        this._clientHandle = 1;
        this._recs = [];

        this.sw = new journalWorker("msg_indicator" + getUniqueNumber(), 1);
        this.sw.upData = this._upData.bind(this);
        this.needReCreate = false;

    }
     /**
     * Период обновления
     * @type {number}
     */
    get updateperiod() {
        return this.sw.options.updatePeriod;
    }
    set updateperiod(value) {
        this.sw.options.updatePeriod = Number(value);
    }
    /**
     * Есть сообщения
     * @readonly
     * @type {bool}
     */
    get hasmessages() {
        return this._hasmessages;
    }
    set hasmessages(value) {
        this._hasmessages = this._toBool(value);
    }
    /**
     * Фильтры
     * @type {JSON}
     */
    get filters() {
        return this._filters;
    }
    set filters(value) {
        try {
            this._filters = JSON.parse(value).filter;
            if (typeof this._filters === 'object' && !Array.isArray(this._filters)) this._filters = [this._filters];
        } catch (e) {
            this._filters = null;
        }
        if (this._inited) this._reMonitoredEvents();
    }
    /**
     * Объект
     * @type {number}
     */
    get objectuid() {
        return this._objectuid;
    }
    set objectuid(value) {
        this._objectuid = Number(value);
        if (this._inited) this._reMonitoredEvents();
    }
    /**
     * Журнал
     * @type {string}
     */
    get datasource() {
        return this._datasource;
    }
    set datasource(value) {
        this._datasource = value;
    }

    _calcFilters() {
        const res = [];
        if (typeof this._filters !== 'undefined') {
            for (let i = 0; i < this._filters.length; i++) {
                const element = this._filters[i];
                if (this._toBool(element.enabled)) {
                    res.push(element.condition);
                }
            }
        }

        return res;

    }

    async _createMonitoredEvents() {
        this._inited = true;
        const packet = {
            clientHandle: this._clientHandle++,
            fields: this._baseFilds,
            filter: this._calcFilters(),
            path: '',
            taskId: 0
        };
        if (this._objectuid) {
            packet.itemId = this._objectuid;
        } else {
            packet.itemId = $sw.ItemSubscription._getParentParam(this, "objectid");
            packet.taskId = $sw.ItemSubscription._getParentParam(this, "taskid");
        }

        return await this.sw.CreateMonitoredEvents([packet])
            .then((data) => {
                if (data.code != 0) { console.log(data.code.toString(16)); return; }
                this.monitoredItemId = data.items[0].monitoredItemId;
                if (this.needReCreate) {
                    this.needReCreate = false;
                    this._reMonitoredEvents();
                    return;
                }
                this.sw.RefreshEvents();
                this._busyMonitoredEvents = false;
            })
            .catch(error => {
                console.log(error);
            });
    }

    update() {
        if (this._recs.length > 0) {
            this.SetParameter('hasmessages', true);
            this._main.style.display = 'flex';
            this._main.innerText = this._recs.length;
        } else {
            this.SetParameter('hasmessages', false);
            this._main.style.display = 'none';
        }
    }

    _upData(ans) {
        const recs = ans.recs || [];
        const del = ans.deleted || [];

        for (let index = 0; index < recs.length; index++) {
            const element = recs[index];

            const i = this._recs.findIndex(item => {
                return item[0].substr(12) === element.fields[0].substr(12);
            });
            switch (element.recType) {
                case 'Update':
                case 'UpdateArchive':
                case 'Refresh':
                    if (i < 0) {
                        this._recs.push(element.fields);
                    } else {
                        this._recs[i] = element.fields;
                    }
                    break;
                case 'Acknowledge':
                    break;
            }

        }

        for (let index = 0; index < del.length; index++) {
            const element = del[index];
            element.eventIds.forEach(el => {
                const i = this._recs.findIndex(item => {
                    return item[0].substr(13) === el.substr(13);
                });
                if (i > -1) {
                    this._recs.splice(i, 1);
                }
            });
        }

        this.update();
    }

    _click(e) {
        e.preventDefault();
        if (this._datasource) {
            if (this.dialog && this.dialog.isConnected) {
                this.dialog.close();
                this.dialog = null;
            } else {
                this.dialog = null;
                const a = new MSPopUpWindow();
                a.dragable = true;
                a.modal = false;
                a.title = '';
                a.sizetocontent = 1;
                a.height = $WinDefs.winDef[this._datasource].height;
                a.width = $WinDefs.winDef[this._datasource].width;
                a.minimized = false;
                a.closable = true;
                // a.titlecolor = this.HeaderBackgroundColor;
                const b = $WinService.addWindow(a);
                if (!b) return;
                a.openWindow({
                    id: this._datasource,
                    template: 't_' + this._datasource,
                    typeid: this._datasource,
                    isvisible: true,
                    isenabled: true,
                    dockstyle: 3,
                    height: $WinDefs.winDef[this._datasource].height,
                    width: $WinDefs.winDef[this._datasource].width,
                    objectid: $sw.ItemSubscription._getParentParam(this, "objectid"),
                    taskid: $sw.ItemSubscription._getParentParam(this, "taskid"),
                });
                this.dialog = b;
            }
        }
    }

    connectedCallback() {
        this.style.fontSize = parseInt(this.clientWidth / 3);
        this.sw.Subscribe().then(this._createMonitoredEvents.bind(this)).then(this.sw.StartWatch.bind(this.sw));
    }

    disconnectedCallback() {
        super.disconnectedCallback();
        this.removeEventListener('click', this._click.bind(this));
        if (this.monitoredItemId) { this.sw.DeleteMonitoredEvents(this.monitoredItemId); }
        this.sw.StopWatch();
        this.sw.ServerAdapter.dispose();
    }

    _reMonitoredEvents() {
        if (this._busyMonitoredEvents || typeof this.monitoredItemId === 'undefined') {
            this.needReCreate = true;
            return;
        };
        this._busyMonitoredEvents = true;
        this.sw.DeleteMonitoredEvents(this.monitoredItemId)
            .then(data => {
                if (data.code != 0) { console.log(data.code.toString(16)); return; }
                this._createMonitoredEvents();
            }).catch(error => {
                console.log('error', error);
            });
        this.monitoredItemId = undefined;
    }


    attributeChangedCallback(attrName, oldVal, newVal, itemIndex) {
        if (this.constructor.observedAttributes.indexOf(attrName) < 0) {
            const p = attrName.split('.');
            if (p.length > 1) {
                if (this[p[0]][p[1]][p[2]] != newVal) {
                    this[p[0]][p[1]][p[2]] = newVal;
                    if (p[0] === 'filters') {
                        this._reMonitoredEvents();
                    }
                    if (this.prop_link[p[0]]) {
                        this.prop_link[p[0]](
                            this.pId ? this.pId + '/' + this.id : this.id,
                            this.Links[p[0]],
                            this[p[0]],
                            p[0],
                            itemIndex
                        );
                    }
                }
            }
        } else {
            super.attributeChangedCallback(attrName, oldVal, newVal);
        }
    }
}