import { BasicSVG } from "../basicsvg.js";
/**
 * @class MSRect
 * @extends BasicSVG
 * @classdesc �������������
 * */
export class MSRect extends BasicSVG {
    constructor() {
        super();
        this._createInnerSVG('rect');
        this.borderthickness = 2;
        this.backgroundcolor = 'TRANSPARENT'
    }

    set width(value) {
        this._width = value;
        const tmp = Number(value);
        if (tmp) {
            this.style.width = this._setValueUnit(value);
            this._path.setAttribute('width', tmp);
        }
    }

    set height(value) {
        this._height = value;
        const tmp = Number(value);
        if (tmp) {
            this.style.height = this._setValueUnit(value);
            this._path.setAttribute('height', tmp);
        }
    }

    /**
    * ����������� ����
    * @type {string}
    */
    get resource() {
        return this._resource;
    }
    set resource(value) {
        this._resource = value;
        if (this._resource) {
            if (this._pattern) this._pattern.remove();

            this._resource = this.getResourceFromList(value);
            this._pattern = document.createElementNS(this._svgNS, 'pattern');
            this._pattern.setAttributeNS('', 'height', '100%');
            this._pattern.setAttributeNS('', 'width', '100%');
            this._pattern.id = `patt_${this.id}`;
            this._pattern_img = document.createElementNS(this._svgNS, 'image');
            this._pattern_img.setAttributeNS('', 'height', '100%');
            this._pattern_img.setAttributeNS('', 'width', '100%');
            this._pattern_img.setAttributeNS('', 'href', `resources/${this._resource}`);
            this._pattern.appendChild(this._pattern_img);
            this._main.appendChild(this._pattern);
            this._path.setAttributeNS('', 'fill', `url(#${this._pattern.id})`);
        } else {
            this._path.setAttributeNS('', 'fill', `${this.backgroundcolor}`);
            this._pattern.remove();
        }
    }
}