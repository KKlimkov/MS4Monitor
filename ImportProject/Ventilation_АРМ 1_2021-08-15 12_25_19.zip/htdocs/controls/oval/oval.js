import { BasicSVG } from "../basicsvg.js";
/**
 * @class MSOval
 * @extends BasicSVG
 * @classdesc ????
 * */
export class MSOval extends BasicSVG {
    constructor() {
        super();
        this._createInnerSVG('ellipse');
        this._path.pointerEvents = 'auto';
        this._main.style.pointerEvents = 'none';
        this._main.style.position = 'absolute';
        this._main.style.width = '100%';
        this._main.style.height = '100%';
        this.borderthickness = 2;
        this.backgroundcolor = 'TRANSPARENT';
    }

    set borderthickness(value) {
        this._borderthickness = Number(value || 0);
        super.borderthickness = value;
        this._calcOval();
    }

    set width(value) {
        this._width = value;
        this._calcOval();
    }

    set height(value) {
        this._height = value;
        this._calcOval();
    }

    _calcOval() {
        const offset = (this._borderthickness + 1) / 2
        const tmpW = Number(this._width);
        if (tmpW) {
            const r1 = Math.ceil(tmpW / 2);
            this._path.setAttribute('cx', r1);
            const rr1 = r1 - this._borderthickness < 0 ? 0 : r1 - offset;
            this._path.setAttribute('rx', rr1);
        }

        const tmpH = Number(this._height);
        if (tmpH) {
            const r2 = Math.ceil(tmpH / 2);
            this._path.setAttribute('cy', r2);
            const rr2 = r2 - this._borderthickness < 0 ? 0 : r2 - offset;
            this._path.setAttribute('ry', rr2);
        }
        const { width, height } = this._path.getBBox();
        this.style.width = this._width + 'px';
        this.style.height = this._height + 'px';
    }

    /**
     * ����������� ����
     * @type {string}
     */
    get resource() {
        return this._resource;
    }
    set resource(value) {
        this._resource = value;
        if (this._resource) {
            if (this._pattern) this._pattern.remove();

            this._resource = this.getResourceFromList(value);
            this._pattern = document.createElementNS(this._svgNS, 'pattern');
            this._pattern.setAttributeNS('', 'height', '100%');
            this._pattern.setAttributeNS('', 'width', '100%');
            this._pattern.id = `patt_${this.id}`;
            this._pattern_img = document.createElementNS(this._svgNS, 'image');
            this._pattern_img.setAttributeNS('', 'height', '100%');
            this._pattern_img.setAttributeNS('', 'width', '100%');
            this._pattern_img.setAttributeNS('', 'preserveAspectRatio', 'none');
            this._pattern_img.setAttributeNS('', 'href', `resources/${this._resource}`);
            this._pattern.appendChild(this._pattern_img);
            this._main.appendChild(this._pattern);
            this._path.setAttributeNS('', 'fill', `url(#${this._pattern.id})`);
        } else {
            this._path.setAttributeNS('', 'fill', `${this.backgroundcolor}`);
            this._pattern.remove();
        }
    }
}
