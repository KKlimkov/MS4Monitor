import { Basic } from "./basic.js";
/**
 * @class BasicSVG
 * @extends Basic
 * @classdesc Базовый класс для SVG-элементов
 * */
export class BasicSVG extends Basic {
    constructor() {
        super();
        this._svgNS = "http://www.w3.org/2000/svg";
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML =
            `<svg xmlns:svg=${this._svgNS} preserveAspectRatio="none" style="width: 100%; height: 100%; overflow: visible;"></svg>`;
        this.style.overflow = 'visible';
        this.style.pointerEvents = 'none';
        this.style.borderWidth = 0;
        this._main = this.shadowRoot.querySelector('svg');
        //this.style.position = 'absolute';
    }
    /**
     * Создать элемент SVG
     * @param {string} elem название тега
     */
    _createInnerSVG(elem) {
        this._main.appendChild(document.createElementNS(this._svgNS, elem));
        this._path = this._main.querySelector(elem);
    }
    get backgroundcolor() {
        return this._fill;
    }
    set backgroundcolor(value) {
        if (typeof value !== 'string') {
            return;
        }
        this._fill = value;
        if (this._path) {
            const color = value.split(' ');
            if (color.length > 1) { //градиент - больше одного цвета
                const gradient = this._setFill(color, color[0]);
                this._path.setAttribute('fill', gradient);
            } else {
                // this.style.fill = value;
                const color = this._transformHexColor(value);
                this._path.setAttribute('fill', color);
            }
        }
    }
    /**
     * Задать заливку
     * @see https://www.w3schools.com/graphics/svg_grad_linear.asp
     * @param {string} color цвет
     * @param {string} name id элемента, который заливают
     * @return {string} ссылка на градиент
     */
    _setFill(color, name) {
        let gradient;

        if (!this.def) {
            this.def = document.createElementNS(this._svgNS, 'defs');
            this._main.appendChild(this.def);
        }

        if (color[0].toLowerCase() == 'radialgradient') {
            gradient = document.createElementNS(this._svgNS, 'radialGradient');
        } else {
            gradient = document.createElementNS(this._svgNS, 'linearGradient');
        }
        let sets;
        gradient.setAttribute('id', this.id + '_' + name);
        switch (color[0].toLowerCase()) {
            case 'topgradient':
                gradient.setAttribute('x1', '0');
                gradient.setAttribute('y1', '0');
                gradient.setAttribute('x2', '0');
                gradient.setAttribute('y2', '1');
                sets = this._getLinearPoints(color);
                break;
            case 'leftgradient':
                gradient.setAttribute('x1', '0');
                gradient.setAttribute('y1', '0');
                gradient.setAttribute('x2', '1');
                gradient.setAttribute('y2', '0');
                sets = this._getLinearPoints(color);
                break;
            case 'bottomgradient':
                gradient.setAttribute('x1', '0');
                gradient.setAttribute('y1', '1');
                gradient.setAttribute('x2', '0');
                gradient.setAttribute('y2', '0');
                sets = this._getLinearPoints(color);
                break;
            case 'rightgradient':
                gradient.setAttribute('x1', '1');
                gradient.setAttribute('y1', '0');
                gradient.setAttribute('x2', '0');
                gradient.setAttribute('y2', '0');
                sets = this._getLinearPoints(color);
                break;
            case 'topleftgradient':
                gradient.setAttribute('x1', '0');
                gradient.setAttribute('y1', '0');
                gradient.setAttribute('x2', '1');
                gradient.setAttribute('y2', '1');
                sets = this._getLinearPoints(color);
                break;
            case 'toprightgradient':
                gradient.setAttribute('x1', '1');
                gradient.setAttribute('y1', '0');
                gradient.setAttribute('x2', '0');
                gradient.setAttribute('y2', '1');
                sets = this._getLinearPoints(color);
                break;
            case 'bottomleftgradient':
                gradient.setAttribute('x1', '0');
                gradient.setAttribute('y1', '1');
                gradient.setAttribute('x2', '1');
                gradient.setAttribute('y2', '0');
                sets = this._getLinearPoints(color);
                break;
            case 'bottomrightgradient':
                gradient.setAttribute('x1', '1');
                gradient.setAttribute('y1', '1');
                gradient.setAttribute('x2', '0');
                gradient.setAttribute('y2', '0');
                sets = this._getLinearPoints(color);
                break;
            case 'radialgradient':
                const radiusScale = Math.ceil(100 - (100 / (color.length - 7))) / 100;
                const cx = color[3],
                    cy = color[4],
                    rx = color[5] * radiusScale,
                    ry = color[6] * radiusScale;
                gradient.setAttribute('cx', cx);
                gradient.setAttribute('cy', cy);
                gradient.setAttribute('rx', rx);
                gradient.setAttribute('ry', ry);
                sets = this._getRadialPoints(color);
                break;
        }
        gradient.innerHTML = sets;
        if (this.def.innerHTML !== '') this.def.innerHTML = '';
        this.def.appendChild(gradient);

        return 'url(#' + this.id + '_' + name + ')';
    }

    _getLinearPoints(color) {
        let sets = '';
        const pr = 100 / (color.length - 2);
        let pr_step = 0;
        for (let i = 1; i < color.length; i++) {
            sets += '<stop offset="' + pr_step + '%" stop-color="' + color[i] + '"/>';
            pr_step += pr;
        }
        return sets;
    }

    _getRadialPoints(color) {
        let sets = '';
        let colorItems = color.slice(7);
        const pr = 100 / (colorItems.length - 1);
        let pr_step = 0;
        for (let i = 0; i < colorItems.length; i++) {
            sets += '<stop offset="' + pr_step + '%" stop-color="' + colorItems[i] + '"/>';
            pr_step += pr;
        }
        return sets;
    }


    get borderthickness() {
        return this._main.getAttribute('stroke-width');
    }
    set borderthickness(value) {
        if (value > 0) {
            this._main.setAttribute('stroke', this._bordercolor || '#000');
            this._main.setAttribute('stroke-width', value);
        } else {
            this._main.setAttribute('stroke', 'hidden');
            this._main.setAttribute('stroke-width', 0);
        }
    }

    get bordercolor() {
        return this._main.getAttribute('stroke');
    }
    set bordercolor(value) {
        this._bordercolor = value;
        this._main.setAttribute('stroke', value);
    }
    get bordergeometry() {
        return this._bordergeometry;
    }
    set bordergeometry(value) {
        this._main.removeChild(this._path);
        this._main.appendChild(document.createElementNS(this._svgNS, "path"));
        this._path = this._main.querySelector("path");
        this._path.setAttributeNS(null, "d", value);
        this._fill && (this.backgroundcolor = this._fill);
        this._borderstyle && (this.borderstyle = this._borderstyle);
    }
    /**
     * Размер тени
     * @type {number}
     */
    get shadowsize() {
        return this._shadowsize;
    }
    set shadowsize(value) {
        value = parseInt(value, 10);
        if (value >= 0) {
            this._shadowsize = value;
            this._calcSVGShadow();
        }
    }

    /**
     * Цвет тени
     * @type {string}
     */
    get shadowcolor() {
        return this._shadowcolor;
    }
    set shadowcolor(value) {
        this._shadowcolor = value ? this._transformHexColor(value) : '';
        this._calcSVGShadow();
    }
    get tooltip() {
        return this._tooltip;
    }
    set tooltip(value) {
        this._tooltip = value;
        this._main._tooltip = value;
        this.dataset.tooltip = value;
        if (value) {
            this._main.firstChild.style.pointerEvents = 'visible';
        } else {
            this._main.firstChild.style.pointerEvents = 'none';
        }
    }

    _calcSVGShadow() {
        if (!this._shadowsize || !this._shadowcolor) {
            this._main.style.filter = '';
            return;
        }
        this._main.style.filter = `drop-shadow(
            ${this._shadowcolor}
            ${this._shadowsize}px
            ${this._shadowsize}px
            1px)`;
    }
    get borderstyle() {
        return this._borderstyle;
    }
    set borderstyle(value) {
        this._borderstyle = value;
        const type = window._enums.BorderStyleType[value];
        switch (type) {
            case 0:
                this._path.setAttribute('stroke-dasharray', '');
                break;
            case 1: //stroke-dasharray: 10, 10; пунктир
                this._path.setAttribute('stroke-dasharray', '10, 10');
                break;
            case 2: //stroke-dasharray: 2.5, 2.5; точки
                this._path.setAttribute('stroke-dasharray', '2.5 2.5');
                break;
            case 3:
                this._path.setAttribute('stroke-dasharray', '0 1');
                break;
        }
    }

    set actionlist(value) {
        super.actionlist = value;
        this.style.pointerEvents = '';
        this._main.style.pointerEvents = '';
    }
}
