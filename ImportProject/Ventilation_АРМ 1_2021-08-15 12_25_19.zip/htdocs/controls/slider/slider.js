"use strict";
/**
 * @class MSSlider
 * @extends Basic
 * @classdesc ��������������/������������ ��������
 * */
import { Basic } from "../basic.js";
export class MSSlider extends Basic {

    static get observedAttributes() {
        return super.observedAttributes.concat([
            'orientation',
            'minvalue',
            'value',
            'maxvalue',
            'forecolor',
            'slidersize',
            'fillcolor',
            'foreborderradius',
            'isoverflow',
            'overflowsize',
            'foreborderwidth',
            'foreborderfill'
        ]);
    }

    constructor() {
        super();
        this.shRoot = this.attachShadow({ mode: 'closed' });
        this.shRoot.innerHTML = `
            <style>
                input{
                    cursor:pointer;
                    height:100%;
                    width:100%;
                    opacity: 0;
                    margin: 0;
                    padding: 0;
                }
            </style>
            <div id="sliderfill" style="height:100%; width:100%; position:relative;" >
                <input id="customrange" type="range" min="0" max="100" value="50">
                <div id="fill" style="display:none; bottom:0; left:0; position:absolute; pointer-events:none; box-sizing: border-box;"></div>
                <div id='stc' style='position:absolute; pointer-events:none; height:100%; width:100%;'>
                    <div id="sliderthumb" style='position:absolute; pointer-events:none; box-sizing: border-box;'></div>
                </div>
            </div>
            `;
        this.style.overflow = 'unset'
        //this.style.position = 'absolute';
        this.style.boxSizing = 'border-box';
        this._sliderfill = this.shRoot.getElementById('sliderfill');
        this._customrange = this.shRoot.getElementById('customrange');
        this._sliderthumb = this.shRoot.getElementById('sliderthumb');
        this._fill = this.shRoot.getElementById('fill');
        this._stc = this.shRoot.getElementById('stc');

        this._sliderthumb.style.borderStyle = 'solid';


        this._updateSliderBind = this._updateSlider.bind(this);
        this._updateWheelBind = this._updateWheel.bind(this);

        this._customrange.addEventListener('input', this._updateSliderBind);
        this._customrange.addEventListener('change', this._updateSliderBind);
        this._customrange.addEventListener('mousewheel', this._updateWheelBind);

        this._orientation = 0;
        this._slidersize = 20;
        this._isoverflow = false;

        this._setThumbValue();
        //
        this.forecolor = "rgb(191,191,191)";
        this.foreborderwidth = 0;
        this.backgroundcolor = "rgb(245,240,245)";
    }

    get isoverflow() {
        return !this._isoverflow;
    }
    set isoverflow(value) {
        this._isoverflow = !this._toBool(value);
        this._setTumb();
    }

    get overflowsize() {
        return this._overflowsize;
    }
    set overflowsize(value) {
        this._overflowsize = parseInt(value);
        this._setTumb();
    }

    get orientation() {
        return this._orientation;
    }
    set orientation(value) {
        // window._enums.OrientationType[value]
        this._orientation = value;
        if (value == 1) {
            this._customrange.setAttribute('orient', 'vertical');
            this._customrange.style.webkitAppearance = 'slider-vertical';
        } else {
            this._customrange.removeAttribute('orient');
            this._customrange.style.webkitAppearance = '';
        }
        this._setTumb();
    }

    get minvalue() {
        return this._minvalue || 0;
    }
    set minvalue(value) {
        this._minvalue = Number(value) || 0;
        this._customrange.setAttribute('min', value);
        if (this.value < this._minvalue) {
            this.SetParameter('value', this._minvalue);
            return;
        }
        this._setThumbValue(this.value);
    }

    get maxvalue() {
        return this._maxvalue || 100;
    }
    set maxvalue(value) {
        this._maxvalue = Number(value) || 0;
        this._customrange.setAttribute('max', value);
        if (this.value > this._maxvalue) {
            this.SetParameter('value', this._maxvalue);
            return;
        }
        this._setThumbValue(this.value);
    }

    get value() {
        return this._customrange.value;
    }
    set value(value) {
        this._customrange.value = value;
        if (value > this.maxvalue) {
            this._adjustValue(this.maxvalue);
            return;
        }
        if (value < this.minvalue) {
            this._adjustValue(this.minvalue);
            return;
        }
        this._setThumbValue(value);
    }

    get slidersize() {
        return this._slidersize;
    }
    set slidersize(value) {
        this._slidersize = parseInt(value, 10);
        this._setTumb();
    }

    get fillcolor() {
        return this._fillcolor;
    }
    set fillcolor(value) {
        this._fillcolor = value;
        this._updateFillDiv();
    }

    get forecolor() {
        return this._sliderthumb.style.backgroundColor;
    }
    set forecolor(value) {
        this._sliderthumb.style.backgroundColor = value;
    }

    get foreborderwidth() {
        return this._sliderthumb.style.borderWidth;
    }
    set foreborderwidth(value) {
        this._sliderthumb.style.borderWidth = this._setValueUnit(value);
    }

    get foreborderfill() {
        return this._sliderthumb.style.borderColor;
    }
    set foreborderfill(value) {
        this._sliderthumb.style.borderColor = value;
    }

    get foreborderradius() {
        return this._sliderthumb.style.borderRadius;
    }
    set foreborderradius(value) {
        this._sliderthumb.style.borderRadius = this._setValueUnit(value);;
    }

    get cornerradius() {
        return this.style.borderRadius;
    }
    set cornerradius(value) {
        const val = this._setValueUnit(value / 2);
        this.style.borderRadius = val;
        this._sliderfill.style.borderRadius = val;
        if (this._orientation == 0) {
            this._fill.style.borderRadius = `${val} 0 0 ${val}`;
        } else {
            this._fill.style.borderRadius = `0 0 ${val} ${val}`;
        }
    }

    set backgroundcolor(value) {
        if (value && typeof value === 'string') {
            this._backgroundcolor = value;
            if (value.indexOf(' ') !== -1) {
                this._sliderfill.style.background = this._calcGradient(value);
            } else {
                this._sliderfill.style.backgroundColor = value;
            }
            this._updateFillDiv();
        }
    }

    set resource(value) {
        if (value) {
            value = this._resource = this.getResourceFromList(value);
            if (value.toLocaleLowerCase().endsWith('svg')) {
                this._svgResource = true;
                this.style.borderWidth = 0;
            }
            this._calcBacgraund(this._sliderfill);
            this._calcBlockShadow();
        } else {
            this._sliderfill.style.backgroundImage = ``;
        }
    }
    set backgroundtile(value) {
        this._backgroundtile = window._enums.TileType[value];
        if (this._resource && this._resource != "") {
            this._calcBacgraund(this._sliderfill);
        }
    }

    _updateFillDiv() {
        if (typeof this._fillcolor === 'undefined') return;
        if (this._fillcolor != this._backgroundcolor && this._fillcolor !== 'TRANSPARENT') {
            this._fill.style.display = 'block';
            this._fill.style.backgroundColor = this._fillcolor;
        } else {
            this._fill.style.display = 'none';
        }
    }

    connectedCallback() {
        super.connectedCallback();
        this._setTumb();
    }

    disconnectedCallback() {
        super.disconnectedCallback();
        this._customrange.removeEventListener('input', this._updateSliderBind);
        this._customrange.removeEventListener('change', this._updateSliderBind);
        this._customrange.removeEventListener('mousewheel', this._updateWheelBind);

        this._sliderfill = null
        this._customrange = null
        this._sliderthumb = null
        this._fill = null
        this._stc = null
    }

    _adjustValue(value) {
        const timerId = setTimeout(() => {
            this.SetParameter('value', value);
            clearTimeout(timerId);
        }, 0);
    }

    _updateSlider(e) {
        const val = parseInt(e.target.value, 10);
        if (e.type === 'change') {
            this.SetParameter('value', val)
        } else {
            this._setThumbValue(val)
        }
    }

    _updateWheel(e) {
        const delta = e.wheelDelta;
        if (delta > 0) {
            const val = parseInt(this.value) + 1;
            if (val <= parseInt(this.maxvalue)) {
                this.SetParameter('value', val);
            }
        } else {
            if (this.value > 0) {
                const val = parseInt(this.value) - 1;
                if (val >= parseInt(this.minvalue)) {
                    this.SetParameter('value', val);
                }
            }
        }

        return false;
    }

    _setTumb() {
        if (this._orientation == 0) {
            this._fill.style.top = '0';
            this._fill.style.right = '';
            this._fill.style.height = '';

            this._sliderthumb.style.height = '';
            this._sliderthumb.style.bottom = '';
            this._sliderthumb.style.width = this._setValueUnit(this._slidersize);

            if (this._overflowsize > 0) {
                this._sliderthumb.style.top = this._sliderthumb.style.bottom = -this._overflowsize + 'px';
            } else {
                this._sliderthumb.style.top = 0;
                this._sliderthumb.style.bottom = 0;
            }

            if (this._isoverflow) {
                this._stc.style.padding = ``;
                this._stc.style.left = 0;
                this._stc.style.right = 0;

            } else {
                this._stc.style.width = '';
                this._stc.style.left = this._stc.style.right = `${this._slidersize / 2}px`;
                this._stc.style.top = 0;
                this._stc.style.bottom = 0;
            }
        } else {
            this._fill.style.top = '';
            this._fill.style.right = '0';
            this._fill.style.width = '';

            this._sliderthumb.style.width = '';
            this._sliderthumb.style.top = '';
            this._sliderthumb.style.height = this._setValueUnit(this._slidersize);

            if (this._overflowsize > 0) {
                this._sliderthumb.style.left = this._sliderthumb.style.right = -this._overflowsize + 'px';
            } else {
                this._sliderthumb.style.left = 0;
                this._sliderthumb.style.right = 0;
            }

            if (this._isoverflow) {
                this._stc.style.padding = ``;
                this._stc.style.top = 0;
                this._stc.style.bottom = 0;

            } else {
                this._stc.style.height = '';
                this._stc.style.top = this._stc.style.bottom = `${this._slidersize / 2}px`;
                this._stc.style.left = 0;
                this._stc.style.right = 0;
            }
        }
        this._setThumbValue(this.value);
    }

    _setThumbValue(val) {
        const fp = parseInt(this.maxvalue) - parseInt(this.minvalue);
        let percent = (val - parseInt(this.minvalue)) / (fp / 100);
        if (percent > 100) percent = 100;
        if (percent < 0) percent = 0;
        const thumbOffset = this._slidersize / 2;
        if (this._orientation == 0) {
            this._sliderthumb.style.left = `calc(${percent}% - ${thumbOffset}px)`;
            this._fill.style.width = `${percent}%`;
        } else {
            this._sliderthumb.style.bottom = `calc(${percent}% - ${thumbOffset}px)`;
            this._fill.style.height = `${percent}%`;
        }

    }
}
