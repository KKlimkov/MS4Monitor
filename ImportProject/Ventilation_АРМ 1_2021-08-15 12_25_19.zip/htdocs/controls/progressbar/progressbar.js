import { Basic } from "../basic.js";
/**
 * @class MSProgressBar
 * @extends Basic
 * @classdesc ��������������/������������ ��������
 * */
export class MSProgressBar extends Basic {

    static get observedAttributes() {
        return super.observedAttributes.concat([
            'minvalue',
            'maxvalue',
            'value',
            'fillcolor',
            'orientation'
        ]);
    }

    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<div id="p" style="align-self: flex-end;"></div>`;
        this._progress = shadowRoot.getElementById('p');

        this._orientation = 0;
        this._min = 0;
        this._max = 100;
        this._value = 50;

        this.AlignText = {
            Horizontal: 0,
            Vertical: 1,
            0: 0,
            1: 1
        }
        this._calcValue();
        //
        this.fillcolor = "rgb(191,191,191)";
        this.backgroundcolor = "rgb(245,240,245)";
    }

    get minvalue() {
        return this._min;
    }
    set minvalue(value) {
        this._min = Number(value);
        this._calcValue();
    }

    get maxvalue() {
        return this._max;
    }
    set maxvalue(value) {
        this._max = Number(value);
        this._calcValue();
    }

    get value() {
        return this._value || 0;
    }
    set value(value) {
        const v = Number(value);
        if (!isNaN(v)) {
            this._value = v;
            this._calcValue();
        }
    }

    get fillcolor() {
        return this._fillcolor;
    }
    set fillcolor(value) {
        this._fillcolor = value;
        this._progress.style.backgroundColor = value;
    }

    get orientation() {
        return this._orientation || 0;
    }
    set orientation(value) {
        this._orientation = value;
        this._calcValue();
    }

    get backgroundcolor() {
        return this.style.backgroundColor;
    }
    set backgroundcolor(value) {
        if (value && typeof value === 'string') {
            this.style.backgroundColor = this._calcGradient(value);
        }
    }


    _calcValue() {
        let v = this._value < this._min ? this._min : this._value > this._max ? this._max : this._value;

        const delta = this._max - this._min;
        const val = v - this._min;
        const percent = (val * 100) / delta;
        if (this._orientation == 0) {
            this._progress.style.height = '100%';
            this._progress.style.width = Math.round(percent) + '%';
        } else {
            this._progress.style.height = Math.round(percent) + '%';
            this._progress.style.width = '100%';
        }
    }
}