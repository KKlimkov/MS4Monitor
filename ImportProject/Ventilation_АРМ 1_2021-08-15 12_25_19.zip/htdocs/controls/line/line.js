﻿import { BasicSVG } from "../basicsvg.js";
/**
 * @class MSLine
 * @extends BasicSVG
 * @classdesc Линия
 * */
export class MSLine extends BasicSVG {
    constructor() {
        super();
        this._createInnerSVG('line');
        this._path.pointerEvents = 'auto';
        this._main.style.pointerEvents = 'none';
        this._main.style.position = 'absolute';
        this._main.style.width = 'auto';
        this._main.style.height = 'auto';
        this.borderthickness = 2;
    }

    get x() {
        return this._x;
    }
    set x(value) {
        this._x = value;
        this._updateWidth();
    }

    get y() {
        return this._y;
    }
    set y(value) {
        this._y = value;
        this._updateHeight();
    }

    set width(value) {
        this._width = value;
        this._updateWidth();
    }

    set height(value) {
        this._height = value;
        this._updateHeight();
    }

    get borderthickness() {
        return this._main.getAttribute('stroke-width');
    }
    set borderthickness(value) {
        if (value > 0) {
            this._main.setAttribute('stroke', this._bordercolor || '#000');
            this._main.setAttribute('stroke-width', value);
        } else {
            this._main.setAttribute('stroke', 'hidden');
            this._main.setAttribute('stroke-width', '');
        }
        this._updateHeight();
        this._updateWidth();
    }

    _updateHeight() {
        if (Number(this._height) < 0) {
            this.style.top = this._setValueUnit(Number(this._y) + Number(this._height));
        } else if (Number(this._height) === 0) {
            this.style.top = this._setValueUnit(this._y);
        } else {
            this.style.top = this._setValueUnit(this._y);
        }
        this._updateLine();
    }

    _updateWidth() {
        if (Number(this._width) < 0) {
            this.style.left = this._setValueUnit(Number(this._x) + Number(this._width));
        } else if (Number(this._width) === 0) {
            this.style.left = this._setValueUnit(this._x);
        } else {
            this.style.left = this._setValueUnit(this._x);
        }
        this._updateLine();
    }

    _updateLine() {
        if (!this._isNumeric(this._height, this._width, this._x, this._y)) return;

        let x1, y1, x2, y2;
        if (Number(this._width) < 0) {
            x1 = -Number(this._width);
            x2 = 0;
        } else {
            x2 = this._width;
            x1 = 0;
        }

        if (Number(this._height) < 0) {
            y1 = -Number(this._height);
            y2 = 0;
        } else {
            y2 = this._height;
            y1 = 0;
        }

        this._path.setAttribute('x1', x1);
        this._path.setAttribute('y1', y1);
        this._path.setAttribute('x2', x2);
        this._path.setAttribute('y2', y2);
    }
    get angle() {
        return this._rotate;
    }
    set angle(value) {
        this._rotate = Number(value);
        if (this._rotate) {
            const x = this._width / 2;
            const y = this._height / 2;
            const r = `rotate(${this._rotate} ${x} ${y})`;
            this._path.setAttribute('transform', r);
        } else {
            this._path.setAttribute('transform', '');
        }
    }

}
