﻿import { BasicSkin } from '../basic.js';
import { color2Matrix } from "../../lib/utils.js";
/**
 * @class MSGauge
 * @extends BasicSkin
 * @classdesc Стрелочный прибор
 * @see https://echarts.apache.org/en/option.html#series-gauge.type
 * */
export class MSGauge extends BasicSkin {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'text',
            'fontname',
            'fontsize',
            'texthorizontalalign',
            'textverticalalign',
            'fontitalic',
            'fontbold',
            'fontmultiline',
            'fontunderlined',
            'cornerradius',
            'textcolor',
            'value',
            'minvalue',
            'maxvalue',
            'intervalsnumber',
            'unit',
            'intervalticksnumber',
            'arrowcolor',
            'showvalue',
            'scalecolor',
            'precision'
        ]);
    }
    constructor() {
        super();

        this.minvalue = 0;
        this.maxvalue = 100;
        this._intervalsnumber = 10;
        this._intervalticksnumber = 5;
        this._arrowcolor = "RED";
        this._scalecolor = "BLACK";
        this._showvalue = true;
        this._value = 0;
        if (this.attributes.skinresource) {
            this._skinresource = this.attributes.skinresource.value;
            this._svgResource = true;
        }

        //this._onScaleChanged()
        this.fontname = "Tahoma";
        this.fontsize = 12;
        this.backgroundcolor = "transparent";
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<div></div>`;
        this._main = shadowRoot.querySelector('div');
        this._skinresource ?
            this.SetParameter('skinresource', this._skinresource) :
            this._setOptiponsInitGauge();
    }

    _setOptiponsInitGauge() {
        const options = {
            tooltip: {
                formatter: "{a} <br/>{b} : {c}%"
            },
            series: [
                {
                    name: 'Прибор',
                    type: 'gauge',
                    detail: { formatter: '{value}' },
                    data: [{ value: 50, name: 'ед' }],
                    min: 0,
                    max: 100,
                    radius: '100%',
                    startAngle: 180,
                    endAngle: 0
                }
            ],
            tooltip: {
                show: false
            }
        };
        this.gauge = echarts.init(this._main,
            null,
            {
                width: this.attributes.width.value,
                height: this.attributes.height.value
            });
        this.gauge.setOption(options);
    }

    _initSkin() {
        this._skin = this.shadowRoot.querySelector('svg');
        this._skin ? this._setEventsForSkin() : this._setInitInnerHtml();
        const label = this.shadowRoot.querySelector('label');
        if (label) {
            label.style.pointerEvents = 'none';
        }
    }

    _setEventsForSkin() {
        this._skin.style.width = '100%';
        this._skin.style.height = '100%';
        this._colorMatrix = this._skin.querySelector('#BackgroundColor');
        this._arrowMatrix = this._skin.querySelector('#ArrowColor');
        this._svgValue = this._skin.querySelector('#showValue');
        this._svgText = this._skin.querySelector('#Text');
        this._svgArrow = this._skin.querySelector('#arrow');
        this._svgScale = this._skin.querySelector('#scale');
        if (this._svgText && this._svgArrow && this._svgScale) {
            this._isSkin = true;
            this.style.borderStyle = 'none';
            this.backgroundcolor = this._backgroundcolor;
            this.showvalue = this._showvalue;
            this.textcolor = this._textcolor;
            this.fontunderlined = this._fontunderlined;
            this.fontsize = this._fontsize;
            this.fontname = this._fontname;
            this.fontitalic = this._fontitalic;
            this.fontbold = this._fontbold;
            this._onScaleChanged();
            this._onValueChanged();
            if (this._value || this._value === 0) {
                const displayValue = this.precision ? this._fixValue() : this._value;
                this._setTextContent(displayValue);
            }
            if (this._arrowcolor && this._arrowMatrix) {
                const color = color2Matrix(this._arrowcolor);
                this._arrowMatrix.setAttribute('values', color);
            }
        } else {
            this._setInitInnerHtml();
        }
    }

    _setTextContent(value) {
        let res = '';
        if ((value || value == 0)) {
            res = `${value}${this._unit ? this._unit : ''}`;
        }
        this._svgText.textContent = res;
    }

    _setInitInnerHtml() {
        this.shadowRoot.innerHTML = this._rootElem;
        this._main = this.shadowRoot.querySelector('div');
        this._setOptiponsInitGauge();
        this._showWarnSkin();
    }

    _resizeGauge(value) {
        if (this.gauge) {
            this.gauge.resize({
                width: value,
                height: value
            });
        }
    }

    set resource(value) {

    }

    get width() {
        return this._width;
    }
    set width(value) {
        this._width = value;
        const tmp = Number(value);
        if (tmp) {
            this.style.width = this._setValueUnit(value);
            this._resizeGauge(value);
        }
    }

    get height() {
        return this._height;
    }
    set height(value) {
        this._height = value;
        const tmp = Number(value);
        if (tmp) {
            this.style.height = this._setValueUnit(value);
            this._resizeGauge(value);
        }
    }

    get backgroundcolor() {
        return this._backgroundcolor;
    }
    set backgroundcolor(value) {
        if (value && typeof value === 'string') {
            this._backgroundcolor = value;
            if (this._skinresource && this._colorMatrix) {
                const color = color2Matrix(value);
                this._colorMatrix.setAttribute('values', color);
            } else if (!this._skinresource) {
                this.style.backgroundColor = this._calcGradient(value);
            }
        }
    }

    get precision() {
        return this._precision;
    }
    set precision(value) {
        value = parseInt(value, 10);
        if (value) {
            this._precision = value;
            if (this._skinresource) {
                if (this._isSkin) {
                    const displayValue = this._value ? this._fixValue() : this._value;
                    this._setTextContent(displayValue);
                }
            }
        }
    }

    get value() {
        return this._value;
    }
    set value(value) {
        if (this._isNumeric(value)) {
            this._value = value;
            if (this._skinresource && this._isSkin) {
                this._onValueChanged();
                const displayValue = this.precision ? this._fixValue() : this._value;
                this._setTextContent(displayValue);
            } else if (!this._skinresource && this.gauge) {
                this.gauge.setOption({ series: { data: [{ value: parseInt(this._value), name: this.attributes.unit ? this.attributes.unit.value : '' }] } });
            }
        }
    }

    get minvalue() {
        return this._minValue;
    }
    set minvalue(value) {
        if (this._isNumeric(value)) {
            this._minValue = parseInt(value, 10);
            if (this._skinresource && this._isSkin) {
                this.onMinMaxChanged();
            } else if (!this._skinresource && this.gauge) {
                this.gauge.setOption({ series: { min: this._minValue } });
            }
        }
    }

    get maxvalue() {
        return this._maxValue;
    }
    set maxvalue(value) {
        if (this._isNumeric(value)) {
            this._maxValue = parseInt(value, 10);
            if (this._skinresource && this._isSkin) {
                this.onMinMaxChanged();
            } else if (!this._skinresource && this.gauge) {
                this.gauge.setOption({ series: { max: this._maxValue } });
            }
        }
    }

    get intervalsnumber() {
        return this._intervalsnumber;
    }
    set intervalsnumber(value) {
        if (this._isNumeric(value)) {
            this._intervalsnumber = parseInt(value, 10);
            if (this._skinresource && this._isSkin) {
                this._onScaleChanged();
            } else if (!this._skinresource && this.gauge) {
                this.gauge.setOption({ series: { splitNumber: this._intervalsnumber } });
            }
        }
    }

    get unit() {
        return this._unit;
    }
    set unit(value) {
        this._unit = value;
        if (this._skinresource && this._isSkin) {
            this._setTextContent(this._value);
        } else if (!this._skinresource && this.gauge) {
            this.setAttribute('unit', value);
            this.gauge.setOption({ series: { data: [{ value: this._value, name: value }] } });
        }
    }

    get intervalticksnumber() {
        return this._intervalticksnumber;
    }
    set intervalticksnumber(value) {
        if (value) {
            this._intervalticksnumber = parseInt(value);
            if (this._skinresource && this._isSkin) {
                this._onScaleChanged();
            } else if (!this._skinresource && this.gauge) {
                this.gauge.setOption({ series: { axisTick: { splitNumber: this._intervalticksnumber } } });
            }
        }
    }

    get arrowcolor() {
        return this._arrowcolor;
    }
    set arrowcolor(value) {
        if (value) {
            this._arrowcolor = value;
            if (this._skinresource && this._arrowMatrix) {
                const color = color2Matrix(value);
                this._arrowMatrix.setAttribute('values', color);
            } else if (!this._skinresource && this.gauge) {
                this.gauge.setOption({ series: { itemStyle: { normal: { color: this._arrowcolor } } } });
            }
        }
    }

    get showvalue() {
        return this._showvalue;
    }
    set showvalue(value) {
        this._showvalue = this._toBool(value);
        if (this._skinresource && this._svgValue) {
            this._svgValue.style.display = this._showvalue ? 'inline' : 'none';
        } else if (!this._skinresource && this.gauge) {
            this.gauge.setOption({ series: { detail: { show: this._showvalue } } });
        }
    }

    get scalecolor() {
        return this._scalecolor;
    }
    set scalecolor(value) {
        if (value) {
            this._scalecolor = value;
            if (this._skinresource && this._isSkin) {
                this._onScaleChanged();
            } else if (!this._skinresource && this.gauge) {
                this.gauge.setOption({ series: { axisLine: { lineStyle: { color: [[0, value], [1, value]] } } } });
            }
        }
    }

    get fontname() {
        return this._fontname;
    }
    set fontname(value) {
        if (value) {
            this._fontname = value;
            if (this._skinresource && this._isSkin) {
                this._svgText.style.fontFamily = value;
            } else if (!this._skinresource && this.gauge) {
                this.gauge.setOption({ series: { detail: { fontFamily: value } } });
            }
        }
    }

    get fontsize() {
        return this._fontsize;
    }
    set fontsize(value) {
        value = parseInt(value, 10);
        if (value) {
            this._fontsize = value;
            if (this._skinresource && this._isSkin) {
                this._svgText.style.fontSize = `${value}px`;
            } else if (!this._skinresource && this.gauge) {
                this.gauge.setOption({ series: { detail: { fontSize: parseInt(value) } } });
            }
        }
    }

    get fontitalic() {
        return this._fontitalic;
    }
    set fontitalic(value) {
        this._fontitalic = this._toBool(value);
        if (this._skinresource && this._isSkin) {
            this._svgText.style.fontStyle = this._fontitalic ? 'italic' : 'normal';
        } else if (!this._skinresource && this.gauge) {
            this.gauge.setOption({ series: { detail: { fontStyle: this._fontitalic ? 'italic' : 'normal' } } });
        }
    }

    get fontbold() {
        return this._fontbold;
    }
    set fontbold(value) {
        this._fontbold = this._toBool(value);
        if (this._skinresource && this._isSkin) {
            this._svgText.style.fontWeight = this._fontbold ? 'bold' : 'normal';
        } else if (!this._skinresource && this.gauge) {
            this.gauge.setOption({ series: { detail: { fontWeight: this._fontbold ? 'bold' : 'normal' } } });
        }
    }

    get fontunderlined() {
        return this._fontunderlined;
    }
    set fontunderlined(value) {
        this._fontunderlined = this._toBool(value);
        if (this._skinresource && this._isSkin) {
            this._svgText.style.textDecoration = this._fontunderlined ? 'underline' : 'none';
        } else if (!this._skinresource && this.gauge) {
            this.gauge.setOption({ series: { detail: { textDecoration: this._fontunderlined ? 'underline' : 'none' } } });
        }
    }

    get textcolor() {
        return this._textcolor;
    }
    set textcolor(value) {
        if (value) {
            this._textcolor = value;
            if (this._skinresource && this._isSkin) {
                this._svgText.setAttribute('fill', value);
            } else if (!this._skinresource && this.gauge) {
                this.gauge.setOption({ series: { detail: { color: value } } });
            }
        }
    }

    _drawLine(point1, point2) {
        const newLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        newLine.setAttribute('id', "line" + this._lineId);
        newLine.setAttribute('x1', point1.x);
        newLine.setAttribute('y1', point1.y);
        newLine.setAttribute('x2', point2.x);
        newLine.setAttribute('y2', point2.y);
        const color = this._scalecolor ? this._scalecolor : '#ffffff';
        newLine.setAttribute('style', 'stroke: ' + color + ';stroke-width:2');
        this._lineId++;
        this._svgScale.appendChild(newLine);
    }

    _drawText(point, text) {
        const newText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        newText.setAttribute('id', "label" + this._textId);
        newText.setAttribute('x', point.x);
        newText.setAttribute('y', point.y);
        newText.setAttribute('font-size', 10);
        newText.setAttribute('text-anchor', 'middle');
        const color = this._scalecolor ? this._scalecolor : '#ffffff';
        newText.setAttribute('fill', color);
        newText.textContent = text;
        this._textId++;
        this._svgScale.appendChild(newText);
    }

    onMinMaxChanged(value) {
        this._onScaleChanged();
        this._onValueChanged();
    }

    _onScaleChanged(value) {
        this._svgScale.innerHTML = '';
        if (this._intervalsnumber > 0) {
            const radius = parseInt(this._svgScale.getAttribute("radius"));
            const length = parseInt(this._svgScale.getAttribute("length"));
            this._lineId = 0;
            this._textId = 0;
            const minAngle = this._getMinAngle();
            const maxAngle = this._getMaxAngle();
            const angleStep = (maxAngle - minAngle) / this._intervalsnumber;
            const innerAngleStep = angleStep / this._intervalticksnumber;
            const valueStep = (this._maxValue - this._minValue) / this._intervalsnumber;
            this._checkRotateCoords();
            for (let i = 0; i <= this._intervalsnumber; i++) {
                const angle = (i * angleStep + minAngle + 90) * (Math.PI / 180);
                this._drawLine({ x: this._calculateScaleX(radius, angle), y: this._calculateScaleY(radius, angle) },
                    { x: this._calculateScaleX(radius + length, angle), y: this._calculateScaleY(radius + length, angle) });
                this._drawText({ x: this._calculateScaleX(radius - 8, angle), y: this._calculateScaleY(radius - 8, angle) }, this._fixValue(parseInt(this._minValue, 10) + valueStep * i, this._precision));
                if (i < this._intervalsnumber) {
                    for (let j = 1; j < this._intervalticksnumber; j++) {
                        const inner_angle = angle + (j * innerAngleStep * Math.PI / 180);
                        this._drawLine({ x: this._calculateScaleX(radius + length / 2, inner_angle), y: this._calculateScaleY(radius + length / 2, inner_angle) },
                            { x: this._calculateScaleX(radius + length, inner_angle), y: this._calculateScaleY(radius + length, inner_angle) });
                    }
                }
            }
        }
    }

    _calculateScaleX(r, u) {
        return this._rotateX + r * Math.cos(u);
    }

    _calculateScaleY(r, u) {
        return this._rotateY + r * Math.sin(u);
    }

    _getCheckedValue(value) {
        let res = value;
        if (this.maxvalue - this.minvalue <= 0) {
            return 0;
        }
        if (value < this.minvalue) {
            res = this.minvalue;
        } else if (value > this.maxvalue) {
            res = this.maxvalue;
        }
        return Number(res);
    }

    _fixValue(value = this._value, prec = this._precision) {
        const fixed = value.toFixed(prec);
        const strVal = value.toString();
        return strVal.length < fixed.length ? value : parseFloat(fixed);
    }

    _changeAngleOfArrow(value = 0) {
        const k = (this._getMaxAngle() - this._getMinAngle()) / Math.abs(this._maxValue - this._minValue);
        const angle = (value - this.minvalue) * k;
        let transform = {};
        this._checkRotateCoords();
        transform.x = this._rotateX;
        transform.y = this._rotateY;
        transform.angle = Math.floor(angle);
        this._svgArrow.setAttribute('transform', this._formatRotate(transform));
    }

    _checkRotateCoords() {
        if (!this._rotateX || !this._rotateY) {
            let transform = this._parseRotate(this._svgArrow.getAttribute("transform"));
            this._rotateX = transform.x;
            this._rotateY = transform.y;
        }
    }

    _onValueChanged() {
        let val = this._value ? this._value : 0;
        const value = this._getCheckedValue(val);
        this._changeAngleOfArrow(value);
    }

    _parseRotate(rotation) {
        const parse = rotation.match(/rotate\(([0-9]*\.?[0-9]*)\s*([0-9]*\.?[0-9]*)?\s*([0-9]*\.?[0-9]*)?\)/);
        return { angle: Math.round(parseInt(parse[1])), x: Math.round(parseInt(parse[2])), y: Math.round(parseInt(parse[3])) };
    }

    _formatRotate(rotation) {
        return ('rotate(' + Math.floor(rotation.angle) + ' ' + Math.floor(rotation.x) + ' ' + Math.floor(rotation.y) + ')');
    }

    _getMaxAngle() {
        return parseInt(this._svgArrow.getAttribute("max-angle"));
    }

    _getMinAngle() {
        return parseInt(this._svgArrow.getAttribute("min-angle"));
    }
}