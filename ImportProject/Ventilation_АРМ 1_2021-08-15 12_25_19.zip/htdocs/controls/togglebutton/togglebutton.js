import { BasicSkin } from "../basic.js";
import { color2Matrix } from "../../lib/utils.js";

/**
 * @class MSToggleButton
 * @extends BasicSkin
 * @classdesc Кнопка
 */
export class MSToggleButton extends BasicSkin {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'ispressed',
            'isfixed',
            'text',
            'fontitalic',
            'fontbold',
            'texthorizontalalign',
            'textverticalalign',
            'fontunderlined',
            'textcolor',
            'fontsize',
            'fontname',
            'fontmultiline',
            'notsendbackwardconnection'
        ]);
    }

    constructor() {
        super();
        this._lockLink = this.getAttribute("notsendbackwardconnection");
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `
            <style>
                :host .tbmain {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }

                :host .tbtext {
                    display: flex;
                    vertical-align: middle;
                    text-align: center;
                    margin: 0 1em;
                    pointer-events: none;
                    user-select: none;
                    white-space: nowrap;
                }
                :host .button {
                    user-select: none;
                    color: #000000;
                    font-size: 14px;
                    font-family: helvetica, serif;
                    box-sizing: border-box;
                    }
            </style>
            <style>
            </style>
            <div class="tbmain button">
                <div class="tbtext"></div>
            </div>
        `;
        this.style.userSelect = 'none';
        this.style.borderStyle = 'unset';

        this._main = shadowRoot.querySelector('.tbmain');
        this._text = shadowRoot.querySelector('.tbtext');

        this._style = shadowRoot.querySelectorAll('style')[1];
        this.ispressed = false;
        this._isfixed = true;
        this._svgPressed = false;
        this._pressBtn = false;

        //
        this.backgroundcolor = "rgb(245,240,245)";
        this.fontsize = 12;
        this.fontname = "Tahoma";
        this.borderstyle = 0;
        this.borderthickness = 1;
        this.bordercolor = "GRAY";
    }

    get notsendbackwardconnection() {
        return this._lockLink;
    }
    set notsendbackwardconnection(value) {
        this._lockLink = this._toBool(value);
    }

    get ispressed() {
        return this._IsPressed;
    }

    set ispressed(value) {
        this._IsPressed = this._toBool(value);
        if (this._IsPressed) {
            this._main.classList.add('active');
            if (this._isSkin && !this._svgBtnPressed) {
                this._setSkinButton();
            }
        } else {
            this._main.classList.remove('active');
            if (this._isSkin && this._svgBtnPressed) {
                this._resetSkinButton();
            }
        }
    }

    get backgroundcolor() {
        return this._backColor;
    }
    set backgroundcolor(value) {
        if (value && typeof value === 'string') {
            this._backColor = value;
            // isGradient(value)
            if (this._isSkin) {
                if (!this._rgbaMatrix) {
                    return;
                }
                const color = color2Matrix(value);
                this._rgbaMatrix.setAttribute('values', color);
                this._backColor = color;
            } else {
                // this._main.style.backgroundColor = this._calcGradient(value);
                this._setRactionStyle(this._calcGradient(value));
            }
        }
    }

    /**
     * Ширина
     * @type {number}
     */
    get width() {
        return this._width;
    }
    set width(value) {
        this._width = value;
        const tmp = Number(value);
        if (tmp) {
            this._main.style.width = this._setValueUnit(value);
        }
    }

    /**
     * Высота
     * @type {number}
     */
    get height() {
        return this._height;
    }

    set height(value) {
        this._height = value;
        const tmp = Number(value);
        if (tmp) {
            this._main.style.height = this._setValueUnit(value);
        }
    }

    get text() {
        return this._textValue;
    }
    set text(value) {
        this._textValue = value;
        this._svgText ?
            this._svgText.textContent = value :
            this._text.innerText = value;
    }

    get fontname() {
        return this._fontname;
    }
    set fontname(value) {
        this._fontname = value;
        this._textField().style.fontFamily = value;
    }

    get fontsize() {
        return this._fontsize;
    }
    set fontsize(value) {
        this._fontsize = value;
        this._textField().style.fontSize = value;
    }

    get texthorizontalalign() {
        return this._horizontalalign;
    }
    set texthorizontalalign(value) {
        this._horizontalalign = value;
        this._main.style.justifyContent = window._enums.AlignHorizontal[value];
    }

    get textverticalalign() {
        return this._verticalalign;
    }
    set textverticalalign(value) {
        this._verticalalign = value;
        this._main.style.alignItems = window._enums.AlignVertical[value];
    }

    get fontitalic() {
        return this._italic;
    }
    set fontitalic(value) {
        this._italic = value || false;
        this._textField().style.fontStyle = this._toBool(value) ? 'italic' : 'normal';
    }

    get fontbold() {
        return this._bold || false;
    }
    set fontbold(value) {
        this._bold = value;
        this._textField().style.fontWeight = this._toBool(value) ? 'bold' : 'normal';
    }

    get fontmultiline() {
        return this._multiline;
    }
    set fontmultiline(value) {
        this._multiline = value;
        this._textField().style.whiteSpace = this._toBool(value) ? 'normal' : 'nowrap';
    }

    get fontunderlined() {
        return this._underline || false;
    }
    set fontunderlined(value) {
        this._underline = value;
        this._textField().style.textDecoration = this._toBool(value) ? 'underline' : 'none';
    }

    get textcolor() {
        return this._textcolor;
    }
    set textcolor(value) {
        this._textcolor = value;
        this._svgText ?
            this._svgText.setAttribute('fill', value) :
            this._text.style.color = value;
    }

    get isfixed() {
        return this._isfixed;

    }
    set isfixed(value) {
        this._isfixed = this._toBool(value);
    }

    get resource() {
        return this._resource;
    }
    set resource(value) {
        this.setResource(value, this._main);
    }

    get backgroundtile() {
        return this._backgroundtile;
    }
    set backgroundtile(value) {
        this._backgroundtile = window._enums.TileType[value];
        if (this._resource && this._resource != "") {
            this._calcBacgraund(this._main);
        }
    }

    /**
 * Толщина рамки
 * @type {number}
 */
    get borderthickness() {
        return this._borderthickness;
    }
    set borderthickness(value) {
        value = parseInt(value, 10);
        if (isNaN(value) || value < 0) {
            return;
        }
        this._borderthickness = value;
        this._main.style.borderWidth = this._setValueUnit(value);
    }
    /**
     * Цвет рамки
     * @type {string}
     */
    get bordercolor() {
        return this._main.style.borderColor;
    }
    set bordercolor(value) {
        this._main.style.borderColor = value;
    }
    get cornerradius() {
        return this.style.borderRadius;
    }
    set cornerradius(value) {
        const val = this._setValueUnit(value / 2);
        this.style.borderRadius = val;
        this._main.style.borderRadius = val;
    }
    get borderstyle() {
        return this._borderstyle;
    }
    set borderstyle(value) {
        this._borderstyle = value;
        const type = window._enums.BorderStyleType[value];
        switch (type) {
            case 0:
                this._main.style.borderStyle = 'solid';
                break;
            case 1:
                this._main.style.borderStyle = 'dashed';
                break;
            case 2:
                this._main.style.borderStyle = 'dotted';
                break;
            case 3:
                this._main.style.borderStyle = 'hidden';
                break;
        }
    }

    connectedCallback() {
        this._onButtonClickBind = this._onButtonClick.bind(this);
        this._onButtonMouseDownBind = this._onButtonMouseDown.bind(this);
        this._onButtonMouseEnterBind = this._onButtonMouseEnter.bind(this);
        this._onButtonMouseLeaveBind = this._onButtonMouseLeave.bind(this);
        this._onButtonContextMenuBind = this._onButtonContextMenu.bind(this);
        if (this._isfixed) {
            this.addEventListener('click', this._onButtonClickBind);
        } else {
            this.addEventListener('mousedown', this._onButtonMouseDownBind);
            this.addEventListener('mouseup', this._onButtonMouseLeaveBind);
            this.addEventListener('mouseleave', this._onButtonMouseLeaveBind);
            this.addEventListener('touchstart', this._onButtonMouseDownBind);
            this.addEventListener('touchend', this._onButtonMouseLeaveBind);
        }
        this.addEventListener('contextmenu', this._onButtonContextMenuBind);
        this.addEventListener('mouseenter', this._onButtonMouseEnterBind);
    }

    _textField() {
        const text = this._svgText || this._text;
        return text;
    }

    _setRactionStyle(value) {
        const color = this._colorValues(value);
        if (color) {
            const p = this._colourIsLight(color[0], color[1], color[2]) ? -1 : 1;
            // value = this._rgbaToHex(color);

            // const hover = this._rgbaToHex(this._LightenDarkenColor(color, 10 * p));
            // const active = this._rgbaToHex(this._LightenDarkenColor(color, 20 * p));

            const hover = p ? 1.05 : '90%';
            const active = p ? 1.25 : '80%';



            this._style.innerText = `
            :host .button {background-color:${value}}
            :host .button:hover {filter: brightness(${hover})} :host .button.active {filter: brightness(${active})}
            `;
        } else {
            this._style.innerText = `
            :host .button {background:${value}}
            :host .button:hover {filter: brightness(1.05)} :host .button.active {filter: brightness(1.25)}
            `;
        }
    }

    _initSkin() {
        this._main = this.shadowRoot.querySelector('svg');
        this._main ? this._setEventsForSkin() : this._setInitInnerHtml();
    }

    _setEventsForSkin() {
        this._isSkin = true;
        this._main.style.width = this._width;
        this._main.style.height = this._height;
        this._svgBody = this._main.querySelector('#body');
        this._svgDown = this._main.querySelector('#down');
        this._svgUp = this._main.querySelector('#up');
        this._svgOver = this._main.querySelector('#over');
        this._svgText = this._main.querySelector('#text');
        this._rgbaMatrix = this._main.querySelector('#BackgroundColor');
        this.classList.add('inputable');
        if (this._backColor && this._rgbaMatrix) {
            const color = color2Matrix(this._backColor);
            this._rgbaMatrix.setAttribute('values', color);
        }
        if (this._svgText && (this._textValue || this._textValue === '')) {
            this._svgText.textContent = this._textValue;
        }
    }

    _isLayers() {
        return this._svgDown && this._svgUp && this._svgOver;
    }

    _setInitInnerHtml() {
        this.shadowRoot.innerHTML = this._rootBtn;
        this._main = this.shadowRoot.querySelector('.tbmain');
        this._text = this.shadowRoot.querySelector('.tbtext');
        this._style = this.shadowRoot.querySelectorAll('style')[1];
        this._showWarnSkin();
    }

    _setUpLayer() {
        if (this._isLayers()) {
            this._svgDown.style.display = 'none';
            this._svgUp.style.display = 'inline';
            this._svgOver.style.display = 'none';
        }
    }

    _setDownLayer() {
        if (this._isLayers()) {
            this._svgOver.style.display = 'none';
            this._svgDown.style.display = 'inline';
            this._svgUp.style.display = 'none';
        }
    }

    _setEnterLayer() {
        if (!this._isLayers()) {
            return;
        }
        if ((this._isfixed && !this.ispressed) || (!this._isfixed && !this._svgBtnPressed)) {
            this._svgDown.style.display = 'none';
            this._svgUp.style.display = 'none';
            this._svgOver.style.display = 'inline';
        }
    }

    _resetSkinButton() {
        if (this._isSkin) {
            this._setUpLayer();
            this._svgBtnPressed = false;
        }
    }

    _setSkinButton() {
        if (this._isSkin) {
            this._setDownLayer();
            this._svgBtnPressed = true;
        }
    }

    _onButtonMouseDown(e) {
        if (e.which === window._enums.ButtonKeyCode.MOUSE_RIGHT) {
            return;
        }
        this._pressBtn = true;
        this._setSkinButton();
        this.SetParameter('ispressed', this._pressBtn);
    }

    _onButtonMouseLeave() {
        if (this._pressBtn) {
            this._pressBtn = false;
            this._resetSkinButton();
            this.SetParameter('ispressed', this._pressBtn);
        }
    }

    _onButtonClick() {
        this._changeBtnState();
    }

    _onButtonMouseEnter() {
        this._setEnterLayer();
    }

    _changeBtnState() {
        this._pressBtn = !this.ispressed;
        this._pressBtn ? this._setSkinButton() : this._resetSkinButton();
        this._interaction = true;
        this.SetParameter('ispressed', this._pressBtn);
        this._interaction = false;
    }

    attributeChangedCallback(attrName, oldVal, newVal) {
        if (attrName === 'ispressed') {
            if (newVal == true && !this._pressBtn && !this.isfixed) {
                return;
            }
        }
        if (attrName === 'ispressed' && !this._interaction) {
            if (this._lockLink) {
                this[attrName] = newVal
                return;
            }
        }
        if (oldVal != newVal) {
            this[attrName] = newVal;
            if (this.prop_link[attrName]) {
                this.prop_link[attrName](
                    this.pId ? this.pId + '/' + this.id : this.id,
                    this.Links[attrName],
                    newVal,
                    attrName,
                    this.ItemIndex,
                    null,
                    this._lockLink
                );
            }
        }
    }

    _onButtonContextMenu(e) {
        e.preventDefault();
        e.stopPropagation();
        return false;
    }

    disconnectedCallback() {

        this.removeEventListener('contextmenu', this._onButtonContextMenuBind);
        this.removeEventListener('click', this._onButtonClickBind);
        this.removeEventListener('mousedown', this._onButtonMouseDownBind);
        this.removeEventListener('mouseup', this._onButtonMouseLeaveBind);
        this.removeEventListener('mouseleave', this._onButtonMouseLeaveBind);
        this.removeEventListener('mouseenter', this._onButtonMouseEnterBind);
        this.removeEventListener('touchstart', this._onButtonMouseDownBind);
        this.removeEventListener('touchend', this._onButtonMouseLeaveBind);

        this._onButtonClickBind = null
        this._onButtonMouseDownBind = null
        this._onButtonMouseEnterBind = null
        this._onButtonMouseLeaveBind = null
        this._onButtonContextMenuBind = null

        this._main.remove()
        this._text.remove()
        this._style.remove()
        this._main.innerHTML = '';
        this._text.innerHTML = '';
        this._style.innerHTML = '';

        this._main = null;
        this._text = null;
        this._style = null;

        super.disconnectedCallback();

        this.shadowRoot.innerHTML = '';
    }

    _LightenDarkenColor(col, amt) {

        col[0] += amt;

        if (col[0] > 255) col[0] = 255;
        else if (col[0] < 0) col[0] = 0;

        col[1] += amt;

        if (col[1] > 255) col[1] = 255;
        else if (col[1] < 0) col[1] = 0;

        col[2] += amt;

        if (col[2] > 255) col[2] = 255;
        else if (col[2] < 0) col[2] = 0;

        return col;
    }


    _rgbaToHex(parts) {
        let r = parts[0].toString(16), g = parts[1].toString(16), b = parts[2].toString(16), a;
        if (parts[3]) {
            a = (parts[3] * 255).toString(16);
        }

        r = r.length > 1 ? r : '0' + r;
        g = g.length > 1 ? g : '0' + g;
        b = b.length > 1 ? b : '0' + b;

        return ('#' + r + g + b + (a ? a : ''));
    }

    _colorValues(color) {
        if (!color)
            return;
        if (color.toLowerCase() === 'transparent')
            return [0, 0, 0, 0];
        if (color[0] === '#') {
            if (color.length < 7) {
                color = '#' + color[1] + color[1] + color[2] + color[2] + color[3] + color[3] + (color.length > 4 ? color[4] + color[4] : '');
            }
            return [parseInt(color.substr(1, 2), 16),
            parseInt(color.substr(3, 2), 16),
            parseInt(color.substr(5, 2), 16),
            color.length > 7 ? parseInt(color.substr(7, 2), 16) / 255 : 1];
        }
        if (color.indexOf('rgb') === -1) {
            const temp_elem = document.body.appendChild(document.createElement('fictum'));
            const flag = 'rgb(1, 2, 3)';
            temp_elem.style.color = flag;
            if (temp_elem.style.color !== flag) {
                document.body.removeChild(temp_elem);
                return;
            }
            temp_elem.style.color = color;
            if (temp_elem.style.color === flag || temp_elem.style.color === '') {
                document.body.removeChild(temp_elem);
                return;
            }
            color = getComputedStyle(temp_elem).color;
            document.body.removeChild(temp_elem);
        }
        if (color.indexOf('rgb') === 0) {
            if (color.indexOf('rgba') === -1)
                color += ',1';
            return color.match(/[\.\d]+/g).map((a) => {
                return +a
            });
        }
    }

    _colourIsLight(r, g, b) {
        var a = 1 - (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        return (a < 0.5);
    }
}
