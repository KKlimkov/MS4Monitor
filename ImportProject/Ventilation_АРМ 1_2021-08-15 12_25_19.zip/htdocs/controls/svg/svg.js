import { Basic } from '../basic.js';
import { getSvgTemplate } from "../../generated/svgtemplates.js"
/**
 * @class MSSvg
 * @extends Basic
 * @classdesc SVG-контрол 
 */
export class MSSvg extends Basic {

    static get observedAttributes() {
        return super.observedAttributes.concat([
            'initsvg'
        ]);
    }

    constructor() {
        super();
        this.shRoot = this.attachShadow({ mode: 'open' });
        this.shRoot.innerHTML = '';
        this.style.overflow = 'visible';
        this.style.userSelect = 'none';
        this.style.borderWidth = 0;
        this._isSVG = true;
        this._cacheClass = {};
    }

    set skinresource(value) {
        if (value.charAt(0) == '#') {
            const tag = value.substr(1);
            const template = getSvgTemplate(tag);
            if (template) {
                this.uid = Math.random().toString(36).substr(2, 9);
                const html = template.replace(/{id}/gi, this.uid);
                this.shRoot.innerHTML = html;
                // const instance = template.content.cloneNode(true);
                // this.shRoot.appendChild(instance);
                this._setSvgProperties();
            }
        } else {
            this._request({ method: 'GET', body: '', url: value })
                .then(data => {
                    this.shRoot.innerHTML = data;
                    this._setSvgProperties();
                })
                .catch(error => {
                    console.log(error);
                });
        }
    }

    _setSvgProperties() {
        this._main = this.shRoot.querySelector('svg');
        const styles = this._main.querySelectorAll('style');
        // костыль на отображение svg при переключении окон
        // без "div{}" не применяется первое свойство в списке стилей тега <style>
        if (styles && styles.length) {
            ([...styles]).forEach((style) => {
                const text = '//div{}' + style.innerHTML;
                style.innerHTML = text;
            });
        }
        this._main.style.width = "100%";
        this._main.style.height = "100%";
        this._main.style.overflow = 'visible';
    }

    set initsvg(value) {
        const param = JSON.parse(value);
        for (let i = 0; i < param.length; i++) {
            const element = param[i];
            const path = element.split(":");
            if (path[0] == 'svg') {
                path.splice(0, 1);
                const val = path[path.length - 1];
                path.splice(-1, 1);
                this.svg(path, val);
            }
        }
    }

    /**
     * Имя ресурса для изображения фона
     * @type {string}
     */
    get resource() {
        return this._resource;
    }
    set resource(value) {
        this._resource = value;
    }

    /**
     * Размер тени
     * @type {number}
     */
    get shadowsize() {
        return this._shadowsize;
    }
    set shadowsize(value) {
        value = parseInt(value, 10);
        if (value >= 0) {
            this._shadowsize = value;
            this._calcSVGShadow();
        }
    }

    /**
     * Цвет тени
     * @type {string}
     */
    get shadowcolor() {
        return this._shadowcolor;
    }
    set shadowcolor(value) {
        this._shadowcolor = value ? this._transformHexColor(value) : '';
        this._calcSVGShadow();
    }

    _calcSVGShadow() {
        if (this._main) {
            if (!this._shadowsize || !this._shadowcolor) {
                this._main.style.filter = '';
                return;
            }
            this._main.style.filter = `drop-shadow(
                ${this._shadowcolor}
                ${this._shadowsize}px
                ${this._shadowsize}px
                1px)`;
        }
    }

    svg(path, value) {
        const items = this._main.querySelectorAll(`[id=${path[0]}]`);
        if (items.length > 0) {
            for (let i = 0; i < items.length; i++) {
                const item = items[i];
                switch (path[1]) {
                    case 'fill':
                        item.style.fill = value;
                        break;
                    case 'Content':
                        item.textContent = value;
                        break;
                    case 'class':
                        if (path[2]) {
                            if (this._cacheClass[path[2]]) {
                                item.classList.remove(this._cacheClass[path[2]]);
                            }
                        } else {
                            while (item.classList.length > 0) {
                                item.classList.remove(item.classList.item(0));
                            }
                        }
                        if (value && value.trim().length > 0)
                            item.classList.add(value);
                        break;
                    default:
                        if (path[0] == 'feColorMatrixBodyFilter' || item.nodeName === 'feColorMatrix') {
                            const color = this._colorValues(value);
                            if (color) {
                                const r = (color[0] / 255).toFixed(2);
                                const g = (color[1] / 255).toFixed(2);
                                const b = (color[2] / 255).toFixed(2);
                                value = `${r} 0 0 0 0 0 ${g} 0 0 0 0 0 ${b} 0 0 0 0 0 ${color[3]} 0`;
                            }
                            // item.setAttribute(path[1], matrix);
                        }
                        if (item.attributes.getNamedItem(path[1])) {
                            item.setAttribute(path[1], value);
                        } else {
                            for (const key in this._cacheClass) {
                                const el = this._cacheClass[key];
                                if (el) {
                                    const items = this._main.querySelectorAll(`.${el}`);
                                    for (let index = 0; index < items.length; index++) {
                                        items[index].classList.toggle(el);
                                        requestAnimationFrame(() => {
                                            items[index].classList.toggle(el);
                                        })
                                    }
                                }
                            }
                        }
                }
            }
            if (path[1] === 'class' && path[2]) {
                if (value && value.trim().length > 0)
                    this._cacheClass[path[2]] = value;
                else
                    this._cacheClass[path[2]] = null;
            }
        } else if (path[0] === 'AvaryBorder') {
            const style = document.createElement('style');
            style.type = 'text/css';
            style.innerHTML = '#AvaryBorder {display:none;} #AvaryBorder.Alarm {display:block; stroke:rgb(255,0,0);} #AvaryBorder.Warning {display:block; stroke:rgb(255,170,0);}';
            this._main.appendChild(style);
            const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            rect.setAttribute('id', 'AvaryBorder');
            let x, y;
            if (this._main.viewBox) {
                x = this._main.viewBox.baseVal.x
                y = this._main.viewBox.baseVal.y
            }
            rect.setAttribute('x', x || 0);
            rect.setAttribute('y', y || 0);
            rect.setAttribute('height', '100%');
            rect.setAttribute('width', '100%');
            rect.style.fill = 'rgb(0,0,0)';
            rect.style.strokeWidth = '1';
            rect.style.fillOpacity = '0';
            rect.innerHTML = `<animate xmlns="http://www.w3.org/2000/svg" attributeName="opacity" attributeType="XML" begin="0s; animEnd.end" dur="1s" values="0;1;0" repeatCount="indefinite"/>`;
            this._main.appendChild(rect);
            this.svg(path, value);
        }
    }

    _colorValues(color) {
        if (!color)
            return;
        if (color.toLowerCase() === 'transparent')
            return [0, 0, 0, 0];
        if (color[0] === '#') {
            if (color.length < 7) {
                color = '#' + color[1] + color[1] + color[2] + color[2] + color[3] + color[3] + (color.length > 4 ? color[4] + color[4] : '');
            }
            return [parseInt(color.substr(1, 2), 16),
            parseInt(color.substr(3, 2), 16),
            parseInt(color.substr(5, 2), 16),
            color.length > 7 ? parseInt(color.substr(7, 2), 16) / 255 : 1];
        }
        if (color.indexOf('rgb') === -1) {
            var temp_elem = document.body.appendChild(document.createElement('fictum'));
            var flag = 'rgb(1, 2, 3)';
            temp_elem.style.color = flag;
            if (temp_elem.style.color !== flag) {
                document.body.removeChild(temp_elem);
                return;
            }
            temp_elem.style.color = color;
            if (temp_elem.style.color === flag || temp_elem.style.color === '') {
                document.body.removeChild(temp_elem);
                return;
            }
            color = getComputedStyle(temp_elem).color;
            document.body.removeChild(temp_elem);
        }
        if (color.indexOf('rgb') === 0) {
            if (color.indexOf('rgba') === -1)
                color += ',1';
            return color.match(/[\.\d]+/g).map((a) => {
                return +a
            });
        }
    }

    _request(obj) {
        return new Promise((resolve, reject) => {
            let xhr = new XMLHttpRequest();
            xhr.open(obj.method || "POST", obj.url);
            if (obj.headers) {
                for (let i = 0; i < array.length; i++) {
                    const key = Object.keys(obj.headers)[i];
                    xhr.setRequestHeader(key, obj.headers[key]);
                }
            }
            xhr.onload = () => {
                if (xhr.status >= 200 && xhr.status < 300) {
                    resolve(xhr.response);
                } else {
                    reject(xhr.statusText);
                }
            };
            xhr.onerror = () => reject(xhr.statusText);
            xhr.send(obj.body);
        });
    }

    disconnectedCallback() {
        this._main.innerHTML = '';
        this.shRoot.innerHTML = ''
        super.disconnectedCallback();
        delete this._main;
        delete this.shRoot;
    }
}