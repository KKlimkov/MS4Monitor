import { MSText } from "../text/text.js";
/**
 * @class MSNumericUpDown
 * @extends MSText
 * @classdesc ���������
 * */
export class MSNumericUpDown extends MSText {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'minvalue',
            'value',
            'maxvalue',
            'incrementstep',
            'isreadonly',
            'allownull',
            'showbuttons',
            'restrictmanualinput',
            'notsendbackwardconnection'
        ]);
    }
    constructor() {
        super();
        this._lockLink = this.getAttribute("notsendbackwardconnection");
        this.style.display = 'flex';
        this.style.overflow = 'hidden';
        this.style.boxSizing = "border-box";
        this.shadowRoot.innerHTML = `<div id="decr" style="user-select: none;border-right: 1px solid;display: flex; align-items: center; justify-content: center; cursor: pointer;"><svg style="width:1em;height:1em" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M21 11V13H3V11H21Z" fill="#1B1A1A"/>
        </svg></div><div style='width: 100%; height: 100%;'><input style='background-color: transparent;' id="numberTextBox"></div><div id="incr" style="user-select: none;border-left: 1px solid;display: flex; align-items: center; justify-content: center; cursor: pointer;"><svg style="width:1em;height:1em" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12.9 11.1H21V12.9H12.9V21H11.1V12.9H3V11.1H11.1V3H12.9V11.1Z" fill="#1B1A1A"/>
        </svg>
        </div>`;
        this._text = this.shadowRoot.querySelector('input');
        this._text.style.width = '100%';
        this._text.style.height = '100%';
        this._text.style.border = '0';

        this._decr = this.shadowRoot.getElementById('decr');
        this._incr = this.shadowRoot.getElementById('incr');
        this._incrementstep = 1;

        const fl = x => ((x.toString().includes('.')) ? (x.toString().split('.').pop().length) : (0));
        this._decr.onclick = (e) => {
            e.preventDefault();
            if (this._isreadonly) { return; }
            const cur = Number(this._text.value);
            let it = Math.max(fl(cur), fl(this._incrementstep));
            if (it == 0) { it = 1 } else { it = Math.pow(10, it) }
            if (!isNaN(cur)) {
                let sum = (cur * it - this._incrementstep * it) / it;
                let val = this._minValidator(sum);
                this._interaction = true;
                this.SetParameter('value', this._adjustValue(val));
                this._interaction = false;
            }
        };

        this._incr.onclick = (e) => {
            e.preventDefault();
            if (this._isreadonly) { return; }
            const cur = Number(this._text.value);
            let it = Math.max(fl(cur), fl(this._incrementstep));
            if (it == 0) { it = 1 } else { it = Math.pow(10, it) }
            if (!isNaN(cur)) {
                let sum = (cur * it + this._incrementstep * it) / it;
                let val = this._maxValidator(sum);
                this._interaction = true;
                this.SetParameter('value', this._adjustValue(val));
                this._interaction = false;
            }
        };

        this._text.onpaste = e => {
            e.stopPropagation();
            e.preventDefault();
            if (this._isreadonly) { return; }

            const clipboardData = e.clipboardData || window.clipboardData;
            const pastedData = Number(clipboardData.getData('Text'));
            if (isNaN(pastedData)) return;
            const start = e.target.selectionStart;
            const end = e.target.selectionEnd;

            const value = this._text.value.substr(0, start) + pastedData + this._text.value.substr(end);
            if (isNaN(value)) return;
            let val = this._maxValidator(Number(value));
            val = this._minValidator(val);
            //val = this._adjustValue(val);
            this._interaction = true;
            this.SetParameter('value', val);
            this._interaction = false;
        }

        this._text.onchange = (e) => {
            e.preventDefault();
            if (this._isreadonly) { return; }
            const cur = Number(this._text.value.replace(',','.'));
            this._interaction = true;
            if (!isNaN(cur)) {
                let val = this._maxValidator(cur);
                val = this._minValidator(val);
                this.SetParameter('value', val);
                this._text.value = val;
            } else {
                this.SetParameter('value', typeof this._minvalue === 'number' ? this._adjustValue(this._minvalue) : 0);
            }
            this._interaction = false;
        };

        this._setInputFilter(this._text);

        this._updateWheelBind = e => {
            e.preventDefault();
            if (this._isreadonly) { return; }
            const delta = e.wheelDelta || -e.deltaY;
            let val = delta > 0 ? this._maxValidator(Number(this._text.value) + this._incrementstep) : this._minValidator(Number(this._text.value) - this._incrementstep);
            val = this._adjustValue(val);
            this.SetParameter('value', val);
            return false;
        }

        const mousewheelevt = (/Firefox/i.test(navigator.userAgent)) ? 'wheel' : 'mousewheel';
        this.addEventListener(mousewheelevt, this._updateWheelBind);

        //this.setBaseParams();
        this._minvalue = this.getAttribute('minvalue') ? this.getAttribute('minvalue') : 0;
        this._maxvalue = this.getAttribute('maxvalue') ? this.getAttribute('maxvalue') : 100;
        if (!this.getAttribute('value')) this.value = 50;
        this._showbuttons = true;
        this._text.style.justifyContent = 'center'; //this.texthorizontalalign = 1;
        this._text.style.textAlign = 'center';
        this._text.style.alignItems = 'center'; //this.textverticalalign = 1;
        this._text.style.fontSize = 12;
        this._text.style.fontFamily = "Tahoma";
        //proto text
        this.textcolor = "BLACK";
        this.borderthickness = 1;
        this.backgroundcolor = "rgb(208,208,208)";
    }

    get notsendbackwardconnection(){
        return this._lockLink;
    }
    set notsendbackwardconnection(value){
        this._lockLink = this._toBool(value);
    }

    _minValidator(val) {
        if (this._isNumeric(this._minvalue)) {
            return val < this._minvalue ? this._minvalue : val;
        }
        return val;
    }

    _maxValidator(val) {
        if (this._isNumeric(this._maxvalue)) {
            return val > this._maxvalue ? this._maxvalue : val;
        }
        return val;
    }

    get allownull() {
        return this._allownull;
    }
    set allownull(value) {
        this._allownull = this._toBool(value);
    }
    /**
    * ������ ������� �����
    * @type {bool}
    */
    get restrictmanualinput() {
        return this._restrictmanualinput || false;
    }
    set restrictmanualinput(value) {
        this._restrictmanualinput = this._toBool(value);
        if (this._restrictmanualinput) {
            this._text.setAttribute('readonly', '');
        } else {
            this._text.removeAttribute('readonly');
        }
    }
    /**
    * �������������� ������������
    * @type {enum}
    */
    get texthorizontalalign() {
        return this._horizontalalign;
    }
    set texthorizontalalign(value) {
        this._horizontalalign = value;
        this._text.style.textAlign = window._enums.AlignText[value];
    }

    get textcolor() {
        return this._text.style.color;
    }
    set textcolor(value) {
        this._text.style.color = value;
    }
    /**
    * �������
    * @type {number}
    */
    get minvalue() {
        return this._minvalue;
    }
    set minvalue(value) {
        const tmp = Number(value);
        if (!isNaN(tmp)) {
            this._minvalue = tmp;
            if (this._value === undefined || this._value < this._minvalue) {
                //const val = this._adjustValue(this._minvalue);
                this.SetParameter('value', this._minvalue);
            }
        }
    }
    /**
     * ��������
    * @type {number}
    */
    get maxvalue() {
        return this._maxvalue;
    }
    set maxvalue(value) {
        const tmp = Number(value);
        if (!isNaN(tmp)) {
            this._maxvalue = tmp;
            if (this._value === undefined || this._value > this._maxvalue) {
                //const val = this._adjustValue(this._maxvalue);
                this.SetParameter('value', this._maxvalue);
            }
        }
    }
    /**
    * ��������
    * @type {number}
    */
    get value() {
        return this._value;
    }
    set value(value) {

        if (!this._isNumeric(value)) {
            if (this.allownull) {
                this._value = null;
                this._text.value = '';
            }
            return;
        }
        if (this._isNumeric(this._maxvalue, this._minvalue)) {
            value = this._maxValidator(Number(value));
            value = this._minValidator(value);
            //value = this._adjustValue(value);
        }
        this._value = Number(value);
        this.oldValue = value;
        this._text.value = value;
    }

    _adjustValue(value) {
        if (!this._isNumeric(value)) {
            return 0;
        }
        const adjust = this._incrementstep ? this._incrementstep : this._text.value;
        if (value % 1 !== 0) {
            let symLength = adjust.toString().includes('.') ? adjust.toString().split('.').pop().length : 0;
            if (symLength) {
                const roundedVal = Number(value).toFixed(symLength);
                value = Number(roundedVal).toString();
            }
        }
        return Number(value);
    }

    set height(value) {
        super.height = value;
    }
    set width(value) {
        super.width = value;
    }

    _calc() {
        if (this._width && this._height) {
            const w = this._width * 0.25;
            const value = this._height < w ? this._height : w;
            this._decr.style.minWidth = `${value}px`;
            this._incr.style.minWidth = `${value}px`;
        }
    }

    get incrementstep() {
        return this._incrementstep;
    }
    set incrementstep(value) {
        const tmp = Number(value);
        if (!isNaN(tmp)) {
            this._incrementstep = tmp;
        }
    }

    get isreadonly() {
        return typeof this._isreadonly === 'boolean' ? this._isreadonly : false;
    }
    set isreadonly(value) {
        this._isreadonly = this._toBool(value);
    }

    get showbuttons() {
        return typeof this._showbuttons === 'boolean' ? this._showbuttons : true;
    }
    set showbuttons(value) {
        this._showbuttons = this._toBool(value);
        const s = this._showbuttons ? 'flex' : 'none';
        this._decr.style.display = s;
        this._incr.style.display = s;
    }

    /**
     * ������� �� ��������� ��������� ��������
     * @see https://w3c.github.io/webcomponents/spec/custom/
     * @param {string} attrName �������� ��������
     * @param {*} oldVal ������ �������� ��������
     * @param {*} newVal ����� �������� ��������
     */
    attributeChangedCallback(attrName, oldVal, newVal) {
        if (oldVal !== newVal) {
            if (attrName === 'value' && !this._interaction) {
                if (this._lockLink) {
                    this[attrName] = newVal
                    return;
                }
            }
            if (oldVal != newVal) {
                this[attrName] = newVal;
                if (this.prop_link[attrName]) {
                    this.prop_link[attrName](
                        this.pId ? this.pId + '/' + this.id : this.id,
                        this.Links[attrName],
                        newVal,
                        attrName,
                        this.ItemIndex,
                        null,
                        this._lockLink
                    );
                }
            }
        }
    }

    disconnectedCallback() {
        this._text.oninput = undefined;
        super.disconnectedCallback();
        this.removeEventListener('mousewheel', this._updateWheelBind);
    }

    _setInputFilter(textbox) {
        textbox.oninput = (e) => {
            e.preventDefault();
            if (this._isreadonly) { textbox.value = this.oldValue; return; }
            this.oldSelectionStart = textbox.selectionStart;
            this.oldSelectionEnd = textbox.selectionEnd;
            if (/^-?\d*[.,]?\d*$/.test(textbox.value)) {
                this.oldValue = textbox.value;
                this._text.value = textbox.value;
            } else if (this.hasOwnProperty("oldValue")) {
                textbox.value = this.oldValue;
                textbox.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
            }
        };
    }
}
