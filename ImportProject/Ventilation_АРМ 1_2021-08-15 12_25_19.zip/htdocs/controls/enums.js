﻿export class enums {
    constructor() {
        this.CultureInfo = Object.freeze({
            numberFormat: {
                currencyNegativePattern: "-n$",
                currencyPositivePattern: "n$",
                currencyGroupSizes: [3],
                currencyGroupSeparator: ",",
                currencyDecimalSeparator: ".",
                currencyDecimalDigits: "2",
                currencySymbol: " ₽",

                negativeSign: "-",
                numberNegativePattern: "-n",
                numberGroupSizes: [3],
                numberGroupSeparator: ",",
                numberDecimalSeparator: ".",
                numberDecimalDigits: 2,
                numberExpDigits: 6,

                percentNegativePattern: "-n%",
                percentPositivePattern: "n%",
                percentGroupSizes: [3],
                percentGroupSeparator: ",",
                percentDecimalSeparator: ".",
                percentDecimalDigits: 2,
                percentSymbol: "%"
            }
        });

        this.Types = Object.freeze({
            "BOOL": {
                "description": {},
                "type": "boolean"
            },

            "BYTE": {
                "description": {
                    "min": 0.0,
                    "max": 255.0,
                    "isInteger": true,
                    "maxNumber": 256
                },
                "type": "wordNumber"
            },

            "REAL": {
                "description": {
                    "min": -3.4028234663852886E+38,
                    "max": 3.4028234663852886E+38,
                    "minPrecision": -1.17549435E-38,
                    "maxPrecision": 1.17549435E-38,
                    "isInteger": false
                },
                "type": "number"
            },

            "LREAL": {
                "description": {
                    "min": -1.7976931348623157E+308,
                    "max": 1.7976931348623157E+308,
                    "minPrecision": -2.225073858507201383E-308,
                    "maxPrecision": 2.225073858507201383E-308,
                    "isInteger": false
                },
                "type": "number"
            },

            "DINT": {
                "description": {
                    "min": -2147483648.0,
                    "max": 2147483647.0,
                    "isInteger": true,
                    "maxNumber": 4294967296
                },
                "type": "number"
            },

            "INT": {
                "description": {
                    "min": -32768.0,
                    "max": 32767.0,
                    "isInteger": true,
                    "maxNumber": 65536
                },
                "type": "number"
            },

            "LINT": {
                "description": {
                    "min": -9.2233720368547758E+18,
                    "max": 9.2233720368547758E+18,
                    "isInteger": true,
                    "maxNumber": 1.8446744073709552E+19
                },
                "type": "number"
            },

            "SINT": {
                "description": {
                    "min": -128.0,
                    "max": 127.0,
                    "isInteger": true,
                    "maxNumber": 256
                },
                "type": "number"
            },

            "UDINT": {
                "description": {
                    "min": 0.0,
                    "max": 4294967295,
                    "isInteger": true,
                    "maxNumber": 4294967296
                },
                "type": "number"
            },

            "UINT": {
                "description": {
                    "min": 0.0,
                    "max": 65535.0,
                    "isInteger": true,
                    "maxNumber": 65536
                },
                "type": "number"
            },

            "ULINT": {
                "description": {
                    "min": 0.0,
                    "max": 1.8446744073709552E+19,
                    "isInteger": true,
                    "maxNumber": 1.8446744073709552E+19
                },
                "type": "number"
            },

            "USINT": {
                "description": {
                    "min": 0.0,
                    "max": 255.0,
                    "isInteger": true,
                    "maxNumber": 256
                },
                "type": "number"
            },

            "DWORD": {
                "description": {
                    "min": 0.0,
                    "max": 4294967295.0,
                    "isInteger": true,
                    "maxNumber": 4294967296
                },
                "type": "wordNumber"
            },

            "LWORD": {
                "description": {
                    "min": 0.0,
                    "max": 1.8446744073709552E+19,
                    "isInteger": true,
                    "maxNumber": 1.8446744073709552E+19
                },
                "type": "wordNumber"
            },

            "WORD": {
                "description": {
                    "min": 0.0,
                    "max": 65535.0,
                    "isInteger": true,
                    "maxNumber": 65536
                },
                "type": "wordNumber"
            },

            "STRING": {
                "description": {},
                "type": "string"
            },

            "DATE": {
                "description": {
                    "min": -8640000000000000,
                    "max": 8640000000000000,
                    "descType": 'date'
                },
                "type": "date"
            },
            "TOD": {
                "description": {
                    "min": -8640000000000000,
                    "max": 8640000000000000,
                    "descType": 'tod'
                },
                "type": "date"
            },
            "DATE_AND_TIME": {
                "description": {
                    "min": -8640000000000000,
                    "max": 8640000000000000,
                    "descType": 'dt'
                },
                "type": "date"
            },
            "DT": {
                "description": {
                    "min": -8640000000000000,
                    "max": 8640000000000000,
                    "descType": 'dt'
                },
                "type": "date"
            },
            "TIME_OF_DAY": {
                "description": {
                    "min": -8640000000000000,
                    "max": 8640000000000000,
                    "descType": 'tod'
                },
                "type": "date"
            },

            "TIME": {
                "description": {
                    "min": -8640000000000000,
                    "max": 8640000000000000,
                    "descType": 'time'
                },
                "type": "date"
            },

            "HMI.GradientColorType": {
                "description": {},
                "type": "string"
            },

            "HMI.SolidColorType": {
                "description": {},
                "type": "string"
            }
        });

        this.PredefinedColors = Object.freeze({
            aliceblue: '#f0f8ff',
            antiquewhite: '#faebd7',
            aqua: '#00ffff',
            aquamarine: '#7fffd4',
            azure: '#f0ffff',
            beige: '#f5f5dc',
            bisque: '#ffe4c4',
            black: '#000000',
            blanchedalmond: '#ffebcd',
            blue: '#0000ff',
            blueviolet: '#8a2be2',
            brown: '#a52a2a',
            burlywood: '#deb887',
            cadetblue: '#5f9ea0',
            chartreuse: '#7fff00',
            chocolate: '#d2691e',
            coral: '#ff7f50',
            cornflowerblue: '#6495ed',
            cornsilk: '#fff8dc',
            crimson: '#dc143c',
            cyan: '#00ffff',
            darkblue: '#00008b',
            darkcyan: '#008b8b',
            darkgoldenrod: '#b8860b',
            darkgray: '#a9a9a9',
            darkgreen: '#006400',
            darkkhaki: '#bdb76b',
            darkmagenta: '#8b008b',
            darkolivegreen: '#556b2f',
            darkorange: '#ff8c00',
            darkorchid: '#9932cc',
            darkred: '#8b0000',
            darksalmon: '#e9967a',
            darkseagreen: '#8fbc8f',
            darkslateblue: '#483d8b',
            darkslategray: '#2f4f4f',
            darkturquoise: '#00ced1',
            darkviolet: '#9400d3',
            deeppink: '#ff1493',
            deepskyblue: '#00bfff',
            dimgray: '#696969',
            dodgerblue: '#1e90ff',
            firebrick: '#b22222',
            floralwhite: '#fffaf0',
            forestgreen: '#228b22',
            fuchsia: '#ff00ff',
            gainsboro: '#dcdcdc',
            ghostwhite: '#f8f8ff',
            gold: '#ffd700',
            goldenrod: '#daa520',
            gray: '#808080',
            green: '#008000',
            greenyellow: '#adff2f',
            honeydew: '#f0fff0',
            hotpink: '#ff69b4',
            indianred: '#cd5c5c',
            indigo: '#4b0082',
            ivory: '#fffff0',
            khaki: '#f0e68c',
            lavender: '#e6e6fa',
            lavenderblush: '#fff0f5',
            lawngreen: '#7cfc00',
            lemonchiffon: '#fffacd',
            lightblue: '#add8e6',
            lightcoral: '#f08080',
            lightcyan: '#e0ffff',
            lightgoldenrodyellow: '#fafad2',
            lightgray: '#d3d3d3',
            lightgreen: '#90ee90',
            lightpink: '#ffb6c1',
            lightsalmon: '#ffa07a',
            lightseagreen: '#20b2aa',
            lightskyblue: '#87cefa',
            lightslategray: '#778899',
            lightsteelblue: '#b0c4de',
            lightyellow: '#ffffe0',
            lime: '#00ff00',
            limegreen: '#32cd32',
            linen: '#faf0e6',
            magenta: '#ff00ff',
            maroon: '#800000',
            mediumaquamarine: '#66cdaa',
            mediumblue: '#0000cd',
            mediumorchid: '#ba55d3',
            mediumpurple: '#9370db',
            mediumseagreen: '#3cb371',
            mediumslateblue: '#7b68ee',
            mediumspringgreen: '#00fa9a',
            mediumturquoise: '#48d1cc',
            mediumvioletred: '#c71585',
            midnightblue: '#191970',
            mintcream: '#f5fffa',
            mistyrose: '#ffe4e1',
            moccasin: '#ffe4b5',
            navajowhite: '#ffdead',
            navy: '#000080',
            oldlace: '#fdf5e6',
            olive: '#808000',
            olivedrab: '#6b8e23',
            orange: '#ffa500',
            orangered: '#ff4500',
            orchid: '#da70d6',
            palegoldenrod: '#eee8aa',
            palegreen: '#98fb98',
            paleturquoise: '#afeeee',
            palevioletred: '#db7093',
            papayawhip: '#ffefd5',
            peachpuff: '#ffdab9',
            peru: '#cd853f',
            pink: '#ffc0cb',
            plum: '#dda0dd',
            powderblue: '#b0e0e6',
            purple: '#800080',
            red: '#ff0000',
            rosybrown: '#bc8f8f',
            royalblue: '#4169e1',
            saddlebrown: '#8b4513',
            salmon: '#fa8072',
            sandybrown: '#f4a460',
            seagreen: '#2e8b57',
            seashell: '#fff5ee',
            sienna: '#a0522d',
            silver: '#c0c0c0',
            skyblue: '#87ceeb',
            slateblue: '#6a5acd',
            slategray: '#708090',
            snow: '#fffafa',
            springgreen: '#00ff7f',
            steelblue: '#4682b4',
            tan: '#d2b48c',
            teal: '#008080',
            thistle: '#d8bfd8',
            tomato: '#ff6347',
            transparent: '#00ffffff',
            turquoise: '#40e0d0',
            violet: '#ee82ee',
            wheat: '#f5deb3',
            white: '#ffffff',
            whitesmoke: '#f5f5f5',
            yellow: '#ffff00',
            yellowgreen: '#9acd32'
        });
        this.DistinguishedColors = [
            "#581100",
            "#fcce00",
            "#0d7b00",
            "#b90014",
            "#008146",
            "#014787",
            "#350029",
            "#980bce",
            "#a7abff",
            "#86c7ff",
            "#277bff",
            "#00251b",
            "#e8005b",
            "#a0ff70",
            "#ea7900",
            "#01779f",
            "#ff5eed",
            "#ffeff5",
            "#0135a8",
            "#019e9a"
        ];
        this.SourceTypes = Object.freeze({
            bool: "BOOL",
            byte: "BYTE",
            real: "REAL",
            lreal: "LREAL",
            dint: "DINT",
            int: "INT",
            lint: "LINT",
            sint: "SINT",
            udint: "UDINT",
            uint: "UINT",
            ulint: "ULINT",
            usint: "USINT",
            dword: "DWORD",
            lword: "LWORD",
            word: "WORD",
            string: "STRING",
            date: "DATE",
            dt: "DATE_AND_TIME",
            tod: "TIME_OF_DAY",
            time: "TIME"
        });

        this.ButtonKeyCode = Object.freeze({
            ENTER: 13,
            ESC: 27,
            MOUSE_LEFT: 1,
            MOUSE_RIGHT: 3,
            DELETE: 46,
            LEFT: 37,
            UP: 38,
            RIGHT: 39,
            DOWN: 40,
            BACKSPACE: 8,
            FULL_SCREEN: 122
        });
        /**
         * Горизонтальное выравнивание
         * @typedef {(Лево("Left")|Центр("Center")|Право("Right"))} AlignHorizontal
         */
        this.AlignHorizontal = Object.freeze({
            Left: 'flex-start',
            Center: 'center',
            Right: 'flex-end',
            0: 'flex-start',
            1: 'center',
            2: 'flex-end'
        });
        /**
         * Вертикальное выравнивание
         * @typedef {(Верх("Top")|Центр("Center")|Низ("Bottom"))} AlignVertical
         */
        this.AlignVertical = Object.freeze({
            Top: 'flex-start',
            Center: 'center',
            Bottom: 'flex-end',
            0: 'flex-start',
            1: 'center',
            2: 'flex-end'
        });
        /**
         * Горизонтальное выравнивание текста
         * @typedef {(Лево("Left")|Центр("Center")|Право("Right"))} AlignText
         */
        this.AlignText = Object.freeze({
            Left: 'left',
            Center: 'center',
            Right: 'right',
            0: 'left',
            1: 'center',
            2: 'right'
        });
        /**
         * Тип замостки фона
         * @typedef {(Нет("No")|Мозаика("Tile")|Заполнение("Fill")|Центр("Center"))} TileType
         */
        this.TileType = Object.freeze({
            No: 0,
            Tile: 1,
            Fill: 2,
            Center: 3,
            0: 0,
            1: 1,
            2: 2,
            3: 3
        });

        this.DateTimeType_Full = Object.freeze({
            Date_Type: 0,
            DateTime_Type: 1,
            TimeDate_Type: 2,
            Time_Type: 3,
            0: 0,
            1: 1,
            2: 2,
            3: 3
        });

        this.OrientationType = Object.freeze({
            Horizontal: 'row',
            Vertical: 'column',
            0: 'row',
            1: 'column'
        });

        this.HorizontalAlignTypeExt = Object.freeze({
            Left: 'flex-start',
            Center: 'center',
            Right: 'flex-end',
            Stretch: 3,
            0: 'flex-start',
            1: 'center',
            2: 'flex-end',
            3: 3
        });

        this.VerticalAlignTypeExt = Object.freeze({
            Top: 'flex-start',
            Center: 'center',
            Bottom: 'flex-end',
            Stretch: 3,
            0: 'flex-start',
            1: 'center',
            2: 'flex-end',
            3: 3
        });
        /**
         * Положение
         * @typedef {("Up"|"Down"|"Left"|"Right")} LayoutType
         */
        this.LayoutType = Object.freeze({
            Up: 0,
            Down: 1,
            Left: 2,
            Right: 3,
            0: 0,
            1: 1,
            2: 2,
            3: 3
        });
        /**
         * Стиль линии рамки
         * @typedef {(Непрерывный("Solid")|Пунктир("Dash")|Точка("Dot")|Нет("None"))} BorderStyleType
         */
        this.BorderStyleType = Object.freeze({
            Solid: 0,
            Dash: 1,
            Dot: 2,
            None: 3,
            0: 0,
            1: 1,
            2: 2,
            3: 3
        });

        this.PenStyleType = Object.freeze({
            0: 'solid',
            1: 'dashed',
            2: 'dotted',
            3: 'none',
            'solid': 'solid',
            'dashed': 'dashed',
            'dotted': 'dotted',
            'none': 'none'

        });
        /**
         * Тип точек (для Тренда)
         * @typedef {("Нет"|"Квадрат"|"Круг"|"Треугольник"|"Ромб"|"Крест")} PointType
         */
        this.PointType = Object.freeze({
            'none': 0,
            'rect': 1,
            'circle': 2,
            'triangle': 3,
            'diamond': 4,
            'path://M 0 1 L 1 0 L 5 4 L 4 5 M 0 4 L 1 5 L 5 1 L 4 0': 5,
            0: 'none',
            1: 'rect',
            2: 'circle',
            3: 'triangle',
            4: 'diamond',
            5: 'path://M 0 1 L 1 0 L 5 4 L 4 5 M 0 4 L 1 5 L 5 1 L 4 0'
        });
        this.DateTimeType_Full = Object.freeze({
            Date_Type: 0,
            DateTime_Type: 1,
            TimeDate_Type: 2,
            Time_Type: 3,
            0: 0,
            1: 1,
            2: 2,
            3: 3
        });
        /**
         * Подгонка
         * @typedef {(Исходный размер("RealSize")|Подогнать("SetSize")|Обрезать("Crop")|Прокрутить("Scroll"))} SizeToContentType
         */
        this.SizeToContentType = Object.freeze({
            RealSize: 0,
            SetSize: 1,
            Crop: 2,
            Scroll: 3,
            0: 0,
            1: 1,
            2: 2,
            3: 3
        });
        /**
         * Тип операции
         * @typedef {(Присвоить("move")|Добавить("add")|Отнять("sub")|Умножить("mul")|Разделить("div"))} HMIOperation
         */
        this.HMIOperation = Object.freeze({
            'Move': 'move',
            'Add': 'add',
            'Sub': 'sub',
            'Mul': 'mul',
            'Div': 'div',
            'move': 'move',
            'add': 'add',
            'sub': 'sub',
            'mul': 'mul',
            'div': 'div',
            'subtract': 'sub',
            'multiply': 'mul',
            'divide': 'div',
            0: 'move',
            1: 'add',
            2: 'sub',
            3: 'mul',
            4: 'div'
        });

        this.DefaultDateFormat = Object.freeze({
            'DATE_AND_TIME': 'dd-MM-yyyy HH:mm:ss',
            'DATE': 'dd-MM-yyyy',
            'TIME': 'd.HH:mm:ss',
            'DT': 'HH:mm:ss'
        });
    }
}