"use strict";

import { Basic } from "../basic.js";
/**
 * @class MSFrame
 * @extends Basic
 * @classdesc Контейнер
 * */
export class MSFrame extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'datasource',
            'sizetocontent'
        ]);
    }

    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        if (this.id == $WinDefs.constructor.mainFrame) {
            this._pushState = true;
        }
        this.style.boxSizing = 'content-box';
        this.style.userSelect = 'none';
        shadowRoot.innerHTML = '<slot></slot>';
        if (window.ipc) {
            this.pdfViewer = window.ipc.get().sendSync('server', 'getPdf');
        }
        this._sizetocontent = 1;
        this.firstRun = true;
    }

    get datasource() {
        return this._datasource;
    }
    set datasource(value) {
        if (this.firstChild && this.firstChild.id == value) {
            if (!this._msWin) this._msWin = this.firstChild;
            this._calcSize();
            return;
        }
        if (value) {
            this._clearWin();
            this._datasource = value;
            if (value.substr(0, 4) == 'http' || this._hasPdfExtension(value) || this._hasHtmlExtension(value)) {
                let url = this._datasource;
                if (this._hasPdfExtension(value) && this.pdfViewer) {
                    url = `file://${this.pdfViewer}?file=${window.location.origin}/${decodeURIComponent(url)}`
                }
                const iframe = `<iframe src="${url}" style="width:100%;height:100%;"></iframe>`
                this.innerHTML = iframe;
            } else {
                const winObj = $WinDefs.winDef[value];
                if (winObj) {
                    this.openWindow(winObj);
                    this._calcSize();
                }
            }
            this._msWin = this.firstChild
        }
    }

    get sizetocontent() {
        return this._sizetocontent;
    }
    set sizetocontent(value) {
        this._sizetocontent = window._enums.SizeToContentType[value];
        this._calcSize();
    }

    get isvisible() {
        return this._showElement;
    }
    set isvisible(value) {
        this._showElement = value;
        const isShow = (this.opacity === '' || this._toBool(this.opacity)) && this._toBool(value);
        this.style.display = isShow ? '' : 'none';
    }

    _calcSize() {
        if (!this._msWin) { return; }
        switch (this._sizetocontent) {
            case window._enums.SizeToContentType.RealSize:
                this._msWin.style.transform = ``;
                this._msWin.style.transformOrigin = '';
                this._backWidth = this._width;
                this._backHeight = this._height;
                this._width = this._msWin.width;
                this._height = this._msWin.height;
                this.style.width = this._setValueUnit(this._width);
                this.style.height = this._setValueUnit(this._height);
                this.style.overflow = 'hidden';
                break;
            default:
            case window._enums.SizeToContentType.SetSize:
                this.style.overflow = 'hidden';
                this._width = this._backWidth ? this._backWidth : this._width;
                this._height = this._backHeight ? this._backHeight : this._height;
                this.style.width = this._setValueUnit(this._width);
                this.style.height = this._setValueUnit(this._height);
                this._calcScale();
                break;
            case window._enums.SizeToContentType.Crop:
                this._msWin.style.transform = ``;
                this._msWin.style.transformOrigin = '';
                this.style.overflow = 'hidden';
                this._width = this._backWidth ? this._backWidth : this._width;
                this._height = this._backHeight ? this._backHeight : this._height;
                this.style.width = this._setValueUnit(this._width);
                this.style.height = this._setValueUnit(this._height);
                break;
            case window._enums.SizeToContentType.Scroll:
                this._msWin.style.transform = ``;
                this._msWin.style.transformOrigin = '';
                this._width = this._backWidth ? this._backWidth : this._width;
                this._height = this._backHeight ? this._backHeight : this._height;
                this.style.overflow = 'auto';
                this.style.width = this._setValueUnit(this._width);
                this.style.height = this._setValueUnit(this._height);
                break;
        }
    }

    _calcScale() {
        const scY = Number(this._msWin.height);
        const scaleY = Number(this._height) / scY;

        const scX = Number(this._msWin.width);
        const scaleX = Number(this._width) / scX;
        const scale = scaleX > scaleY ? scaleY : scaleX;

        const pr = this._msWin.proportiontype
        const hasRoot = this.parentElement && this.parentElement.hasAttribute('root');
        if (hasRoot && pr === 0) {
            this._msWin.style.transform = `scale(${scaleX},${scaleY})`;
            this._msWin.style.transformOrigin = '0 0';
            return;
        }
        if (scale !== 1) {
            this._msWin.style.transform = `scale(${scale})`;
            this._msWin.style.transformOrigin = '0 0';
        } else {
            this._msWin.style.transform = ``;
            this._msWin.style.transformOrigin = '';
        }
    }

    openWindow(obj, force) {
        if (this._msWin && this._msWin.id === obj.id &&
            obj.objectid === this._msWin.getAttribute("objectid")) { return; }
        if (!force && this._pushState) {
            history.pushState({ obj }, obj.id, "?" + obj.id);
        }
        this._clearWin();
        let param = "";
        const keys = Object.keys(obj);
        keys.forEach(key => {
            if (key !== 'windowTriggers') {
                let paramVal = obj[key];
                if (typeof paramVal === 'object') paramVal = JSON.stringify(paramVal);
                param += ` ${key}='${paramVal}'`;
            }
        });

        const win = `<ms-window${param}></ms-window>`;

        this.innerHTML = win;

        this._msWin = this.querySelector('ms-window');
        if (obj['windowTriggers'] && !this._msWin.windowTriggers) { //TODO
            this._msWin.windowTriggers = JSON.parse(JSON.stringify(obj.windowTriggers));
        }
        this._msWin.closeWin = this._clearWin.bind(this);
        this._calcSize();
        if (!this.firstRun) {
            this.afterInitialize()
        }
        return this._msWin;
    }

    _hasPdfExtension(url) {
        return url.match(/\.pdf$/i);
    }

    _hasHtmlExtension(url) {
        return url.match(/\.html$/i);
    }

    _clearWin() {
        const hasRoot = this.parentElement && this.parentElement.hasAttribute('root');
        if (!hasRoot) {
            while (this.firstChild) {
                //this.removeChild(this.firstChild);
                this.firstChild.remove();
            }
            if (this._msWin) {
                this._msWin.remove();
                this._msWin = null;
            }
        }
    }

    afterInitialize() {
        for (let i = 0; i < this.children.length; i++) {
            if (this.children[i].afterInitialize) this.children[i].afterInitialize();
        }
        this.firstRun = false;
    }
}