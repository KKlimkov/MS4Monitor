"use strict";
import { SMask } from '../../lib/smask.js';
import { MSText } from "../text/text.js";
/**
 * @class MSTextInput
 * @extends MSText
 * @classdesc ��������� ����
 * */
export class MSTextInput extends MSText {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'mask',
            'isreadonly',
            'maxlength',
            'notsendbackwardconnection'
        ]);
    }

    constructor() {
        super();
        this._lockLink = this.getAttribute("notsendbackwardconnection");
        this.prop_link = [];
        this.shadowRoot.innerHTML = '<input type="text"></input>';
        this.style.display = 'flex';
        this.style.overflow = 'hidden';
        this._text = this.shadowRoot.querySelector('input');
        this._text.style.backgroundColor = 'transparent';
        this._text.style.width = '100%';
        this._text.style.height = '100%';
        this._text.style.border = '0';
        this._text.onchange = this._onChange.bind(this);

        //
        this._isreadonly = false;
        this._maxlength = 1000;
        this._text.style.justifyContent = 'center'; //this.texthorizontalalign = 1;
        this._text.style.textAlign = 'center';
        this._text.style.alignItems = 'center'; //this.textverticalalign = 1;
        this._text.style.fontSize = 12;
        this._text.style.fontFamily = "Tahoma";
        //from proto basic
        this.textcolor = "BLACK";
        this.borderthickness = 1;
        this.backgroundcolor = "rgb(208,208,208)";

        this.onfocus = e => this._text.focus();
    }

    _changeRoot() {
        const cs = this._text.getAttribute('style');
        this.shadowRoot.innerHTML = '<textarea></textarea>';
        this.style.display = 'flex';
        this.style.overflow = 'hidden';
        this._text = this.shadowRoot.querySelector('textarea');
        this._text.setAttribute('style', cs);
        this._text.style.resize = 'none';
        this._text.style.backgroundColor = 'transparent';
        this._text.style.width = '100%';
        this._text.style.height = '100%';
        this._text.style.border = '0';
        this._text.onchange = this._onChange.bind(this);
        this.text = this._textValue;
    }

    get notsendbackwardconnection(){
        return this._lockLink;
    }
    set notsendbackwardconnection(value){
        this._lockLink = this._toBool(value);
    }

    get fontmultiline() {
        return this._multiline;
    }
    set fontmultiline(value) {
        this._multiline = value;
        if (!this._isChangeRoot) {
            this._isChangeRoot = true;
            if (this._toBool(value)) {
                this._changeRoot();
            }
        }
    }

    get mask() {
        return this._mask;
    }
    set mask(value) {
        if (value) {
            this._text.value = '';
            this._mask = value;
            if (value.indexOf('_') !== -1) {
                this._mask = value.replace(/_/g, '&');
            }
            this.sm = new SMask();
            this.sm.setMask(this._text, this._mask);
        } else {
            if (this.sm) {
                this.sm.delMask();
            }
            this._mask = '';
            this._text.onchange = this._onChange.bind(this);
        }
    }

    get text() {
        return typeof this._textValue !== 'undefined' ? this._textValue : this.getAttribute("text");
    }
    set text(value) {
        if (value == undefined) return;
        this._textValue = value;
        if (this.sm) {
            this.sm.SetValue(value);
            if (value) this.sm._isFilling = true;
            else this.sm._isFilling = false;
        } else {
            this._text.value = value.toString().substr(0, this._maxlength);
        }
    }

    /**
     * ������� �� ��������� ��������� ��������
     * @see https://w3c.github.io/webcomponents/spec/custom/
     * @param {string} attrName �������� ��������
     * @param {*} oldVal ������ �������� ��������
     * @param {*} newVal ����� �������� ��������
     */
    attributeChangedCallback(attrName, oldVal, newVal) {
        if (oldVal !== newVal) {
            if (attrName === 'text' && !this._interaction) {
                if (this._lockLink) {
                    this[attrName] = newVal
                    return;
                }
            }
            if (oldVal != newVal) {
                this[attrName] = newVal;
                if (this.prop_link[attrName]) {
                    this.prop_link[attrName](
                        this.pId ? this.pId + '/' + this.id : this.id,
                        this.Links[attrName],
                        newVal,
                        attrName,
                        this.ItemIndex,
                        null,
                        this._lockLink
                    );
                }
            }
        }
    }

    get isenabled() {
        return !this._text.disabled;
    }
    set isenabled(value) {
        this.disabled = !this._toBool(value);
        this._text.disabled = !this._toBool(value);
        super.isenabled = value;
    }

    get isreadonly() {
        return this._isreadonly || false;
    }
    set isreadonly(value) {
        this._isreadonly = this._toBool(value);
        this._text.readOnly = this._isreadonly;
    }

    get texthorizontalalign() {
        return this._horizontalalign;
    }

    set texthorizontalalign(value) {
        this._horizontalalign = value;
        this._text.style.textAlign = window._enums.AlignText[value];
    }

    get maxlength() {
        return this._maxlength;
    }
    set maxlength(value) {
        this._maxlength = value;
        this._text.maxLength = value;
    }

    _onChange(e) {
        e.preventDefault();
        if (this._isreadonly) { return; }
        const ml = e.target.value.split('\n');
        for (let i = 0; i < ml.length; i++) {
            ml[i] = ml[i].replace(/\s+/g, ' ');
        }
        const newText = this.sm ? this.sm.value : ml.join('\n');
        const old = this._text.getAttribute("value");
        if (old != newText) {
            this._interaction = true;
            this.SetParameter('text', newText);
            this._interaction = false;
        }
    }

    disconnectedCallback() {
        this._text.remove()
        this._text.onchange = null;
        this.onfocus = null;
        delete this._text
        super.disconnectedCallback()
        this.shadowRoot.innerHTML = ''
    }
}
