﻿import { Basic } from "../basic.js";
import { Inputs } from "../../lib/inputs.js"
import { DataTypes } from '../../generated/datatypes.js'
/**
 * @class MSLegend
 * @extends Basic
 * @classdesc Легенда для Тренда
 * */
export class MSLegend extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'trend',
            'gridtype'
        ]);
    }
    constructor() {
        super();
        this.style.overflow = 'visible';
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<style>
            /* Tabulator v4.6.3 (c) Oliver Folkerd */
            .tabulator{position:relative;border:1px solid #999;background-color:#888;font-size:14px;text-align:left;overflow:hidden;}.tabulator[tabulator-layout=fitDataFill] .tabulator-tableHolder .tabulator-table{min-width:100%}.tabulator.tabulator-block-select{-webkit-user-select:none;-ms-user-select:none;user-select:none}.tabulator .tabulator-header{position:relative;box-sizing:border-box;width:100%;border-bottom:1px solid #999;background-color:#e6e6e6;color:#555;font-weight:700;white-space:nowrap;overflow:hidden;-moz-user-select:none;-khtml-user-select:none;-webkit-user-select:none;-o-user-select:none}.tabulator .tabulator-header.tabulator-header-hidden{display:none}.tabulator .tabulator-header .tabulator-col{display:inline-block;position:relative;box-sizing:border-box;border-right:1px solid #aaa;background:#e6e6e6;text-align:left;vertical-align:bottom;overflow:hidden}.tabulator .tabulator-header .tabulator-col.tabulator-moving{position:absolute;border:1px solid #999;background:#cdcdcd;pointer-events:none}.tabulator .tabulator-header .tabulator-col .tabulator-col-content{box-sizing:border-box;position:relative;padding:4px}.tabulator .tabulator-header .tabulator-col .tabulator-col-content .tabulator-header-menu-button{padding:0 8px}.tabulator .tabulator-header .tabulator-col .tabulator-col-content .tabulator-header-menu-button:hover{cursor:pointer;opacity:.6}.tabulator .tabulator-header .tabulator-col .tabulator-col-content .tabulator-col-title{box-sizing:border-box;width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;vertical-align:bottom}.tabulator .tabulator-header .tabulator-col .tabulator-col-content .tabulator-col-title .tabulator-title-editor{box-sizing:border-box;width:100%;border:1px solid #999;padding:1px;background:#fff}.tabulator .tabulator-header .tabulator-col .tabulator-col-content .tabulator-arrow{display:inline-block;position:absolute;top:9px;right:8px;width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:6px solid #bbb}.tabulator .tabulator-header .tabulator-col.tabulator-col-group .tabulator-col-group-cols{position:relative;display:-ms-flexbox;display:flex;border-top:1px solid #aaa;overflow:hidden;margin-right:-1px}.tabulator .tabulator-header .tabulator-col:first-child .tabulator-col-resize-handle.prev{display:none}.tabulator .tabulator-header .tabulator-col .tabulator-header-filter{position:relative;box-sizing:border-box;margin-top:2px;width:100%;text-align:center}.tabulator .tabulator-header .tabulator-col .tabulator-header-filter textarea{height:auto!important}.tabulator .tabulator-header .tabulator-col .tabulator-header-filter svg{margin-top:3px}.tabulator .tabulator-header .tabulator-col .tabulator-header-filter input::-ms-clear{width:0;height:0}.tabulator .tabulator-header .tabulator-col.tabulator-sortable .tabulator-col-title{padding-right:25px}.tabulator .tabulator-header .tabulator-col.tabulator-sortable:hover{cursor:pointer;background-color:#cdcdcd}.tabulator .tabulator-header .tabulator-col.tabulator-sortable[aria-sort=none] .tabulator-col-content .tabulator-arrow{border-top:none;border-bottom:6px solid #bbb}.tabulator .tabulator-header .tabulator-col.tabulator-sortable[aria-sort=asc] .tabulator-col-content .tabulator-arrow{border-top:none;border-bottom:6px solid #666}.tabulator .tabulator-header .tabulator-col.tabulator-sortable[aria-sort=desc] .tabulator-col-content .tabulator-arrow{border-top:6px solid #666;border-bottom:none}.tabulator .tabulator-header .tabulator-col.tabulator-col-vertical .tabulator-col-content .tabulator-col-title{-ms-writing-mode:tb-rl;writing-mode:vertical-rl;text-orientation:mixed;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center}.tabulator .tabulator-header .tabulator-col.tabulator-col-vertical.tabulator-col-vertical-flip .tabulator-col-title{transform:rotate(180deg)}.tabulator .tabulator-header .tabulator-col.tabulator-col-vertical.tabulator-sortable .tabulator-col-title{padding-right:0;padding-top:20px}.tabulator .tabulator-header .tabulator-col.tabulator-col-vertical.tabulator-sortable.tabulator-col-vertical-flip .tabulator-col-title{padding-right:0;padding-bottom:20px}.tabulator .tabulator-header .tabulator-col.tabulator-col-vertical.tabulator-sortable .tabulator-arrow{right:calc(50% - 6px)}.tabulator .tabulator-header .tabulator-frozen{display:inline-block;position:absolute;z-index:10}.tabulator .tabulator-header .tabulator-frozen.tabulator-frozen-left{border-right:2px solid #aaa}.tabulator .tabulator-header .tabulator-frozen.tabulator-frozen-right{border-left:2px solid #aaa}.tabulator .tabulator-header .tabulator-calcs-holder{box-sizing:border-box;min-width:600%;background:#f3f3f3!important;border-top:1px solid #aaa;border-bottom:1px solid #aaa;overflow:hidden}.tabulator .tabulator-header .tabulator-calcs-holder .tabulator-row{background:#f3f3f3!important}.tabulator .tabulator-header .tabulator-calcs-holder .tabulator-row .tabulator-col-resize-handle{display:none}.tabulator .tabulator-header .tabulator-frozen-rows-holder{min-width:600%}.tabulator .tabulator-header .tabulator-frozen-rows-holder:empty{display:none}.tabulator .tabulator-tableHolder{position:relative;width:100%;white-space:nowrap;overflow:auto;-webkit-overflow-scrolling:touch}.tabulator .tabulator-tableHolder:focus{outline:none}.tabulator .tabulator-tableHolder .tabulator-placeholder{box-sizing:border-box;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;width:100%}.tabulator .tabulator-tableHolder .tabulator-placeholder[tabulator-render-mode=virtual]{min-height:100%;min-width:100%}.tabulator .tabulator-tableHolder .tabulator-placeholder span{display:inline-block;margin:0 auto;padding:10px;color:#ccc;font-weight:700;font-size:20px}.tabulator .tabulator-tableHolder .tabulator-table{position:relative;display:inline-block;background-color:#fff;white-space:nowrap;overflow:visible;color:#333}.tabulator .tabulator-tableHolder .tabulator-table .tabulator-row.tabulator-calcs{font-weight:700;background:#e2e2e2!important}.tabulator .tabulator-tableHolder .tabulator-table .tabulator-row.tabulator-calcs.tabulator-calcs-top{border-bottom:2px solid #aaa}.tabulator .tabulator-tableHolder .tabulator-table .tabulator-row.tabulator-calcs.tabulator-calcs-bottom{border-top:2px solid #aaa}.tabulator .tabulator-footer{padding:5px 10px;border-top:1px solid #999;background-color:#e6e6e6;text-align:right;color:#555;font-weight:700;white-space:nowrap;-ms-user-select:none;user-select:none;-moz-user-select:none;-khtml-user-select:none;-webkit-user-select:none;-o-user-select:none}.tabulator .tabulator-footer .tabulator-calcs-holder{box-sizing:border-box;width:calc(100% + 20px);margin:-5px -10px 5px;text-align:left;background:#f3f3f3!important;border-bottom:1px solid #aaa;border-top:1px solid #aaa;overflow:hidden}.tabulator .tabulator-footer .tabulator-calcs-holder .tabulator-row{background:#f3f3f3!important}.tabulator .tabulator-footer .tabulator-calcs-holder .tabulator-row .tabulator-col-resize-handle{display:none}.tabulator .tabulator-footer .tabulator-calcs-holder:only-child{margin-bottom:-5px;border-bottom:none}.tabulator .tabulator-footer .tabulator-paginator{color:#555;font-family:inherit;font-weight:inherit;font-size:inherit}.tabulator .tabulator-footer .tabulator-page-size{display:inline-block;margin:0 5px;padding:2px 5px;border:1px solid #aaa;border-radius:3px}.tabulator .tabulator-footer .tabulator-pages{margin:0 7px}.tabulator .tabulator-footer .tabulator-page{display:inline-block;margin:0 2px;padding:2px 5px;border:1px solid #aaa;border-radius:3px;background:hsla(0,0%,100%,.2)}.tabulator .tabulator-footer .tabulator-page.active{color:#d00}.tabulator .tabulator-footer .tabulator-page:disabled{opacity:.5}.tabulator .tabulator-footer .tabulator-page:not(.disabled):hover{cursor:pointer;background:rgba(0,0,0,.2);color:#fff}.tabulator .tabulator-col-resize-handle{position:absolute;right:0;top:0;bottom:0;width:5px}.tabulator .tabulator-col-resize-handle.prev{left:0;right:auto}.tabulator .tabulator-col-resize-handle:hover{cursor:ew-resize}.tabulator .tabulator-loader{position:absolute;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;top:0;left:0;z-index:100;height:100%;width:100%;background:rgba(0,0,0,.4);text-align:center}.tabulator .tabulator-loader .tabulator-loader-msg{display:inline-block;margin:0 auto;padding:10px 20px;border-radius:10px;background:#fff;font-weight:700;font-size:16px}.tabulator .tabulator-loader .tabulator-loader-msg.tabulator-loading{border:4px solid #333;color:#000}.tabulator .tabulator-loader .tabulator-loader-msg.tabulator-error{border:4px solid #d00;color:#590000}.tabulator-row{position:relative;box-sizing:border-box;min-height:22px;background-color:#fff}.tabulator-row.tabulator-row-even{background-color:#efefef}.tabulator-row.tabulator-selectable:hover{background-color:#bbb;cursor:pointer}.tabulator-row.tabulator-selected{background-color:#9abcea}.tabulator-row.tabulator-selected:hover{background-color:#769bcc;cursor:pointer}.tabulator-row.tabulator-row-moving{border:1px solid #000;background:#fff}.tabulator-row.tabulator-moving{position:absolute;border-top:1px solid #aaa;border-bottom:1px solid #aaa;pointer-events:none;z-index:15}.tabulator-row .tabulator-row-resize-handle{position:absolute;right:0;bottom:0;left:0;height:5px}.tabulator-row .tabulator-row-resize-handle.prev{top:0;bottom:auto}.tabulator-row .tabulator-row-resize-handle:hover{cursor:ns-resize}.tabulator-row .tabulator-frozen{display:inline-block;position:absolute;background-color:inherit;z-index:10}.tabulator-row .tabulator-frozen.tabulator-frozen-left{border-right:2px solid #aaa}.tabulator-row .tabulator-frozen.tabulator-frozen-right{border-left:2px solid #aaa}.tabulator-row .tabulator-responsive-collapse{box-sizing:border-box;padding:5px;border-top:1px solid #aaa;border-bottom:1px solid #aaa}.tabulator-row .tabulator-responsive-collapse:empty{display:none}.tabulator-row .tabulator-responsive-collapse table{font-size:14px}.tabulator-row .tabulator-responsive-collapse table tr td{position:relative}.tabulator-row .tabulator-responsive-collapse table tr td:first-of-type{padding-right:10px}.tabulator-row .tabulator-cell{display:inline-block;position:relative;box-sizing:border-box;padding:4px;border-right:1px solid #aaa;vertical-align:middle;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.tabulator-row .tabulator-cell.tabulator-editing{border:1px solid #1d68cd;padding:0}.tabulator-row .tabulator-cell.tabulator-editing input,.tabulator-row .tabulator-cell.tabulator-editing select{border:1px;background:transparent}.tabulator-row .tabulator-cell.tabulator-validation-fail{border:1px solid #d00}.tabulator-row .tabulator-cell.tabulator-validation-fail input,.tabulator-row .tabulator-cell.tabulator-validation-fail select{border:1px;background:transparent;color:#d00}.tabulator-row .tabulator-cell:first-child .tabulator-col-resize-handle.prev{display:none}.tabulator-row .tabulator-cell.tabulator-row-handle{display:-ms-inline-flexbox;display:inline-flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;-moz-user-select:none;-khtml-user-select:none;-webkit-user-select:none;-o-user-select:none}.tabulator-row .tabulator-cell.tabulator-row-handle .tabulator-row-handle-box{width:80%}.tabulator-row .tabulator-cell.tabulator-row-handle .tabulator-row-handle-box .tabulator-row-handle-bar{width:100%;height:3px;margin-top:2px;background:#666}.tabulator-row .tabulator-cell .tabulator-data-tree-branch{display:inline-block;vertical-align:middle;height:9px;width:7px;margin-top:-9px;margin-right:5px;border-bottom-left-radius:1px;border-left:2px solid #aaa;border-bottom:2px solid #aaa}.tabulator-row .tabulator-cell .tabulator-data-tree-control{display:-ms-inline-flexbox;display:inline-flex;-ms-flex-pack:center;justify-content:center;-ms-flex-align:center;align-items:center;vertical-align:middle;height:11px;width:11px;margin-right:5px;border:1px solid #333;border-radius:2px;background:rgba(0,0,0,.1);overflow:hidden}.tabulator-row .tabulator-cell .tabulator-data-tree-control:hover{cursor:pointer;background:rgba(0,0,0,.2)}.tabulator-row .tabulator-cell .tabulator-data-tree-control .tabulator-data-tree-control-collapse{display:inline-block;position:relative;height:7px;width:1px;background:transparent}.tabulator-row .tabulator-cell .tabulator-data-tree-control .tabulator-data-tree-control-collapse:after{position:absolute;content:"";left:-3px;top:3px;height:1px;width:7px;background:#333}.tabulator-row .tabulator-cell .tabulator-data-tree-control .tabulator-data-tree-control-expand{display:inline-block;position:relative;height:7px;width:1px;background:#333}.tabulator-row .tabulator-cell .tabulator-data-tree-control .tabulator-data-tree-control-expand:after{position:absolute;content:"";left:-3px;top:3px;height:1px;width:7px;background:#333}.tabulator-row .tabulator-cell .tabulator-responsive-collapse-toggle{display:-ms-inline-flexbox;display:inline-flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;-moz-user-select:none;-khtml-user-select:none;-webkit-user-select:none;-o-user-select:none;height:15px;width:15px;border-radius:20px;background:#666;color:#fff;font-weight:700;font-size:1.1em}.tabulator-row .tabulator-cell .tabulator-responsive-collapse-toggle:hover{opacity:.7}.tabulator-row .tabulator-cell .tabulator-responsive-collapse-toggle.open .tabulator-responsive-collapse-toggle-close{display:initial}.tabulator-row .tabulator-cell .tabulator-responsive-collapse-toggle.open .tabulator-responsive-collapse-toggle-open,.tabulator-row .tabulator-cell .tabulator-responsive-collapse-toggle .tabulator-responsive-collapse-toggle-close{display:none}.tabulator-row .tabulator-cell .tabulator-traffic-light{display:inline-block;height:14px;width:14px;border-radius:14px}.tabulator-row.tabulator-group{box-sizing:border-box;border-bottom:1px solid #999;border-right:1px solid #aaa;border-top:1px solid #999;padding:5px;padding-left:10px;background:#ccc;font-weight:700;min-width:100%}.tabulator-row.tabulator-group:hover{cursor:pointer;background-color:rgba(0,0,0,.1)}.tabulator-row.tabulator-group.tabulator-group-visible .tabulator-arrow{margin-right:10px;border-left:6px solid transparent;border-right:6px solid transparent;border-top:6px solid #666;border-bottom:0}.tabulator-row.tabulator-group.tabulator-group-level-1{padding-left:30px}.tabulator-row.tabulator-group.tabulator-group-level-2{padding-left:50px}.tabulator-row.tabulator-group.tabulator-group-level-3{padding-left:70px}.tabulator-row.tabulator-group.tabulator-group-level-4{padding-left:90px}.tabulator-row.tabulator-group.tabulator-group-level-5{padding-left:110px}.tabulator-row.tabulator-group .tabulator-group-toggle{display:inline-block}.tabulator-row.tabulator-group .tabulator-arrow{display:inline-block;width:0;height:0;margin-right:16px;border-top:6px solid transparent;border-bottom:6px solid transparent;border-right:0;border-left:6px solid #666;vertical-align:middle}.tabulator-row.tabulator-group span{margin-left:10px;color:#d00}.tabulator-menu{position:absolute;display:inline-block;box-sizing:border-box;background:#fff;border:1px solid #aaa;box-shadow:0 0 5px 0 rgba(0,0,0,.2);font-size:14px;overflow-y:auto;-webkit-overflow-scrolling:touch;z-index:10000}.tabulator-menu .tabulator-menu-item{padding:5px 10px;-webkit-user-select:none;-ms-user-select:none;user-select:none}.tabulator-menu .tabulator-menu-item.tabulator-menu-item-disabled{opacity:.5}.tabulator-menu .tabulator-menu-item:not(.tabulator-menu-item-disabled):hover{cursor:pointer;background:#efefef}.tabulator-menu .tabulator-menu-separator{border-top:1px solid #aaa}.tabulator-edit-select-list{position:absolute;display:inline-block;box-sizing:border-box;max-height:200px;background:#fff;border:1px solid #aaa;font-size:14px;overflow-y:auto;-webkit-overflow-scrolling:touch;z-index:10000}.tabulator-edit-select-list .tabulator-edit-select-list-item{padding:4px;color:#333}.tabulator-edit-select-list .tabulator-edit-select-list-item.active{color:#fff;background:#1d68cd}.tabulator-edit-select-list .tabulator-edit-select-list-item:hover{cursor:pointer;color:#fff;background:#1d68cd}.tabulator-edit-select-list .tabulator-edit-select-list-notice{padding:4px;color:#333;text-align:center}.tabulator-edit-select-list .tabulator-edit-select-list-group{border-bottom:1px solid #aaa;padding:4px;padding-top:6px;color:#333;font-weight:700}.tabulator-print-fullscreen{position:absolute;top:0;bottom:0;left:0;right:0;z-index:10000}body.tabulator-print-fullscreen-hide>:not(.tabulator-print-fullscreen){display:none!important}.tabulator-print-table{border-collapse:collapse}.tabulator-print-table .tabulator-data-tree-branch{display:inline-block;vertical-align:middle;height:9px;width:7px;margin-top:-9px;margin-right:5px;border-bottom-left-radius:1px;border-left:2px solid #aaa;border-bottom:2px solid #aaa}.tabulator-print-table .tabulator-data-tree-control{display:-ms-inline-flexbox;display:inline-flex;-ms-flex-pack:center;justify-content:center;-ms-flex-align:center;align-items:center;vertical-align:middle;height:11px;width:11px;margin-right:5px;border:1px solid #333;border-radius:2px;background:rgba(0,0,0,.1);overflow:hidden}.tabulator-print-table .tabulator-data-tree-control:hover{cursor:pointer;background:rgba(0,0,0,.2)}.tabulator-print-table .tabulator-data-tree-control .tabulator-data-tree-control-collapse{display:inline-block;position:relative;height:7px;width:1px;background:transparent}.tabulator-print-table .tabulator-data-tree-control .tabulator-data-tree-control-collapse:after{position:absolute;content:"";left:-3px;top:3px;height:1px;width:7px;background:#333}.tabulator-print-table .tabulator-data-tree-control .tabulator-data-tree-control-expand{display:inline-block;position:relative;height:7px;width:1px;background:#333}.tabulator-print-table .tabulator-data-tree-control .tabulator-data-tree-control-expand:after{position:absolute;content:"";left:-3px;top:3px;height:1px;width:7px;background:#333}
            :host {
                user-select: none;
            }
            [class^="hmi-j-"], [class*=" hmi-j-"] {
                /* use !important to prevent issues with browser extensions that change fonts */
                font-family: 'hmi' !important;
                speak: none;
                font-style: normal;
                font-weight: normal;
                font-variant: normal;
                text-transform: none;
                line-height: 1;
                font-size: 14px;
                /* Better Font Rendering =========== */
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
            }
            .hmi-j-chk_empt:before {
                content: "\\e907";
            }
        
            .hmi-j-chk_sel:before {
                content: "\\e908";
            }
            .box-p {
                display: flex;
                align-items: center;
                justify-content: center;
                position: absolute;
                top: 0;
                bottom: 0;
                left: 10;
                right: 10;
            }
            .box-p-i {
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
            }
        
        </style>
        <style></style>
        <div></div><div id="inbox"></div>`;
        this._main = shadowRoot.querySelector('div');
        this._in = shadowRoot.querySelector('#inbox');
        this._style = shadowRoot.querySelectorAll('style')[1];
        this._gridtype = 0;
        this.columns = [
            {
                title: '<span id="shAll" style="width: 10px; padding-right: 10px;" class="hmi-j-chk_sel"></span>Вид.', headerTooltip: () => {
                    return 'Видимость.'
                }, field: "visible", frozen: true, formatter: (cell, formatterParams) => {
                    return cell.getValue() ? '<span class="hmi-j-chk_sel"></span>' : '<span class="hmi-j-chk_empt"></span>';
                }, hozAlign: "center", cellClick: (e, cell) => {
                    this._trendControl.pens[cell.getData().id].isvisible = !cell.getValue();
                    this._trendControl.saveState();
                },
                headerClick: (e, col) => {
                    if (e.target.tagName === 'SPAN') {
                        e.stopImmediatePropagation();
                        const sel = e.target.classList.contains('hmi-j-chk_empt');
                        for (let index = 0; index < this._trendControl.pens.length; index++) {
                            const element = this._trendControl.pens[index];
                            element.isvisible = sel
                        }

                    }
                }
            },
            { title: "Перо", headerTooltip: () => { return 'Графические атрибуты пера.' }, field: "graph", frozen: true, formatter: this._genGraph, variableHeight: false },
            { title: "Имя", headerTooltip: () => { return 'Имя пера.' }, field: "name", frozen: true },
            { title: "Источник", headerTooltip: () => { return 'Путь к переменной, связанной с пером.' }, field: "source" },
            { title: "Ед.изм.", headerTooltip: () => { return 'Единицы измерения.' }, field: "units" },
            { title: "Значение", headerTooltip: () => { return 'Значение переменной, связанной с пером.' }, field: "value" },
            { title: "Вр.посл.", headerTooltip: () => { return 'Время последнего изменения значения.' }, field: "lasttime" },
            { title: "Кач-во.", headerTooltip: () => { return 'Признак качества.' }, field: "isbad", hozAlign: "center" },
            // {
            //     title: "ш.вид", field: "showaxis", formatter: (cell, formatterParams) => {
            //         return cell.getValue() ? '<span class="hmi-j-chk_sel"></span>' : '<span class="hmi-j-chk_empt"></span>';
            //     }, align: "center", cellClick: (e, cell) => {
            //         this._trendControl.pens[cell.getData().id].showaxis = !cell.getValue();
            //     }
            // },
            { title: "Шк.Мин.", headerTooltip: () => { return 'Минимальное значение шкалы.' }, field: "scalemin" },
            { title: "Шк.Макс.", headerTooltip: () => { return 'Максимальное значение шкалы.' }, field: "scalemax" },
            { title: "НАУ", headerTooltip: () => { return 'Нижняя аварийная уставка. (LoLo)' }, field: "lolo" },
            { title: "НПУ", headerTooltip: () => { return 'Нижняя предупреждающая уставка. (Lo)' }, field: "lo" },
            { title: "ВПУ", headerTooltip: () => { return 'Верхняя предупреждающая уставка. (Hi)' }, field: "hi" },
            { title: "ВАУ", headerTooltip: () => { return 'Верхняя аварийная уставка. (HiHi)' }, field: "hihi" },
            { title: "Нач.знач.", headerTooltip: () => { return 'Значение переменной в начале диапазона' }, field: "start" },
            { title: "Мин.знач.", headerTooltip: () => { return 'Минимальное значение переменной в диапазоне' }, field: "min" },
            { title: "Макс.знач.", headerTooltip: () => { return 'Максимальное значение переменной в диапазоне' }, field: "max" },
            { title: "Кон.знач.", headerTooltip: () => { return 'Значение переменной в конце диапазона' }, field: "end" }
        ];
        this._loadState();

        const fnSize = document.createElement('span');
        fnSize.style.fontSize = '14px';
        fnSize.style.fontWeight = 'bold';
        document.body.appendChild(fnSize);

        for (let i = 0; i < this.columns.length; i++) {
            if (typeof this.columns[i].width !== 'undefined') continue;
            const regex = /<[a-zA-Z\/][^>]*>/g;
            fnSize.innerText = this.columns[i].title.replace(regex, "");
            const offset = fnSize.innerText.length < this.columns[i].title.length ? 60 : 40
            this.columns[i].width = fnSize.getBoundingClientRect().width + offset;
        }
        fnSize.remove();

        this.__reciver = this._reciver.bind(this);
        this._tabledata = [];
        this.table = new Tabulator(this._main, {
            autoResize: true,
            height: `${this.getAttribute('height')}px`,
            layout: 'fitColumns',
            layoutColumnsOnNewData: false,
            virtualDom: true,
            pagination: false,
            columns: this.columns,
            movableColumns: true,
            headerSortTristate: true,
            columnResized: (column) => {
                this._saveState();
                if (!column.getDefinition().frozen) return;
                let width = 0;
                for (const col of column.getTable().getColumns()) {
                    if (col.getField() !== column.getField() && col.getDefinition().frozen) {
                        width += col._column.width;
                    }
                }
                if (width + column._column.getWidth() > this.width - 10) {
                    column._column.setWidth(this.width - 11 - width);
                }
            },
            rowClick: (e, row) => {
                const index = row.getIndex();
                if (this._selectedIndex !== index) {
                    this.table.deselectRow(this._selectedIndex);
                    this._oldSelectedIndex = this._selectedIndex;
                    this._selectedIndex = index;
                    this.table.selectRow(this._selectedIndex);
                    this._trendControl.selectPen(index);
                }
            },
            cellDblClick: (e, cell) => {
                switch (cell.getField()) {
                    case 'scalemax':
                        this.setScaleMax(e, cell.getRow());
                        break;
                    case 'scalemin':
                        this.setScaleMin(e, cell.getRow());
                        break;
                    case 'graph':
                        this.setGraph(e, cell.getRow());
                        break;
                    default:
                        break;
                }
            }
        });
        this._shAll = this._main.querySelector('#shAll')
    }
    updateShAll(show) {
        if (show) {
            this._shAll.classList.remove('hmi-j-chk_empt')
            this._shAll.classList.add('hmi-j-chk_sel')
        } else {
            this._shAll.classList.remove('hmi-j-chk_sel')
            this._shAll.classList.add('hmi-j-chk_empt')
        }

    }
    set height(value) {
        super.height = value;
        if (this.table) {
            this.table.setHeight(value);
        }
    }

    get gridtype() {
        return this._gridtype;
    }
    set gridtype(v) {
        this._gridtype = Number(v);
        this.genRowStyle();
    }

    genRowStyle() {
        this._style.innerHTML = `
        .tabulator-row {
          ${this._gridtype === 1 || this._gridtype === 2 ? `border-bottom: 1px solid gray !important;;` : `border-bottom: 1px none !important;`};
        }
        .tabulator-cell {
          ${this._gridtype === 0 || this._gridtype === 2 ? `border-right: 1px solid gray !important;` : `border-right: 1px none !important;`};
        }`;
    }

    get trend() {
        return this._trend;
    }
    set trend(value) {
        this._trend = value;
        if (typeof value !== 'object') {
            let ms = this.parentElement;
            while (ms.nodeName !== 'MS-WINDOW') {
                ms = ms.parentElement;
            }
            if (value) {
                if (this._trendControl) this._trendControl.removeObserver(this.__reciver);

                this._trendControl = ms.querySelector(`[id="${value}"]`);
                if (this._trendControl) {
                    this._trendControl.addObserver(this.__reciver);
                } else {
                    $ns.add({ type: 'error', time: new Date().toLocaleString(), title: 'wrong trend ID', text: `legend ID:${this.id} set wrong trend ID:${value}` });
                }
            }
        } else {
            this._trendControl = value;
        }
    }

    _reciver() {
        if (!this.table) return;
        const data = this._trendControl.pens;
        if (!this.updateloc) {
            this.updateloc = true;
            requestAnimationFrame(() => {
                if (!this.table) return;
                const options = { year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };
                if (data.length < this.table.getDataCount()) {
                    const offset = this.table.getDataCount() - data.length;
                    for (let i = this.table.getDataCount() - offset; i < this.table.getDataCount(); i++) {
                        this.table.deleteRow(this.table.getDataCount() - 1);
                        i--;
                    }
                }
                var shCalc = false;
                for (let i = 0; i < data.length; i++) {
                    const el = data[i];
                    if (el.isvisible) shCalc = true;
                    let time = '', value = '', isbad = 0, lolo = '', lo = '', hi = '', hihi = '', yFormat = '';
                    let decor, type = '';
                    if (el.serie.type === 'custom') {
                        if (el.isEnum) {
                            let index
                            if (el.lastValue) {
                                index = el.lastValue[1];
                                if (el.subType.Indexes) {
                                    index = el.subType.Indexes.findIndex(eli => eli == el.lastValue[1])
                                }
                            }
                            const color = el.lastValue && el.lastValue[1] ? el.subType.Colors[index] : el.color;
                            decor = `${color}|solid|4`;
                            type = 'custom';
                        } else {
                            decor = `${el.color}|solid|4`;
                            type = 'custom';
                        }

                    } else {
                        decor = `${el.color}|${el.linestyle}|${el.thickness}|${el.serie.symbol}|${el.serie.symbolSize}`;
                    }

                    if (el.lastValue) {
                        if (el.isEnum) {
                            let index
                            if (el.lastValue) {
                                index = el.lastValue[1];
                                if (el.subType.Indexes) {
                                    index = el.subType.Indexes.findIndex(eli => eli == el.lastValue[1])
                                }
                            }
                            value = el.subType.DisplayValues[index]
                        } else {
                            switch (typeof el.lastValue[1]) {
                                case 'boolean':
                                    yFormat = '';
                                    break;
                                default:
                                    yFormat = el.yformat;
                            }
                            value = String.format(yFormat, el.lastValue[1].toString());
                            time = new Date(el.lastValue[0]).toLocaleDateString('ru', options);
                            isbad = el.lastValue[2] || 0;
                        }
                    }
                    if (el.penlimits) {
                        lolo = el.penlimits.lolo ? el.penlimits.lolo.datasource : '';
                        lo = el.penlimits.lo ? el.penlimits.lo.datasource : '';
                        hi = el.penlimits.hi ? el.penlimits.hi.datasource : '';
                        hihi = el.penlimits.hihi ? el.penlimits.hihi.datasource : '';
                    }

                    //if (this.table.getDataCount() > i) {
                    this.table.updateOrAddRow(i, {
                        id: i,
                        visible: el.isvisible,
                        graph: decor,
                        _type: type,
                        name: el.serie.name,
                        source: el.source,
                        units: el.unit,
                        value: value,
                        lasttime: time,
                        isbad: isbad,
                        // showaxis: el.showaxis,
                        scalemin: el.miny,
                        scalemax: el.maxy,
                        lolo: lolo,
                        lo: lo,
                        hi: hi,
                        hihi: hihi,
                        min: el.minmax && el.minmax[0] !== ''  && el.minmax[0] !== null ? String.format(yFormat, el.minmax[0].toString()) : '',
                        max: el.minmax && el.minmax[1] !== '' && el.minmax[1] !== null ? String.format(yFormat, el.minmax[1].toString()) : '',
                        start: el.minmax && el.minmax[2] !== '' && el.minmax[2] !== null ? String.format(yFormat, el.minmax[2].toString()) : '',
                        end: el.minmax && el.minmax[3] !== '' && el.minmax[3] !== null ? String.format(yFormat, el.minmax[3].toString()) : ''
                    });
                    if (el.selected && this._selectedIndex !== i) {
                        this._oldSelectedIndex = this._selectedIndex;
                        this._selectedIndex = i;
                        this.table.selectRow(i);
                    }
                };
                this.updateShAll(shCalc);
                if (this._oldSelectedIndex !== undefined) this.table.deselectRow(this._oldSelectedIndex);
                this.updateloc = false;
            });
        }
    }

    _genGraph(cell) {
        const param = cell.getValue().split('|');
        let inner = '';
        if (param[4] > 0) {
            switch (param[3]) {
                case 'rect':
                    inner = `<div style="background-color:${param[0]}; width:${param[4]}px; height:${param[4]}px; position: absolute; top:-${Math.ceil(param[4] / 2)}"></div>`
                    break;
                case 'circle':
                    inner = `<div style="border-radius: 50%; background-color:${param[0]}; width:${param[4]}px; height:${param[4]}px; position: absolute; top:-${Math.ceil(param[4] / 2)}"></div>`
                    break;
                case 'triangle':
                    inner = `<div style="
                    width: 0;
                    height: 0;
                    border-style: solid;
                    border-width: 0 ${param[4] / 2}px ${param[4]}px ${param[4] / 2}px;
                    border-color: transparent transparent ${param[0]} transparent;
                    position: absolute; top:-${Math.ceil(param[4] / 2)}"></div>`
                    break;
                case 'diamond':
                    inner = `<div style="transform: rotate(-45deg); background-color:${param[0]}; width:${param[4]}px; height:${param[4]}px; position: absolute; top:-${Math.ceil(param[4] / 2)}"></div>`
                    break;
                case 'none':
                    break;
                default:
                    inner = `<div style="width:${param[4]}px; height:${param[4]}px; transform: rotate(-45deg); position: absolute; top:-${Math.ceil(param[4] / 2)};
                    background: linear-gradient(to bottom, transparent 35%, ${param[0]} 35%, ${param[0]} 65%,  transparent 65%),
                    linear-gradient(to right, transparent 35%, ${param[0]} 35%, ${param[0]} 65%, transparent 65%);"></div>`
                    break;
            }
        }
        return `<div class="box-p"><div class="box-p-i" style="pointer-events:none;width:100%; border-top:${param[2]}px ${param[1]} ${param[0]};">${inner}</div></div>`;
    }

    setScaleMax(e, row) {
        const type = row.getData()._type;
        if (type === 'custom') return;
        if ($pm.hasPermissions && !$pm.checkAllow($pm.getEntryFromElement(this, 'TrendChangePens'))) return;
        const inputNum = new Inputs(this._in);
        inputNum.inputBoxNumber(null, 'Max', row.getData().scalemax, (v) => {
            const value = Number(v);
            if (!isNaN(value) && row.getData().scalemax !== value) {
                if ($pm.hasPermissions) {
                    const options = {
                        cancel: () => { },
                        customText: `${this.elname} Изменение шкалы пера ${this._trendControl.pens[row.getIndex()].name}: ${this._trendControl.pens[row.getIndex()].miny}-${value}`
                    };
                    $pm.resolveControl(this, "TrendChangePens", () => { this._trendControl.pens[row.getIndex()].maxy = value; }, options);
                }
                else {
                    this._trendControl.pens[row.getIndex()].maxy = value;
                    this._trendControl.saveState();
                }
            }
        }, {
            toBody: true,
            alignToElement: true,
            element: e.target,
            showFocus: true,
            min: row.getData().scalemin,
            max: Infinity,
            zIndex: 11000
        });
    }

    setScaleMin(e, row) {
        const type = row.getData()._type;
        if (type === 'custom') return;
        if ($pm.hasPermissions && !$pm.checkAllow($pm.getEntryFromElement(this, 'TrendChangePens'))) return;
        const inputNum = new Inputs(this._in);
        inputNum.inputBoxNumber(null, 'Min', row.getData().scalemin, (v) => {
            const value = Number(v);
            if (!isNaN(value) && row.getData().scalemin !== value) {
                if ($pm.hasPermissions) {
                    const options = {
                        cancel: () => { },
                        customText: `${this.elname} Изменение шкалы пера ${this._trendControl.pens[row.getIndex()].name}: ${value}-${this._trendControl.pens[row.getIndex()].maxy}`
                    };
                    $pm.resolveControl(this, "TrendChangePens", () => { this._trendControl.pens[row.getIndex()].miny = value; }, options);
                }
                else {
                    this._trendControl.pens[row.getIndex()].miny = value;
                    this._trendControl.saveState();
                }
            }
        }, {
            toBody: true,
            alignToElement: true,
            element: e.target,
            showFocus: true,
            min: -Infinity,
            max: row.getData().scalemax,
            zIndex: 11000
        });
    }

    setGraph(e, row) {
        const inputNum = new Inputs(this._in);
        const type = row.getData()._type;
        let index = 0;
        const pcursor = window._enums.PointType[this._trendControl.pens[row.getIndex()].pointtype]
        const PenPointType = type !== 'custom' ? DataTypes.dataTypes['HMI.PenPointType'].DisplayValues.map((current) => {
            return `<option value="${index}"${index++ === pcursor ? ' selected' : ''}>${current}</option>`;
        }).join() : '';
        let html = '';
        html += '<div style="flex-direction:column;width:240px;margin-bottom:19px;">';
        if (type !== 'custom') {
            html += `        
            <div style="margin-top:0.5em;display:flex;">
                <span style="align-self: center; width:10em;">Тип&nbsp;графика</span>
                <select id="linejoin" style="width: 120px; height: 24px;">
                    <option value="false"${!this._trendControl.pens[row.getIndex()].linejoin ? ' selected' : ''}>Линия</option>
                    <option value="true"${!this._trendControl.pens[row.getIndex()].linejoin ? '' : ' selected'}>Ступенька</option>
                </select>
            </div>
            <div style="margin-top:0.5em;display: flex;">
                <span style="align-self: center; width:10em;">Толщина</span>
                <ms-numericupdown height="24" width="120" texthorizontalalign="1" type="number" id="inp" size="40" value="${this._trendControl.pens[row.getIndex()].thickness}" incrementstep="1.0" style="position:relative; width: 180px; border: 1px solid;"></ms-numericupdown>
            </div>`
        }
        if (this._trendControl.pens[row.getIndex()].isEnum) {
            for (const key in this._trendControl.pens[row.getIndex()].subType.Colors) {
                const color = this._trendControl.pens[row.getIndex()].subType.Colors[key];
                const name = this._trendControl.pens[row.getIndex()].subType.DisplayValues[key];
                html += `
                <div style="margin-top:0.5em;display:flex;">
                    <span style="align-self: center; width:10em;">${name}</span>
                    <ms-colorpicker data-index="${key}" borderthickness="1" bordercolor="#131517" height="24" width="24" colorselect="${color}" style="position:relative; width:110px; height:20px;"></ms-colorpicker>
                </div>`
            }
        } else {
            html += `
            <div style="margin-top:0.5em;display:flex;">
                <span style="align-self: center; width:10em;">Цвет</span>
                <ms-colorpicker borderthickness="1" bordercolor="#131517" height="24" width="24" colorselect="${this._trendControl.pens[row.getIndex()].color}" style="position:relative; width:110px; height:20px;"></ms-colorpicker>
            </div>`
        }

        if (type !== 'custom') {
            html += `       
            <div style="margin-top:0.5em;display:flex;">
                <span style="align-self: center; width:10em;">Стиль&nbsp;линии</span>
                <select id="linestyle" style="width: 120px; height: 24px;">
                    <option value="0"${this._trendControl.pens[row.getIndex()].linestyle === 'solid' ? ' selected' : ''}>Линия</option>
                    <option value="1"${this._trendControl.pens[row.getIndex()].linestyle === 'dashed' ? ' selected' : ''}>Пунктир</option>
                    <option value="2"${this._trendControl.pens[row.getIndex()].linestyle === 'dotted' ? ' selected' : ''}>Точки</option>
                </select>
            </div>
            <div style="margin-top:0.5em;display:flex;">
                <span style="align-self: center; width:10em;">Вид&nbsp;точки</span>
                <select id="PenPointType" style="width: 120px; height: 24px;">
                    ${PenPointType}
                </select>
            </div>
            <div style="margin-top:0.5em;display: flex;">
                <span style="align-self: center; width:10em;">Размер&nbsp;точки</span>
                <ms-numericupdown height="24" width="120" texthorizontalalign="1" type="number" id="pointsize" size="40" value="${this._trendControl.pens[row.getIndex()].pointsize}" incrementstep="1.0" style="position:relative; width: 180px; border: 1px solid;"></ms-numericupdown>
            </div>
            <div style="margin-top:0.5em;display:flex;">
                <span style="align-self: center; width:10em;">Видимость&nbsp;шкалы</span>
                <ms-checkbox id="showaxis" borderstyle="0" borderthickness="1" bordercolor="#8C8C8C" height="24" width="24" ischecked="${this._trendControl.pens[row.getIndex()].showaxis}" style="position:relative;"></ms-checkbox>
            </div>
        `;
        }
        html += '</div>';
        inputNum.inputBoxCustom(null, html, row.getData().scalemin, (v) => {
            if (this._trendControl.pens[row.getIndex()].isEnum) {
                const colorselect = v.querySelectorAll('ms-colorpicker');
                colorselect.forEach(element => {
                    this._trendControl.pens[row.getIndex()].subType.Colors[element.dataset.index] = element.colorselect;
                });
            } else {
                const colorselect = v.querySelector('ms-colorpicker').colorselect;
                this._trendControl.pens[row.getIndex()].color = colorselect;
            }
            if (type !== 'custom') {
                const th = v.querySelector('ms-numericupdown').value;
                this._trendControl.pens[row.getIndex()].thickness = Number(th);
                const linestyle = v.querySelector('[id="linestyle"]').value;
                this._trendControl.pens[row.getIndex()].linestyle = Number(linestyle);
                const linejoin = v.querySelector('[id="linejoin"]').value;
                this._trendControl.pens[row.getIndex()].linejoin = this._toBool(linejoin);
                const ppType = v.querySelector('[id="PenPointType"]').value;
                this._trendControl.pens[row.getIndex()].pointtype = Number(ppType);
                const pointsize = v.querySelector('[id="pointsize"]').value;
                this._trendControl.pens[row.getIndex()].pointsize = Number(pointsize);
                const showaxis = v.querySelector('[id="showaxis"]').ischecked;
                this._trendControl.pens[row.getIndex()].showaxis = this._toBool(showaxis);
            }
            this._trendControl.saveState();
            this._reciver()
        }, { toBody: true, alignToElement: true, element: e.target, showFocus: true, zIndex: 11000 });
    }
    disconnectedCallback() {
        this._saveState();
        super.disconnectedCallback();
        delete this.__reciver;
        this.table.destroy();
        delete this.table;
    }

    _saveState() {
        const save = [];
        if (this.table && this.table.getColumnLayout) {
            const col = this.table.getColumns();
            col.forEach(el => {
                save.push({ width: el._column.width });
            });
            let headers = Number(/.\d/.exec(this.table.element.querySelector('[role="columnheader"]').style.height));
            const s = { col: save, header: headers };
            this.saveItemState({ colState: s });
        }
    }
    _loadState() {
        try {
            this.originPath = this.getOriginPath();
            let storedState = $ss.getItemState(this.originPath);
            if (storedState) {
                const save = storedState.colState || [];
                for (let i = 0; i < save.col.length; i++) {
                    this.columns[i].width = save.col[i].width;
                }
            }
        } catch (error) {

        }
    }
}