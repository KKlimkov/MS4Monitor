import { Trendbase } from './trendbase.js';
import { trendWorker } from '../../observer/trendWorker.js';
import { Pen } from './pen.js';
import { ObjectTree } from './objecttree.js';
import { Sampler } from './sampler.js';
/**
 * @class MSTrend
 * @extends Trendbase
 * @classdesc Тренд
 * */
export class MSTrend extends Trendbase {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'till',
            'autoscroll',
            'interval',
            'shift',
            'hasobjecttree',
            'resampleinterval',
            'intervalpageturn',
            'updatetime',
            'archivestart',
            'archiveend',
            'yaxisperpen',
            'zoomallaxes',
            'maxpens',
            'penStates',
            'intervalState',
            'curentPenState'
        ]);
    }
    /**
     * @constructor
     * */
    constructor() {
        super();
        const ds = this.tagName == 'MS-TRENDDS';
        this.cacheOptions = {};
        this.isbusy = true;
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<style>
                                    @import "controls/trend/trend.css";
                                </style>
                                <div class="t-main">
                                    <div class="t-left">
                                        <ms-toolbar id='toolbar' style="display: flex; width: 100%; height: 30px"
                                        buttons='[{"method": "Autoscroll", "class": ["hmi-j-play", "hmi-j-pause"], "tooltip": ["Автопрокрутка", "Остановить автопрокрутку"], "type": "toggle"},
                                        {"method": "ObjectTree", "class": "hmi-j-tree", "tooltip": "Дерево объекта", "type": "button"},
                                        {"method": "Export", "class": "hmi-j-table", "tooltip": "Таблица", "type": "button"},
                                        {"method": "DownloadCsv", "class": "hmi-j-export", "tooltip": "Экспорт", "type": "button"},
                                        {"method": "FirstPage", "class": "hmi-j-f_page", "tooltip": "Первая страница", "type": "button"},
                                        {"method": "PreviousPage", "class": "hmi-j-p_page", "tooltip": "Предыдущая страница", "type": "button"},
                                        {"method": "NextPage", "class": "hmi-j-n_page", "tooltip": "Следующая страница", "type": "button"},
                                        {"method": "LastPage", "class": "hmi-j-l_page", "tooltip": "Последняя страница", "type": "button"},
                                        {"method": "BrushSet", "class": ["hmi-j-setMark", "hmi-j-setMark"], "tooltip": ["Установить", "Зафиксировать"], "type": "toggle"},
                                        {"method": "BrushCancel", "class": "hmi-j-clearMark", "tooltip": "Сбросить", "type": "button"},
                                        {"type": "expander"},
                                        {"method": "ShowLegend", "class": "hmi-j-trend_legend", "tooltip": "Показать минилегенду", "type": "button"},
                                        {"method": "Print", "class": "hmi-j-print", "tooltip": "Печать", "type": "button"},
                                        {"method": "SaveImageAs", "class": "hmi-j-print_screen", "tooltip": "Экспорт графика", "type": "button"},
                                        {"method": "ClearOptions", "class": "hmi-j-reset_settings", "tooltip": "Сброс", "type": "button"}]'></ms-toolbar>
                                        <div style="top: 30px" id="trend" class="t-body"></div>
                                        <ms-datazoom id="datazoom" datazoomindex="0" incrementstep="1" format="dd.MM.yyyy HH:mm:ss" width="${(this.attributes.width.value - 80)}" height="20" foreborderwidth="2" orientation="0" isvisible="false"
                                        style="box-sizing: border-box; display: flex; left: 38; overflow: unset; z-index: 1;"></ms-datazoom>
                                    </div>
                                    <div class="t-right">
                                        <ms-minilegend id="legend" style="right: 0" width='${this.attributes.legendwidth.value}' pens='${this.attributes.data.value}'></ms-minilegend>
                                    </div>
                                    <ms-datazoom id="ydatazoom" ${ds ? 'locksize="true"' : ''} datazoomindex="1"  incrementstep="1" precision="0" format="f0" width="20" height="${(this.attributes.height.value - 100)}" min="0" max="100" minvalue="0" maxvalue="100" foreborderwidth="2" orientation="1"
                                    style="top: 50; right: 10; box-sizing: border-box; display: flex; overflow: unset; z-index: 1;"></ms-datazoom>
                                    <div class="preloader"><div>Загрузка</div><div data-loader="timer"></div></div>
                                </div>`;
        this.hasArchive = false; //если архив в тренде не появится после подписок, то горизонтальный ползунок не будет виден

        this.setParts(shadowRoot);
        this.msdatazoom.updateForDatazoom = (start, end) => { //изменение значения горизонтального ползунка 
            this.nointeraction = true;
            this.autoscroll = false;
            this.SetParameterSilent("till", end);
            this.SetParameterSilent("interval", end - start);
            this.updateInsideZoom(start, end);
            this.getBlocksIfNeeded();
            this.nointeraction = false;
            if (!this.autoscroll && !this._intervalState && this._afterInit) {
                this.saveStateInterval();
            }
        };
        this.msydatazoom.updateForDatazoom = (start, end) => { //изменение значения вертикального ползунка
            this.updateAxesForZoom();
            this.echarts && this.echarts.dispatchAction({
                type: 'dataZoom',
                dataZoomIndex: 1,
                startValue: start,
                endValue: end
            });
            this.saveCurentPenState(start, end);
        };
        this.dcIndex = 0;
        this.observers = [];
        this._cacheDataSource = [];
        this._cacheStringPenChanged = [];
        this.createTrend();
        this.createDataZoom();
        this.initialized = false;
        this.awateDataSource = [];
        this.archivedpens = {};
        this.archivedpens.toRequest = [];
        this.penindex = 1; //нумератор для clientHandle-ов
        this.datasources = [];
        this.stringpens = [];
        this._markBrush = {};
        this.msdatazoom.echarts = this.echarts;
        this.msydatazoom.echarts = this.echarts;
        this.initTrendOption();
        this.echarts.on("datazoom",
            (params) => {
                if (params.dataZoomIndex === 1)
                    return;
                if (this._clearTask) return;
                if (!this.nointeraction) {
                    this.nointeraction = true;
                    this.SetParameter("autoscroll", false);
                    this.delayedTill = this.datazoom.endValue;
                    this.delayedInterval = this.datazoom.endValue - this.datazoom.startValue;
                    this.echarts._zr.animation._update();
                    clearTimeout(this.datazooming);
                    this.msdatazoom.minvalue = this.datazoom.startValue;
                    this.msdatazoom.maxvalue = this.datazoom.endValue;
                    this.datazooming = setTimeout(() => {
                        this.nointeraction = false;
                        this.SetParameterSilent("interval", this.delayedInterval);
                        this.SetParameterSilent("till", this.delayedTill);
                        this.saveStateInterval();
                    }, 200);
                }
                this.nointeraction = false;
            });
        this.echarts.on('finished', () => {
            if (this._toolXY) {
                this.echarts.dispatchAction({
                    type: 'showTip',
                    x: this._toolXY.x,
                    y: this._toolXY.y
                });
            }
        });
        this.echarts.on('brushEnd', (params) => {
            const sr = this.pens;
            if (params.areas.length === 0) {
                for (let i = 0; i < sr.length; i++) {
                    sr[i].minmax = null;
                }
                return;
            }
            const min = parseInt(params.areas[0].coordRange[0]), max = parseInt(params.areas[0].coordRange[1]);
            this._markBrush = { min: min, max: max, set: true };
            for (let i = 0; i < sr.length; i++) {
                const data = sr[i].serie.data;
                let start = -1; //Находим либо ближайшую справа точку к левой границе диапазона, если нет, то первую точку внутри диапазона
                while (start + 1 < data.length && data[start + 1][0] <= max && (data[start + 1][0] <= min || start < 0))
                    start++;

                if (start > -1) {
                    const end = data.slice().reverse().findIndex(el => {
                        return el[0] <= max;
                    });
                    if (end > -1) {
                        if (start < data.length - end) {
                            const res = data.slice(start, data.length - end);
                            const minmax = res.reduce((minMax, currentValue) => {
                                if (currentValue[1] !== null) { //null портит весь расчет
                                    minMax[0] = Math.min(minMax[0], currentValue[1]);
                                    minMax[1] = Math.max(minMax[1], currentValue[1]);
                                }
                                return minMax;
                            }, [Infinity, -Infinity]);
                            if (minmax[0] === Infinity) minmax[0] = '';
                            if (minmax[1] === -Infinity) minmax[1] = '';
                            if (res.length > 0) {
                                minmax[2] = res[0][1];
                                minmax[3] = res[res.length - 1][1];
                            } else {
                                minmax[2] = '';
                                minmax[3] = '';
                            }
                            sr[i].minmax = minmax;
                        } else {
                            if ((sr[i].linejoin || data[data.length - end][3]) && start > 0) {
                                const value = data[start - 1][1];
                                sr[i].minmax = [value, value, value, value];
                            } else {
                                sr[i].minmax = null;
                            }
                        }
                    } else {
                        sr[i].minmax = null;
                    }
                } else {
                    sr[i].minmax = null;
                }

            }
            this.broadcast();
        });

        shadowRoot.querySelector('svg').onmousemove = (e) => {
            this._toolXY = { x: e.offsetX, y: e.offsetY };
            if (!this.b) {
                this.b = true;
                requestAnimationFrame(() => {
                    if (this.echarts) {
                        this.echarts._zr.animation._update();
                        this.b = false;
                    }
                });
            }
        };
        shadowRoot.querySelector('svg').onmouseleave = (e) => {
            this._toolXY = null;
        };
        if (this.autoscroll) {
            this.autoscrollevent = true;
        }
        this.toolbar.context = this;
        this.setPm()

        this._preLoad = shadowRoot.querySelector('.preloader')

        // console.log(`item's has state is ${this.hasItemState()}`);
    }
    setPm() {
        if ($pm.hasPermissions) {
            const ackAll = $pm.checkAllow($pm.getEntryFromElement(this, 'TrendAddPens'))
            this.toolbar.setEnable(this.toolbar.elements["ObjectTree"], ackAll);

            const print = $pm.checkAllow($pm.getEntryFromElement(this, 'TrendPrint'))
            this.toolbar.setEnable(this.toolbar.elements["Print"], print);

            const download = $pm.checkAllow($pm.getEntryFromElement(this, 'TrendSave'))
            this.toolbar.setEnable(this.toolbar.elements["DownloadCsv"], download);
            this.toolbar.setEnable(this.toolbar.elements["SaveImageAs"], download);

            // const filters = $pm.checkAllow($pm.getEntryFromElement(this, 'TrendChangePens'))
            // this._toolBar.setEnable(this._toolBar.elements["_onFilterClick"], filters);
        }
    }
    initTrendOption() {
        this.echarts.setOption({
            tooltip: {
                trigger: 'axis',
                show: true,
                hideDelay: 500,
                triggerOn: 'mousemove',
                axisPointer: {
                    show: true,
                    animation: false
                },
                backgroundColor: 'rgba(245, 245, 245, 0.8)',
                borderWidth: 1,
                borderColor: '#ccc',
                padding: 10,
                textStyle: {
                    color: '#000'
                },
                position: (pos, params, el, elRect, size) => { //всплывающая подсказка появляется всегда в одном и том же месте
                    return { top: 10, left: 30 };
                },
                formatter: params => {
                    let result = '';
                    params.forEach(pen => {
                        if (pen.axisDim === 'x' && pen.data[1] !== null && !pen.data[3]) {
                            const index = this.pens.findIndex(e => { return e.serie.name === pen.seriesName; });
                            let value;
                            if (this.pens[index].isEnum) {
                                let ind = pen.value[1];
                                if (this.pens[index].subType.Indexes) {
                                    ind = this.pens[index].subType.Indexes.findIndex(el => el == pen.value[1])
                                }
                                value = this.pens[index].subType.DisplayValues[ind];
                            } else {
                                value = this.pens[index].yformat ? String.format(this.pens[index].yformat, Number(pen.value[1]).toString()) : pen.value[1];
                            }
                            const stroke = `${pen.seriesName}: ${value}<br>`;
                            if (result.indexOf(stroke) === -1)
                                result = `${result}${stroke}`;
                        }
                    });
                    return result;
                }
            },
            xAxis: {
                type: "time",
                axisLabel: {
                    color: "#000000",
                    formatter: (value, index) => {
                        return String.format(this._xformat, new Date(value));
                    }
                },
                axisPointer: {
                    show: true,
                    lineStyle: {
                        color: "#000000",
                        opacity: 0.5,
                        width: 1
                    },
                    label: {
                        show: true,
                        formatter: function (params) {
                            return echarts.format.formatTime('hh:mm:ss', params.value);
                        },
                        backgroundColor: "#004E52"
                    },
                    handle: {
                        size: 15,
                        color: "#00ff11"
                    }
                }
            }
        });
        this.echarts._zr.animation.stop();
        this.pens.forEach(pen => {
            pen.isvisible = pen.isvisible;
        });
    }
    /**
     * Добавить наблюдателя (для Легенды)
     * @param {any} fn
     */
    addObserver(fn) {
        this.observers.push(fn);
    }
    /**
     * Убрать наблюдателя
     * @param {any} fn
     */
    removeObserver(fn) {
        this.observers = this.observers.filter(subscriber => subscriber !== fn);
    }
    /**
     * Вещание об изменениях (для Легенды)
     * */
    broadcast() {
        this.observers.forEach(subscriber => subscriber(this.pens));
    }
    /**
     * Метод Установить регион
     * */
    BrushSet() {
        if (this.pens.length === 0) return;
        if (this.autoscroll) this.SetParameter("autoscroll", false);
        let brushType = 'lineX';
        if (!this._brushState) {
            this._brushState = true;
            this.toolbar.setToggleState(this.toolbar.elements["BrushSet"], this._brushState);
        } else {
            this.SetMarkBrush();
            this._brushState = false;
            brushType = false;
            this.toolbar.setToggleState(this.toolbar.elements["BrushSet"], this._brushState);
        }
        if (this._markBrush.set && this._brushState) {
            this._brushMarkArea = null;
            this._marksLine = null;
            if (this.currentPen)
                this.createMarkAreaOption(this.pens[this.currentPen].penlimits);
            this.echarts.dispatchAction({
                type: 'brush',
                areas: [{
                    xAxisIndex: 0,
                    brushType: 'lineX',
                    brushMode: 'single',
                    range: [this._markBrush.min, this._markBrush.max],
                    coordRange: [this._markBrush.min, this._markBrush.max]
                }]
            });
        }
        this.echarts.dispatchAction({
            type: 'takeGlobalCursor',
            key: 'brush',
            brushOption: {
                brushMode: 'single',
                brushType: brushType
            }
        });
    }
    /**
     * Метод Сбросить регион
     * */
    BrushCancel() {
        if (this.pens.length === 0) return;
        if (this._markBrush) this._markBrush.set = false;

        let brushType = 'lineX';
        this.echarts.dispatchAction({
            type: 'brush',
            areas: []
        });
        if (this._brushState) {
            this.echarts.dispatchAction({
                type: 'takeGlobalCursor',
                key: 'brush',
                brushOption: {
                    brushMode: 'single',
                    brushType: brushType
                }
            });
        }
        this._brushMarkArea = null;
        this._marksLine = null;
        this.pens.forEach(pen => {
            if (pen.minmax) {
                delete pen.minmax;
            }
        });
        this.createMarkAreaOption(this.pens[this.currentPen || 0].penlimits);
    }
    SetMarkBrush() {
        if (this.pens.length > 0 && this._markBrush.set) {
            this.echarts.dispatchAction({
                type: 'brush',
                areas: []
            });
            this._brushMarkArea = [{
                xAxis: this._markBrush.min,
                itemStyle: {
                    color: '#aaa',
                    opacity: 0.2
                }
            }, {
                xAxis: this._markBrush.max
            }];
            this._marksLine = [
                { label: { formatter: this.axFormater.bind(this) }, name: 'Start', xAxis: this._markBrush.min },
                { label: { formatter: this.axFormater.bind(this) }, name: 'End', xAxis: this._markBrush.max }
            ];
            if (this.pens[this.currentPen] && this.pens[this.currentPen].penlimits) {
                this.createMarkAreaOption(this.pens[this.currentPen].penlimits);
            } else {
                this.createMarkAreaOption(this.pens[0].penlimits);
            }
        }
    }
    /**
     * Форматирование оси Х
     * @param {number} value значение для форматирования
     * @return {string} форматированное значение
     */
    axFormater(value) {
        return String.format(this._xformat, new Date(value.value));
    }
    /**
     * Метод Масштабировать
     * @deprecated
     * в последних версиях echarts он перестал работать
     * */
    ZoomIn() {
        this.echarts.dispatchAction({
            type: 'takeGlobalCursor',
            key: 'dataZoomSelect',
            dataZoomSelectActive: true
        });
    }
    /**
     * Метод Вернуть масштаб
     * @deprecated
     * */
    ZoomCancel() {
        this.echarts.dispatchAction({
            type: 'takeGlobalCursor',
            key: 'dataZoomSelect',
            dataZoomSelectActive: false
        });
    }
    /**
     * Метод Добавить перо
     * @param {any} e объект с источником пера в PenName
     * @example {PenName: "Объекты.Объект 1.Параметр 2"}
     */
    AddPen(obj, inSide, forcePerm) {
        if (!obj || !obj.PenName) return;
        if (!forcePerm && $pm.hasPermissions) {
            const options = {
                cancel: () => { },
                customText: `${this.elname} Добавлено перо ${obj.PenName}`
            };
            $pm.resolveControl(this, "TrendAddPens", () => this.addPenMethod(obj), options);
        }
        else {
            if (inSide)
                this.addPenMethod(obj);
            else
                this.reCreatePens([obj.PenName]);
        }
    }
    /**
     * Добавить перо
     * @param {object} e перо для добавления
     */
    addPenMethod(e) {
        const oldBusy = this.isbusy;
        this.isbusy = true;
        //Новые перья должны по возможности получать новые цвета, а не переиспользовать старые 
        let dc = window._enums.DistinguishedColors; //массив "отличных цветов" размера N, dc[N]
        //Пройтись по используемым цветам и собрать их в набор
        let usedColors = new Set();
        this.pens.forEach(pen => {
            usedColors.add(pen.color);
        });
        //Есть индекс первого неиспользуемого цвета this.dcIndex
        let i = this.dcIndex; //запоминаем его
        //Если цвета в наборе нет - отдать его, иначе смотреть следующий i = (i + 1) % N 
        while (usedColors.has(dc[this.dcIndex])) {
            this.dcIndex = (this.dcIndex + 1) % dc.length;
            if (this.dcIndex == i) { //перебрали все цвета, они все есть в наборе, всё равно отдать dc[this.dcIndex] 
                break;
            }
        }
        const npen = this.addPenSerie({ source: e.PenName, name: e.PenName.split('.').pop(), index: this.pens.length, basic: true, color: dc[this.dcIndex] });
        //следующий цвет будет новый, а не повторный
        this.dcIndex = (this.dcIndex + 1) % dc.length;
        this.addLastAxis();
        this.addDataSource({
            dataSourceId: "MPLCDataSource",
            itemId: 0,
            path: e.PenName,
            queueSize: 0,
            taskId: 0,
            timestampsToReturn: "Source",
            type: "LREAL",
            usesCounts: 1
        }, "Pens." + (this.pens.length - 1) + ".DataSource");
        if (this._penStates) {
            const i = this._penStates.findIndex(el => el.source === npen.source);
            npen.color = this._penStates[i].color;
            npen.thickness = this._penStates[i].thickness;
            npen.linestyle = this._penStates[i].linestyle;
            npen.linejoin = this._penStates[i].linejoin;
            npen.pointsize = this._penStates[i].pointsize;
            npen.pointtype = this._penStates[i].pointtype;
            npen.maxy = this._penStates[i].maxy;
            npen.miny = this._penStates[i].miny;
            npen.showaxis = this._penStates[i].showaxis;
            npen.isvisible = this._penStates[i].isvisible;
            npen.saved = true;
        }

        this.isbusy = oldBusy;
    }
    /**
     * Добавление пера в echarts
     * @param {any} pen структура с базовыми характеристиками пера
     * @example
     * {name: "Параметр 2", index: 1, basic: true, color: "#fcce00"}
     * name - имя параметра
     * index - номер пера в массиве перьев
     * basic - остальные характеристики будут заданы по умолчанию
     * color - цвет пера
     */
    addPenSerie(pen) {
        pen.index = this.pens.length;
        let npen = new Pen(pen);
        npen.source = pen.source;
        npen._echarts = this.echarts;
        npen.updateSeriesAxises = this.updateSeriesAxises.bind(this);
        npen.updateYAxisesOffset = this.updateYAxisesOffset.bind(this);
        npen.createMarkAreaOption = this.createMarkAreaOption.bind(this);
        npen.msydatazoom = this.msydatazoom;
        npen.minilegend = this.legend;
        npen.broadcast = this.broadcast.bind(this);
        npen.sampler = new Sampler();
        this.pens.series.push(npen.serie);
        this.pens.series.push((new Pen(pen)).serie); //дубликат для недостоверной линии
        this.pens.series[this.pens.series.length - 1].lineStyle.normal.type = "dashed";
        this.pens.push(npen);
        return npen;
    }
    /**
     * Добавить новую ось в конец
     * */
    addLastAxis() {
        if (this.pens.yaxises.length === undefined) { //тренд до этого был совсем пустым
            this.pens.yaxises = [];
            this.createDataZoom();
        }
        this.pens.yaxises.push(this.pens[this.pens.length - 1].yAxis);
        /*this.echarts.setOption({
            yAxis: this.pens[this.pens.length - 1].yAxis
        });*/
        this.legend.update(this.pens);
        /*if (this.zoomallaxes){
            this.ydatazoom.yAxisIndex.push(this.pens.length - 1);
        }*/
    }
    /**
     * Метод Удалить перо
     * @param {any} e объект с источником пера в PenName
     */
    RemovePen(e) {
        if ($pm.hasPermissions) {
            const options = {
                cancel: () => { },
                customText: `${this.elname} Удалено перо ${e.PenName}`
            };
            $pm.resolveControl(this, "TrendDeletePens", this.removePen.bind(this, e), options);
        }
        else
            this.removePen(e);
    }
    /**
     * Удаление пера
     * @param {object} e объект с источников пера в PenName
     */
    removePen(e) {
        this.unsubscribeBySource(e);
        if (this.pens.length > 0) this.updateYAxises();
        this.legend.update(this.pens);
    }
    /**
     * Обновить оси
     * */
    updateYAxises() {
        this.pens.forEach((pen, index) => {
            pen.serie.yAxisIndex = index;
            this.pens.series[2 * index + 1].yAxisIndex = index;
        });
        if (this.pens.yaxises.length === 0) { //перьев не осталось, но об их отсутствии Легенде нужно сообщить
            this.broadcast();
        }
        let oldaxes = this.echarts.getOption().yAxis; //сколько осей зарегистрировано в Тренде
        oldaxes.forEach((axis, i) => {
            if (this.pens[i]) {
                this.pens[i].serie.yAxisIndex = i;
                this.pens.series[2 * i + 1].yAxisIndex = i;
                this.pens.yaxises[i] = this.pens[i].yAxis;
            } else {
                if (this.pens.yaxises[i]) this.pens.yaxises[i].show = false;
            }
        });
        this.updateYAxisesOffset();
    }
    /**
     * Обновить отступы в осях
     * */
    updateYAxisesOffset() {
        if (typeof this.pens.yaxises === 'undefined') return;

        if (!this._aixFontF && this.echarts.getModel()) {
            this._aixFontF = this.echarts.getModel().option.textStyle.fontFamily;
            this._aixFontS = this.echarts.getModel().option.textStyle.fontSize;
        }
        const fnSize = document.createElement('span');
        fnSize.style.fontSize = `${this._aixFontS}px`;
        document.body.appendChild(fnSize);

        let visibleindex = 0;
        this.pens.forEach((pen) => {
            if (pen.isvisible && (pen.showaxis && this.yaxisperpen || !this.yaxisperpen && pen.selected)) {
                pen.yAxis.show = true;
                if (pen.maxy !== null) {
                    fnSize.innerText = pen.maxy.toString().length > pen.miny.toString().length ? pen.maxy : pen.miny;
                    const tWidth = Math.ceil(fnSize.getBoundingClientRect().width)

                    pen.yAxis.offset = visibleindex;
                    visibleindex = (tWidth + pen.yAxis.offset + 20);
                } else {
                    fnSize.innerText = "100";
                    const tWidth = Math.ceil(fnSize.getBoundingClientRect().width)

                    pen.yAxis.offset = visibleindex;
                    visibleindex = (tWidth + pen.yAxis.offset + 20)
                }
                // pen.yAxis.offset = 3 * visibleindex;
                // visibleindex++;
            } else {
                pen.yAxis.show = false;
            }
        });
        this.echarts.setOption({
            grid: { left: visibleindex },
            yAxis: this.pens.yaxises
        });
        fnSize.remove();
    }
    /**
     * Отписаться от данных пера и удалить перо
     * @param {object} e объект с источников пера в PenName
     */
    unsubscribeBySource(e) {
        this.pens.forEach((pen, i) => {
            if (pen.source === e.PenName) {
                this.unsubscribeById(i);
            }
        });
        for (let i = 0; i < this.pens.length; i++) {
            if (this.pens[i].source === e.PenName) {
                this.pens[i].destroy();
                this.pens.splice(i, 1);
                this.pens.series.splice(2 * i, 2);
                this.pens.yaxises.splice(i, 1);
                i--;
            }
        }
    }
    /**
     * Отписаться от данных пера
     * @param {number} i номер пера в массиве
     */
    unsubscribeById(i) {
        this.sw.DeleteMonitoredDataItems(this.pens[i].monitoredItemId);
        for (let apen in this.archivedpens) { //перо удалено из середины массива, необходим сдвиг
            if (this.archivedpens[apen] > this.archivedpens[this.pens[i].archiveItemId])
                this.archivedpens[apen]--;
        }
        delete this.archivedpens[this.pens[i].archiveItemId];
        this.pens[i].serie.data = [];
        this.pens.series[i * 2].data = [];
        this.pens.series[i * 2 + 1].data = [];
        this.echarts.setOption({ series: this.pens.series });
        this.archivedpens.toRequest = this.archivedpens.toRequest.filter(element => {
            return element.archiveItemId != this.pens[i].archiveItemId;
        });
    }
    /**
     * Включить/выключить автоскролл
     * */
    Autoscroll() {
        this._initAutoscroll = true;
        this.SetParameter("autoscroll", !this.autoscroll);
        this._initAutoscroll = false;
    }
    /**
     * Конец
     * @type {number}
     */
    get till() {
        return this._till;
    }
    set till(value) {
        if (!this._afterInit) {
            this.originPath = this.getOriginPath();
            let storedState = $ss.getItemState(this.originPath);
            if (storedState && storedState.intervalState && storedState.intervalState.till) {
                value = storedState.intervalState.till;
            }
        }
        if (value === "0") //значение атрибута по умолчанию
            return;
        if (+value > this.archiveend + this._interval) {
            value = this.archiveend + this._interval;
        } else if (+value < this.archivestart + this._interval) {
            value = this.archivestart + this._interval;
        }
        this._till = +value;
        if (!this.nointeraction) {
            this.nointeraction = true;
            if (!this.autoscrollevent)
                this.SetParameter("autoscroll", false);
            else
                this.autoscrollevent = false;
            this.updateInsideZoom(this._till - this._interval, this._till);
            this.updateSliderZoom(this._till - this._interval, this._till);
            this.getBlocksIfNeeded();
        }
        this.nointeraction = false;
    }
    /**
     * Обновить границы datazoom внутри echarts
     * @param {number} start левая граница полотна
     * @param {number} end правая граница полотна
     */
    updateInsideZoom(start, end) {
        if (start > 0 && end > 0)
            this.echarts && this.echarts.dispatchAction({
                type: 'dataZoom',
                dataZoomIndex: 0,
                startValue: start,
                endValue: end
            });
    }
    /**
     * Обновить границы горизонтального ползунка
     * @param {number} start левая граница
     * @param {number} end правая граница
     */
    updateSliderZoom(start, end) {
        this.msdatazoom.minvalue = start;
        this.msdatazoom.maxvalue = end;
    }
    /**
     * Автопрокрутка
     * @type {boolean}
     */
    get autoscroll() {
        return this._autoscroll;
    }
    set autoscroll(value) {
        if (!this._afterInit) {
            this.originPath = this.getOriginPath();
            let storedState = $ss.getItemState(this.originPath);
            if (storedState && storedState.intervalState && typeof storedState.intervalState.autoscroll === 'boolean') {
                value = storedState.intervalState.autoscroll;
            }
        }
        this._autoscroll = this._toBool(value);
        this.autoscrollevent = true;
        if (this._autoscroll && this.archiveend) {
            this.SetParameterSilent("till", this.archiveend);
        }
        if (this.autoscroll) //при отключении не нужно запрашивать архив
            this.getBlocksIfNeeded();
        this.toolbar.setToggleState(this.toolbar.elements["Autoscroll"], this._autoscroll);
        this.saveStateInterval();
    }
    /**
     * Интервал (в мс)
     * @type {number}
     */
    get interval() {
        return this._interval;
    }
    set interval(value) {
        this._interval = +value;
        if (this._interval < 1) this.interval = 1;
        if (!this.nointeraction && this._till) {
            this.nointeraction = true;
            this.updateInsideZoom(this.till - this._interval, this.till);
            this.updateSliderZoom(this.till - this._interval, this.till);
            this.getBlocksIfNeeded();
        }
    }
    /**
    * Дерево выбора перьев
    * @type {boolean}
    */
    get intervalpageturn() {
        return this._intervalturn;
    }
    set intervalpageturn(value) {
        this._intervalturn = value;
    }
    /**
     * Период обновления данных
     * @type {number}
     */
    get updatetime() {
        return this._updatetime;
    }
    set updatetime(value) {
        this._updatetime = value;
        if (this.updateTime)
            clearInterval(this.updateTime);
        this.updateTime = setInterval(this.update.bind(this), +this._updatetime);
    }
    /**
     * Дерево выбора перьев
     * @type {boolean}
     */
    get hasobjecttree() {
        return this._hasobjecttree;
    }
    set hasobjecttree(value) {
        this._hasobjecttree = value;
        let name = "ObjectTree";
        if (this._toBool(value))
            this.toolbar.setVisible(this.toolbar.elements[name], true);
        else
            this.toolbar.setVisible(this.toolbar.elements[name], false);
    }
    /**
     * Масштабировать по всем осям
     * @type {boolean}
     */
    get zoomallaxes() {
        return this._zoomallaxes;
    }
    set zoomallaxes(value) {
        this._zoomallaxes = this._toBool(value);
        this.updateAxesForZoom();
    }
    /**
     * Обновить связи вертикального echarts datazoom с осями
     * */
    updateAxesForZoom() {
        if (this.zoomallaxes) {
            this.ydatazoom.yAxisIndex = Array.from(Array(this.pens.length).keys());
        }
        else {
            this.ydatazoom.yAxisIndex = this.currentPen;
        }
    }
    /**
    * Начало архива
    * @readonly
    * @type {number}
    */
    get archivestart() {
        return this._archivestart;
    }
    set archivestart(value) {
        this._archivestart = +value;
        this.msdatazoom.min = this._archivestart;
    }
    /**
    * Конец архива
    * @readonly
    * @type {number}
    */
    get archiveend() {
        return this._archiveend;
    }
    set archiveend(value) {
        this._archiveend = +value;
        this.msdatazoom.max = this._archiveend + this._interval;
    }
    /**
    * Автоматически создавать оси значений
    * @type {boolean}
    */
    get yaxisperpen() {
        return this._yaxisperpen;
    }
    set yaxisperpen(value) {
        this._yaxisperpen = this._toBool(value);
        this.updateYAxisesOffset();
    }
    /**
    * Максимальное количество перьев
    * @type {number}
    */
    get maxpens() {
        return this._maxpens;
    }
    set maxpens(value) {
        this._maxpens = +value;
    }
    /**
     * Изменить свойство пера
     * @param {string} attr имя свойства
     * @param {any} value значение
     */
    changePenAttribute(attr, value) {
        let index = +attr.split('.')[1];
        let parameter = attr.split('.')[2];
        this.pens[index][parameter.toLowerCase()] = value;
        this.updateSeriesAxises();
    }
    /**
     * Обновить перья и оси в echarts
     * */
    updateSeriesAxises() {
        this.echarts.setOption({
            series: this.pens.series,
            yAxis: this.pens.yaxises
        });
    }
    /**
     * Применить предупредительныве границы
     * @param {Array} markarea области
     * @param {Array} markline линии
     */
    applyMark(markarea, markline) {
        if (this._brushMarkArea) {
            markarea.push(this._brushMarkArea);
        }
        if (this._marksLine) {
            markline = markline.concat(this._marksLine);
        }
        this.pens.forEach((pen, i) => {
            if (i != this.currentPen && pen.serie.markArea) {
                pen.serie.markArea.data = [];
                pen.serie.markLine.data = [];
            }
        });
        this.pens[this.currentPen || 0].serie.markArea = { silent: true, data: markarea };
        this.pens[this.currentPen || 0].serie.markLine = { data: markline };
        this.echarts._zr.animation._update();
    }
    /**
     * Инициализация перьев
     * */
    createSeriesOption() {
        this.pens = [];
        this.pens.series = [];
        // this.originPath = this.getOriginPath();
        // const storedState = $ss.getItemState(this.originPath);
        // if (storedState.penStates) return;
        try {
            const pens = JSON.parse(this.attributes.data.value);
            for (let penname in pens) {
                this.addPenSerie(pens[penname]);
            }
            this.updateYAxisesOffset();
        } catch (e) { }
    }
    /**
     * Добавить новый источник данных
     * @param {any} link связь
     * @param {any} path имя параметра
     */
    addDataSource(link, path) {
        if (!this._afterInit) {
            this._cacheDataSource.push({ link, path });
            return;
        }
        if (this._intervalState) {
            if (this._intervalState.interval) this.interval = this._intervalState.interval;
            if (this._intervalState.autoscroll) this.autoscroll = this._intervalState.autoscroll;
            delete this._intervalState;
        }
        let i = +path.split('.')[1];
        this.pens[i].itemId = link.itemId;
        this.pens[i].path = link.path;
        if (link.type === "STRING") {//если перо стринговое
            if (this.stringpens[i]) //стринговое перо определено
                return;
            this.stringpens[i] = link;
        } else {
            if (!this.initialized) {
                this.awateDataSource.push({ link: link, path: path });
                return;
            }
            link.timestampsToReturn = "Source";
            link.clientHandle = this.penindex++;
            link['queueSize'] = 0;
            this.pens[i].clientHandle = link.clientHandle;
            this.pens.series[i * 2].data = [];
            this.pens.series[i * 2 + 1].data = [];
            this.isbusy = true;
            this.sw && this.sw.getArchiveItems(link).then(result => {
                this.pens.forEach((pen, j) => {
                    if (pen.itemId === result.itemId && pen.path === result.path) {
                        if (result.archiveItemId !== -1) {
                            this.hasArchive = true;
                            this.msdatazoom.isvisible = true;
                            if (this.archivedpens[result.archiveItemId] == undefined) //если такого пера в архивах еще нет
                                this.archivedpens.toRequest.push({ archiveItemId: result.archiveItemId });
                            pen.archiveItemId = result.archiveItemId;
                            this.archivedpens[result.archiveItemId] = j;
                            if (!Number(this.archivestart) || this.archivestart > result.startTime) {
                                this.SetParameterSilent("archivestart", result.startTime);
                                this.echarts.setOption({ xAxis: { min: this.archivestart } });
                            }
                            if (!Number(this.archiveend) || this.archiveend < result.endTime) {
                                this.SetParameterSilent("archiveend", result.endTime);
                                this.echarts.setOption({ xAxis: { max: this.archiveend + this._interval } });
                            }
                            this.autoscrollevent = true;
                            this.nointeraction = true;
                            if (this.autoscroll) {
                                this.SetParameterSilent("till", this.archiveend);
                            }
                            //this.getAsyncArchiveData(this._till - this._interval, this._till, [{ archiveItemId: result.archiveItemId }], true);
                            this.createMonitoredDataItems(link, i);
                            this.getBlocksIfNeeded(true);
                        } else {
                            if (!result.statusCode) {
                                this.createMonitoredDataItems(link, i);
                            } else {
                                $ns.add({ type: 'error', time: new Date().toLocaleString(), title: "Ошибка тренда", text: `Невозможно подписаться на параметр ${result.itemId}/${result.path}` });
                                return;
                            }
                        }
                        if (result.scaleAI) { //если есть шкала у параметра
                            pen.yformat = result.scaleAI.format ? result.scaleAI.format : '';
                            pen.unit = result.scaleAI.unit ? result.scaleAI.unit : '';
                            if (!pen.saved) {
                                pen.miny = result.scaleAI.min;
                                pen.maxy = result.scaleAI.max;
                            }
                            pen.penlimits = {};
                            pen.penlimits.min = result.scaleAI.min;
                            pen.penlimits.max = result.scaleAI.max;
                            if (result.scaleAI.hihi)
                                pen.penlimits["hihi"] = { backgroundcolor: "red", color: "red", linestyle: 0, thickness: 1, isvisible: !!result.scaleAI.hihi, datasource: result.scaleAI.hihi };
                            if (result.scaleAI.hi)
                                pen.penlimits["hi"] = { backgroundcolor: "yellow", color: "orange", linestyle: 0, thickness: 1, isvisible: !!result.scaleAI.hi, datasource: result.scaleAI.hi };
                            if (result.scaleAI.lo)
                                pen.penlimits["lo"] = { backgroundcolor: "yellow", color: "orange", linestyle: 0, thickness: 1, isvisible: !!result.scaleAI.lo, datasource: result.scaleAI.lo };
                            if (result.scaleAI.lolo)
                                pen.penlimits["lolo"] = { backgroundcolor: "red", color: "red", linestyle: 0, thickness: 1, isvisible: !!result.scaleAI.lolo, datasource: result.scaleAI.lolo };
                        }
                        pen.source = result.fullName; //даже если архива нет, у пера всё равно есть источник
                        if (j === this.currentPen || this.currentPen === undefined) {
                            pen.miny = pen.miny;
                            pen.maxy = pen.maxy;
                            this.selectPen(j);
                        }
                    }
                });
            });
        }
    }
    /**
     * Создать подписку на данные для получения новых PublishData
     * @param {object} link связь
     * @param {number} i номер пера в массиве перьев
     */
    createMonitoredDataItems(link, i) {
        this.sw && this.sw.CreateMonitoredDataItems([link]).then(data => {
            if (this._stop) return;
            if (data.code != 0) {
                console.log(data.code.toString(16));
                return;
            }
            this.pens[i].monitoredItemId = data.items[0].monitoredItemId;
            this.isbusy = false;
        });
    }
    /**
     * Обновление Тренда
     */
    update() {
        if (this.isbusy)
            return;
        if (this.autoscroll) {
            this.autoscrollevent = true;
            this.SetParameterSilent("till", this.archiveend);
        }
        let needRedraw = false;
        this.pens.forEach(pen => {
            if (pen.drawconstant) {
                let lastElement = pen.serie.data[pen.serie.data.length - 1];
                if (this.archiveend > this.msdatazoom.minvalue) {
                    const seriedata = pen.serie.data;
                    if (lastElement) {
                        if (lastElement[3]) {
                            const preLastElement = seriedata[pen.serie.data.length - 2];
                            if (preLastElement && preLastElement[3]) {
                                seriedata.splice(seriedata.length - 2);
                            } else {
                                seriedata.splice(seriedata.length - 1);
                            }
                            lastElement = seriedata[seriedata.length - 1];
                        }
                        if (lastElement[0] < this.msdatazoom.minvalue) {
                            seriedata.push([this.msdatazoom.minvalue + 1, lastElement[1], lastElement[2], true]);
                        }
                        const tm = this.archiveend > lastElement[0] ? this.archiveend : lastElement[0];
                        seriedata.push([tm, lastElement[1], lastElement[2], true]);
                        needRedraw = true;
                    }
                }
            }
        });
        if (this.pens.rightBorder !== this.msdatazoom.maxvalue || this.pens.leftBorder !== this.msdatazoom.minvalue) {
            this.pens.rightBorder = this.msdatazoom.maxvalue;
            this.pens.leftBorder = this.msdatazoom.minvalue;
            this.nointeraction = true;
            this.updateInsideZoom(this.pens.leftBorder, this.pens.rightBorder);
            needRedraw = true;
        }
        if (needRedraw) {
            this.echarts.setOption({
                series: this.pens.series,
                xAxis: {
                    max: this.archiveend + this._interval
                }
            }, false, true);
            this.echarts._zr.animation._update();
        }
    }
    debugFindTrubl(data) {
        const res = data.filter((e, i, a) => { return a[i + 1] && e[0] > a[i + 1][0] });
        if (res.length > 0)
            console.log(res);
    }
    /**
     * Обработчик на новое значение пера
     * @param {object} item новое значение
     */
    onDataSourceChanged(item) {
        this.SetParameterSilent("archiveend", item.sourceTime);
        if (this.autoscroll && this.blockEnd && this.blockStart) {
            this.blockEnd = item.sourceTime;
            this.blockStart = item.sourceTime - this.blockInterval;
        }
        if (this.blockEnd < item.sourceTime && this.datazoom.endValue + this.blockInterval * 2 < item.sourceTime)
            return;
        if (isNaN(item.value))
            return;
        const i = this.pens.findIndex(pen => pen.clientHandle == item.clientHandle);
        if (i === -1) //была отписка, но данные успели прийти
            return;
        let unreliableSerieData = this.pens.series[i * 2 + 1].data;
        let serieData = this.pens[i].serie.data;
        const sampler = this.pens[i].sampler;
        sampler.data = serieData;
        sampler.interval_len = this.calcResampleInterval();

        this.clearPen(serieData);
        this.clearPen(unreliableSerieData);

        if (item.statusCode != 0 && item.statusCode !== undefined) {
            if (!this.pens[i].unreliable) { //недостоверное данное пришло впервые
                let lastElementIndex = serieData.length - 1;
                if (lastElementIndex > 0) {
                    while (lastElementIndex > 0 && serieData[lastElementIndex][3]) { //нужна настоящая точка, а не дорисовка константы
                        lastElementIndex--;
                    }
                    unreliableSerieData.push(serieData[lastElementIndex]);
                }
            }
            if (item.statusCode == 0xa80000) { //это выключенный рантайм
                unreliableSerieData.push([item.sourceTime, null, item.statusCode]);
            } else {
                unreliableSerieData.push([item.sourceTime, item.value, item.statusCode]);
            }
            sampler.sPush([item.sourceTime, null, item.statusCode]);
            this.pens[i].unreliable = true;
        } else {
            if (this.pens[i].unreliable) {
                unreliableSerieData.push([item.sourceTime, item.value, item.statusCode]);
                this.pens[i].unreliable = false;
            } else {
                if (this.pens[i].unreliable !== undefined) {
                    unreliableSerieData.push([item.sourceTime, null, item.statusCode]);
                }
            }
            if (!this.pens[i].archiveItemId) {
                if (item.sourceTime > this.till + this.interval && serieData.length > 0) { //новая точка ушла за границу
                    this.resetnonarchived = true;
                } else {
                    if (this.resetnonarchived) { //вернулась в границу. чтобы не было линии между провалом нужно все удалить
                        serieData = [];
                        this.resetnonarchived = false;
                    }
                }
            }
            if (serieData.length === 0 || serieData.slice(-1)[0][0] < item.sourceTime) {
                sampler.sPush([item.sourceTime, item.value, item.statusCode]);
            } else {
                const a = serieData.findIndex((a, b, c) => a[0] >= item.sourceTime);
                serieData.splice(a)
                sampler.sPush([item.sourceTime, item.value, item.statusCode]);
            }
        }
        this.pens[i].lastValue = [item.sourceTime, item.value, item.statusCode];
        let k = 0;
        let blockStart = typeof this.blockStart !== 'undefined' ? this.blockStart : this._till - this._interval * 2;
        while (serieData[k] && serieData[k][0] < blockStart && serieData.length > 2) {
            if (serieData[k + 1] && serieData[k + 1][0] < blockStart) k++;
            else break;
        }
        if (k > 0) {
            serieData.splice(0, k);
        }
        k = serieData.length - 1;
        while (k > 0 && serieData[k][0] > this.blockEnd + this._interval && serieData.length > 2) {
            if (serieData[k - 1][0] > this.blockEnd) k--;
            else break;
        }
        if (++k < serieData.length) {
            serieData.splice(k);
        }
        if (unreliableSerieData.length) { //у недостоверной линии может не быть точек
            k = 0;
            while (unreliableSerieData.length && unreliableSerieData[k] && unreliableSerieData[k][0] < blockStart) {
                if (unreliableSerieData[k + 1] && unreliableSerieData[k + 1][0] < blockStart) k++;
                else break;
            }
            if (k > 0) {
                unreliableSerieData.splice(0, k);
            }
            k = unreliableSerieData.length - 1;
            while (k >= 0 && unreliableSerieData[k][0] > this.blockEnd + this._interval) {
                if (unreliableSerieData[k - 1] && unreliableSerieData[k - 1][0] > this.blockEnd) k--;
                else break;
            }
            if (++k < serieData.length) {
                unreliableSerieData.splice(k);
            }
        }
        this.broadcast();
        if (this.showlegend) {
            this.legend.setLastValue(i, String.format(this.pens[i].yformat, item.value) + this.pens[i].unit);
        }
    }

    /**
     * Изменение стрингового пера
     * @param {string} propertyPath имя параметра
     * @example Pens[1].DataSource
     * @param {string} value значение
     * @example Объекты.Объект 1.Параметр 1
     */
    onStringPenChanged(propertyPath, value) {
        if (!this._afterInit) {
            this._cacheStringPenChanged.push({ propertyPath, value });
            return;
        }
        let i = +propertyPath.split('.')[1];
        if (!this.stringpens[i])
            return;
        if (this.pens[i] && this.pens[i].monitoredItemId)
            this.unsubscribeById(i);
        this.stringpens[i].path = value;
        this.stringpens[i].itemId = 0;
        this.stringpens[i].type = "LREAL";
        this.pens[i].serie.data = []; //сброс старых значений
        this.pens.series[i * 2].data = [];
        this.pens.series[i * 2 + 1].data = [];
        this.addDataSource(this.stringpens[i], propertyPath);
    }
    /**
     * Обработчик при получении с сервера нового времени
     * Нужно для того чтобы Конец Тренда продолжал двигаться вперед при включенной автопрокрутке, даже если новых данных нет (константа)
     * @param {number} time новое время
     */
    onUpdateTime(time) {
        if (this.autoscroll) {
            this.autoscrollevent = true;
            this.SetParameterSilent("till", this.archiveend);
        }
        this.archiveend = time;
    }
    /** Получение блоков архива с сервера
     * @async
     * @param {boolean} needUpdate обязательно ли запрашивать архив
     * @return {promise} промис
     * @example
     * интервал = 7 мс, конец = 00:00:00.030 мс 1 января 1970
     * ближайший превосходящий интервал размер блока = 8 (2 в степени 3)  
     * номер блока, в который попал конец = 30 / 8 = 3
     * видимые данные на полотне Тренда: 23-30 
     * с сервера запросятся блоки 2,3,4, т.е. с 16 мс до 40 мс
     * если пользователь двигает окошко вперед-назад, то попадёт на блоки 1,2,3 или 3,4,5 
     * сначала попадёт на уже загруженный блок 2 или 4, и в идеале с сервера придёт ответ до того как окно достигнет блоков 1 или 5 
     * если меняется интервал, то размер блока пересчитается, когда интервал станет меньше 4 или больше 8
     * ничего не будет запрашиваться с сервера пока интервал будет в пределах от 4 до 8 и конец от 24 до 32
     * благодаря тому, что блоки фиксированные, это всегда будут одни и те же запросы на сервер, которые можно закешировать
    */
    getBlocksIfNeeded(needUpdate) {
        if (!(this._till && this._interval && this.archivedpens.toRequest.length))
            return;
        const K = 2;
        const lnK = Math.log(K);
        //размер блока - ближайшее число степень двойки от интервала
        const bsRank = Math.ceil(Math.log(this.interval) / lnK);
        if (bsRank !== this.currentBlockSizeRank) { //изменился ли размер блока
            needUpdate = true;
            this.currentBlockSizeRank = bsRank;
        }
        const blockSize = Math.pow(K, bsRank);
        //небольшие изменения размера интервала не меняют размер блока
        //если значительно меняется конец, то меняется только номер блока
        const block = Math.floor(this.till / blockSize);
        if (this.currentBlock !== block && (!this.autoscroll || (this.autoscroll && this._initAutoscroll))) { //изменился ли номер блока
            needUpdate = true;
            this.currentBlock = block;
        }

        if (needUpdate) {
            this.blockStart = (block - 1) * blockSize;
            this.blockEnd = (block + 1) * blockSize;
            this.blockInterval = this.blockEnd - this.blockStart;
            //запрашивается архив на один блок вперед и на один блок назад
            return this.getAsyncArchiveData((block - 1) * blockSize, (block + 1) * blockSize, this.archivedpens.toRequest);
        }
        return;
    }
    /**
    * Метод Следующая страница
    */
    NextPage() {
        this.SetParameter("autoscroll", false);
        this.SetParameter("till", this.till + this.interval * this._intervalturn / 100);
    }
    /**
    * Метод Предыдущая страница
    */
    PreviousPage() {
        this.SetParameter("autoscroll", false);
        this.SetParameter("till", this.till - this.interval * this._intervalturn / 100);
    }
    /**
    * Метод Первая страница
    */
    FirstPage() {
        this.SetParameter("autoscroll", false);
        this.SetParameter("till", this.archivestart + this.interval);
    }
    /**
    * Метод Последняя страница
    */
    LastPage() {
        this.SetParameter("autoscroll", false);
        this.SetParameter("till", this.archiveend);
    }
    /**
     * Открыть дерево выбора параметров для добавления в качестве перьев
     * */
    ObjectTree() {
        if (!this._ObjectTree) {
            this._ObjectTree = new ObjectTree();
        }
        this._ObjectTree.onUpdate = (newSources) => {
            let oldSources = this.sources || [];
            const toRemove = oldSources.filter(a => { return newSources.indexOf(a) < 0; });
            const toAdd = newSources.filter(a => { return oldSources.indexOf(a) < 0; });
            if (toRemove.length || toAdd.length) {
                let text, textPen;
                if (toRemove.length) {
                    textPen = toRemove.join(', ');
                    text = toRemove.length === 1 ? `Удалено перо: ${textPen}` : `Удалено ${toRemove.length} перьев : ${textPen}\n`;
                }
                if (toAdd.length) {
                    textPen = toAdd.join(', ');
                    text = toAdd.length === 1 ? `Добавлено перо: ${textPen}` : `Добавлено ${toAdd.length} перьев : ${textPen}\n`;
                }
                if ($pm.hasPermissions) {
                    const options = {
                        cancel: () => { },
                        customText: `${this.elname} ${text}`,
                        customDialogText: 'Добавление/удаление перьев'
                    };
                    $pm.resolveControl(this, "TrendAddPens", () => this.reCreatePens(newSources), options);
                } else {
                    this.reCreatePens(newSources);
                }
            }
        };
        this.sources = this.pens.map(pen => pen.source);
        this._ObjectTree.selected = this.sources;
        this._ObjectTree.Open(this._title);
    }
    reCreatePens(newSources, notSave) {
        this.isbusy = true;
        let oldSources = this.sources || [];
        let toRemove = oldSources.filter(a => { return newSources.indexOf(a) < 0; });
        toRemove.forEach((pen) => {
            this.removePen({ PenName: pen });
        });
        let toAdd = newSources.filter(a => { return oldSources.indexOf(a) < 0; });
        const toKeep = oldSources.length - toRemove.length;
        if (toKeep < this.maxpens) { // Можно добваить
            const canAddN = this.maxpens - toKeep;
            if (canAddN < toAdd.length) {
                $ns.add({
                    type: 'warning',
                    time: new Date().toLocaleString(),
                    title: "Предупреждение тренда",
                    text: `Не все параметры были добавлены в тренд (${toAdd.length - canAddN} не добавлено) из-за превышения ограничения в (${this.maxpens})`
                });
            }
            toAdd.splice(this.maxpens - toKeep);
            toAdd.forEach((pen) => {
                if (pen) this.addPenMethod({ PenName: pen });
            });
        } else { // Всё занято
            if (toAdd.length) {
                $ns.add({
                    type: 'warning',
                    time: new Date().toLocaleString(),
                    title: "Предупреждение тренда",
                    text: `Ни один параметр не был добавлен тренд (${toAdd.length} не добавлено) из-за превышения ограничения (${this.maxpens})`
                });
            }
        }
        this.sources = newSources;
        // if (this.pens.length > 0) {
        //     this.currentPen = 0;
        //     this.selectPen(this.currentPen);
        // }

        if (this.pens.length > 0) {
            this.echarts.clear();
            this.createBasePensOptions();
            this.echarts.setOption(this.cacheOptions);
            this.createDataZoom();
            this.initTrendOption();
        } else {
            this.legend.clear();
            this.sources = undefined;
            this.currentPen = undefined;
            this.echarts.clear();
            this.createSeriesOption();
            this.createYAxisesOption();
            this.createBasePensOptions();
            this.legend.init();
            this.echarts.setOption(this.cacheOptions);
            this.createDataZoom();
            this.initTrendOption();
        }
        if (!notSave) this.saveState();
        this.isbusy = false;
        this.broadcast();
    }

    saveState() {
        if (!this._afterInit) return;
        const pensForSave = [];
        for (let i = 0; i < this.pens.length; i++) {
            const pen = this.pens[i];
            pensForSave.push(
                {
                    source: pen.source,
                    color: pen.color,
                    miny: pen.miny,
                    maxy: pen.maxy,
                    thickness: pen.thickness,
                    linestyle: pen.linestyle,
                    linejoin: pen.linejoin,
                    pointtype: pen.pointtype,
                    pointsize: pen.pointsize,
                    showaxis: pen.showaxis,
                    isvisible: pen.isvisible
                }
            )
        }
        this.saveItemState({ penStates: pensForSave });
    }
    saveStateInterval() {
        if (!this._afterInit) return;
        this.saveItemState({
            intervalState: {
                till: this.till,
                interval: this.interval,
                autoscroll: this.autoscroll
            }
        });
    }

    saveCurentPenState(start, end) {
        if (!this._afterInit) return;
        this.saveItemState({
            curentPenState: {
                currentPen: this.currentPen,
                start: start,
                end: end
            }
        });
    }

    get penStates() {
        return this._penStates;
    }
    set penStates(v) {
        this._penStates = v;
    }

    get intervalState() {
        return this._intervalState;
    }
    set intervalState(v) {
        this._intervalState = v;
    }

    get curentPenState() {
        return this._curentPenState;
    }
    set curentPenState(v) {
        this._curentPenState = v;
    }

    /**
     * @async
     * Асинхронный запрос архива с сервера
     * @param {number} startTime время начала в мс 
     * @param {number} endTime время конца в мс
     * @param {Array} pens архивные перья для запроса
     * @returns {promise} промис
     */
    getAsyncArchiveData(startTime, endTime, pens, init) {
        if (this._preLoad) { this._preLoad.classList.add("show") }
        return this.sw.getAsyncArchiveData(startTime, endTime, this.calcResampleInterval(), pens)
            .then(result => this.processArchiveData(result, init))
            .catch(err => {
                console.log(err);
            });
    }
    /**
     * Обработка архивных данных после получения с сервера
     * @param {Array} result данные из ответа
     * @param {boolean} init является ли этот запрос для Тренда первым
     */
    processArchiveData(packet, init) {
        if (packet && packet.length > 0) {
            if (!init) {
                for (let key in this.archivedpens) {
                    if (key !== "toRequest") {
                        this.pens.series[this.archivedpens[key] * 2].data = []
                        this.pens.series[this.archivedpens[key] * 2 + 1].data = []; //опустошить массив
                        // this.pens[this.archivedpens[key]].serie.data = []; //опустошить массив
                    }
                }
            }
            packet.forEach(element => {
                if (element) {
                    element.forEach(result => {
                        let penIndex = this.archivedpens[result.archiveItemId];
                        if (result.values.length > 0 && result.values[0][2] !== undefined
                        ) { //если данные есть и у них есть метка качества
                            result.values.forEach((data, index) => {
                                if (data[2] !== 0) {
                                    if (index > 0) {
                                        if (result.values[index - 1][2] !== 0) {
                                            this.pens.series[penIndex * 2 + 1].data.push(result.values[index - 1]);
                                        } else {
                                            this.pens.series[penIndex * 2].data.push(result.values[index]);
                                        }
                                    }
                                    if (data[2] == 0xa80000) { //это выключенный рантайм
                                        this.pens.series[penIndex * 2 + 1].data.push([data[0], null, data[2]]);
                                    } else {
                                        this.pens.series[penIndex * 2 + 1].data.push(data);
                                    }
                                    //if (this.pens[penIndex].serie.data.length === 0 || this.pens[penIndex].serie.data.slice(-1)[0][0] < data[0])
                                    this.pens[penIndex].serie.data.push([data[0], null, data[2]]);
                                } else {
                                    if (index > 0 && result.values[index - 1][2] != 0) {
                                        this.pens.series[penIndex * 2 + 1].data.push(data);
                                    }
                                    this.pens.series[penIndex * 2 + 1].data.push([data[0], null, data[2]]);
                                    if (this.pens[penIndex].serie.data.length === 0 || this.pens[penIndex].serie.data.slice(-1)[0][0] < data[0])
                                        this.pens[penIndex].serie.data.push(data);
                                }
                            });
                        } else {
                            this.pens[penIndex].serie.data = result.values;
                        }
                    });
                }
            });
        }
        if (this._preLoad) { this._preLoad.classList.remove("show") }
    }
    /**
     * Расчет интервала прореживания в мс. Сервер вернет не более 4 значений на интервал
     * @return {number} Интервал в мс
     * @example
     * Шаг прореживания = 1, Интервал = 1 минута (60000 мс)
     * Ширина Тренда 800 пикселей, масштаб 1:1
     * 60000 * 1 / 800 * 1 = 75
     * На каждые 75 мс сервер вернет не более 4 значений на интервал
     * Если данные изменялись чаще, чем раз в 75 миллисекунд, то в архиве на одно перо придет от 800 до 3200 значений
     * Этого достаточно чтобы на каждый пиксель полотна Тренда было значение
     */
    calcResampleInterval() {
        return (((this.interval * window.__scale.x) /
            this.attributes.width.value) *
            this.attributes.resampleinterval.value);
    }
    /**
     * Вызывается когда элемент встроен в DOM
     * @see https://developer.mozilla.org/en-US/docs/Web/Web_Components/Using_custom_elements
     * */
    connectedCallback() {
        if (typeof this.saveStateFlag === 'undefined') {
            this.saveStateFlag = this.calcSaveState();
        }
        if (this.saveStateFlag) {
            this.updateItemState();
        }
        this.sw = new trendWorker("trend_" + this.id);
        this.sw.CreateDataSubscription().then(() => {
            this.initialized = true;
            this.awateDataSource.forEach(el => {
                if (el.link.itemId === "0") {
                    el.link.itemId = $sw.ItemSubscription._getParentParam(this, "objectid");
                    if (el.link.taskId === -1) {
                        el.link.taskId = $sw.ItemSubscription._getParentParam(this, "taskid");
                    }
                }
                this.addDataSource(el.link, el.path);
            });
            this.awateDataSource = [];
        }).then(() => { this.sw && this.sw.StartWatch(); });
        this.sw.LinkUp = this.onDataSourceChanged.bind(this);
        this.sw.UpdateTime = this.onUpdateTime.bind(this);
    }
    afterInitialize() {
        if (this._afterInit)
            return;
        this._afterInit = true;
        if (this._penStates) {
            this.pens.splice(0, this.pens.length);
            this.pens.series = [];
            this.pens.yaxises = [];
            this.reCreatePens(this._penStates.map(e => e.source), true);
            delete this._penStates;
        } else {
            for (let index = 0; index < this._cacheDataSource.length; index++) {
                const element = this._cacheDataSource[index];
                this.addDataSource(element.link, element.path);
            }
            for (let index = 0; index < this._cacheStringPenChanged.length; index++) {
                const element = this._cacheStringPenChanged[index];
                this.onStringPenChanged(element.propertyPath, element.value);
            }
        }
        if (this._curentPenState) {
            this.currentPen = this._curentPenState.currentPen;
            this.updateAxesForZoom();
            this.echarts && this.echarts.dispatchAction({
                type: 'dataZoom',
                dataZoomIndex: 1,
                startValue: this._curentPenState.start,
                endValue: this._curentPenState.end
            });
            this.legend.onSelect(this.currentPen, true);
            this.msydatazoom.minvalue = this._curentPenState.start;
            this.msydatazoom.maxvalue = this._curentPenState.end;
        }
    }
    /**
     * Вызывается когда элемент удаляется из DOM
     */
    disconnectedCallback() {
        this._stop = true;
        if (this._ObjectTree) {
            this._ObjectTree.dispose();
            delete this._ObjectTree;
        }
        this.pens.forEach((pen, index) => {
            this.unsubscribeById(index);
        });
        for (let i = 0; i < this.pens.length; i++) {
            this.pens[i].destroy();
            this.pens.splice(i, 1);
            this.pens.series.splice(i, 1);
            this.pens.yaxises.splice(i, 1);
            i--;
        }
        this.sw.ServerAdapter.dispose();
        super.disconnectedCallback();
        delete this.sw;
        clearInterval(this.updateTime);
        this.echarts.setOption({}, true);
        this.echarts.dispose();
        this.echarts = null;
    }
    /**
     * Установить значение без записи в Журнал (права доступа)
     * Используется для внутренних изменений параметров (без действий пользователя)
     * @example
     * При включенной автопрокрутке постоянно обновляется параметр Конец, но спамить из-за этого Журнал не нужно
     * @param {any} Param параметр, который нужно установить
     * @param {any} value значение
     */
    SetParameterSilent(Param, value) {
        this.attributeChangedCallback(Param, this[Param], value);
    }

    clearPen(arr) {
        let i = arr.length - 1;
        while (i > 0) {
            if (arr[i][3]) arr.splice(i, 1);
            i--;
        }
    }
}