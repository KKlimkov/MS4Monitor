export class Sampler {
    constructor(interval_len) {
        this.MAX_RESPONSE_SIZE = 10000;
        this.MIN_SAMPLING_INTERVAL = 100;
        this.last_interval = 0;
        this.m_interval_len = interval_len || 0;
        this.v_min = 0;
        this.v_max = 0;
        this._new = 0;
    }
    get interval_len() {
        return this.m_interval_len;
    }
    set interval_len(v) {
        this.m_interval_len = v;
        this.last_interval = 0;
    }

    sPush(unit) {
        if (this.m_interval_len <= this.MIN_SAMPLING_INTERVAL) this.m_interval_len = 0;
        if (this.m_interval_len === 0) {
            this.data.push(unit);
        } else if (unit[0] < this.last_interval * this.m_interval_len) {
            this.last = null;
            this._new = unit[1];
            if (this._new < this.v_min) {
                this.p_min = unit;
                this.v_min = this._new;
            } else if (this._new > this.v_max) {
                this.p_max = unit;
                this.v_max = this._new;
            } else {
                this.last = unit;
            }
        } else {
            this.flush();
            this.data.push(unit);
            this._new = unit[1];
            this.v_max = this.v_min = this._new;
            this.last_interval = unit[0] / this.m_interval_len + 1;
        }
    }

    flush() {
        if (this.p_max && this.p_min) {
            if (this.p_max[0] > this.p_min[0]) {
                this.data.push(this.p_min);
                this.p_min = null;
            } else {
                this.data.push(this.p_max);
                this.p_max = null;
            }
        }
        if (this.p_min) this.data.push(this.p_min);
        if (this.p_max) this.data.push(this.p_max);
        if (this.last) this.data.push(this.last);
        this.p_min = null;
        this.p_max = null;
        this.last = null;
    }

    destroy(){
        this.p_min = null;
        this.p_max = null;
        this.last = null; 
    }
}