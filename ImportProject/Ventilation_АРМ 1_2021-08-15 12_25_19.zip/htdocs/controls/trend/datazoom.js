﻿import { MSRange } from "../range/range.js";
/**
 * @class MSDataZoom
 * @extends MSRange
 * @classdesc Ползунок для Тренда
 */
export class MSDataZoom extends MSRange {
    constructor(echarts) {
        super();
        super.inTrend(this.attributes.format.value); // инициализация ползунка под тренд
        this.echarts = echarts;
    }

    // событие изменения нижнего и верхнего значений ползунка интервала
    updateRange(){
        this.echarts._zr.animation._update();
        this.dispatchDataZoomAction();
    }
    /**
     * Действие в тренде при изменении границ
     * */
    dispatchDataZoomAction() {
        if (this.updateForDatazoom) {
            this.updateForDatazoom(this._minvalue, this._maxvalue);
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        delete this.echarts;
    }
}