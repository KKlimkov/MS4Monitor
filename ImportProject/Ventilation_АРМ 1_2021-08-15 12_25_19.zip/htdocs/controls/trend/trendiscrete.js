import { MSTrend } from './trend.js'
import { ObjectTree } from './objecttree.js';
import { Pen } from './pen.js';
import { Sampler } from './sampler.js';
import { DataTypes } from '../../generated/datatypes.js';

export class MSTrendDiscrete extends MSTrend {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'truelevel',
            'falselevel'
        ]);
    }
    constructor() {
        super();
        this._penHeight = 20;
        this._penLowHeight = 2;
        this._penYStart = 0;
        this._aixFont = '';
        this._aixFontSize = '';

        this.msydatazoom.updateForDatazoom = (start, end) => { //изменение значения вертикального ползунка
            if (this._maxPens >= this.pens.length) return;
            this.echarts.setOption({
                yAxis: {
                    min: start,
                    max: end,
                }
            });
            this.saveCurentPenState(start, end);
        };
    }

    get truelevel() {
        return this._penHeight;
    }
    set truelevel(value) {
        this._penHeight = Number.parseInt(value);
    }

    get falselevel() {
        return this._penLowHeight;
    }
    set falselevel(value) {
        this._penLowHeight = Number.parseInt(value)
    }

    get height() {
        return super.height;
    }
    set height(value) {
        super.height = value;
        this.setYAixSize();
    }

    setYAixSize() {
        this._maxPens = Math.floor(this._heightTrend / (this._penHeight + 40));
        const max = this._penYStart + this._maxPens;
        if (this.pens.length - 1 > this._maxPens) {
            this.msydatazoom.maxvalue = this.msydatazoom.minvalue + this._maxPens;
            this.msydatazoom.max = this.pens.length - 1;
        } else {
            this.msydatazoom.max = this.pens.length - 1;
            this.msydatazoom.min = 0;
            this.msydatazoom.minvalue = 0;
            this.msydatazoom.maxvalue = this.pens.length - 1;
        }

        this.echarts.setOption({
            yAxis: {
                min: this._penYStart,
                max: max,
            }
        });
    }

    createBasePensOptions() {
        const opt = {
            title: {
                textStyle: {
                    color: "#000000"
                },
                left: "center"
            },
            legend: {
                show: false
            },
            toolbox: {
                feature: {
                    brush: {
                        show: false
                    }
                }
            },
            grid: {
                show: true,
                backgroundColor: "#FFFFFF",
                borderWidth: 0,
            },
            xAxis: {
                boundaryGap: false,
                triggerEvent: true,
                silent: false,
                offset: 0,
                axisPointer: {
                    show: true,
                    lineStyle: {
                        color: "#000000",
                        opacity: 0.5,
                        width: 1
                    },
                    label: {
                        show: true,
                        backgroundColor: "#004E52"
                    },
                    handle: {
                        size: 15,
                        color: "#00ff11"
                    }
                },
                axisLine: {
                    lineStyle: {
                        width: 1,
                        color: "#000000"
                    }
                },
                nameTextStyle: {
                    color: "#000000"
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        color: "#C0C0C0"
                    }
                },
                name: ""
            },
            series: this.pens.series,
            animation: false,
            silent: false,
            brush: {
                xAxisIndex: 0,
                outOfBrush: {
                    colorAlpha: 1
                }
            }
        };
        if (this.pens.length === 0) {
            opt.yAxis = {
                min: 0,
                max: 0,
            }
        }
        this.echarts.setOption(opt);
    }

    renderItem(params, api) {
        const categoryIndex = this.pens.offsets ? this.pens.offsets[params.seriesIndex] : params.seriesIndex;
        if (!this.pens.series[params.seriesIndex]) return;
        const preLast = this.pens.series[params.seriesIndex].data[params.dataIndex - 1];
        const startC = preLast ? this.pens.series[params.seriesIndex].data[params.dataIndex - 1][0] : api.value(0);
        const start = api.coord([startC, categoryIndex]);
        const end = api.coord([api.value(0), categoryIndex]);
        const val = preLast ? preLast[1] : api.value(1);
        const height = this._penHeight;
        const a = this._penHeight / 2;
        if (end[0] < 0) return;
        let rectShape, style
        if (this.pens[params.seriesIndex].subType) {
            rectShape = echarts.graphic.clipRectByRect({
                x: start[0],
                y: start[1] - a,
                width: end[0] - start[0],
                height: height
            }, {
                x: params.coordSys.x,
                y: params.coordSys.y,
                width: params.coordSys.width,
                height: params.coordSys.height
            });
            style = api.style();
            let index = val;
            if (this.pens[params.seriesIndex].subType.Indexes) {
                index = this.pens[params.seriesIndex].subType.Indexes.findIndex(el => el == val)
            }
            style.fill = this.pens[params.seriesIndex].subType.Colors[index];
            if (preLast && preLast[2] > 0) {
                style.stroke = style.fill;
                style.fill = 'transparent';
                style.lineDash = [5, 5];
            }
        } else {
            rectShape = echarts.graphic.clipRectByRect({
                x: start[0],
                y: !this._toBool(val) ? start[1] + a - this._penLowHeight : start[1] - a,
                width: end[0] - start[0],
                height: !this._toBool(val) ? this._penLowHeight : height
            }, {
                x: params.coordSys.x,
                y: params.coordSys.y,
                width: params.coordSys.width,
                height: params.coordSys.height
            });
            style = api.style();
            if (preLast && preLast[2] > 0) {
                style.stroke = style.fill;
                style.fill = 'transparent';
                style.lineDash = [5, 5];
            }
        }

        return rectShape && {
            type: 'rect',
            shape: rectShape,
            style: style
        };
    }

    /**
     * Добавление пера в echarts
     * @param {any} pen структура с базовыми характеристиками пера
     * @example
     * {name: "Параметр 2", index: 1, basic: true, color: "#fcce00"}
     * name - имя параметра
     * index - номер пера в массиве перьев
     * basic - остальные характеристики будут заданы по умолчанию
     * color - цвет пера
     */
    addPenSerie(pen) {
        pen.index = this.pens.length;
        let npen = new Pen(pen, this.renderItem.bind(this));
        npen._echarts = this.echarts;
        npen.updateSeriesAxises = this.updateSeriesAxises.bind(this);
        npen.updateYAxisesOffset = this.updateYAxisesOffset.bind(this);
        npen.msydatazoom = this.msydatazoom;
        npen.minilegend = this.legend;
        npen.broadcast = this.broadcast.bind(this);
        npen.sampler = new Sampler();
        npen.pens = this.pens;
        this.pens.series.push(npen.serie);
        this.pens.push(npen);
        return npen;
    }
    /**
     * Обновить оси
     * */
    updateYAxises() {
        if (this.pens.yaxises.length === 0) { //перьев не осталось, но об их отсутствии Легенде нужно сообщить
            this.broadcast();
        }
        this.updateYAxisesOffset();
    }
    /**
     * Обновить отступы в осях
     * */
    updateYAxisesOffset() {
        let maxWidth = 0;
        if (!this._aixFont && this.echarts.getModel()) {
            this._aixFont = this.echarts.getModel().option.textStyle.fontFamily;
            this._aixFont = this.echarts.getModel().option.textStyle.fontSize;
        }
        const fnSize = document.createElement('span');
        fnSize.style.fontSize = '14px';
        fnSize.style.fontWeight = 'bold';
        document.body.appendChild(fnSize);

        const penNames = [];
        this.pens.forEach((pen) => {
            if (pen.isvisible) {
                penNames.push(pen.name)
                pen.yAxis.show = false;
                fnSize.innerText = pen.name;
                const tWidth = fnSize.getBoundingClientRect().width
                maxWidth = maxWidth < tWidth ? tWidth : maxWidth;
            } else {
                pen.yAxis.show = false;
            }
        });
        fnSize.remove();
        //.axisLine.lineStyle.width = +this.attributes.axisthicknessy.value
        this.echarts.setOption({
            grid: { left: maxWidth + 10 },
            yAxis: {
                min: this._penYStart,
                max: this._penYStart + this._maxPens,
                type: 'category',
                data: penNames,
                nameTextStyle: {
                    color: this.attributes.textcolor.value
                },
                splitLine: {
                    lineStyle: {
                        color: this.attributes.gridfill.value,
                    }
                },
                axisLine: {
                    lineStyle: {
                        width: +this.attributes.axisthicknessy.value,
                    }
                },
                axisTick: {
                    length: this.attributes.tickwidthy ? +this.attributes.tickwidthy.value : 3,
                    lineStyle: {
                        color: this.attributes.tickcolory.value,
                        width: +this.attributes.tickheighty.value
                    }
                }
            }
        });
    }
    /**
     * Отписаться от данных пера и удалить перо
     * @param {object} e объект с источников пера в PenName
     */
    unsubscribeBySource(e) {
        this.pens.forEach((pen, i) => {
            if (pen.source === e.PenName) {
                this.unsubscribeById(i);
            }
        });
        for (let i = 0; i < this.pens.length; i++) {
            if (this.pens[i].source === e.PenName) {
                this.pens[i].destroy();
                this.pens.splice(i, 1);
                this.pens.series.splice(i, 1);
                this.pens.yaxises.splice(i, 1);
                i--;
            }
        }
    }
    /**
     * Отписаться от данных пера
     * @param {number} i номер пера в массиве
     */
    unsubscribeById(i) {
        this.sw.DeleteMonitoredDataItems(this.pens[i].monitoredItemId);
        for (let apen in this.archivedpens) { //перо удалено из середины массива, необходим сдвиг
            if (this.archivedpens[apen] > this.archivedpens[this.pens[i].archiveItemId])
                this.archivedpens[apen]--;
        }
        delete this.archivedpens[this.pens[i].archiveItemId];
        this.pens[i].serie.data = [];
        this.echarts.setOption({ series: this.pens.series });
        this.archivedpens.toRequest = this.archivedpens.toRequest.filter(element => {
            return element.archiveItemId != this.pens[i].archiveItemId;
        });
    }
    /**
     * Обновить перья и оси в echarts
     * */
    updateSeriesAxises() {
        this.echarts.setOption({
            series: this.pens.series
        });
    }

    /**
     * Добавить новый источник данных
     * @param {any} link связь
     * @param {any} path имя параметра
     */
    addDataSource(link, path) {
        if (!this._afterInit) {
            this._cacheDataSource.push({ link, path });
            return;
        }
        if (this._intervalState) {
            if (this._intervalState.interval) this.interval = this._intervalState.interval;
            if (this._intervalState.autoscroll) this.autoscroll = this._intervalState.autoscroll;
            delete this._intervalState;
        }
        let i = +path.split('.')[1];
        this.pens[i].itemId = link.itemId;
        this.pens[i].path = link.path;
        if (link.type === "STRING") {//если перо стринговое
            if (this.stringpens[i]) //стринговое перо определено
                return;
            this.stringpens[i] = link;
        } else {
            if (!this.initialized) {
                this.awateDataSource.push({ link: link, path: path });
                return;
            }
            link.timestampsToReturn = "Source";
            link.clientHandle = this.penindex++;
            link['queueSize'] = 0;
            this.pens[i].clientHandle = link.clientHandle;
            this.pens.series[i].data = [];
            this.isbusy = true;
            this.sw && this.sw.getArchiveItems(link).then(result => {
                this.pens.forEach((pen, j) => {
                    pen.isvisible = pen.isvisible;
                    if (pen.itemId === result.itemId && pen.path === result.path) {
                        if (typeof result.type !== 'undefined') {
                            pen.type = result.type
                            if (DataTypes.dataTypes[result.type] &&
                                DataTypes.dataTypes[result.type].DataType === 'EnumeratedType') {
                                let subType = JSON.parse(JSON.stringify(DataTypes.dataTypes[result.type]));
                                if (pen.subType && pen.subType.reStored && pen.subType.Colors.length === subType.Colors.length) {
                                    subType.Colors = pen.subType.Colors;
                                    subType.reStored = true;
                                }
                                pen.subType = subType;
                                
                                pen.isEnum = true;
                                this.getDCColor(pen)
                            }
                        };
                        if (pen.type === 'BOOL') pen.yformat = '';
                        if (typeof result.scaleAI !== 'undefined') {
                            pen.yformat = result.scaleAI.format ? result.scaleAI.format : '';
                            pen.unit = result.scaleAI.unit ? result.scaleAI.unit : '';
                        }
                        if (result.archiveItemId !== -1) {
                            this.hasArchive = true;
                            this.msdatazoom.isvisible = true;
                            if (this.archivedpens[result.archiveItemId] == undefined) //если такого пера в архивах еще нет
                                this.archivedpens.toRequest.push({ archiveItemId: result.archiveItemId });
                            pen.archiveItemId = result.archiveItemId;
                            this.archivedpens[result.archiveItemId] = j;
                            if (!Number(this.archivestart) || this.archivestart > result.startTime) {
                                this.SetParameterSilent("archivestart", result.startTime);
                                this.echarts.setOption({ xAxis: { min: this.archivestart } });
                            }
                            if (!Number(this.archiveend) || this.archiveend < result.endTime) {
                                this.SetParameterSilent("archiveend", result.endTime);
                                this.echarts.setOption({ xAxis: { max: this.archiveend + this._interval } });
                            }
                            this.autoscrollevent = true;
                            this.nointeraction = true;
                            if (this.autoscroll) {
                                this.SetParameterSilent("till", this.archiveend);
                            }
                            // this.getAsyncArchiveData(this._till - this._interval, this._till, [{ archiveItemId: result.archiveItemId }], true);
                            if (typeof link.type === 'undefined' && typeof result.type !== 'undefined') link.type = result.type;
                            this.createMonitoredDataItems(link, i);
                            this.getBlocksIfNeeded(true);
                        } else {
                            if (!result.statusCode) {
                                this.createMonitoredDataItems(link, i);
                            } else {
                                $ns.add({ type: 'error', time: new Date().toLocaleString(), title: "Ошибка тренда", text: `Невозможно подписаться на параметр ${result.itemId}/${result.path}` });
                            }
                        }
                        pen.source = result.fullName; //даже если архива нет, у пера всё равно есть источник

                        this.updateYAxisesOffset();
                    }
                });
            });
        }
    }

    getDCColor(pen) {
        let dc = window._enums.DistinguishedColors; //массив "отличных цветов" размера N, dc[N]
        //Пройтись по используемым цветам и собрать их в набор
        let usedColors = new Set();
        this.pens.forEach(pen => {
            if (pen.subType) {
                for (const key in pen.subType.Colors) {
                    usedColors.add(pen.subType.Colors[key]);
                }
            } else {
                usedColors.add(pen.color);
            }
        });
        //Есть индекс первого неиспользуемого цвета this.dcIndex
        let i = this.dcIndex; //запоминаем его
        //Если цвета в наборе нет - отдать его, иначе смотреть следующий i = (i + 1) % N 
        if (!pen.subType.Colors) {
            pen.subType.Colors = {}
            for (const key in pen.subType.Indexes) {
                while (usedColors.has(dc[this.dcIndex])) {
                    this.dcIndex = (this.dcIndex + 1) % dc.length;
                    if (this.dcIndex == i) { //перебрали все цвета, они все есть в наборе, всё равно отдать dc[this.dcIndex] 
                        break;
                    }
                }
                pen.subType.Colors[key] = dc[this.dcIndex]
                this.dcIndex = (this.dcIndex + 1) % dc.length;
            }

        }

    }

    /**
     * Обработчик на новое значение пера
     * @param {object} item новое значение
     */
    onDataSourceChanged(item) {
        this.SetParameterSilent("archiveend", item.sourceTime);
        if (this.autoscroll && this.blockEnd && this.blockStart) {
            this.blockEnd = item.sourceTime;
            this.blockStart = item.sourceTime - this.blockInterval;
        }
        if (this.blockEnd < item.sourceTime && this.datazoom.endValue + this.blockInterval * 2 < item.sourceTime)
            return;
        if (isNaN(item.value))
            return;
        const i = this.pens.findIndex(pen => pen.clientHandle == item.clientHandle);
        if (i === -1) //была отписка, но данные успели прийти
            return;
        let serieData = this.pens[i].serie.data;
        const sampler = this.pens[i].sampler;
        sampler.data = serieData;
        sampler.interval_len = this.calcResampleInterval();

        this.clearPen(serieData);

        if (!this.pens[i].archiveItemId) {
            if (item.sourceTime > this.till + this.interval && serieData.length > 0) { //новая точка ушла за границу
                this.resetnonarchived = true;
            } else {
                if (this.resetnonarchived) { //вернулась в границу. чтобы не было линии между провалом нужно все удалить
                    serieData = [];
                    this.resetnonarchived = false;
                }
            }
        }
        if (serieData.length === 0 || serieData.slice(-1)[0][0] < item.sourceTime) {
            sampler.sPush([item.sourceTime, item.value, item.statusCode, null, item.sourceTime, i]);
        } else {
            const a = serieData.findIndex((a) => a[0] >= item.sourceTime);
            serieData.splice(a)
            sampler.sPush([item.sourceTime, item.value, item.statusCode, null, item.sourceTime, i]);
        }

        this.pens[i].lastValue = [item.sourceTime, item.value, item.statusCode];
        let k = 0;
        let blockStart = typeof this.blockStart !== 'undefined' ? this.blockStart : this._till - this._interval * 2;
        while (serieData[k] && serieData[k][0] < blockStart && serieData.length > 2) {
            if (serieData[k + 1] && serieData[k + 1][0] < blockStart) k++;
            else break;
        }
        if (k > 0) {
            serieData.splice(0, k);
        }
        k = serieData.length - 1;
        while (k > 0 && serieData[k][0] > this.blockEnd + this._interval && serieData.length > 2) {
            if (serieData[k - 1][0] > this.blockEnd) k--;
            else break;
        }
        if (++k < serieData.length) {
            serieData.splice(k);
        }

        this.broadcast();
        if (this.showlegend) {
            if (this.pens[i].isEnum) {
                let index = item.value;
                if (this.pens[i].subType.Indexes) {
                    index = this.pens[i].subType.Indexes.findIndex(el => el == item.value)
                }
                const val = this.pens[i].subType.DisplayValues[index];
                const color = this.pens[i].subType.Colors[index];
                this.legend.setLastValue(i, val);
                this.legend.setColor(i, color);
            } else {
                const val = this.pens[i].yformat ? String.format(this.pens[i].yformat, item.value) : item.value;
                const unit = this.pens[i].unit ? this.pens[i].unit : '';
                this.legend.setLastValue(i, val + unit);
            }
        }
    }

    /**
     * Обновление Тренда
     */
    update() {
        if (this.isbusy)
            return;
        if (this.autoscroll) {
            this.autoscrollevent = true;
            this.SetParameterSilent("till", this.archiveend);
        }
        let needRedraw = false;
        this.pens.forEach(pen => {
            if (pen.drawconstant) {
                let lastElement = pen.serie.data[pen.serie.data.length - 1];
                if (this.archiveend > this.msdatazoom.minvalue) {
                    const seriedata = pen.serie.data;
                    if (lastElement) {
                        if (lastElement[3]) {
                            const preLastElement = seriedata[pen.serie.data.length - 2];
                            if (preLastElement && preLastElement[3]) {
                                seriedata.splice(seriedata.length - 2);
                            } else {
                                seriedata.splice(seriedata.length - 1);
                            }
                            lastElement = seriedata[seriedata.length - 1];
                        }
                        if (lastElement[0] < this.msdatazoom.minvalue) {
                            seriedata.push([this.msdatazoom.minvalue + 1, lastElement[1], lastElement[2], true]);
                        }
                        const tm = this.archiveend > lastElement[0] ? this.archiveend : lastElement[0];
                        seriedata.push([tm, lastElement[1], lastElement[2], true]);
                        needRedraw = true;
                    }
                }
            }
        });
        if (this.pens.rightBorder !== this.msdatazoom.maxvalue || this.pens.leftBorder !== this.msdatazoom.minvalue) {
            this.pens.rightBorder = this.msdatazoom.maxvalue;
            this.pens.leftBorder = this.msdatazoom.minvalue;
            this.nointeraction = true;
            this.updateInsideZoom(this.pens.leftBorder, this.pens.rightBorder);
            needRedraw = true;
        }
        if (needRedraw) {
            this.echarts.setOption({
                series: this.pens.series,
                xAxis: {
                    max: this.archiveend + this._interval
                }
            }, false, true);
            this.echarts._zr.animation._update();
        }
    }

    /**
     * Обработка архивных данных после получения с сервера
     * @param {Array} result данные из ответа
     * @param {boolean} init является ли этот запрос для Тренда первым
     */
    processArchiveData(packet, init) {
        if (this._stop) return;
        if (packet && packet.length > 0) {
            if (!init) {
                for (let key in this.archivedpens) {
                    if (key !== "toRequest") {
                        this.pens.series[this.archivedpens[key]].data = []
                    }
                }
            }
            packet.forEach(element => {
                if (element) {
                    element.forEach(result => {
                        let saveData;
                        let penIndex = this.archivedpens[result.archiveItemId];
                        if (this._autoscroll) {
                            const last = result.values && result.values.length > 0 ? result.values[result.values.length - 1][0] : 0;
                            const ind = this.pens.series[penIndex].data.findIndex(el => el[0] > last);
                            if (ind > -1) {
                                saveData = this.pens.series[penIndex].data.slice(ind);
                            }
                            this.pens.series[penIndex].data = [];
                        }
                        result.values.forEach((data, index) => {
                            // item.sourceTime, item.value, item.statusCode, null, item.sourceTime, i
                            this.pens.series[penIndex].data.push([data[0], data[1], data[2], null]);
                        });
                        if (saveData) {
                            this.pens.series[penIndex].data.concat(saveData);
                        }
                    });
                }
            });
        }
        if (this._preLoad) { this._preLoad.classList.remove("show") }
    }

    reCreatePens(newSources, notSave) {
        this.isbusy = true;
        let oldSources = this.sources || [];
        let toRemove = oldSources.filter(a => { return newSources.indexOf(a) < 0; });
        toRemove.forEach((pen) => {
            this.removePen({ PenName: pen });
        });
        let toAdd = newSources.filter(a => { return oldSources.indexOf(a) < 0; });
        const toKeep = oldSources.length - toRemove.length;
        if (toKeep < this.maxpens) { // Можно добваить
            const canAddN = this.maxpens - toKeep;
            if (canAddN < toAdd.length) {
                $ns.add({
                    type: 'warning',
                    time: new Date().toLocaleString(),
                    title: "Предупреждение тренда",
                    text: `Не все параметры были добавлены в тренд (${toAdd.length - canAddN} не добавлено) из-за превышения ограничения в (${this.maxpens})`
                });
            }
            toAdd.splice(this.maxpens - toKeep);
            toAdd.forEach((pen) => {
                if (pen) this.addPenMethod({ PenName: pen });
            });
        } else { // Всё занято
            if (toAdd.length) {
                $ns.add({
                    type: 'warning',
                    time: new Date().toLocaleString(),
                    title: "Предупреждение тренда",
                    text: `Ни один параметр не был добавлен тренд (${toAdd.length} не добавлено) из-за превышения ограничения (${this.maxpens})`
                });
            }
        }
        this.sources = newSources;

        if (this.pens.length > 0) {
            this._clearTask = true;
            this.echarts.clear();
            this.echarts.setOption(this.cacheOptions);
            this.createDataZoom();
            this.initTrendOption();
            this.updateInsideZoom(this._till - this._interval, this._till);
            this.createBasePensOptions();
            delete this._clearTask;
        }
        this.legend.update(this.pens);
        this.setYAixSize();
        this.updateYAxisesOffset();
        if (!notSave) this.saveState();
        this.isbusy = false;
        this.broadcast();
    }

    /**
     * Создать 2 datazoom-a от echarts
     * */
    createDataZoom() {
        this.echarts.setOption({
            dataZoom: [
                {
                    type: "inside",
                    filterMode: 'none',
                    xAxisIndex: 0
                },
                {
                    type: "inside",
                    filterMode: 'none',
                    yAxisIndex: 0,
                    zoomOnMouseWheel: false,
                    disabled: true
                }
            ]
        });
        this.datazoom = this.echarts.getModel().option.dataZoom[0];
        this.ydatazoom = this.echarts.getModel().option.dataZoom[1];
    }

    /**
     * Добавить перо
     * @param {object} e перо для добавления
     */
    addPenMethod(e) {
        const oldBusy = this.isbusy;
        this.isbusy = true;
        //Новые перья должны по возможности получать новые цвета, а не переиспользовать старые 
        let dc = window._enums.DistinguishedColors; //массив "отличных цветов" размера N, dc[N]
        //Пройтись по используемым цветам и собрать их в набор
        let usedColors = new Set();
        this.pens.forEach(pen => {
            if (pen.subType) {
                for (const key in pen.subType.Colors) {
                    usedColors.add(pen.subType.Colors[key]);
                }
            } else {
                usedColors.add(pen.color);
            }
        });
        //Есть индекс первого неиспользуемого цвета this.dcIndex
        let i = this.dcIndex; //запоминаем его
        //Если цвета в наборе нет - отдать его, иначе смотреть следующий i = (i + 1) % N 
        while (usedColors.has(dc[this.dcIndex])) {
            this.dcIndex = (this.dcIndex + 1) % dc.length;
            if (this.dcIndex == i) { //перебрали все цвета, они все есть в наборе, всё равно отдать dc[this.dcIndex] 
                break;
            }
        }
        const npen = this.addPenSerie({
            source: e.PenName,
            name: e.PenName.split('.').pop(),
            index: this.pens.length,
            basic: true,
            color: dc[this.dcIndex],
            drawconstant: true,
            isvisible: true,
            yformat: 'f3',
            unit: ''
        });
        if (!Array.isArray(this.pens.yaxises)) this.pens.yaxises = [];
        this.pens.yaxises.push(npen.yAxis);
        //следующий цвет будет новый, а не повторный
        this.dcIndex = (this.dcIndex + 1) % dc.length;
        this.addDataSource({
            dataSourceId: "MPLCDataSource",
            itemId: 0,
            path: e.PenName,
            queueSize: 0,
            taskId: 0,
            timestampsToReturn: "Source",
            // type: "LREAL",
            usesCounts: 1
        }, "Pens." + (this.pens.length - 1) + ".DataSource");
        this.legend.update(this.pens);
        if (this._penStates) {
            const i = this._penStates.findIndex(el => el.source === e.PenName);
            npen.color = this._penStates[i].color;
            npen.thickness = this._penStates[i].thickness;
            npen.isvisible = this._penStates[i].isvisible;
            if (this._penStates[i].subtype) {
                npen.subType = this._penStates[i].subtype;
                npen.subType.reStored = true;
            }
            npen.saved = true;
        }
        this.setYAixSize();
        this.isbusy = oldBusy;
    }

    saveState() {
        if (!this._afterInit) return;
        const pensForSave = [];
        for (let i = 0; i < this.pens.length; i++) {
            const pen = this.pens[i];
            pensForSave.push(
                {
                    source: pen.source || pen.path,
                    color: pen.color,
                    thickness: pen.thickness,
                    linestyle: pen.linestyle,
                    linejoin: pen.linejoin,
                    subtype: pen.subType,
                    isvisible: pen.isvisible
                }
            )
        }
        this.saveItemState({ penStates: pensForSave });
    }

    /**
     * Изменение стрингового пера
     * @param {string} propertyPath имя параметра
     * @example Pens[1].DataSource
     * @param {string} value значение
     * @example Объекты.Объект 1.Параметр 1
     */
    onStringPenChanged(propertyPath, value) {
        if (!this._afterInit) {
            this._cacheStringPenChanged.push({ propertyPath, value });
            return;
        }
        let i = +propertyPath.split('.')[1];
        if (!this.stringpens[i])
            return;
        if (this.pens[i] && this.pens[i].monitoredItemId)
            this.unsubscribeById(i);
        this.stringpens[i].path = value;
        this.stringpens[i].itemId = 0;
        this.stringpens[i].type = "LREAL";
        this.pens[i].serie.data = []; //сброс старых значений
        this.pens.series[i].data = [];
        this.addDataSource(this.stringpens[i], propertyPath);
    }

    /**
    * Метод возврата к проектному состоянию
    */
    ClearOptions() {
        if (!this.sources) return;
        this._penStates = undefined;
        this.saveItemState({ penStates: undefined });
        this.saveItemState({ intervalState: undefined });
        this.sources.forEach((pen) => {
            this.removePen({ PenName: pen });
        });

        this.sources = undefined;
        this.createSeriesOption();

        this.legend.update(this.pens);
        this.pens.yaxises = [];
        for (let index = 0; index < this._cacheDataSource.length; index++) {
            const element = this._cacheDataSource[index];
            this.addDataSource(element.link, element.path);
        }
    }

    get curentPenState() {
        return this._curentPenState;
    }
    set curentPenState(v) {
        this._curentPenState = null;
    }

    ClearOptions() {
        super.ClearOptions();
        this.setYAixSize();
    }

    /**
 * Открыть дерево выбора параметров для добавления в качестве перьев
 * */
    ObjectTree() {
        if (!this._ObjectTree) {
            this._ObjectTree = new ObjectTree();
            this._ObjectTree.filter = (el) => {
                if (el && (el.STType === 'BOOL' || el.STType === 'SYSTEM_BOOL_PARAM')) return true;
                if (DataTypes.dataTypes[el.STType] &&
                    DataTypes.dataTypes[el.STType].DataType === 'EnumeratedType') return true;
                return false;
            }
        }
        this._ObjectTree.onUpdate = (newSources) => {
            let oldSources = this.sources || [];
            const toRemove = oldSources.filter(a => { return newSources.indexOf(a) < 0; });
            const toAdd = newSources.filter(a => { return oldSources.indexOf(a) < 0; });
            if (toRemove.length || toAdd.length) {
                let text, textPen;
                if (toRemove.length) {
                    textPen = toRemove.join(', ');
                    text = toRemove.length === 1 ? `Удалено перо: ${textPen}` : `Удалено ${toRemove.length} перьев : ${textPen}\n`;
                }
                if (toAdd.length) {
                    textPen = toAdd.join(', ');
                    text = toAdd.length === 1 ? `Добавлено перо: ${textPen}` : `Добавлено ${toAdd.length} перьев : ${textPen}\n`;
                }
                if ($pm.hasPermissions) {
                    const options = {
                        cancel: () => { },
                        customText: `${this.elname} ${text}`,
                        customDialogText: 'Добавление/удаление перьев'
                    };
                    $pm.resolveControl(this, "TrendAddPens", () => this.reCreatePens(newSources), options);
                } else {
                    this.reCreatePens(newSources);
                }
            }
        };
        this.sources = this.pens.map(pen => pen.source);
        this._ObjectTree.selected = this.sources;
        this._ObjectTree.Open(this._title);
    }

}