﻿import { Basic } from "../basic.js";
/**
 * @class MSMiniLegend
 * @extends Basic
 * @classdesc Минилегенда
 * */
export class MSMiniLegend extends Basic {
    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<style>@import "controls/trend/trend.css";</style>
            <table></table>`;
        this._main = this.shadowRoot.querySelector('table');
        this.pens = [];
        this._legendopacity = 100;
    }
    init() {
        this.pens = [];
        try {
            const pens = JSON.parse(this.attributes.pens.value);
            for (let i in pens) {
                this.addNewPen();
                this.setPenParams(this.pens.length - 1, pens[i]);
            }
        }
        catch (e) { }
    }
    /**
     * Обработка события выбора пера
     * @param {number} k номер пера в массиве перьев
     */
    onSelect(k, force) {
        if (this.trend.currentPen === k && !force) return;
        if (this.trend.pens.length === 0) return;
        if (this.trend.zoomallaxes === false && typeof this.trend.currentPen !== 'undefined' && typeof this.trend.pens[this.trend.currentPen] !== 'undefined') {
            this.trend.pens[this.trend.currentPen].cacheZoom = {
                min: this.trend.msydatazoom.min,
                max: this.trend.msydatazoom.max,
                minvalue: this.trend.msydatazoom.minvalue,
                maxvalue: this.trend.msydatazoom.maxvalue
            }
        }
        this.pens.forEach((pen, i) => {
            if (pen.isselected.style.display === "none")
                return;
            if (i == k) {
                pen.isselected.classList.add('select');
                this.trend.currentPen = k;
                this.trend.pens[i].selected = true;
            }
            else {
                if (typeof this.trend.pens[i] !== 'undefined' && this.trend.pens[i].selected) {
                    pen.isselected.classList.remove('select');
                    this.trend.pens[i].selected = false;
                }
            }
        });
        if (this.trend.zoomallaxes === false && !force && this.trend.pens[this.trend.currentPen]) {
            this.trend.ydatazoom.yAxisIndex = k;
            this.trend.echarts && this.trend.echarts.dispatchAction({
                type: 'dataZoom',
                dataZoomIndex: 1,
                startValue: this.trend.pens[this.trend.currentPen].miny,
                endValue: this.trend.pens[this.trend.currentPen].maxy
            });
        }

        if (this.trend.pens[this.trend.currentPen]) {
            if (this.trend.pens[this.trend.currentPen].miny) {
                this.trend.msydatazoom.min = this.trend.pens[this.trend.currentPen].miny;
                this.trend.msydatazoom.minvalue = this.trend.pens[this.trend.currentPen].miny;
            }
            if (this.trend.pens[this.trend.currentPen].maxy) {
                this.trend.msydatazoom.max = this.trend.pens[this.trend.currentPen].maxy;
                this.trend.msydatazoom.maxvalue = this.trend.pens[this.trend.currentPen].maxy;
            }
            this.trend.createMarkAreaOption(this.trend.pens[this.trend.currentPen].penlimits); //показать границы
        }

        this.trend.echarts.setOption({
            series: this.trend.pens.series
        });
    }
    /**
     * Обработка события изменения видимости пера
     * @param {number} k номер пера в массиве перьев
     */
    onCheckbox(k) {
        this.trend.pens[k].isvisible = !this.pens[k].isvisible.classList.contains('ch');
    }
    /**
     * Установить видимость в минилегенде и отправить событие для echarts
     * @param {number} k номер пера в массиве перьев
     * @param {boolean} value значение видимости
     */
    setIsVisible(k, value) {
        if (!this.pens[k]) return;
        if (value) {
            this.pens[k].isvisible.classList.add('ch');
            this.trend.echarts.dispatchAction({
                type: 'legendSelect',
                name: this.pens[k].name.innerHTML
            });
        } else {
            this.pens[k].isvisible.classList.remove('ch');
            this.trend.echarts.dispatchAction({
                type: 'legendUnSelect',
                name: this.pens[k].name.innerHTML
            });
        }
    }
    /**
     * Получить последнее значение пера
     * @param {number} k номер пера в массиве перьев
     * @return {number} последнее значение
     */
    getLastValue(k) {
        return this.pens[k].lastvalue.innerHTML;
    }
    /**
     * Установить последнее значение пера
     * @param {number} k номер пера в массиве перьев
     * @param {number} value последнее значение
     */
    setLastValue(k, value) {
        this.pens[k].lastvalue.innerHTML = value;
    }
    /**
     * Получить цвет пера
     * @param {number} k номер пера в массиве перьев
     * @return {string} цвет пера
     */
    getColor(k) {
        return this.pens[k].color.style.backgroundColor;
    }
    /**
     * Установить цвет пера
     * @param {number} k номер пера в массиве перьев
     * @param {string} value цвет
     */
    setColor(k, value) {
        this.pens[k].color.style.backgroundColor = value;
    }
    /**
     * Получить имя пера
     * @param {number} k номер пера в массиве перьев
     * @return {string} имя пера
     */
    getName(k) {
        return this.pens[k].name.innerHTML;
    }
    /**
     * Установить имя пера
     * @param {number} k номер пера в массиве
     * @param {string} value значение
     */
    setName(k, value) {
        this.pens[k].name.innerHTML = value;
    }
    /**
     * Установить все параметры пера
     * @param {number} i номер пера в массиве
     * @param {object} pen перо
     */
    setPenParams(i, pen) {
        this.setColor(i, pen.color);
        this.setIsVisible(i, pen.isvisible);
        this.setName(i, pen.name);
    }
    /**
     * Обновить всю минилегенду (для добавления/удаления перьев в RT)
     * @param {Array} pens новый массив перьев
     */
    update(pens) {
        let i = this.pens.length;
        while (pens.length > this.pens.length) {
            this.addNewPen(pens[i]);
            i++;
        }
        i = this.pens.length;
        while (i > pens.length) {
            this.pens[i - 1].isselected.style.display = "none";
            i--;
        }
        pens.forEach((pen, i) => {
            this.pens[i].isselected.style.display = "";
            this.setPenParams(i, pen);
        });
    }

    clear() {
        this._main.innerHTML = "";
    }

    /**
     * Добавить новое пустое перо
     * */
    addNewPen() {
        const i = this.pens.length;
        this.pens.push(this.createPen());
        this._main.appendChild(this.pens[i].isselected);
        this.pens[i].isselected.onclick = this.onSelect.bind(this, i);
        this.pens[i].isvisible.onclick = this.onCheckbox.bind(this, i);
    }
    /**
     * Создать структуру для одного пера
     * @return {object} элемент таблицы с пером
     * */
    createPen() {
        let npen = {};
        npen.isselected = document.createElement('tr');
        npen.isvisible = document.createElement('td');
        npen.isvisible.innerHTML = `<span></span>`;
        npen.name = document.createElement('td');
        npen.lastvalue = document.createElement('td');
        npen.color = document.createElement('td');
        npen.isselected.appendChild(npen.isvisible);
        npen.isselected.appendChild(npen.name);
        npen.isselected.appendChild(npen.lastvalue);
        npen.isselected.appendChild(npen.color);
        return npen;
    }
    /**
     * Создать минилегенду в SVG (для сохранения изображения и отправки на печать)
     * @return {HTMLElement} svg
     * */
    createSVG() {
        let table = document.createElement('g');
        let maxlength = 0;
        this.pens.forEach((pen, i) => {
            if (this.getName(i).length > maxlength)
                maxlength = this.getName(i).length;
        });
        for (let i = 0; i < this.pens.length; i++) {
            table.innerHTML += `
            <text x='5' y='${15 + i * 20}' font-size='small'>${this.getName(i)}</text>
            <rect x=${maxlength * 8} y='${1 + i * 20}' width='40' height='18' fill='${this.getColor(i)}'/>`;
        }
        return table;
    }

    get legendopacity() {
        return this._legendopacity;
    }
    set legendopacity(value) {
        this._legendopacity = Number(value);
        this.style.opacity = this._legendopacity / 100;
    }
}