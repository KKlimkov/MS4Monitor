﻿import { Basic } from "../basic.js";
import { MSToolbar } from "../trend/toolbar.js";
import { MSDataZoom } from "../trend/datazoom.js";
import { MSMiniLegend } from "../trend/minilegend.js";
import { exportTextfile, genetateFileName, mergeDeep } from '../../lib/utils.js';
/**
 * @class Trendbase
 * @extends Basic
 * @classdesc Базовый класс для Тренда/Графика XY
 * */
export class Trendbase extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'title',
            'chartbackground',
            'backgroundcolor',
            'gridlinethickness',
            'gridfill',
            'textcolor',
            'cursorcolor',
            'cursorthickness',
            'showcursor',
            'tickmargintopx',
            'tickmarginrighty',
            'axiscolorx',
            'xaxislabel',
            'yaxislabel',
            'axisthicknessx',
            'axisthicknessy',
            'xformat',
            'tickcountx',
            'tickcounty',
            'tickwidthx',
            'tickwidthy',
            'tickcolorx',
            'tickcolory',
            'tickheightx',
            'tickheighty',
            'showlegend',
            'legendwidth',
            'legendopacity',
            'lowresolutionmode',
            'printminilegend'
        ]);
    }
    /**
     * Установить составляющие тренда
     * @param {any} shadowRoot корень контрола
     */
    setParts(shadowRoot) {
        this._main = shadowRoot.querySelector('#trend');
        this.checkComponent('ms-datazoom', MSDataZoom);
        this.checkComponent('ms-toolbar', MSToolbar);
        this.checkComponent('ms-minilegend', MSMiniLegend);
        this.legend = shadowRoot.querySelector('#legend');
        this.msdatazoom = shadowRoot.querySelector('#datazoom');
        this.msydatazoom = shadowRoot.querySelector('#ydatazoom');
    }
    /**
     * Создать Тренд
     * @see https://echarts.apache.org/en/option.html
     * */
    createTrend() {
        if (!this.echarts) {
            this.echarts = echarts.init(this._main,
                null,
                {
                    renderer: 'svg',
                    width: this.attributes.width.value,
                    height: Number(this.attributes.height.value) - 30
                });
        }
        this.pens = [];
        this.legend = this.shadowRoot.getElementById("legend");
        this.toolbar = this.shadowRoot.querySelector('#toolbar');
        this.legend.trend = this;
        this.createSeriesOption();
        this.createYAxisesOption();
        this.createBasePensOptions();
        this.legend.init();
    }
    createBasePensOptions() {
        this.echarts.setOption({
            title: {
                textStyle: {
                    color: "#000000"
                },
                left: "center"
            },
            legend: {
                show: false
            },
            toolbox: {
                feature: {
                    brush: {
                        show: false
                    }
                }
            },
            grid: {
                show: true,
                backgroundColor: "#FFFFFF",
                borderWidth: 0,
                left: 10 + 25 * this.pens.length
            },
            xAxis: {
                boundaryGap: false,
                triggerEvent: true,
                silent: false,
                offset: 0,
                axisPointer: {
                    show: true,
                    lineStyle: {
                        color: "#000000",
                        opacity: 0.5,
                        width: 1
                    },
                    label: {
                        show: true,
                        backgroundColor: "#004E52"
                    },
                    handle: {
                        size: 15,
                        color: "#00ff11"
                    }
                },
                axisLine: {
                    lineStyle: {
                        width: 1,
                        color: "#000000"
                    }
                },
                nameTextStyle: {
                    color: "#000000"
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        color: "#C0C0C0"
                    }
                },
                name: ""
            },
            yAxis: this.pens.yaxises,
            series: this.pens.series,
            // backgroundColor: "#FFFFFF",
            animation: false,
            silent: false,
            brush: {
                xAxisIndex: 0,
                outOfBrush: {
                    colorAlpha: 1
                }
            }
        });
    }
    /**
     * Создать 2 datazoom-a от echarts
     * */
    createDataZoom() {
        let zomm;
        if (this.zoomallaxes) {
            zomm = Array.from(Array(this.pens.length).keys());
        }
        else {
            zomm = this.currentPen || 0;
        }
        if (zomm.length === 0) return;
        this.echarts.setOption({
            dataZoom: [
                {
                    type: "inside",
                    filterMode: 'none',
                    xAxisIndex: 0
                },
                {
                    type: "inside",
                    filterMode: 'none',
                    yAxisIndex: zomm,
                    zoomOnMouseWheel: false,
                    disabled: true
                }
            ]
        });
        this.datazoom = this.echarts.getModel().option.dataZoom[0];
        this.ydatazoom = this.echarts.getModel().option.dataZoom[1];
    }
    /**
     * Метод Показать легенду
     * */
    ShowLegend() {
        this.showlegend = !this.showlegend;
    }
    get width() {
        return super.width;
    }
    set width(value) {
        super.width = value;
        this.echarts.resize({
            width: this._width
        });
        this.msdatazoom.width = value - 80;
    }
    get height() {
        return super.height;
    }
    set height(value) {
        super.height = value;
        if (this._lowresolutionmode) {
            this._heightTrend = this._height;
        } else {
            this._heightTrend = this._height - 30;
        }
        this.echarts.resize({
            height: this._heightTrend
        });
        this.msydatazoom.height = this._height - 100;
    }
    /**
     * Титул
     * @type {string} 
     */
    get title() {
        return this.echarts.getOption().title[0].text;
    }
    set title(value) {
        this._title = value;
        const opt = { title: { text: value } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Заливка графика 
     * @type {string}
     */
    get chartbackground() {
        return this.echarts.getOption().grid[0].backgroundColor;
    }
    set chartbackground(value) {
        const opt = { grid: { backgroundColor: value } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    get backgroundcolor() {
        return this._backgroundcolor;
    }
    set backgroundcolor(value) {
        super.backgroundcolor = value;
        this._backgroundcolor = value;
        if (this.toolbar)
            this.toolbar.backgroundcolor = value;
    }
    /**
     * Толщина линий сетки (такое есть?) 
     * @type {number}
     */
    get gridthickness() {
        return this.echarts.getOption().xAxis[0].splitLine.lineStyle.width;
    }
    set gridthickness(value) {
        const opt1 = { xAxis: { splitLine: { lineStyle: { width: +value } } } };
        const opt2 = { yAxis: { splitLine: { lineStyle: { width: +value } } } };
        this.echarts.setOption(opt1);
        this.echarts.setOption(opt2);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt1);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt2);
    }
    /**
     * Цвет линий сетки 
     * @type {string}
     */
    get gridfill() {
        return this.echarts.getOption().xAxis[0].splitLine.lineStyle.color;
    }
    set gridfill(value) {
        const opt = { xAxis: { splitLine: { lineStyle: { color: value } } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
        const ds = this.tagName == 'MS-TRENDDS';
        if (!ds) {
            this.pens.forEach(pen => {
                pen.yAxis.splitLine.lineStyle.color = value;
            });
            this.echarts.setOption({ yAxis: this.pens.yaxises });
            this.cacheOptions['yAxis'] = this.pens.yaxises;
        }
    }
    /**
    * Цвет текста (титул, подписи оси Х)
    * @type {string}
    */
    get textcolor() {
        return this.echarts.getOption().title[0].textStyle.color;
    }
    set textcolor(value) {
        const opt1 = { title: { textStyle: { color: value } } };
        const opt2 = { xAxis: { axisLabel: { color: value } } };
        const opt3 = { xAxis: { nameTextStyle: { color: value } } };
        this.echarts.setOption(opt1);
        this.echarts.setOption(opt2);
        this.echarts.setOption(opt3);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt1);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt2);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt3);
    }
    /**
    * Цвет курсора
    * @type {string}
    */
    get cursorcolor() {
        return this.echarts.getOption().xAxis[0].axisPointer.lineStyle.color;
    }
    set cursorcolor(value) {
        const opt = { xAxis: { axisPointer: { lineStyle: { color: value } } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Толщина курсора
     * @type {string}
     */
    get cursorthickness() {
        return this.echarts.getOption().xAxis[0].axisPointer.lineStyle.width;
    }
    set cursorthickness(value) {
        const opt = { xAxis: { axisPointer: { lineStyle: { width: value } } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
    * Видимость курсора
    * @type {string}
    */
    get showcursor() {
        return this.echarts.getOption().xAxis[0].axisPointer.show;
    }
    set showcursor(value) {
        const opt = { xAxis: { axisPointer: { show: this._toBool(value) } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Верхний отступ делений X
     * @type {number}
     */
    get tickmargintopx() {
        return this.echarts.getOption().xAxis[0].axisLabel.padding;
    }
    set tickmargintopx(value) {
        const opt = { xAxis: { axisLabel: { padding: +value } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Правый отступ делений Y
     * @type {number}
     */
    get tickmarginrighty() {
        return this._tickmarginrighty || this.echarts.getOption().yAxis[0].axisLabel.padding;
    }
    set tickmarginrighty(value) {
        this._tickmarginrighty = value;
        this.pens.yaxises.forEach && this.pens.yaxises.forEach(aix => {
            aix.axisLabel.padding = +value
        });
        this.echarts.setOption({ yAxis: this.pens.yaxises });
        const opt = { yAxis: { axisLabel: { padding: +value } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Цвет оси X
     * @type {string}
     */
    get axiscolorx() {
        return this.echarts.getOption().xAxis[0].axisLine.lineStyle.color;
    }
    set axiscolorx(value) {
        const opt = { xAxis: { axisLine: { lineStyle: { color: value } } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Подпись X
     * @type {string}
     */
    get xaxislabel() {
        return this.echarts.getOption().xAxis[0].name;
    }
    set xaxislabel(value) {
        const opt = { xAxis: { name: value } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Формат значений X
     * @type {string}
     */
    get xformat() {
        return this._xformat;
    }
    set xformat(value) {
        this._xformat = value;
        const opt = { title: { text: this.title } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Подпись Y
     * @type {string}
     */
    get yaxislabel() {
        return this._yaxislabel || this.echarts.getOption().yAxis[0].name;
    }
    set yaxislabel(value) {
        this._yaxislabel = value;
        this.pens.yaxises.forEach && this.pens.yaxises.forEach(aix => {
            aix.name = value
        });
        const ds = this.tagName == 'MS-TRENDDS';
        if (!ds) {
            this.echarts.setOption({ yAxis: this.pens.yaxises });
        }
        const opt = { yAxis: { name: value } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Толщина оси X
     * @type {number}
     */
    get axisthicknessx() {
        return this.echarts.getOption().xAxis[0].axisLine.lineStyle.width;
    }
    set axisthicknessx(value) {
        const opt = { xAxis: { axisLine: { lineStyle: { width: +value } } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Толщина оси Y
     * @type {number}
     */
    get axisthicknessy() {
        return this._axisthicknessy || this.echarts.getOption().yAxis[0].axisLine.lineStyle.width;
    }
    set axisthicknessy(value) {
        this._axisthicknessy = value;
        this.pens.yaxises.forEach && this.pens.yaxises.forEach(aix => {
            aix.axisLine.lineStyle.width = +value
        });
        const ds = this.tagName == 'MS-TRENDDS';
        if (!ds) {
            this.echarts.setOption({ yAxis: this.pens.yaxises });
        }
        const opt = { yAxis: { axisLine: { lineStyle: { width: +value } } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Количество делений X
     * @type {number}
     */
    get tickcountx() {
        return this.echarts.getOption().xAxis[0].splitNumber;
    }
    set tickcountx(value) {
        const opt = { xAxis: { splitNumber: value } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
    * Количество делений Y
    * @type {number}
    */
    get tickcounty() {
        return this.echarts.getOption().yAxis[0].splitNumber;
    }
    set tickcounty(value) {
        const opt = { yAxis: { splitNumber: value } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Толщина делений X
     * @type {number}
     */
    get tickwidthx() {
        return this.echarts.getOption().xAxis[0].axisTick.lineStyle.width;
    }
    set tickwidthx(value) {
        const opt = { xAxis: { axisTick: { lineStyle: { width: value } } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Толщина делений Y
     * @type {number}
     */
    get tickwidthy() {
        return this._tickwidthy || this.echarts.getOption().yAxis[0].axisTick.length;
    }
    set tickwidthy(value) {
        this._tickwidthy = value;
        this.pens.yaxises.forEach && this.pens.yaxises.forEach(aix => {
            aix.axisTick.length = +value
        });
        this.echarts.setOption({ yAxis: this.pens.yaxises });
        const opt = { yAxis: { axisTick: { length: value } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Цвет делений X
     * @type {string}
     */
    get tickcolorx() {
        return this.echarts.getOption().xAxis[0].axisTick.lineStyle.color;
    }
    set tickcolorx(value) {
        const opt = { xAxis: { axisTick: { lineStyle: { color: value } } } }
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Цвет делений Y
     * @type {string}
     */
    get tickcolory() {
        return this._tickcolory || this.echarts.getOption().yAxis[0].axisTick.lineStyle.color;
    }
    set tickcolory(value) {
        this._tickcolory = value;
        this.pens.yaxises.forEach && this.pens.yaxises.forEach(aix => {
            aix.axisTick.lineStyle.color = value
        });
        const ds = this.tagName == 'MS-TRENDDS';
        if (!ds) {
            this.echarts.setOption({ yAxis: this.pens.yaxises });
        }
        const opt = { yAxis: { axisTick: { lineStyle: { color: value } } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Длина делений X
     * @type {number}
     */
    get tickheightx() {
        return this.echarts.getOption().xAxis[0].axisTick.length;
    }
    set tickheightx(value) {
        const opt = { xAxis: { axisTick: { length: value } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Длина делений Y
     * @type {number}
     */
    get tickheighty() {
        return this._tickheighty || this.echarts.getOption().yAxis[0].axisTick.lineStyle.width;
    }
    set tickheighty(value) {
        this._tickheighty = value;
        this.pens.yaxises.forEach && this.pens.yaxises.forEach(aix => {
            aix.axisTick.lineStyle.width = value
        });
        const ds = this.tagName == 'MS-TRENDDS';
        if (!ds) {
            this.echarts.setOption({ yAxis: this.pens.yaxises });
        }
        const opt = { yAxis: { axisTick: { lineStyle: { width: value } } } };
        this.echarts.setOption(opt);
        this.cacheOptions = mergeDeep(this.cacheOptions, opt);
    }
    /**
     * Отображать легенду
     * @type {boolean}
     */
    get showlegend() {
        return this._showlegend;
    }
    set showlegend(value) {
        this._showlegend = value;
        if (this._toBool(value)) {
            this.legend.style.display = '';
        }
        else {
            this.legend.style.display = 'none';
        }
    }
    /**
     * Минимальный вид
     * @type {boolean}
     */
    get lowresolutionmode() {
        return this._lowresolutionmode;
    }
    set lowresolutionmode(value) {
        this._lowresolutionmode = this._toBool(value);
        if (this._lowresolutionmode) {
            this.toolbar.isvisible = false;
            this._main.style.top = 0;
            this.echarts.setOption({ grid: { top: 30 } });
            this.echarts.setOption({ grid: { bottom: 20 } });
            this.echarts.setOption({ grid: { right: 20 } });
            this.cacheOptions = mergeDeep(this.cacheOptions, { grid: { top: 30 } });
            this.cacheOptions = mergeDeep(this.cacheOptions, { grid: { bottom: 20 } });
            this.cacheOptions = mergeDeep(this.cacheOptions, { grid: { right: 20 } });
            this.msydatazoom.isvisible = false;
            this.msdatazoom.isvisible = false;
            this.echarts.resize({
                width: this.attributes.width.value,
                height: this.attributes.height.value
            });
        } else {
            this.toolbar.isvisible = true;
            this._main.style.top = 30;
            this.echarts.setOption({ grid: { top: 30 } });
            this.echarts.setOption({ grid: { bottom: 50 } });
            this.echarts.setOption({ grid: { right: 50 } });
            this.cacheOptions = mergeDeep(this.cacheOptions, { grid: { top: 30 } });
            this.cacheOptions = mergeDeep(this.cacheOptions, { grid: { bottom: 50 } });
            this.cacheOptions = mergeDeep(this.cacheOptions, { grid: { right: 50 } });

            this.msydatazoom.isvisible = true;
            if (this.hasArchive !== false)
                this.msdatazoom.isvisible = true;
            this.echarts.resize({
                width: this.attributes.width.value,
                height: this.attributes.height.value - 30
            });
        }
    }
    /**
     * Печать минилегенды
     * @type {boolean}
     */
    get printminilegend() {
        return this._printminilegend;
    }
    set printminilegend(value) {
        this._printminilegend = value;
    }
    /**
     * Ширина минилегенды
     * @type {number}
     */
    get legendwidth() {
        return this.legend.width;
    }
    set legendwidth(value) {
        this.legend.width = value;
    }

    get legendopacity() {
        return this.legend.legendopacity;
    }
    set legendopacity(value) {
        this.legend.legendopacity = value;
    }

    /**
     * Сделать перо текущим
     * @param {any} index номер пера в массиве
     */
    selectPen(index) {
        this.legend.onSelect(index);
    }
    /**
     * Создать оси при инициализации
     * */
    createYAxisesOption() {
        if (this.attributes.data.value === "") {
            this.pens.yaxises = {};
            return;
        } else {
            this.pens.yaxises = [];
        }
        try {
            const pens = JSON.parse(this.attributes.data.value);
            let index = 0;
            for (let penname in pens) {
                this.pens.yaxises.push(this.pens[index].yAxis);
                this.pens.yaxises[index].splitLine.lineStyle.color = this.attributes.gridfill.value;
                this.pens.yaxises[index].axisLine.lineStyle.width = +this.attributes.axisthicknessy.value;
                this.pens.yaxises[index].axisTick.lineStyle.width = +this.attributes.tickheighty.value;
                this.pens.yaxises[index].axisTick.lineStyle.color = this.attributes.tickcolory.value;
                this.pens.yaxises[index].axisTick.lineStyle.length = +this.attributes.tickwidthy.value;
                this.pens.yaxises[index].nameTextStyle.color = this.attributes.textcolor.value;
                index++;
            }
        } catch (e) { }
    }


    /**
     * Генерация массива значений для экспорта или табличного представления
     *
     * @returns массив значений
     * @memberof Trendbase
     */
    _generateArrayForTable() {
        let iterators = this.pens.map(x => {
            let it = x.serie.data.values();
            return { it, val: it.next() };
        });
        let notTheEnd = true;
        let resultTable = [["Время", ...this.pens.map(x => x.serie.name)]];
        while (notTheEnd) {
            let lastLine = new Array(resultTable[0].length).fill('-');
            let min = iterators.reduce((min, x) => {
                if (!x.val.done) {
                    return min === undefined ? x.val.value[0] : Math.min(x.val.value[0], min);
                }
            }, undefined);
            // Все пустые!
            if (min === undefined) {
                break;
            }
            lastLine[0] = String.format(this.xformat, new Date(min)); //присваиваем время
            notTheEnd = false;
            iterators.forEach((x, idx, arr) => {
                if (!x.val.done && x.val.value[0] == min) {
                    let text = String.format(this.pens[idx]._yformat, x.val.value[1]);
                    lastLine[idx + 1] = text;
                    x.val = { old: text, ...x.it.next() };
                    notTheEnd = true;
                } else {
                    if (x.val.old !== undefined) {
                        lastLine[idx + 1] = x.val.old;
                    }
                }
            });
            resultTable.push(lastLine);
        }
        return resultTable;
    }
    /**
    * Метод возврата к проектному состоянию
    */
    ClearOptions() {
        this.originPath = this.getOriginPath();
        const storedState = $ss.getItemState(this.originPath);
        if (!storedState) return;
        if (Object.keys(storedState).length === 0) return;
        // if (!this.sources) return;
        this._penStates = undefined;
        this.saveItemState({ penStates: undefined });
        this.saveItemState({ intervalState: undefined });
        this.saveItemState({ curentPenState: undefined });
        if (this.sources && this.sources.length > 0) {
            this.sources.forEach((pen) => {
                this.removePen({ PenName: pen });
            });
        }
        this.legend.clear();
        this.sources = undefined;
        this.currentPen = undefined;
        this.echarts.clear();
        // createSeriesOption
        this.createSeriesOption();
        this.createYAxisesOption();
        this.createBasePensOptions();
        this.legend.init();
        this.echarts.setOption(this.cacheOptions);
        this.createDataZoom();
        this.initTrendOption();

        for (let index = 0; index < this._cacheDataSource.length; index++) {
            const element = this._cacheDataSource[index];
            this.addDataSource(element.link, element.path);
        }
    }
    /**
    * Метод Экспортировать данные в CSV
    */
    DownloadCsv() {

        const fileName = genetateFileName('trend') + ".csv";
        if ($pm.hasPermissions) {
            const options = {
                cancel: () => { },
                customText: window.savePath ? `${this.elname} Экспорт данных ${window.savePath}${fileName}` : `${this.elname} Экспорт данных`
            };
            $pm.resolveControl(this, "TrendSave", this._DownloadCsv.bind(this, fileName), options);
        }
        else
            this._DownloadCsv(fileName);

    }

    _DownloadCsv(fileName) {
        const resultTable = this._generateArrayForTable();
        let res = '';
        for (const iterator of resultTable) {
            res += `${iterator.join(';')}\n`;
        }
        exportTextfile(res, fileName, true);
    }
    /**
    * Метод Экспортировать данные
    */
    Export() {
        if (!this.table) {
            const resultTable = this._generateArrayForTable();
            var table = '<table style="width: 100%;text-align:center;">';
            table = resultTable.reduce((acc, val) => acc + "<tr><td>" + val.join('</td><td>') + "</td></tr>", table);
            table += '</table>';
            let div = document.createElement('div');
            div.id = "table";
            div.style.position = 'absolute';
            div.style.top = 0;
            div.style.backgroundColor = 'white';
            div.style.height = this.attributes.height.value - 30;
            div.style.overflowY = 'auto';
            div.innerHTML = table;
            div.style.zIndex = 3;
            this.table = div;
            this._main.appendChild(this.table);
        } else {
            this._main.removeChild(this.table);
            this.table = null;
        }
    }
    /**
     * Сотворить из полотна тренда картинку svg
     * @return {string} картинка
     * */
    getSvgDataUrl() {
        let parentNode = this.shadowRoot.querySelector("svg").parentNode.cloneNode(true);
        let svg = parentNode.querySelector('svg');
        let legend = this.legend.createSVG();
        legend.setAttribute("transform", `translate(0, ${svg.getAttribute("height")})`);
        svg.setAttribute("height", +svg.getAttribute("height") + this.pens.length * 20);
        svg.appendChild(legend);
        return `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(parentNode.innerHTML)))}`;
    }
    /**
     * Метод Сохранить изображение
     */
    SaveImageAs() {
        const fileName = genetateFileName('trend') + ".png";
        if ($pm.hasPermissions) {
            const options = {
                cancel: () => { },
                customText: window.savePath ? `${this.elname} Экспорт графика ${window.savePath}${fileName}` : `${this.elname} Экспорт графика`
            };
            $pm.resolveControl(this, "TrendSave", this.saveImageAs.bind(this, fileName), options);
        }
        else
            this.saveImageAs(fileName);
    }
    /**
     * Внутренний метод сохрания изображения
     * */
    saveImageAs(fileName) {
        const svg = this.shadowRoot.querySelector("svg");
        let h = svg.clientHeight * 2;
        if (this.printminilegend)
            h += this.pens.length * 20;
        const w = svg.clientWidth * 2;
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const context = canvas.getContext("2d");
        context.fillStyle = "#fff";
        context.fillRect(0, 0, w, h);

        const dataUrl = this.getSvgDataUrl();

        const image = new Image(w, h);
        image.src = dataUrl;
        image.onload = () => {
            context.drawImage(image, 0, 0, w, h);
            if (window.eFs && window.savePath) {
                const url = canvas.toDataURL("image/png");
                window.eFs.get().writeFile(`${window.savePath}${fileName}`, url, 'base64', (err) => {
                    if (err) {
                        $ns.add({ type: 'error', time: new Date().toLocaleString(), title: 'write file error', text: `cannot write file: ${window.savePath}${name}` });
                    }
                });
            } else {
                const link = document.createElement('a');
                link.download = fileName;
                //link.href = this.echarts.getDataURL({ pixelRatio: 2, backgroundColor: '#fff' }).replace("image/png", "image/octet-stream");
                link.href = canvas.toDataURL("image/png");
                link.click();
            }
        };
    }
    /**
     * Метод Печать
     */
    Print() {
        if ($pm.hasPermissions) {
            const options = {
                cancel: () => { },
                customText: window.clientPrinter ? `${this.elname} Печать графика на принтер ${window.PrinterName}` : `${this.elname} Печать графика`
            };
            $pm.resolveControl(this, "TrendPrint", this.print.bind(this), options);
        }
        else
            this.print();
    }
    /**
     * Внутренний метод печати
     * */
    print() {
        const dataUrl = this.getSvgDataUrl();
        let windowContent = `<!DOCTYPE html>
                                <style>@media print { @page {size: A4 landscape; } img { height: 90%; margin: 0; padding: 0; } };  
                                </style>
                                <html>
                                    <head><title>Печать тренда</title>
                                    </head>
                                <body>
                                <img src="${dataUrl}">
                                </body>
                                </html>`;
        if (window.ipc && window.clientPrinter) {
            window.ipc.get().send('server', 'print', `data:text/html;charset=utf8,${windowContent}`);
        } else {
            this._iframe = document.createElement('iframe');
            this._iframe.onload = () => {
                let printDocument = this._iframe.contentWindow || this._iframe.contentDocument;
                if (printDocument.document) printDocument = printDocument.document;

                requestAnimationFrame(() => {
                    this._iframe.focus();
                    this._iframe.contentWindow.print();
                    this._iframe.remove();
                    this._iframe = null;
                });
            };
            this._iframe.srcdoc = windowContent;
            document.body.appendChild(this._iframe);
        }
    }
    /**
     * Создать область границы
     * @param {number} max максимум границы
     * @param {object} penlimit данные границы
     * @return {object} граница в формате echarts
     */
    createMarkArea(max, penlimit) {
        return [
            {
                yAxis: max
            }, {
                name: '',
                yAxis: +penlimit.datasource,
                itemStyle: {
                    color: penlimit.backgroundcolor,
                    opacity: 0.2
                }
            }
        ];
    }
    /**
     * Создать линию границы
     * @param {object} penlimit данные границы
     * @return {object} граница в формате echarts
     */
    createMarkLine(penlimit) {
        return {
            yAxis: +penlimit.datasource,
            lineStyle: {
                color: penlimit.color,
                width: +penlimit.thickness
            }
        };
    }
    /**
     * Нарисовать 4 границы
     * @param {object} penlimits данные о границах
     */
    createMarkAreaOption(penlimits) {
        let markarea = [];
        let markline = [];
        // выход если границы отсутствуют
        if (typeof penlimits !== 'undefined') {
            if (penlimits["hihi"] && penlimits["hihi"].isvisible) {
                markarea.push(this.createMarkArea(penlimits.max, penlimits["hihi"]));
                markline.push(this.createMarkLine(penlimits["hihi"]));
            }
            if (penlimits["hi"] && penlimits["hi"].isvisible) {
                markarea.push(this.createMarkArea(penlimits["hihi"] ? penlimits["hihi"].datasource : penlimits.max, penlimits["hi"]));
                markline.push(this.createMarkLine(penlimits["hi"]));
            }
            if (penlimits["lo"] && penlimits["lo"].isvisible) {
                markarea.push(this.createMarkArea(penlimits["lolo"] ? penlimits["lolo"].datasource : penlimits.min, penlimits["lo"]));
                markline.push(this.createMarkLine(penlimits["lo"]));
            }
            if (penlimits["lolo"] && penlimits["lolo"].isvisible) {
                markarea.push(this.createMarkArea(penlimits.min, penlimits["lolo"]));
                markline.push(this.createMarkLine(penlimits["lolo"]));
            }
        }
        this.applyMark(markarea, markline);
    }
}