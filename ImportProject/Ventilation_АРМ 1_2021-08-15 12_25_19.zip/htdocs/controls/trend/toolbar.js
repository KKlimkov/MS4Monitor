﻿import { Basic } from "../basic.js";
/**
 * @class MSToolbar
 * @extends Basic
 * @classdesc Панель инструментов
 * */
export class MSToolbar extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'buttons'
        ]);
    }
    constructor() {
        super();
        this.elements = {};
        this.shRoot = this.attachShadow({ mode: 'open' });
        this.shRoot.innerHTML = '<style>@import "controls/trend/trend.css";</style><div id="toolbar" style="border-width: 0px; width: 100%; height: 30px; display: flex; align-items: center;"></div>';
        this._main = this.shRoot.querySelector('#toolbar');
        this.style.borderWidth = 0;
        this.shRoot.addEventListener('mouseover', this.toolTipShow);
        this.shRoot.addEventListener('mouseout', this.toolTipHide);
    }
    /**
     * Кнопки
     * @type {string}
     */
    get buttons() {
        return this._buttons;
    }
    set buttons(value) {
        this._buttons = JSON.parse(value);
        this._buttons.forEach(element => {
            switch (element.type) {
                case 'button':
                    this.addButton(element.method, element.class, element.tooltip);
                    break;
                case 'toggle':
                    this.addToggle(element.method, element.class, element.tooltip);
                    break;
                case 'expander':
                    this.addExpander();
                    break;
            }
        });
    }
    /**
     * Позиция тулбара (задел на будущее)
     * @type {enum}
     */
    get position() {

    }
    set position(value) {

    }
    set height(value) {
        super.height = value;
        this._main.style.height = this._setValueUnit(value);
        this.style.minHeight = this._setValueUnit(value);
        this.style.maxHeight = this._setValueUnit(value);
    }
    /**
     * Контекст панели инструментов (Тренд)
     * @type {HTMLElement} 
     */
    get context() {
        return this._context;
    }
    set context(value) {
        this._context = value;
        for (let button in this.elements) {
            if (this._context[button])
                this.elements[button].onclick = this._context[button].bind(this._context);
        }
    }
    /**
     * Добавить кнопку в панель инструментов
     * @param {string} methodname название функции для вызова по клику на кнопку
     * @param {string} classname имя класса (символ) кнопки
     * @param {string} tooltip всплывающая подсказка
     */
    addButton(methodname, classname, tooltip) {
        const button = document.createElement('div');
        button.dataset.tooltip = tooltip;
        button.style.width = 30;
        button.style.height = 30;
        button.className = classname;
        button.classList.add("btn");
        this._main.appendChild(button);
        this.elements[methodname] = button;
    }
    /**
     * Добавить кнопку-переключатель в панель инструментов
     * @param {string} methodname название функции для вызова по клику на кнопку
     * @param {Array} classname 2 имени класса (символа) для каждого состояния кнопки
     * @param {Array} tooltip 2 всплывающые подсказки для каждого состояния кнопки
     */
    addToggle(methodname, classname, tooltip) {
        const button = document.createElement('div');
        button.classnames = classname;
        button.tooltips = tooltip;
        button.classList.add("btn");
        button.dataset.tooltip = tooltip[0];
        button.style.width = 30;
        button.style.height = 30;
        button.classList.add(classname[0]);
        this._main.appendChild(button);
        this.elements[methodname] = button;
    }
    /**
     * Задать состояние для кнопки-переключателя
     * @param {HTMLElement} button кнопка для задания состояния
     * @param {boolean} state состояние (вкл/выкл)
     */
    setToggleState(button, state) {
        if (!state) {
            button.classList.remove('active');
            button.classList.remove(button.classnames[1]);
            button.classList.add(button.classnames[0]);
            button.setAttribute('tooltip', button.tooltips[0]);
        } else {
            button.classList.add('active');
            button.classList.remove(button.classnames[0]);
            button.classList.add(button.classnames[1]);
            button.setAttribute('tooltip', button.tooltips[1]);
        }
    }
    /**
     * Задать видимость кнопки
     * @param {HTMLElement} button кнопка
     * @param {boolean} state видимость
     */
    setVisible(button, state) {
        if (!state) {
            button.style.display = 'none';
        } else {
            button.style.display = '';
        }
    }
    /**
     * Задать активность кнопки
     * @param {HTMLElement} button кнопка
     * @param {boolean} state активность
     */
    setEnable(button, state) {
        if (!state) {
            button.classList.add('disable');
        } else {
            button.classList.remove('disable');
        }
    }
    /**
     * Добавить разделитель
     * */
    addExpander() {
        const exp = document.createElement('div');
        exp.style.flex = '1';
        this._main.appendChild(exp);
    }

    toolTipShow(event) {
        const target = event.target;
        const tooltipHtml = target.dataset.tooltip;
        if (!tooltipHtml) return;

        this.tooltipElem = document.createElement('div');
        this.tooltipElem.className = 'tooltip';
        this.tooltipElem.innerHTML = tooltipHtml;
        document.body.append(this.tooltipElem);

        let coords = target.getBoundingClientRect();

        let left = coords.left + (coords.width - this.tooltipElem.offsetWidth) / 2;
        if (left < 0) left = 0;

        let top = coords.top - this.tooltipElem.offsetHeight - 5;
        if (top < 0) {
            top = coords.bottom + 5;
        }

        this.tooltipElem.style.left = left + 'px';
        this.tooltipElem.style.top = top + 'px';
    }
    toolTipHide() {
        if (this.tooltipElem) {
            this.tooltipElem.remove();
            this.tooltipElem = null;
        }
    }
    disconnectedCallback() {
        for (let button in this.elements) {
            if (this._context[button])
                this.elements[button].onclick = null
        }
        delete this._context;
        this.shRoot.removeEventListener('mouseover', this.toolTipShow);
        this.shRoot.removeEventListener('mouseout', this.toolTipHide);
    }
}