﻿/**
 * @class Pen
 * @classdesc Перо
 * */
export class Pen {
    constructor(pen, renderItem) {
        if (typeof renderItem === 'function') {
            this.serie = {
                name: pen.name,
                type: 'custom',
                renderItem: renderItem,
                itemStyle: {
                    normal: {
                        show: true,
                        color: pen.color
                    },
                    emphasis: {
                        show: true,
                        symbolSize: 1
                    }
                },
                lineStyle: {
                    normal: {},
                    emphasis: {}
                },
                data: []
            };
            this.yformat = pen.yformat;
            this.penlimits = pen.penlimits;
            this.yAxis = {
                type: 'value',
                position: 'left',
                splitLine: {
                    lineStyle: {}
                },
                axisTick: {
                    lineStyle: {}
                },
                nameTextStyle: {},
                splitNumber: +pen.tickcounty,
                axisLine: {
                    lineStyle: {
                        color: pen.color
                    }
                },
                axisLabel: {
                    padding: 0//+this.attributes.tickmarginright
                }
            };
            this._maxy = pen.maxy;
            this._miny = pen.miny;
            this.autoscale = pen.autoscale;
            this.unit = pen.unit;
            this._isvisible = pen.isvisible;
            this.thickness = pen.thickness;
            this.linestyle = pen.linestyle;
            this._showaxis = pen.showaxis;
            this.color = pen.color;
            this._drawconstant = pen.drawconstant;
        } else if (!pen.basic) {
            this.serie = {
                name: pen.name,
                type: 'line',
                showSymbol: true,
                yAxisIndex: pen.index,
                itemStyle: {
                    normal: {
                        show: true,
                        color: pen.color
                    },
                    emphasis: {
                        show: true,
                        symbolSize: 1
                    }
                },
                lineStyle: {
                    normal: {},
                    emphasis: {}
                },
                symbol: window._enums.PointType[pen.pointtype],
                symbolSize: pen.pointsize,
                step: +pen.linejoin ? "end" : false,
                data: []
            };
            this.yformat = pen.yformat;
            this.penlimits = pen.penlimits;
            this.yAxis = {
                type: 'value',
                position: 'left',
                splitLine: {
                    lineStyle: {}
                },
                axisTick: {
                    lineStyle: {}
                },
                nameTextStyle: {},
                splitNumber: +pen.tickcounty,
                axisLine: {
                    lineStyle: {
                        color: pen.color
                    }
                },
                axisLabel: {
                    padding: 0//+this.attributes.tickmarginright
                }
            };
            this._maxy = pen.maxy;
            this._miny = pen.miny;
            this.autoscale = pen.autoscale;
            this.unit = pen.unit;
            this._isvisible = pen.isvisible;
            this.thickness = pen.thickness;
            this.linestyle = pen.linestyle;
            this._showaxis = pen.showaxis;
            this.color = pen.color;
            this._drawconstant = pen.drawconstant;
        }
        else {
            this.serie = {
                name: pen.name,
                type: 'line',
                yAxisIndex: pen.index,
                data: [],
                symbol: "none",
                symbolSize: 0,
                showSymbol: true,
                itemStyle: {
                    normal: {
                        show: true,
                        color: pen.color
                    },
                    emphasis: {}
                },
                lineStyle: {
                    normal: {
                        show: true,
                        color: pen.color,
                        type: 'solid'
                    },
                    emphasis: {}
                }
            };
            this.yformat = "f3";
            this.unit = "";
            this.yAxis = {
                type: 'value',
                position: 'left',
                show: true,
                axisLine: {
                    lineStyle: {
                        color: pen.color
                    }
                }
            };
            this._maxy = 100;
            this._miny = 0;
            this.autoscale = false;
            this._showaxis = true;
            this._isvisible = true;
            this.thickness = 1;
            this._drawconstant = true;
        }
        this.name = pen.name;
        this.idx = pen.index;
    }
    /**
     * Цвет пера
     * @type {string} 
     */
    get color() {
        return this.serie.lineStyle.normal.color;
    }
    set color(value) {
        this.serie.lineStyle.normal.color = value;
        this.serie.lineStyle.emphasis.color = value;
        this.serie.itemStyle.normal.color = value;
        this.yAxis.axisLine.lineStyle.color = value;
        if (this.selected) {
            this.shadow();
        }
        if (this.minilegend)
            this.minilegend.setColor(this.idx, value);
    }
    /**
     * Минимум
     * @type {string} 
     */
    get miny() {
        return this.yAxis.min;
    }
    set miny(value) {
        this._miny = value;
        this.broadcast();
        this.yAxis.min = this._miny;
        if (!this.autoscale) {
            if (this.penlimits)
                this.penlimits.min = this._miny;
            this.updateSeriesAxises();
            if (this.selected)
                this.createMarkAreaOption(this.penlimits);
            this.msydatazoom.min = this._miny;
            if (this.msydatazoom.minvalue < this._miny) this.msydatazoom.minvalue = this._miny;
            this._mindecimal = this.getDecimals(this._miny);
            this.msydatazoom.precision = Math.max(this._mindecimal, this._maxdecimal);
            this.msydatazoom.incrementstep = 1 / Math.pow(10, this.msydatazoom.precision);
            this.msydatazoom.format = `f${this.msydatazoom.precision}`;
        }
    }
    /**
     * Максимум
     * @type {string} 
     */
    get maxy() {
        return this.yAxis.max;
    }
    set maxy(value) {
        this._maxy = value;
        this.broadcast();
        this.yAxis.max = this._maxy;
        if (!this.autoscale) {
            if (this.penlimits)
                this.penlimits.max = this._maxy;
            this.updateSeriesAxises();
            if (this.selected)
                this.createMarkAreaOption(this.penlimits);
            this._maxdecimal = this.getDecimals(this._maxy);
            this.msydatazoom.precision = Math.max(this._mindecimal, this._maxdecimal);
            this.msydatazoom.incrementstep = 1 / Math.pow(10, this.msydatazoom.precision);
            this.msydatazoom.format = `f${this.msydatazoom.precision}`;
            this.msydatazoom.max = this._maxy;
            if (this.msydatazoom.maxvalue > this._maxy) this.msydatazoom.maxvalue = this._maxy;
        }
    }
    /**
     * Посчитать число знаков после запятой
     * @param {number} value значение для анализа
     * @return {number} число знаков после запятой
     */
    getDecimals(value) {
        const stringval = value ? value.toString() : '';
        const pos = stringval.indexOf('.');
        if (pos === -1)
            return 0;
        else
            return stringval.length - 1 - pos;
    }
    /**
     * Видимость пера
     * @type {bool} 
     */
    get isvisible() {
        return this._isvisible;
    }
    set isvisible(value) {
        this._isvisible = value;
        if (this.pens) {
            this.pens.offsets = [];
            let offset = 0;
            for (let i = 0; i < this.pens.length; i++) {
                const element = this.pens[i];
                if (!element.isvisible) {
                    offset++;
                }
                this.pens.offsets[i] = i - offset;
            }
        }
        this.minilegend.setIsVisible(this.idx, value);
        this.broadcast();
        this.updateYAxisesOffset();
    }
    /**
     * Дорисовка константы
     * @type {bool} 
     */
    get drawconstant() {
        return this._drawconstant;
    }
    set drawconstant(value) {
        this._drawconstant = value;
        if (!this._drawconstant) { //дорисовка отключилась - надо убрать за собой
            this.serie.data = this.serie.data.filter(o => {
                return !o[3];
            });
        }
    }
    /**
     * Является ли перо текущим
     * @type {bool} 
     */
    get selected() {
        return this._selected;
    }
    set selected(value) {
        this._selected = value;
        if (value) {
            this.shadow();
        } else {
            this.unShadow();
        }
        this.broadcast();
        this.updateYAxisesOffset();
    }
    /**
     * Тип графика
     * Линия или ступенька
     * @type {enum} 
     */
    get linejoin() {
        return !!this.serie.step;
    }
    set linejoin(value) {
        this.serie.step = value ? "end" : false;
    }
    /**
     * Стиль линии
     * @type {BorderStyleType}
     */
    get linestyle() {
        return this.serie.lineStyle.normal.type;
    }
    set linestyle(value) {
        let newstyle = window._enums.PenStyleType[value];
        if (newstyle !== 'none') {
            this.serie.lineStyle.normal.type = window._enums.PenStyleType[value];
            this.serie.lineStyle.normal.opacity = 1.0;
        }
        else
            this.serie.lineStyle.normal.opacity = 0.0;
    }
    /**
     * Автомасштабирование
     * @type {bool} 
     */
    get autoscale() {
        return this._autoscale;
    }
    set autoscale(value) {
        this._autoscale = value;
        if (value) {
            this.yAxis.min = null;
            this.yAxis.max = null;
            this.yAxis.scale = true;
        } else {
            this.yAxis.min = this._miny;
            this.yAxis.max = this._maxy;
            this.yAxis.scale = false;
        }
    }
    /**
     * Единицы измерения
     * @type {string} 
     */
    get unit() {
        return this._unit;
    }
    set unit(value) {
        this._unit = value;
    }
    /**
     * Толщина линии
     * @type {number} 
     */
    get thickness() {
        return this._thickness;
    }
    set thickness(value) {
        this._thickness = value;
        this.serie.lineStyle.normal.width = value;
        this.serie.lineStyle.emphasis.width = value;
    }
    /**
     * Тип точек
     * @type {PointType} 
     */
    get pointtype() {
        return this.serie.symbol;
    }
    set pointtype(value) {
        this.serie.symbol = typeof value === 'string' ? value : window._enums.PointType[value];
    }
    /**
     * Размер точек
     * @type {number} 
     */
    get pointsize() {
        return this._pointsize || this.serie.symbolSize;
    }
    set pointsize(value) {
        this._pointsize = value;
        this.serie.symbolSize = value;
    }
    /**
     * Формат значений Y
     * @type {string} 
     */
    get yformat() {
        return this._yformat;
    }
    set yformat(value) {
        this._yformat = value;
    }
    /**
     * Отображать ось значений
     * @type {boolean} 
     */
    get showaxis() {
        return this._showaxis;
    }
    set showaxis(value) {
        this._showaxis = value;
        this.updateYAxisesOffset();
        this.updateSeriesAxises();
    }
    /**
     * Количество делений Y
     * @type {number} 
     */
    get tickcounty() {
        return this.yAxis.splitNumber;
    }
    set tickcounty(value) {
        this.yAxis.splitNumber = value;
    }
    /**
     * Выделить текущее перо
     * */
    shadow() {
        this.serie.lineStyle.normal.width = this.thickness + 2;
        if (this.pointsize) //ненулевой размер точки
            this.serie.symbolSize = this.pointsize + 2;
    }
    /**
     * Сбросить выделение текущего пера
     * */
    unShadow() {
        this.serie.lineStyle.normal.width = this.thickness;
        this.serie.symbolSize = this.pointsize;
    }

    destroy() {
        if (this.sampler) {
            this.sampler.destroy();
            delete this.sampler;
        }
        delete this.broadcast;
        delete this._echarts;
    }
}