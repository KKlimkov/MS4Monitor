import { MSPopUpWindow } from '../popup_window/popup_window.js';
import { MSDataTree } from '../tree/tree.js';
/**
 * @class ObjectTree
 * @classdesc Дерево для выбора перьев в Тренде или объектов в Журнале
 * */
export class ObjectTree {
    constructor(sel = [], type) {
        if (typeof window.customElements.get('ms-tree') === 'undefined') {
            window.customElements.define('ms-tree', MSDataTree);
        }
        this._selected = sel;
        this._type = type;
    }

    CreateWin(title) {
        this.popup = new MSPopUpWindow();
        this.popup.dragable = true;
        this.popup.modal = false;
        this.popup.title = title ? `Выбора перьев - ${title}` : this._type ? 'Выбор объектов' : 'Выбор перьев';
        this.popup.height = this.Height;
        if (this.Width) this.popup.width = this.Width;
        this.popup.minimized = false;
        this.popup.mini = false;
        this.popup.closable = true;
        this.popup.resize = false;
        this.popup.boundsrestricted = true;
        this.popup.sizetocontent = 0;
        this.popup.offsetx = 0;
        this.popup.offsety = 0;
        this.popup.isenabled = true;
        this.popup.isvisible = false;
        if (!this.Width) this.popup.maxwidth = window.innerWidth - 20;
        if (this._type) {
            this.popup.innerHTML = `<ms-tree idfield="ID" autoselect="false" horizontalalign="1" verticalalign="1" sourcetype="1" multiselect="true" expanded="true" displayfield="Name" proportiontype="4" style="box-sizing: border-box; display: flex; overflow: hidden; position: relative; z-index: 2; width: 100%; height: 480px; background-color: rgb(245, 240, 245);"></ms-tree><div><button style="width: 50%;height: 2em;" class="ms update">Применить</button><button style="width: 50%;height: 2em;" class="ms close">Отмена</button></div>`
        } else {
            this.popup.innerHTML = `<ms-tree filter='{"IsArchived":true}' idfield="ItemPath" horizontalalign="1" verticalalign="1" sourcetype="0" multiselect="true" expanded="true" displayfield="Name" proportiontype="4" style="box-sizing: border-box; display: flex; overflow: hidden; position: relative; z-index: 2; width: 100%; height: 480px; background-color: rgb(245, 240, 245);"></ms-tree><div><button style="width: 50%;height: 2em;" class="ms update">Применить</button><button style="width: 50%;height: 2em;" class="ms close">Отмена</button></div>`
        }
        this.tree = this.popup.querySelector('ms-tree');
        if (this.filter) this.tree.filtercallback = this.filter;
        this.tree.rootitem = this.rootitem;

        this.popup.querySelector('.update').onclick = e => {
            this._selected = this.tree.values;
            this.popup.close();
            this._callback(this.selected);
        };

        this.popup.querySelector('.close').onclick = e => {
            this.popup.close();
        };

        $WinService.addWindow(this.popup);
    }

    Open(title) {
        if (!this.popup || !this.popup.isConnected) {
            this.popup = null;
            this.CreateWin(title);
        }
        this.tree.values = this._selected;
        this.popup.isvisible = true;
        this.popup._upWindow();
    }

    get onUpdate() {
        value = this._callback;
    }
    set onUpdate(value) {
        this._callback = value;
    }


    get selected() {
        return this._selected;
    }
    set selected(value) {
        this._selected = value;
    }

    get rootitem() {
        return this._rootitem;
    }
    set rootitem(v) {
        this._rootitem = v;
    }
    /**
    * Тренд
    * @type {string}
    */
    get trend() {
        return this._trend;
    }
    set trend(value) {
        this._trend = value;
        if (typeof value !== 'object') {
            let ms = this.parentElement;
            while (ms.nodeName !== 'MS-WINDOW') {
                ms = ms.parentElement;
            }
            if (value) {
                if (this._trendControl) this._trendControl.removeObserver(this.__reciver);

                this._trendControl = ms.querySelector(`[id="${value}"]`);

                this._trendControl.addObserver(this.__reciver);
            }
        } else {
            this._trendControl = value;
        }
    }

    dispose() {
        this.filter = null;
        this.tree =  null;
        $WinService.removeWindow(this.popup);
        this.popup = null;
    }
}