import { Basic } from "../basic.js";
import { DataTypes } from '../../generated/datatypes.js';
import { Converter } from "../../observer/converter.js";
/**
 * @class MSPanelStack
 * @extends Basic
 * @classdesc Стековая панель
 * */
export class MSPanelStack extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'orientation',
            'horizontalelementsalign',
            'verticalelementsalign',
            'paneldatasource',
            'tiled'
        ]);
    }
    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<slot></slot>`;
        this.style.display = 'flex';
        this.style.overflow = 'hidden';
        this.style.backgroundColor = "rgb(245,240,245)";
        this._child = [];
        this.orientation = 0;
        this.horizontalelementsalign = 3;
        this.verticalelementsalign = 3;
        this.keysDict = {};
        for (let index = 0; index < this.children.length; index++) {
            const element = this.children[index];
            element.style.position = element.tagName === 'MS-PCANVAS' ? 'relative' : 'static';
            element.style.display = 'flex';
            element.style.top = '';
            element.style.left = '';
            element.style.minWidth = parseInt(element.attributes.width ? element.attributes.width.value : 20) + 'px';
            this._child.push(element);
        };
    }

    afterInitialize() {
        if (this.inited)
            return;
        this.inited = true;
        if (typeof this.initDataString === "string" && typeof this._paneldatasource_dataType === "string") {
            let dataTypeObj = DataTypes.dataTypes[this._paneldatasource_dataType];
            if (typeof dataTypeObj !== 'undefined') {
                if (dataTypeObj.DataType == "ArrayType" && dataTypeObj.Subranges.length == 1) {
                    let elementType = DataTypes.dataTypes[dataTypeObj.TypeOfElementsName];
                    let acc = [], valObj = {};
                    try {
                        valObj = JSON.parse(this.initDataString);
                        if (elementType.DataType == 'StructureType') {
                            Object.keys(valObj).forEach(x => {
                                valObj[x] = Converter._convert(valObj[x], elementType.Fields[x]);
                            });
                        }
                    } catch (e) {
                        valObj = {};
                    }
                    for (let i = 0; i < dataTypeObj.Subranges[0]; i++) {
                        acc.push(valObj);
                    }
                    let resultValue = {
                        dataType: this._paneldatasource_dataType,
                        value: acc,
                    }
                    this.paneldatasource = resultValue;
                }
            }
        }
    }

    get orientation() {
        return this._orientation || 0;
    }
    set orientation(value) {
        this._orientation = value;
        this.style.flexDirection = _enums.OrientationType[value];
        this._calcOverflow();
    }

    _calcOverflow() {
        if (this._tiled) {
            this.style.overflow = 'auto';
            return;
        }
        switch (this.style.flexDirection) {
            case _enums.OrientationType.Vertical:
                this.style.overflowX = 'hidden';
                this.style.overflowY = 'auto';
                break;
            case _enums.OrientationType.Horizontal:
                this.style.overflowX = 'auto';
                this.style.overflowY = 'hidden';
                break;
            default:
                this.style.overflowX = 'hidden';
                this.style.overflowY = 'hidden';
                break
        }
    }

    get horizontalelementsalign() {
        return this._horizontalelementsalign;
    }
    set horizontalelementsalign(value) {
        this._horizontalelementsalign = value;
        const resH = _enums.HorizontalAlignTypeExt[this._horizontalelementsalign];
        this._orientation == 1 ?
            this.style.justifyContent = resH :
            this.style.alignItems = resH;
        this.calcAlign();
    }

    get verticalelementsalign() {
        return this._verticalelementsalign;
    }
    set verticalelementsalign(value) {
        this._verticalelementsalign = value;
        const resV = _enums.VerticalAlignTypeExt[this._verticalelementsalign];
        this._orientation == 1 ?
            this.style.justifyContent = resV :
            this.style.alignItems = resV;
        this.calcAlign();
    }

    get tiled() {
        return this._tiled;
    }
    set tiled(value) {
        this._tiled = this._toBool(value);
        if (this._tiled) {
            this.style.flexWrap = 'wrap';
            this.style.justifyContent = 'flex-start';
            this.style.alignContent = 'flex-start';
        } else {
            this.style.flexWrap = '';
            this.style.justifyContent = '';
            this.style.alignContent = '';
        }

        this._calcOverflow();
    }

    calcAlign() {
        if (!this.children.length) return;
        const resH = _enums.HorizontalAlignTypeExt[this._horizontalelementsalign];
        const resV = _enums.VerticalAlignTypeExt[this._verticalelementsalign];

        if (resV) {
            [...this.children].forEach((child) => {
                if (this._orientation == 0) {
                    child.style.flexBasis = (resV == 3) ? '100%' : '';
                    //resV == 3 && (child.style.minHeight = '100%');
                } else {
                    child.style.flexBasis = '';
                }
            });
        }

        if (resH) {
            [...this.children].forEach((child) => {
                if (this._orientation == 1) {
                    //resH == 3 && (child.style.minWidth = '100%');
                    child.style.flexGrow = (resH == 3) ? '1' : '';
                } else {
                    child.style.flexGrow = 0;
                }
            });
        }
    }

    get paneldatasource() {
        return this._paneldatasource;
    }
    set paneldatasource(value) {
        if (typeof value == 'object') {
                this._paneldatasource_dataType = DataTypes.dataTypes[value.dataType];
                this._paneldatasource_typeOfElement =
                    DataTypes.dataTypes[this._paneldatasource_dataType.TypeOfElementsName];
                this._paneldatasource_data = JSON.parse(JSON.stringify(value.value));
                this._paneldatasource = value;
                this._createContent();
                this.calcAlign();
        } else if (typeof value == 'string' && value != "") {
            this.initDataString = value;
        }
    }

    _createContent() {
        const offset = this._child.length;
        const t = this.children.length / offset;
        const dLen = this._paneldatasource_data.length;

        for (let i = 0; i < this._child.length; i++) {
            this._resetStyle(this._child[i]);
            if (typeof this._child[i].ItemIndex === 'undefined') {
                this.setItemIndexDescent(this._child[i], 0);
                for (const key in this.Links) {
                    if (this.Links.hasOwnProperty(key)) {
                        this.Links[key].Targets.forEach(el => {
                            if (el.SourcePath) {
                                if (typeof el.el.ItemIndex === 'undefined') el.el.ItemIndex = 0;
                            }
                        });
                    }
                }
            }
        }

        if (dLen > t) {
            for (let i = 0; i < dLen - t; i++) {
                this._child.forEach(child => {
                    const newEl = this.clone(child, i + t, this);
                    this._resetStyle(newEl);
                });

            }
        } else if (dLen < t) {
            for (let i = 0; i < t - dLen; i++) {
                this.children[this.children.length - 1].remove();
            }
        }

        // fix: crap code (необходимо уже на входе иметь имена пораметров в LowerCase)
        // от рт и от линков
        let key, keys_t;
        let newobj = {}
        if (this._paneldatasource_data.length > 0) {
            keys_t = Object.keys(this._paneldatasource_data[0]);
            let n = keys_t.length;
            while (n--) {
                key = keys_t[n];
                this.keysDict[key.toLowerCase()] = key;
                newobj[key.toLowerCase()] = this._paneldatasource_data[0][key];
            }
        }

        for (let i = 0; i < this._paneldatasource_data.length; i++) {
            const element = this._paneldatasource_data[i];
            for (let co = 0; co < offset; co++) {
                const child = this.children[co + offset * i];
                for (let lKey in this.Links) {
                    const l = this.Links[lKey];
                    l.Targets.forEach(target => {
                        const innerTarget = target.ItemId == child.id ? child : child.querySelector(`[id="${target.ItemId}"]`);
                        if (innerTarget) {
                            // fix: Вроде как костыль
                            // const preKey = keys[innerTarget.id].split('.');
                            const srcKey = target.SourcePath.split('.');
                            const key = srcKey[srcKey.length - 1];

                            if (target.els === undefined)
                                target.els = [];
                            target.els[i] = innerTarget;

                            //Этот вызов необходим для правильной конвертации
                            const DataType = target.SourceDataType != undefined ? target.SourceDataType : l.Source.DataType;
                            const result = $sw.ItemSubscription._operation(target, element[key], DataType, i, l.Source.ItemId);
                        }
                    });
                };
            }
        }
    }
    _resetStyle(el) {
        el.style.top = '0';
        el.style.left = '0';
        if (el.style.display != 'none') {
            el.style.display = 'flex';
        }
        el.style.minWidth = `${el.getAttribute('width')}px`;
        el.style.minHeight = `${el.getAttribute('height')}px`;
        //if (el.children.length > 0) {
        //    for (let i = 0; i < el.children.length; i++) {
        //        el.children[i].style.position = ``;
        //    }
        //}
    }

    attributeChangedCallback(attrName, oldVal, newVal, itemIndex) {
        const path = attrName.split('.');
        if (path.length > 1 && path[0] == 'paneldatasource') {

            const key = this.keysDict[path[1]];
            if (key !== undefined && this._paneldatasource_data && typeof itemIndex === 'number') {
                if (this._paneldatasource_data[itemIndex][key] != newVal) {
                    this._paneldatasource_data[itemIndex][key] = newVal;
                    if (this.prop_link[path[0]]) {
                        this.prop_link[path[0]](
                            this.pId ? this.pId + '/' + this.id : this.id,
                            this.Links[path[0]],
                            this._paneldatasource_data,
                            path[0],
                            itemIndex
                        );
                    }
                }
            }
        } else {
            super.attributeChangedCallback(attrName, oldVal, newVal);
        }
    }

    clone(node, index, parent) {
        if (node.tagName === 'MS-WINDOW') {
            const el = node.cloneNode(false);
            el.style.position = 'relative';
            this.setItemIndexDescent(el, index);
            parent.appendChild(el);

            if (node.Links && node.propLink) {
                this.mergeLink(el.Links, node.Links, el);
                el.propLink = { ...node.propLink }
            }

            return el;
        } else {
            const newItem = node.cloneNode(false);
            if (node.children.length > 0) {
                for (let i = 0; i < node.children.length; i++) {
                    const newChield = this.clone(node.children[i], index);
                    newItem.appendChild(newChield);

                }
            }
            if (parent) parent.appendChild(newItem);
            if (node.Links && node.propLink) {
                this.mergeLink(newItem.Links, node.Links, newItem); //Нужно заменить target
                newItem.propLink = node.propLink;
                newItem.ItemIndex = index;
            }
            return newItem;
        }
    }

    setItemIndexDescent(node, index) {
        node.ItemIndex = index;
        if (node.childElementCount > 0) {
            node.childNodes.forEach(chode => {
                this.setItemIndexDescent(chode, index);
            })
        }
    }

    setPdsType(dtype) {
        this._paneldatasource_dataType = dtype;
    }

    mergeLink(newLinks, oldLinks, newItem) {
        const m = (newTargets, oldTargets) => {
            for (const oldTarget of oldTargets) {
                const index = newTargets.findIndex(el => {
                    return el.ItemId === oldTarget.ItemId && el.PropertyPath === oldTarget.PropertyPath;
                });
                if (index < 0) {
                    let newTarget = {};
                    const innerTarget = oldTarget.ItemId == newItem.id ? newItem : newItem.querySelector(`[id="${newTargets.ItemId}"]`);

                    for (var key in oldTarget) {
                        if (oldTarget.hasOwnProperty(key) && typeof oldTarget[key] !== 'object')
                            newTarget[key] = oldTarget[key];
                    }
                    if (innerTarget)
                        newTarget.el = innerTarget;
                    else
                        newTarget.el = oldTarget.el;

                    newTargets.push(newTarget);
                }
            }
        }
        for (const key in oldLinks) {
            if (oldLinks.hasOwnProperty(key)) {
                if (!newLinks.hasOwnProperty(key)) newLinks[key] = {};
                const sEl = oldLinks[key];
                const tEl = newLinks[key];
                if (typeof tEl.Targets === 'undefined') {
                    tEl.Targets = [];
                    tEl.Source = { ...sEl.Source };
                }
                m(tEl.Targets, sEl.Targets);
            }
        }
    }

    disconnectedCallback() {
        super.disconnectedCallback();
        for (let i = 0; i < this._child.length; i++) {
            this._child[i] = null;
        }
        this._child = null;
        this.innerHTML = '';
    }
}
