import { Basic } from "../basic.js";
/**
 * @class MSPanelTabControl
 * @extends Basic
 * @classdesc Панель вкладок
 * */
export class MSPanelTabControl extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'layout',
            'orientation',
            'loadinvisiblecontent',
            'currenttab',
            'tabs',
            'headerbackgroundcolor'
        ]);
    }
    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `
            <style>
                .tab__presentation {
                    display: flex;
                    flex-wrap: wrap;
                    margin-top: 15px;
                }
                .tabpanel {
                    width: 816px;
                    height: auto;
                    display: flex;
                    margin-bottom: 15px;
                    flex-shrink: 0;
                }
                .tab_column {
                    flex-direction: column;
                }
                .tab_row {
                    flex-direction: row;
                }
                .row_reverse {
                    flex-direction: row-reverse;
                }
                .column_reverse {
                    flex-direction: column-reverse;
                }
                .tabpanel__body {
                    background: #FFFFFF;
                    border: 1px solid #8DA1C0;
                    box-sizing: border-box;
                    flex: 1;
                    min-height: 100px;
                    height: auto;
                }
                .tabpanel__header {
                    background: #E8ECF2;
                    display: flex;
                }
                .tabheader__row {
                    display: flex;
                    flex-wrap: wrap;
                    width: 100%;
                }
                .tabheader__row button {
                    margin-left: 1px;
                    margin-bottom: 1px;
                }
                .tabheader__column {
                    flex-direction: column;
                    width: auto;
                }
                .tabheader__column button {
                    margin-bottom: 1px;
                }
                .tabpanel__btn,
                .tabpanel__btn_black {
                    position: relative;
                    min-width: 100px;
                    padding: 0 1em;
                    height: 29px;
                    background: #2C6FD7;
                    color: white;
                    transition: .3s;
                    cursor: pointer;
                    outline: none;
                    border: none;
                }
                .tabpanel__btn_black {
                    background: #828282;
                }
                .tabpanel__btn_black.active {
                    background: rgba(0, 0, 0, 0.8);
                }
                .vertical-tabs > button.tabpanel__btn_black.active {
                    flex-shrink: 0;
                }
                .tabpanel__btn_black:hover {
                    background: rgba(0, 0, 0, 0.8);
                }
                .tabpanel__btn.active {
                    background: linear-gradient(0deg, rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), #2C6FD7;
                }
                .tabpanel__btn:hover {
                    background: linear-gradient(0deg, rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), #2C6FD7;
                }
                .rotated > button {
                    height: 100px;
                    width: 29px;
                    overflow: hidden;
                }
                .rotated > button span {
                    display: inline-block;
                    width: 100px;
                    height: 100px;
                    transform:rotate(-90deg)
                }
                .btn-align > button {
                    text-align: left;
                }
                .btn-align > button span {
                    position: absolute;
                    bottom: 6px;
                    overflow: hidden;
                }
            </style>
            <div id="tabs" class="tabpanel__header tabheader__row"></div><slot></slot>
        `;
        this.style.display = 'flex';
        this.style.flexDirection = 'column';
        this.style.boxSizing = 'content-box';
        this.style.backgroundColor = "rgb(245,240,245)";
        this._loadinvisiblecontent = true;
        this._tabs = shadowRoot.getElementById('tabs');
    }

    _genTabs() {
        let t_innerHTML = '';
        this._tabs.innerHTML = '';
        this._child = [];
        this._childBtn = [];
        for (let index = 0; index < this._tabsDef.length; index++) {
            const element = this._tabsDef[index];

            const btn = document.createElement('button');
            this._childBtn.push(btn);
            btn.style.whiteSpace = 'nowrap';
            btn.classList.add('tabpanel__btn_black');
            btn.setAttribute('msIndex', index);
            btn.innerHTML = `<span>${element.name}</span>`;
            btn.onclick = this._onTabClick.bind(this);
            this._tabs.appendChild(btn);

            if (this._loadinvisiblecontent) {
                const template = this._loadTab(element.id);
                if (Number(element.id) === this._currenttab) {
                    template.style.display = 'flex';
                    template.style.visibility = "visible";
                    btn.classList.add('active');
                    this._Index = index;
                //} else {
                //    template.style.visibility = "hidden";
                    // template.style.display = 'none';
                }
            } else {
                if (Number(element.id) === this._currenttab) {
                    const template = this._loadTab(element.id);
                    template.style.display = 'flex';
                    btn.classList.add('active');
                    this._Index = index;
                }
            }
        };
    }

    _loadTab(id) {
        const template = document.querySelector(`template#t_${id}`).content.children[0].cloneNode(true);
        template.style.flexShrink = 0;
        template.style.position = 'relative';
        template.x = 0;
        template.y = 0;
        this.appendChild(template);
        this._child.push(template)
        template.setAttribute('height', '100%');
        template.setAttribute('width', '100%');
        return template;
    }

    _onTabClick(e) {
        const c = Number(e.currentTarget.getAttribute('msIndex'));
        this.SelectTab(c);
    }

    /**
     * переключить табулятор на закладку по индексу
     * @param {*} newIndex
     * @memberof MSPanelTabControl
     */
    SelectTab(newIndex) {
        if (this._Index != newIndex) {
            const id = this._tabsDef[newIndex].id;
            this._childBtn[this._Index].classList.remove('active');
            this._childBtn[newIndex].classList.add('active');
            if (this._loadinvisiblecontent) {
                this._child[this._Index].style.display = 'none';
                this._child[newIndex].style.display = 'flex';
            } else {
                this.innerHTML = '';
                const template = this._loadTab(id);
                template.style.display = 'flex';
            }
            this._Index = newIndex;
            this.SetParameter('currenttab', id);
        }
    }

    get headerbackgroundcolor() {
        return this._HeaderBackgroundColor || '#E8ECF2';
    }
    set headerbackgroundcolor(value) {
        this._HeaderBackgroundColor = value;
        this._tabs.style.backgroundColor = value;
    }

    get layout() {
        return this._layout;
    }
    set layout(value) {
        this._layout = value;
        const type = window._enums.LayoutType[value];
        switch (type) {
            case 0:
                this.style.flexDirection = 'column';
                this._switchHorizontalPosition();
                break;
            case 1:
                this.style.flexDirection = 'column-reverse';
                this._switchHorizontalPosition();
                break;
            case 2:
                this.style.flexDirection = 'row';
                this._switchVerticalPosition();
                break;
            case 3:
                this.style.flexDirection = 'row-reverse';
                this._switchVerticalPosition();
                break;
        }
    }

    _switchHorizontalPosition() {
        this._tabs.style.flexShrink = '0';
        this._tabs.classList.add('tabheader__row');
        this._tabs.classList.remove('tabheader__column');
        this._tabs.classList.remove('vertical-tabs');
        this._isRotated ?
            this._tabs.classList.add('btn-align') :
            this._tabs.classList.remove('btn-align');

    }

    _switchVerticalPosition() {
        this._tabs.style.flexShrink = '';
        this._tabs.classList.remove('tabheader__row');
        this._tabs.classList.add('tabheader__column');
        if (this._isRotated) {
            this._tabs.classList.remove('btn-align');
            this._tabs.classList.add('vertical-tabs');
        } else {
            this._tabs.classList.add('btn-align');
        }
    }

    get orientation() {
        return this._orientation;
    }
    set orientation(value) {
        this._orientation = value;
        if (window._enums.OrientationType[value] == 'row') {
            this._tabs.classList.remove('rotated');
            this._tabs.classList.remove('vertical-tabs');
            this._isRotated = false;
            switch (Number(this._layout)) {
                case 0: case 1:
                    this._tabs.classList.remove('btn-align');
                    break;
                case 2: case 3:
                    this._tabs.classList.add('btn-align');
                    break;
            }
        } else {
            this._tabs.classList.add('rotated');
            this._isRotated = true;
            switch (Number(this._layout)) {
                case 0: case 1:
                    this._tabs.classList.add('btn-align');
                    this._tabs.classList.remove('vertical-tabs');
                    break;
                case 2: case 3:
                    this._tabs.classList.remove('btn-align');
                    this._tabs.classList.add('vertical-tabs');
                    break;
            }
        }
    }

    get loadinvisiblecontent() {
        return this._loadinvisiblecontent;
    }
    set loadinvisiblecontent(value) {
        //this._loadinvisiblecontent = this._toBool(value);
        this._loadinvisiblecontent = true;
    }

    get currenttab() {
        return this._currenttab;
    }
    set currenttab(v) {
        this._currenttab = Number(v);
        if (typeof this._tabsDef === 'undefined') return;
        const index = this._tabsDef.findIndex((el) => {
            return Number(el.id) === this._currenttab;
        });
        this.SelectTab(index);
    }

    get tabs() {
        return this._tabsDef;
    }
    set tabs(v) {
        try {
            this._tabsDef = JSON.parse(v);
        } catch (error) {
            this._tabsDef = [];
        }
        this._genTabs();
    }

    set isvisible(value) {
        this._showElement = this._toBool(value);
        const isShow = (this.opacity === '' || this._toBool(this.opacity)) && this._showElement;
        this.style.display = isShow ? '' : 'none';
        this._tabs.display = this._showElement ? '' : 'none';
    }

    get resource() {
        return this._resource;
    }
    set resource(value) {
        this._resource = value;
    }
    afterInitialize() {
        for (let i = 0; i < this._child.length; i++) {
            if (this._child[i].afterInitialize) this._child[i].afterInitialize();
        }
        requestAnimationFrame(()=>{
            for (let i = 0; i < this._child.length; i++) {
                const element = this._child[i];
                if (element.style.visibility === 'hidden') {
                    element.style.display = 'none';
                }
                element.style.visibility = '';
            }
        })
    }
}
