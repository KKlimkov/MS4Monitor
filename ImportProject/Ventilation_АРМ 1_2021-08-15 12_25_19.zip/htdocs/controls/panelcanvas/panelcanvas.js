import { Basic } from "../basic.js";
import { DataTypes } from '../../generated/datatypes.js';

/**
 * @class MSPanelCanvas
 * @extends Basic
 * @classdesc ������
 * */
export class MSPanelCanvas extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'displayname',
            'paneldatasource'
        ]);
    }

    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<slot></slot>`;
        //this.style.position = 'absolute';
        this.style.display = 'flex';
        this.style.borderWidth = "1px";
        this.style.backgroundColor = "rgb(245,240,245)";

        this._child = [];
        this.keysDict = {};
        for (let index = 0; index < this.children.length; index++) {
            const element = this.children[index];
            this._child.push(element);
        };
    }

    get displayname() {
        return this._displayname;
    }
    set displayname(value) {
        this._displayname = value;
    }

    get paneldatasource() {
        return this._paneldatasource;
    }
    set paneldatasource(value) {
        if (typeof value == 'object') {
            this._paneldatasource_dataType = DataTypes.dataTypes[value.dataType];
            this._paneldatasource_typeOfElement = DataTypes.dataTypes[this._paneldatasource_dataType.TypeOfElementsName];
            this._paneldatasource_data = JSON.parse(JSON.stringify(value.value));
            this._paneldatasource = value;
            this._createContent();
        }
    }

    _createContent() {
        const offset = this._child.length;
        const t = this.children.length / offset;
        const dLen = this._paneldatasource_data.length;

        for (let i = 0; i < this._child.length; i++) {
            if (typeof this._child[i].ItemIndex === 'undefined') {
                this._child[i].ItemIndex = 0;
                for (const key in this.Links) {
                    if (this.Links.hasOwnProperty(key)) {
                        this.Links[key].Targets.forEach(el => {
                            if (el.SourcePath) {
                                if (typeof el.el.ItemIndex === 'undefined') el.el.ItemIndex = 0;
                            }
                        });
                    }
                }
            }
        }

        if (dLen > t) {
            for (let i = 0; i < dLen - t; i++) {
                this._child.forEach(child => {
                    const newEl = this.clone(child, i + t, this);
                });
            }
        } else if (dLen < t) {
            for (let i = dLen - t; i < dLen; i++) {
                this.children[this.children.length - 1].remove();
            }
        }

        let key, keys_t;
        let newobj = {}
        if (this._paneldatasource_data.length > 0) {
            keys_t = Object.keys(this._paneldatasource_data[0]);
            let n = keys_t.length;
            while (n--) {
                key = keys_t[n];
                this.keysDict[key.toLowerCase()] = key;
                newobj[key.toLowerCase()] = this._paneldatasource_data[0][key];
            }
        }

        for (let i = 0; i < this._paneldatasource_data.length; i++) {
            const element = this._paneldatasource_data[i];
            for (let co = 0; co < offset; co++) {
                const child = this.children[co + offset * i];
                for (let lKey in this.Links) {
                    const l = this.Links[lKey];
                    l.Targets.forEach(target => {
                        const innerTarget = target.ItemId == child.id ? child : child.querySelector(`[id="${target.ItemId}"]`);
                        if (innerTarget) {
                            const srcKey = target.SourcePath.split('.');
                            const key = srcKey[srcKey.length - 1];
                            if (innerTarget.SetParameter) {
                                innerTarget.SetParameter(target.PropertyPath.toLowerCase(), element[key], true);
                            } else {
                                innerTarget[target.PropertyPath.toLowerCase()] = element[key];
                            }
                        }
                    });
                };
            }
        }
    }

    clone(node, index, parent) {
        if (node.tagName === 'MS-WINDOW') {
            const el = node.cloneNode(false);
            parent.appendChild(el);
            el.style.position = 'relative';
            el.ItemIndex = index;
            this.mergeLink(el.Links, node.Links);
            return el;
        } else {
            const newItem = node.cloneNode(false);
            if (node.Links && node.propLink) {
                newItem.Links = node.Links;
                newItem.propLink = node.propLink;
                newItem.ItemIndex = index;
            }
            if (node.children.length > 0) {
                for (let i = 0; i < node.children.length; i++) {
                    const newChield = this.clone(node.children[i], index);
                    newItem.appendChild(newChield);

                }
            }
            if (parent) parent.appendChild(newItem);
            return newItem;
        }
    }

    mergeLink(target, source) {
        const m = (target, source) => {
            for (const iterator of source) {
                const index = target.findIndex(el => {
                    return el.ItemId === iterator.ItemId;
                });
                if (index < 0) {
                    target.push(iterator);
                }
            }
        }
        for (const key in source) {
            if (source.hasOwnProperty(key)) {
                if (!target.hasOwnProperty(key)) target[key] = {};
                const sEl = source[key];
                const tEl = target[key];
                if (typeof tEl.Targets === 'undefined') tEl.Targets = [];
                m(tEl.Targets, sEl.Targets);
            }
        }
    }

    attributeChangedCallback(attrName, oldVal, newVal, itemIndex) {
        const path = attrName.split('.');
        if (path.length > 1 && path[0] == 'paneldatasource') {

            const key = this.keysDict[path[1]];
            if (this._paneldatasource_data && typeof itemIndex === 'number') {
                if (this._paneldatasource_data[itemIndex][key] != newVal) {
                    this._paneldatasource_data[itemIndex][key] = newVal;
                    if (this.prop_link[path[0]]) {
                        this.prop_link[path[0]](
                            this.pId ? this.pId + '/' + this.id : this.id,
                            this.Links[path[0]],
                            this._paneldatasource_data,
                            path[0],
                            itemIndex
                        );
                    }
                }
            }
        } else {
            super.attributeChangedCallback(attrName, oldVal, newVal);
        }
    }

    afterInitialize() {
        for (let i = 0; i < this.children.length; i++) {
            if (this.children[i].afterInitialize) this.children[i].afterInitialize();
        }
    }

    disconnectedCallback() {
        super.disconnectedCallback();
        for (let i = 0; i < this._child.length; i++) {
            this._child[i] = null;
        }
        this._child = null;
        this.innerHTML = '';
    }
}