﻿import { MSDateTimePicker } from "../dtpicker/dtpicker.js";
/**
 * @class MSInterval
 * @extends MSDateTimePicker
 * @classdesc Интервал
 * */
export class MSInterval extends MSDateTimePicker {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'datetime',
            'timeformat',
            'isreadonly'
        ]);
    }

    constructor() {
        super();
        this.shadowRoot.innerHTML = `
            <style>
                .bgimg {
                    width: 34px;
                    background-origin: content-box;
                    background-position: center;
                    background-repeat: no-repeat;
                    background-size: 60%;
                    background-image: url('./styles/data_ico.svg');
                    border-left: 1px solid;
                }
                .bgimg:hover {
                    background-color: #00000021;
                }
            </style>
            <input data-id='dtinput' style="height:100%;width:100%;min-width:0px;background-color:transparent;border:0;text-align:center">
            <div class="bgimg" id='btnCal'></div>
        `;
        this.shadowRoot.getElementById('btnCal').onclick = this.showInput.bind(this);
        this._text = this.shadowRoot.querySelector('input');

        this._inputKeyDown = this._inputKeyDown.bind(this);
        this._onInputDTFocus = this._onInputDTFocus.bind(this);
        this._onInputDTBlur = this._onInputDTBlur.bind(this);
        this._onIncBtnMouseDown = this._onIncBtnMouseDown.bind(this);
        this._onIncBtnStop = this._onIncBtnStop.bind(this);
        this._onInputPaste = this._onInputPaste.bind(this);

        this.onfocus = e => this._text.focus();
        this._text.oncut = () => false;
        this._text.addEventListener('keydown', this._inputKeyDown);
        this._text.addEventListener('focus', this._onInputDTFocus);
        this._text.addEventListener('blur', this._onInputDTBlur);
        this._text.addEventListener('paste', this._onInputPaste);
        this._limits = {
            maxdd: 999,
            maxHH: 23,
            maxmm: 59,
            maxss: 59,
            maxfff: 999,
            mindd: 0,
            minHH: 0,
            minmm: 0,
            minss: 0,
            minfff: 0
        };
        this._timeNames = {
            HH: 'Часы',
            mm: 'Мин.',
            ss: 'Сек.',
            fff: 'Миллисек.'
        };
        this._dateNames = {
            dd: 'День'
        };
        this._MSEC_OF_DAY = 86400000;
        this._MSEC_OF_HOUR = 3600000;
        this._MSEC_OF_MINUTE = 60000;
        this._MSEC_OF_SEC = 1000;
        //this.timeformat = 'dd.HH:mm:ss.fff';
        this._fullmask = this.timeformat;

        //this.setBaseParams();
        this.isreadonly = true;
        this.datetime = 0;
        this.timeformat = "dd.HH:mm:ss";
        //
        this.textcolor = "BLACK";
        this._text.style.fontFamily = "Tahoma";
        this._text.style.fontSize = 12;
        this.style.justifyContent = 'center'; //this.texthorizontalalign = 1;
        this.style.textAlign = 'center';
        this.style.alignItems = '';
        this.borderthickness = 1;
        this.backgroundcolor = "rgb(208,208,208)";
    }

    get utc() {
        return this._utc;
    }
    set utc(value) {
        this._utc = value;
    }

    get timeformat() {
        return this._timeformat;
    }
    set timeformat(value) {
        const correctFormat = this._getCorrectFormat(value);
        this._timeformat = correctFormat;
        this._fullmask = correctFormat;
        if (typeof this._datetime !== 'undefined') this._update();
    }

    get datetime() {
        return this._datetime;
    }
    set datetime(value) {
        this._datetime = value;
        this._update();
    }

    get isreadonly() {
        return this._isreadonly;
    }
    set isreadonly(value) {
        this._isreadonly = this._toBool(value);
        this._text.disabled = this._isreadonly;

        if (this._isreadonly && this.datePopup) {
            this.datePopup.parentElement.remove();
            this.datePopup.remove();
            this.datePopup = null;
        }
    }

    saveClick(e) {
        e.preventDefault();
        let formatedValue = {};
        const formData = new FormData(this.datePopup);
        for (const pair of formData.entries()) {
            const [name, value] = pair;
            formatedValue[name] = Number(value);
        }
        this._setNewDateTime(formatedValue);
        this.datePopup.parentElement && this.datePopup.parentElement.remove();
        this.datePopup.remove();
        this.datePopup = null;
    }

    cancelClick(e) {
        e.preventDefault();
        this.datePopup.parentElement.remove();
        this.datePopup.remove();
        this.datePopup = null;
    }

    _showPlaceholder(value) {
        // const font = parseInt(this._text.style.fontSize);
        // this._text.offsetParent.style.fontSize = `${Math.floor(font / 1.1)}px`;
        // this._text.offsetParent.setAttribute('data-value', value);
        // this._text.offsetParent.style.overflow = 'visible';
        // this._text.offsetParent.classList.add('span-placeholder');
    }

    _hidePlaceholder() {
        // this._text.offsetParent.style.overflow = 'hidden';
        // this._text.offsetParent.style.fontSize = '';
        // this._text.offsetParent.classList.remove('span-placeholder');
    }

    _adjustValue(val, category, oldValue = null) {
        const min = this._limits[`min${category}`];
        const max = this._limits[`max${category}`];
        if (val < min) {
            val = oldValue ? oldValue : max;
        }
        if (val > max) {
            val = oldValue ? oldValue : min;
        }
        while (val.toString().length < category.length) {
            val = '0' + val;
        }
        return val;
    }

    _onInputBoxWheel(e) {
        e.preventDefault();
        if (this._isreadonly) return;
        let val = Number(e.target.value);
        const delta = -e.deltaY;
        val = delta > 0 ? val + 1 : val - 1;
        val = this._adjustValue(val, e.target.id);
        e.target.value = val;
        return false;
    }

    _onInputBoxChange(e) {
        if (this._isreadonly) return;
        let val = Number(e.target.value);
        val = this._adjustValue(val, e.target.id, e.target.dataset.oldValue);
        e.target.value = val;
        return false;
    }

    _onInputDTFocus(e) {
        e.target.dataset.oldValue = e.target.value;
        if (e.target.dataset.id === 'dtinput') {
            this._showPlaceholder(this._fullmask);
        }
    }

    _onInputPaste(evt) {
        evt.preventDefault();
        const pastedValue = evt.clipboardData.getData('Text');
        this._setValue(pastedValue);
    }

    _onInputDTBlur(e) {
        this._setValue(e.target.value);
        this._hidePlaceholder();
    }

    showInput(e) {
        if (this._isreadonly) {
            e.preventDefault();
            return false;
        }
        if (!this.datePopup) {
            this.datePopup = this._createDatePopup();
        } else {
            this.datePopup.parentElement.remove();
            this.datePopup.remove();
            this.datePopup = null;
            return;
        }
        const btnSave = this.datePopup.querySelector('button[id="save"]');
        btnSave.onclick = this.saveClick.bind(this);

        this.datePopup.style.userSelect = 'none';
        this.datePopup.onclick = (e) => {
            e.stopImmediatePropagation();
        }

        const incBtns = this.datePopup.querySelectorAll('button.incbtn');
        incBtns.forEach((btn) => {
            btn.onmousedown = this._onIncBtnMouseDown;
            btn.ontouchstart = this._onIncBtnMouseDown;
        });

        const btnCancel = this.datePopup.querySelector('button[id="cancel"]');
        btnCancel.onclick = this.cancelClick.bind(this);

        const inputs = this.datePopup.querySelectorAll('input');
        inputs.forEach((input) => {
            input.onwheel = this._onInputBoxWheel.bind(this);
            input.onchange = this._onInputBoxChange.bind(this);
            input.onfocus = this._onInputDTFocus.bind(this);
        });

        const win = window.__rootWin.getBoundingClientRect();
        const baseScale = window.__rootWin.offsetWidth / win.width;

        const back = document.createElement('div');
        back.id = 'divCancel';
        back.style.position = 'absolute';
        back.style.display = 'flex';
        back.style.flexDirection = 'column';
        back.style.top = '0';
        back.style.left = '0';
        back.style.bottom = '0';
        back.style.right = '0';
        back.style.zIndex = '10003';
        back.appendChild(this.datePopup);
        back.onclick = this.cancelClick.bind(this);
        document.body.appendChild(back);

        const rect = this.datePopup.getBoundingClientRect();
        const baseRect = this.getBoundingClientRect();

        if (baseRect.left + rect.width > win.width) {
            this.datePopup.style.left = (win.width - rect.width) + 'px';
        } else {
            this.datePopup.style.left = (baseRect.left) + 'px';
        }
        if (baseRect.bottom + rect.height > win.height) {
            this.datePopup.style.top = (baseRect.top - rect.height) + 'px';
        } else {
            this.datePopup.style.top = (baseRect.bottom) + 'px';
        }
    }

    _onIncBtnMouseDown(evt) {
        evt.preventDefault();
        evt.target.onmouseup = this._onIncBtnStop;
        evt.target.ontouchend = this._onIncBtnStop;
        document.addEventListener('touchmove', this._onIncBtnStop);
        evt.target.onmouseleave = this._onIncBtnStop;
        this._intervalId = setInterval(() => {
            this._interv = true;
            this._changeBtnIncValue(evt.target);
        }, 100);
    }

    _onIncBtnStop(evt) {
        clearInterval(this._intervalId);
        evt.target.onmouseup = null;
        evt.target.ontouchend = null;
        document.removeEventListener('touchmove', this._onIncBtnStop);
        evt.target.onmouseleave = null;
        if (this._interv) {
            this._interv = false;
            return false;
        }
        this._changeBtnIncValue(evt.target);
    }

    _changeBtnIncValue(btn) {
        const input = btn.parentElement.querySelector('input');
        let val = Number(input.value);
        if (btn.id === 'up') {
            val += 1;
        } else {
            val -= 1;
        }
        val = this._adjustValue(val, input.id);
        input.value = val;
    }

    _createDatePopup() {
        const template = document.createElement('template');
        template.innerHTML = this._getTemplate();
        return template.content.children[0];
    }

    _getTemplate() {
        return `<form id="calend" class="form-calendar" style="z-index: 1001; left: 153px; top: 63px;">
            ${this._getCalendarSections()}
            <div class="calendar-btns">
                <button id="save">Выбрать</button>
                <button id="cancel">Отмена</button>
            </div>
        </form>`;
    }

    _getCalendarSections() {
        const { isDate, isTime, dateObj, timeObj } = this._getIntervalTimeObj();
        const dateHtml = isDate ? this._getDateTemplate(dateObj) : '';
        const timeHtml = isTime ? this._getTimeTemplate(timeObj) : '';
        return dateHtml + timeHtml;
    }

    _getDateTemplate(dateObj) {
        return `<div class="calendar">
            ${(Object.entries(dateObj).map((pair, i) => this._getInputTemplate(this._dateNames[pair[0]], pair))).join(' ')}
        </div>`;
    }

    _getTimeTemplate(timeObj) {
        return `<div class="calendar">
            ${(Object.entries(timeObj).map((pair, i) => this._getInputTemplate(this._timeNames[pair[0]], pair))).join(' ')}
        </div>`;
    }

    _getInputTemplate(name, [format, value]) {
        return `<div class="calendar__section">
            <span>${name}</span>
            <button type="button" id="up" class="incbtn">&#9652;</button>
            <input type="number" name="${format}" id="${format}" class="data_inp" value="${value}">
            <button type="button" id="down" class="incbtn">&#9662;</button>
        </div>`;
    }

    _getCurrentDateObj(isDate, isTime) {
        let formatedValue = [];
        formatedValue.push(isDate
            ? this._getFormatedObj(['dd'])
            : {}
        );
        formatedValue.push(isTime
            ? this._getFormatedObj(this._timeformat.replace(/\W+/g, '-').split('-'))
            : {}
        );
        return formatedValue;
    }

    _getFormatedObj(formats) {
        let obj = {};
        let dt;
        if (formats.length === 1 && formats[0] === 'dd') {
            return { dd: this._getDaysAmount() }
        }
        if (this._datetime === undefined) {
            dt = window._df.dateFormat(new Date(Number(0)), `${formats.join('-')}`, this.utc);
        } else {
            dt = window._df.dateFormat(new Date(Number(this._datetime || 0)), `${formats.join('-')}`);
        }
        let dtItems = dt.split('-');
        dtItems.forEach((item, i) => obj[formats[i]] = item);
        return obj;
    }

    _getCorrectFormat(value) {
        const arr = ['dd', 'HH', 'mm', 'ss', 'fff'];
        const token = /(d+|H+|m+|s+|f+)/g;
        const extValue = value.replace(token, (match, ctt, index) => {
            if (/f/.test(match)) {
                if (match.length >= 3) {
                    return match.slice(0, 3);
                }
                while (match.length < 3) {
                    match = match + 'f';
                }
                return match;
            }
            while (match.length < 2) {
                match += match;
            }
            return match.slice(0, 2);
        });
        const matches = extValue.match(token);
        const groups = new Set(matches);
        let str = '';
        arr.forEach((item) => {
            if (groups.has(item)) {
                str += item;
            }
        });
        str = str.replace(/(d+)|(H+)|(m+)|(s+)|(f+)/g, (match, p1, p2, p3, p4, p5, index, srcStr) => {
            if (p1) {
                return (index + match.length === srcStr.length) ? match : `${match}.`;
            }
            if (p2) {
                return (index + match.length === srcStr.length) ? match : `${match}:`;
            }
            if (p3) {
                return (index + match.length === srcStr.length) ? match : `${match}:`;
            }
            if (p4) {
                return (index + match.length === srcStr.length) ? match : `${match}:`;
            }
            if (p5) {
                return match;
            }
        })
        return str;
    }

    _getObjectFormat(value) {
        const token = /(d|M|y|H|m|s|f)+/g;
        const correctFormat = value.replace(token, match => {
            if (/f/.test(match)) {
                return 'fff';
            }
            while (match.length < 2) {
                match += match;
            }
            return match;
        });
        return correctFormat;
    }

    _setValue(val) {
        if (val === this._text.dataset.oldValue) return;
        let dtObj = {};
        if (val.includes('_')) {
            this._text.value = this._text.dataset.oldValue;
            return;
        }
        let value = val.replace(/(\W|[A-Za-zА-ЯЁа-яё])+/g, (match, p1, index) => (index === 0 || ((index + match.length) === val.length)) ? '' : '-');
        const values = value.split('-');
        let mask = this._fullmask.replace(/\W/g, '-');
        const names = mask.split('-');

        names.forEach((name, i) => {
            const format = this._getObjectFormat(name);
            dtObj[format] = values[i] ? values[i] : 0;
        });
        this._setNewDateTime(dtObj);
    }

    _setNewDateTime(date) {
        let days = date.dd ? date.dd * this._MSEC_OF_DAY : 0;
        let hours = date.HH ? date.HH * this._MSEC_OF_HOUR : 0;
        let minutes = date.mm ? date.mm * this._MSEC_OF_MINUTE : 0;
        let sec = date.ss ? date.ss * this._MSEC_OF_SEC : 0
        let ms = date.fff ? date.fff : 0;
        let timestamp = Number(days) + Number(hours) + Number(minutes) + Number(sec) + Number(ms);
        this._isEvent = true;
        this.SetParameter('datetime', timestamp, this.force);
        this._isEvent = false;
    }

    _update() {
        if (typeof this._datetime === 'undefined') { return; }
        if (typeof this._datetime === 'undefined' && this._allownull) { this._text.value = ''; return; }

        this._text.value = this._getIntervalTime();
    }

    _getIntervalTime() {
        let isDate = this._getIsDate();
        let format = this._getTimeFormat();
        let days = this._getDaysAmount();
        let isTime = format.length !== 0;
        let date = new Date(Math.abs(this._datetime));
        if (isNaN(date)) {
            const message = `Значение ${this._datetime} не может быть преобразовано в формат ${format}`;
            return new CustomConvertError('00.00:00:00', message);
        }
        const utc = isTime ? window._df.dateFormat(date, format, true) : '';
        return `${isDate ? `${days}` : ''}${(isDate && isTime) ? '.' : ''}${utc}`;
    }

    _getIntervalTimeObj() {
        let dateObj = {};
        let timeObj = {};
        let isDate = this._getIsDate();
        let format = this._getTimeFormat();
        let isTime = format.length !== 0;
        let days = this._getDaysAmount();
        if (isDate) {
            dateObj['dd'] = days;
        }
        let date = new Date(Math.abs(this._datetime));
        format = format.replace(/\W/g, '-');
        const utcArr = window._df.dateFormat(date, format, true).split('-');
        if (isTime) {
            const formatArr = format.split('-');
            formatArr.forEach((item, i) => {
                timeObj[item] = utcArr[i];
            });
        }
        return { isDate, isTime, dateObj, timeObj };
    }

    _getIsDate() {
        const rxTime = /^(d{1,2})/i;
        return rxTime.test(this._timeformat);
    }

    _getDaysAmount() {
        const absValue = Math.abs(this._datetime);
        let days = (Math.floor(absValue / this._MSEC_OF_DAY)).toString();
        while (days.length < 2) {
            days = '0' + days;
        }
        return days;
    }

    _getTimeFormat() {
        const rxTime = /^(d{1,2})/i;
        const rxDays = /\W/;
        const isDate = rxTime.test(this._timeformat);
        if (isDate) {
            const indexDays = this._timeformat.search(rxDays);
            return (indexDays === -1)
                ? ''
                : this._timeformat.slice(indexDays + 1);
        }
        return this._timeformat;
    }

    _inputKeyDown(evt) {
        if (evt.ctrlKey || this._isreadonly) {
            return false;
        }
        if (evt.which === window._enums.ButtonKeyCode.DELETE) {
            evt.preventDefault();
            return false;
        }
        const input = evt.target;
        let index = input.selectionStart;
        const currentValue = input.value;
        if (evt.which === window._enums.ButtonKeyCode.BACKSPACE) {
            evt.preventDefault();
            if (input.selectionStart === input.selectionEnd) {
                if (index === 0) {
                    return;
                }
                if (!(/\W/.test(currentValue[index - 1]))) {
                    input.value = currentValue.slice(0, index - 1) + '_' + currentValue.slice(index);
                }
                input.setSelectionRange(index - 1, index - 1);
            } else {
                const ind = input.selectionStart;
                let selectVal = currentValue.slice(input.selectionStart, input.selectionEnd);
                selectVal = selectVal.replace(/\d/g, '_');
                input.value = currentValue.slice(0, input.selectionStart) + selectVal + currentValue.slice(input.selectionEnd);
                input.setSelectionRange(ind, ind);
            }
        } else if (evt.key.length === 1) {
            evt.preventDefault();
            if (index === currentValue.length || !(/\d/.test(evt.key))) {
                return;
            }
            if ((!(/\d/.test(currentValue[index])) && currentValue[index] !== '_')) {
                input.setSelectionRange(index + 1, index + 1);
                return;
            }
            input.value = currentValue.slice(0, index) + evt.key + currentValue.slice(index + 1);
            index += (/\W/.test(currentValue[index + 1])) ? 2 : 1;
            input.setSelectionRange(index, index);
        } else if (evt.which === window._enums.ButtonKeyCode.RIGHT) {
            input.setSelectionRange(index + 1, index + 1);
        } else if (evt.which === window._enums.ButtonKeyCode.LEFT) {
            if (index === 0) {
                return;
            }
            input.setSelectionRange(index - 1, index - 1);
        } else if (evt.which === window._enums.ButtonKeyCode.ENTER) {
            this._onInputDTBlur({ target: { value: input.value } });
        }
    }

    disconnectedCallback() {
        if (this._text && this._text.oncut) this._text.oncut = null;
        this._text.removeEventListener('paste', this._onInputPaste);
        this._text.removeEventListener('keydown', this._inputKeyDown);
        this._text.removeEventListener('focus', this._onInputDTFocus);
        this._text.removeEventListener('blur', this._onInputDTBlur);
        super.disconnectedCallback();
        if (this.datePopup) {
            this.datePopup.parentElement.remove();
            this.datePopup.remove();
            this.datePopup = null;
        }
    }
}
