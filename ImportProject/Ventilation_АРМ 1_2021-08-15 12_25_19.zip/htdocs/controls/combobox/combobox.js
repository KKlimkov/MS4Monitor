import { Basic } from "../basic.js";
/**
 * @class MSComboBox
 * @extends Basic
 * @classdesc ���������� ������
 * */
export class MSComboBox extends Basic {

    static get observedAttributes() {
        return super.observedAttributes.concat([
            'fontname',
            'fontsize',
            'fontitalic',
            'fontbold',
            'fontunderlined',
            'textcolor',
            'itemssource',
            'selecteditem',
            'notsendbackwardconnection'
        ]);
    }

    constructor() {
        super();
        this._lockLink = this.getAttribute("notsendbackwardconnection");
        this.shRoot = this.attachShadow({ mode: 'closed' });
        this.shRoot.innerHTML = '<select></select>';
        //this.style.position = 'absolute';
        this.style.display = 'flex';
        this.style.overflow = 'hidden';
        this._text = this.shRoot.querySelector('select');
        this._text.style.width = '100%';
        this._text.style.height = '100%';
        this._text.style.border = '0';
        this._text.onchange = this._onChange.bind(this);
        // 
        this.fontname = "Tahoma";
        this.fontsize = 12;
        this.onfocus = e => this._text.focus();
    }

    _onChange(ev) {
        this._interaction = true;
        this.SetParameter('selecteditem', ev.target.value);
        this._interaction = false;
    }

    get notsendbackwardconnection(){
        return this._lockLink;
    }
    set notsendbackwardconnection(value){
        this._lockLink = this._toBool(value);
    }

    get fontname() {
        return this._text.style.fontFamily;
    }
    set fontname(value) {
        this._text.style.fontFamily = value;
    }

    get fontsize() {
        return this._text.style.fontSize;
    }
    set fontsize(value) {
        this._text.style.fontSize = value;
    }

    get fontitalic() {
        return this._italic;
    }
    set fontitalic(value) {
        this._italic = value || false;
        this._text.style.fontStyle = this._toBool(value) ? 'italic' : 'normal';
    }

    get fontbold() {
        return this._bold || false;
    }
    set fontbold(value) {
        this._bold = value;
        this._text.style.fontWeight = this._toBool(value) ? 'bold' : 'normal';
    }

    get fontunderlined() {
        return this._underline || false;
    }
    set fontunderlined(value) {
        this._underline = value;
        this._text.style.textDecoration = this._toBool(value) ? 'underline' : 'none';
    }

    get textcolor() {
        return this._text.style.color;
    }
    set textcolor(value) {
        this._text.style.color = value;
    }
    set backgroundcolor(value) {
        if (typeof value !== 'undefined' && typeof value === 'string') {
            this._backgroundcolor = value;
            if (value.indexOf(' ') !== -1) {
                this._text.style.background = this._calcGradient(value);
            } else {
                this._text.style.backgroundColor = value;
            }
        }
    }
    get itemssource() {
        return this._itemssource;
    }
    set itemssource(value) {
        this._itemssource = value;
        const list = value.split('~');
        while (this._text.options.length > 0) {
            this._text.options[0].remove();
        }

        for (let i = 0; i < list.length; i++) {
            const element = list[i];
            if (!element) { continue; }
            const opt = document.createElement("option");
            opt.value = opt.text = element;
            this._text.add(opt);
        }

        if (this._selecteditem) {
            this._text.value = this._selecteditem;
        } else {
            this._text.value = list[0];
        }


    }


    get selecteditem() {
        return this._selecteditem;
    }
    set selecteditem(value) {
        this._selecteditem = value;


        const list = (this._itemssource || '').split('~');
        const index = list.findIndex(o => { return o == value; });
        if (index > 0) {
            this._text.value = value;
        } else {
            this._text.value = list[0];
        }

    }

    get resource() {
        return this._resource;
    }
    set resource(value) {
        if (value) {
            this._resource = this.getResourceFromList(value);
            this._calcBacgraund(this._text);
            this._calcBlockShadow();
            this.backgroundcolor = "transparent";
        } else {
            this._text.style.backgroundImage = ``;
            const bg = this.getAttribute("backgroundcolor");
            if (bg != null) {
                this.backgroundcolor = bg;
            } else {
                this.backgroundcolor = "rgb(245,240,245)";
            }
        }
    }

    /**
     * ������� �� ��������� ��������� ��������
     * @see https://w3c.github.io/webcomponents/spec/custom/
     * @param {string} attrName �������� ��������
     * @param {*} oldVal ������ �������� ��������
     * @param {*} newVal ����� �������� ��������
     */
    attributeChangedCallback(attrName, oldVal, newVal) {
        if (oldVal !== newVal) {
            if (attrName === 'selecteditem' && !this._interaction) {
                if (this._lockLink) {
                    this[attrName] = newVal
                    return;
                }
            }
            if (oldVal != newVal) {
                this[attrName] = newVal;
                if (this.prop_link[attrName]) {
                    this.prop_link[attrName](
                        this.pId ? this.pId + '/' + this.id : this.id,
                        this.Links[attrName],
                        newVal,
                        attrName,
                        this.ItemIndex,
                        null,
                        this._lockLink
                    );
                }
            }
        }
    }

}
