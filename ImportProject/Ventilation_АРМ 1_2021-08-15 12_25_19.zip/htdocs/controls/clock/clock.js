import { MSText } from "../text/text.js";
/**
 * @class MSClock
 * @extends MSText
 * @classdesc ����
 * */
export class MSClock extends MSText {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'timeformat',
            'dateformat',
            'datetimetype'
        ]);
    }

    constructor() {
        super();
        this._timeformat = 'HH:mm:ss.f';
        this._dateformat = 'dd-MM-yyyy';
        this._df = this._timeformat;

        this.df = window._df;
        this._interval = setInterval(() => {
            let now = new Date();
            this._text.innerText = this.df.dateFormat(now, this._df);
        }, 1000);
        this._text.innerText = this.df.dateFormat(new Date(), this._df);
        this.textcolor = "BLACK";
        this.borderthickness = 1;
        this.backgroundcolor = "rgb(245,240,245)";
    }

    get timeformat() {
        return this._timeformat;
    }
    set timeformat(value) {
        this._timeformat = value;
        this._updateFormat();
    }

    get dateformat() {
        return this._dateformat;
    }
    set dateformat(value) {
        this._dateformat = value;
        this._updateFormat();
    }

    get datetimetype() {
        return this._datetimetype;
    }
    set datetimetype(value) {
        this._datetimetype = window._enums.DateTimeType_Full[value];
        this._updateFormat();
    }

    _updateFormat() {
        switch (this._datetimetype) {
            case window._enums.DateTimeType_Full.Date_Type:
                this._df = this._dateformat;
                break;
            case window._enums.DateTimeType_Full.DateTime_Type:
                this._df = this._dateformat + ' ' + this._timeformat;
                break;
            case window._enums.DateTimeType_Full.TimeDate_Type:
                this._df = this._timeformat + ' ' + this._dateformat;
                break;
            case window._enums.DateTimeType_Full.Time_Type:
            default:
                this._df = this._timeformat;
                break;
        }
        this._text.innerText = this.df.dateFormat(new Date(), this._df);
    }


    disconnectedCallback() {
        this.df = null;
        super.disconnectedCallback();
        clearInterval(this._interval);
    }
}