"use strict";
import { DragElement } from "../../lib/drag.js"
import { Basic } from "../basic.js";
/**
 * @class MSPopUpWindow
 * @extends Basic
 * @classdesc Всплывающее окно
 * */
export class MSPopUpWindow extends Basic {

    static get observedAttributes() {
        return super.observedAttributes.concat([
            'dragable',
            'modal',
            'title',
            'showtitle',
            'titlecolor',
            'titlefontcolor',
            'minimized',
            'closable',
            'resize',
            'sizetocontent',
            'mini',
            'opendialogpoint',
            'boundsrestricted',
            'offsetx',
            'offsety',
            'context',
            'default',
            'scale',
            'onclose',
            'maxwidth'
        ]);
    }

    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });

        this.style.boxSizing = "border-box";

        shadowRoot.innerHTML =
            `
        <style>
        :host {
            overflow: unset;
            z-index: 10000;
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0; margin: 0; padding: 0;
            background-color: #00000030;
            display: none;
        }
        .disabled {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: rgba(82, 82, 82, 0.5);
            z-index: 10000;
            display: none;
        }
        .pop_up {
            position: absolute;
            display: flex;
            flex-direction: column;
            z-index: 1;
            border: 1px solid #6287C6;
            box-shadow: none;
            box-sizing: content-box;
        }

        .pop_up__header {
            cursor: default;
            width: 100%;
            height: ${window._globalParams.DialogHeaderSize}px;
            min-height: ${window._globalParams.DialogHeaderSize}px;
            background: #E0E7ED;
            display: flex;
            justify-content: space-between;
            padding-left: 10px;
            align-items: center;
            box-sizing: border-box;
            color: #1B1A1A;
        }

        .pop_up__header span {
            font-size: ${window._globalParams.DialogFontSize}px;
            font-family: ${window._globalParams.DialogFontName};
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
        }

        .header__btngroup {
            height: 100%;
            display: flex;
        }

        .header__btngroup button {
            width: ${window._globalParams.DialogHeaderSize}px;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            background: none;
            border: none;
            transition: .4s;
            outline: none;
            cursor: pointer;
        }

        .header__btngroup button:hover {
            background: rgba(37, 100, 214, 0.5);
        }

        .btn_hidden::before {
            content: '';
            width: 50%;
            height: 1px;
            position: absolute;
            background: #1B1A1A;
            bottom: 30%;
        }

        .btn_close::before {
            width: 50%;
            height: 1px;
            content: '';
            position: absolute;
            background: #1B1A1A;
            transform: rotate(45deg);
        }

        .btn_close::after {
            width: 50%;
            height: 1px;
            content: '';
            position: absolute;
            background: #1B1A1A;
            transform: rotate(-45deg);
        }

        .pop_up__body {
            overflow: hidden;
            background: white;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
        }

        .body__name {
            line-height: 18px;
            font-size: 13px;
            color: #1B1A1A;
        }

        .body__btn {
            cursor: pointer;
            width: 85px;
            height: 24px;
            line-height: 1;
            background: linear-gradient(180deg, #4574CF 0%, #2B5099 100%);
            outline: none;
            border: 1px solid #345AA4;
            box-sizing: border-box;
            font-size: 11px;
            color: #FDFDFD;
            margin-top:8px;
        }

        label {
            cursor: pointer;
        }

        .body__labelgroup {
            display: flex;
            align-items: center;
            margin-top: 16px;
        }

        .body__btn + .body__labelgroup {
            margin-top: 32px;
        }

        .active {
            border: 1px solid #2C6FD7;
            box-shadow: var(--popup-shadow);
            z-index: 4;
        }

        .active .pop_up__header {
            background: #2C6FD7;

        }

        .active .header__btngroup button::before,
        .active .header__btngroup button::after {
            background: white;
        }

        .hidder {
            height: 0px;
            padding: 0;
        }

        .active .header__btngroup button:hover {
            background: rgba(0, 0, 0, 0.3);
        }

        .header_colored_white button::before,
        .active .header_colored_white button::before,
        .header_colored_white button::after,
        .active .header_colored_white button::after{
            background: rgb(22, 22, 22);
        }

        .header_colored_white button:hover,
        .active .header_colored_white button:hover {
            background: rgba(22, 22, 22, 0.3);
        }

        .active .header_colored_black  button::before,
        .header_colored_black  button::before,
        .active .header_colored_black  button::after,
        .header_colored_black  button::after {
            background: rgb(247, 244, 244);
        }

        .active .header_colored_black  button:hover,
        .header_colored_black  button:hover {
            background: rgba(245, 241, 241, 0.3);
        }

        </style>
        <div class='pop_up' id="popup" style='user-select: none; --popup-shadow: 0px 3px 10px rgba(35, 39, 76, 0.5);'>
            <div class="pop_up__header" id="title">
                <span id="text"></span>
                <div class="header__btngroup">
                    <button id="minimize" class='btn_hidden'></button>
                    <button id="closed" class='btn_close'></button>
                </div>
            </div>
            <div id="work" class="pop_up__body" style='overflow: hidden;'>
            <slot></slot>
            <div id="disabled" class="disabled"></div>
            </div>
            <div style="width:10px;position:absolute;right:-5px;bottom:0;top:0;cursor:ew-resize;" id="r_rsize"></div>
            <div style="height:10px;position:absolute;right:0;bottom:-5;left:0;cursor:ns-resize;" id="b_rsize"></div>
            <div style="height:30px;width:30px;position:absolute;right:-5px;bottom:-5px;cursor:nw-resize;" id="rsize"></div>
        </div>
        `;
        this._popup = shadowRoot.getElementById('popup');
        this._disabled = shadowRoot.getElementById('disabled');
        this._title = shadowRoot.getElementById('title');
        this._caption = shadowRoot.getElementById('text');
        this._r_resizeEl = shadowRoot.getElementById('r_rsize');
        this._r_resizeEl.onmousedown = this._reSizeWindow.bind(this, 'r');
        this._r_resizeEl.ontouchstart = this._reSizeWindow.bind(this, 'r');
        this._b_resizeEl = shadowRoot.getElementById('b_rsize');
        this._b_resizeEl.onmousedown = this._reSizeWindow.bind(this, 'b');
        this._b_resizeEl.ontouchstart = this._reSizeWindow.bind(this, 'b');
        this._resizeEl = shadowRoot.getElementById('rsize');
        this._resizeEl.onmousedown = this._reSizeWindow.bind(this, 'n');
        this._resizeEl.ontouchstart = this._reSizeWindow.bind(this, 'n');

        this.isMini = false;
        this._work = shadowRoot.getElementById('work');
        this._minimized = shadowRoot.getElementById('minimize');
        this._minimized.onclick = () => {
            this.mini = !this.mini;
        }

        this._close = shadowRoot.getElementById('closed');
        this._close.onclick = () => {
            this.close();
        }

        this.onmousedown = (e) => {
            if (e.needClickIgnode) return;
            this._upWindow();
        }
        this.onDefault = this.onDefault.bind(this);
        this.showtitle = true;
        this._borderthickness = 1;
        // this._minimize();
        this._upWindow();

    }

    get scale() {
        return this._scale;
    }
    set scale(value) {
        this._scale = Number(value);
        if (this._scale === 1) {
            this._popup.style.transformOrigin = '';
            this._popup.style.transform = '';
        } else {
            this._popup.style.transformOrigin = '0 0';
            this._popup.style.transform = `scale(${this._scale})`;
        }
    }

    get isvisible() {
        return this._isvisible;
    }
    set isvisible(value) {
        this._isvisible = value;
        this.style.visibility = this._toBool(value) ? '' : 'hidden';
    }

    /**
     * Ширина
     * @type {number}
     */
    get width() {
        return this._width;
    }
    set width(value) {
        this._width = value;
        const tmp = Number(value);
        if (tmp) {
            this._popup.style.width = this._setValueUnit(tmp);
            this._work.style.width = this._setValueUnit(tmp);
            this._calcSize();
        }
    }
    /**
     * Высота
     * @type {number}
     */
    get height() {
        return this._height;
    }
    set height(value) {
        this._height = value;
        const tmp = Number(value);
        if (tmp) {
            this._popup.style.height = this._setValueUnit(value);
            this._work.style.height = this._setValueUnit(value);
            this._calcSize();
        }
    }

    get minimized() {
        return this._mini;
    }
    set minimized(value) {
        this._mini = this._toBool(value);
        this._minimized.style.display = this._mini ? '' : 'none';
    }

    get closable() {
        return this._closable;
    }
    set closable(value) {
        this._closable = this._toBool(value);
        this._close.style.display = this._closable ? '' : 'none';
    }

    get showtitle() {
        return this._showtitle;
    }
    set showtitle(value) {
        this._showtitle = this._toBool(value);
        this._title.style.display = this._showtitle ? 'flex' : 'none';
        if (this._dragable && this._dnd && this._showtitle) {
            this._dnd.setDragZone(this._title);
        }
    }

    get title() {
        return this._titletext;

    }
    set title(value) {
        this._titletext = value;
        this._caption.innerText = value;
    }

    get modal() {
        return this._modal;
    }
    set modal(value) {
        this._modal = value;
        const mod = this._toBool(value);
        if (mod) {
            this.style.overflow = 'hidden';
            this.style.right = '0';
            this.style.bottom = '0';
            this.style.zIndex = '20000';
        } else {
            this.style.overflow = 'unset';
            this.style.right = 'unset';
            this.style.bottom = 'unset';
            this.style.zIndex = '10000';
        }

    }

    get dragable() {
        return this._dragable;
    }
    set dragable(value) {
        this._dragable = value;
        if (this._dragable) {
            if (!this._dnd && this._popup) {
                if (this._showtitle) {
                    this._dnd = new DragElement(this._popup, this._title, { controlPosition: this._boundsrestricted, scale: this._scale || 1 });
                } else {
                    this._dnd = new DragElement(this._popup, this._popup, { controlPosition: this._boundsrestricted, scale: this._scale || 1 });
                }
            }
        }
    }

    get titlefontcolor() {
        return this._titlefontcolor;
    }
    set titlefontcolor(v) {
        this._titlefontcolor = v;
        this._title.style.color = v;
    }

    get titlecolor() {
        return this._titlecolor;
    }
    set titlecolor(value) {
        this._titlecolor = value;
        this._title.style.backgroundColor = value;
        //if (!this.titlefontcolor) {
        const tmp = this.colorValues(value);
        if (tmp && this.colourIsLight(tmp[0], tmp[1], tmp[2])) {
            this._title.classList.remove("header_colored_black");
            this._title.classList.add("header_colored_white");
        } else {
            this._title.classList.remove("header_colored_white");
            this._title.classList.add("header_colored_black");
        }
        //}
    }

    get bordercolor() {
        return this._bordercolor;
    }
    set bordercolor(value) {
        this._bordercolor = value;
        this._popup.style.borderColor = value;
    }

    get borderthickness() {
        return this._borderthickness;
    }
    set borderthickness(value) {
        this._borderthickness = value;
        this._popup.style.borderWidth = `${value}px`;
    }

    get borderstyle() {
        return this.borderstyle;
    }
    set borderstyle(value) {
        this._borderstyle = value;
        const type = window._enums.BorderStyleType[value];
        switch (type) {
            case 0:
                this._popup.style.borderStyle = 'solid';
                break;
            case 1:
                this._popup.style.borderStyle = 'dashed';
                break;
            case 2:
                this._popup.style.borderStyle = 'dotted';
                break;
            case 3:
                this._popup.style.borderStyle = 'hidden';
                break;
        }
    }

    get opacity() {
        return this._opacity;
    }
    set opacity(value) {
        this._opacity = value;
        this._popup.style.opacity = Number(this._opacity) / 100;
    }

    get sizetocontent() {
        return this._sizetocontent;
    }
    set sizetocontent(value) {
        this._sizetocontent = window._enums.SizeToContentType[value];
    }

    get resize() {
        return this._resize;

    }
    set resize(value) {
        this._resize = this._toBool(value);
        if (this._resize) {
            this._resizeEl.style.display = 'block';
            this._b_resizeEl.style.display = 'block';
            this._r_resizeEl.style.display = 'block';
        } else {
            this._resizeEl.style.display = 'none';
            this._b_resizeEl.style.display = 'none';
            this._r_resizeEl.style.display = 'none';
        }
    }

    get mini() {
        return !this._miniState;
    }
    set mini(value) {
        this._miniState = !this._toBool(value);
        if (this._miniState) {
            this._work.style.display = 'block';
            this._popup.style.height = this.__popHeigiht;
            this._resizeEl.style.display = this.__popResize;
            this._b_resizeEl.style.display = this.__popResize;
            this._r_resizeEl.style.display = this.__popResize;
        } else {
            this._work.style.display = 'none';
            this.__popHeigiht = this._popup.style.height;
            this._popup.style.height = '';
            this.__popResize = this._resizeEl.style.display;
            this._resizeEl.style.display = 'none';
            this._b_resizeEl.style.display = 'none';
            this._r_resizeEl.style.display = 'none';
        }
    }

    get opendialogpoint() {
        return this._opendialogpoint;
    }
    set opendialogpoint(value) {
        this._opendialogpoint = Number(value);
    }

    get offsetx() {
        return this._offsetx;
    }
    set offsetx(value) {
        this._offsetx = value;
    }

    get offsety() {
        return this._offsety;
    }
    set offsety(value) {
        this._offsety = value;
    }

    get context() {
        return this._context;
    }
    set context(value) {
        this._context = value;

        const el = this._context.detail && this._context.detail.el ? this._context.detail.el : this._context.target || this._context.currentTarget;
        const elRect = el.getBoundingClientRect();

        const sh = Number(el.clientHeight);
        const sw = Number(el.clientWidth);
        const scaleH = elRect.height / sh;
        const scaleW = elRect.width / sw;

        this._context_scale = scaleH < scaleW ? scaleH : scaleW;
    }

    get shadowsize() {
        return this._shadowsize !== 'undefined' ? this._shadowsize : 3;
    }
    set shadowsize(value) {
        this._shadowsize = value;
        this._drawShadow();
    }

    get shadowcolor() {
        return typeof this._shadowcolor !== 'undefined' ? this._shadowcolor : 'rgba(35, 39, 76, 0.5)';
    }
    set shadowcolor(v) {
        this._shadowcolor = v;
        this._drawShadow();
    }

    get isenabled() {
        return this._isenabled;
    }
    set isenabled(value) {
        this._isenabled = this._toBool(value);
        this._disabled.style.display = this._isenabled ? 'none' : 'block';
    }

    get boundsrestricted() {
        return this._boundsrestricted;
    }
    set boundsrestricted(value) {
        this._boundsrestricted = this._toBool(value);
        this._dnd.option.controlPosition = this._boundsrestricted;
    }

    get default() {
        return this._default;
    }
    set default(value) {
        this._default = value;

        if (value) {
            document.addEventListener("keypress", this.onDefault);
        } else {
            document.removeEventListener("keypress", this.onDefault);
        }
    }

    get onclose() {
        return this._onclose;
    }
    set onclose(v) {
        this._onclose = v;
    }

    get maxwidth() {
        return this._maxwidth;
    }
    set maxwidth(value) {
        this._maxwidth = value;
        this._popup.style.maxWidth = `${value}px`;
    }

    onDefault(e) {
        if (e.key === 'Enter' && this._popup.classList.contains('active')) {
            e.preventDefault();
            this._default();
        }
    }

    _drawShadow() {
        if (this._shadowsize && this._shadowcolor) {
            this._popup.style.setProperty('--popup-shadow', `${this._shadowsize}px ${this._shadowsize}px 10px ${this._shadowcolor}`);
        } else {
            this._popup.style.setProperty('--popup-shadow', '0px 3px 10px rgba(35, 39, 76, 0.5)');
        }
    }

    disconnectedCallback() {
        super.disconnectedCallback();
        if (this._dnd) {
            this._dnd.dispose();
            delete this._dnd;
        }
        this._resizeEl.onmousedown = null;
        this._b_resizeEl.onmousedown = null;
        this._r_resizeEl.onmousedown = null;
        delete this._context
        document.removeEventListener("keypress", this.onDefault);
    }

    connectedCallback() {
        this.positionWindow();

        if (!this._toBool(this._dragable)) {
            this._popup.style.top = '';
            this._popup.style.left = '';
            this._popup.style.alignSelf = 'center';
            this.style.justifyContent = 'center';
        }

        if (!this.titlefontcolor) {
            this._title.style.color = 'white';
        }
    }

    positionWindow() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        let el, elRect;
        switch (this.opendialogpoint) {
            case 0:
                const target = this._context.currentTarget || this._context.target;
                el = this._context.detail && this._context.detail.el ? this._context.detail.el : target;
                elRect = el.getBoundingClientRect();
                this.setPosition(
                    elRect.left + elRect.width + this.offsetx * this._context_scale,
                    elRect.top + this.offsety * this._context_scale,
                    this._popup.offsetWidth,
                    this._popup.offsetHeight
                );
                break;
            case 1: // смещение от указателя
                const ev = this._context.detail && this._context.detail.pageX ? this._context.detail : this._context;
                this.setPosition(
                    ev.pageX + this.offsetx,
                    ev.pageY + this.offsety,
                    this._popup.offsetWidth,
                    this._popup.offsetHeight
                );
                break;
            case 2:
                this.setPosition(
                    this._offsetx,
                    this._offsety,
                    this._popup.offsetWidth,
                    this._popup.offsetHeight
                );
                break;
            case 3:
            default:
                const left = (width - this._popup.clientWidth) / 2;
                const top = (height - this._popup.clientHeight) / 2;
                this._popup.style.left = `${left}px`;
                this._popup.style.top = `${top}px`;
                break;
        }
    }
    setPosition(x, y, width, height) {
        if (this._boundsrestricted) {
            if (window.innerWidth < x + width) x = window.innerWidth - width - 2;
            if (x < 0) x = 0;
            if (window.innerHeight < y + height) y = window.innerHeight - height - 2;
            if (y < 0) y = 0;
        }
        this._popup.style.top = `${y}px`;
        this._popup.style.left = `${x}px`;
    }


    openWindow(obj) {
        this._clearWin();
        let param = "";
        const keys = Object.keys(obj);
        keys.forEach(key => {
            if (key !== 'windowTriggers') {
                param += ` ${key}="${obj[key]}"`;
            }
        });
        this.closeWin = this.close.bind(this);
        const win = `<ms-window${param} position='absolute'></ms-window>`;

        this.innerHTML = win;

        this._msWin = this.querySelector('ms-window');

        this._msWin.closeWin = this.close.bind(this);
        if (obj['windowTriggers'] && !this._msWin.windowTriggers) { //TODO
            this._msWin.windowTriggers = JSON.parse(JSON.stringify(obj.windowTriggers));
        }
        this._calcSize();
        this._upWindow();
        this.positionWindow();
        return this._msWin;
    }

    onResizeContent() {
        if (this.sizetocontent === 0) { //real size
            this._calcSize();
        }
    }

    _reSizeWindow(type, e) {
        if (e.targetTouches) e = e.targetTouches[0];
        if (this.sizetocontent === 0) {
            this.sizetocontent = window._enums.SizeToContentType.SetSize;
        }
        const mainCoords = this.getCoords(this._resizeEl);
        const shiftX = mainCoords.left + (e.pageX - mainCoords.left);
        const shiftY = mainCoords.top + (e.pageY - mainCoords.top);
        const scaleW = mainCoords.width / this._resizeEl.clientWidth;
        const scaleH = mainCoords.height / this._resizeEl.clientHeight;

        const popup_width = this._width = this._popup.clientWidth;
        const popup_height = this._height = this._popup.clientHeight;

        this._work.style.height = `100%`;
        this._work.style.width = `100%`;
        const mouseMove = (e) => {
            if (e.targetTouches) e = e.targetTouches[0];
            let newLeft = (e.pageX - shiftX) / scaleW;
            let newTop = (e.pageY - shiftY) / scaleH;

            if ((newLeft + popup_width) < (this._popup.clientLeft + 80)) {
                newLeft = 80 - popup_width;
            }
            if ((newTop + popup_height) < (this._popup.clientTop + 40)) {
                newTop = 40 - popup_height;
            }
            if (type !== 'r') {
                this._height = popup_height + newTop;
                this._popup.style.height = `${this._height}px`;
            }

            if (type !== 'b') {
                this._width = popup_width + newLeft;
                this._popup.style.width = `${this._width}px`;
            }

            this._calcSize();
        }

        const mouseUp = () => {
            document.removeEventListener('mousemove', mouseMove);
            document.removeEventListener('mouseup', mouseUp);
            document.removeEventListener('touchmove', mouseMove);
            document.removeEventListener('touchend', mouseUp);
        };

        document.addEventListener('touchmove', mouseMove);
        document.addEventListener('touchend', mouseUp);

        document.addEventListener('mousemove', mouseMove);
        document.addEventListener('mouseup', mouseUp);

        return false;
    }

    getCoords(elem) {
        var box = elem.getBoundingClientRect();
        return {
            top: box.top + pageYOffset,
            left: box.left + pageXOffset,
            width: box.width,
            height: box.height
        };
    }

    _calcSize() {
        if (!this._msWin) {
            this._work.style.height = this._setValueUnit(this.height);
            this._work.style.width = this._setValueUnit(this.width);
            return;
        }
        switch (this._sizetocontent) {
            case window._enums.SizeToContentType.RealSize:
                this._msWin.style.transform = '';
                this._msWin.style.transformOrigin = '';
                this._work.style.overflow = '';
                this._msWin.style.position = 'relative';
                this._work.style.height = this._setValueUnit(this._msWin.offsetHeight);
                this._work.style.width = this._setValueUnit(this._msWin.offsetWidth);

                this._popup.style.height = this._setValueUnit(this._msWin.offsetHeight + 20);
                this._popup.style.width = this._setValueUnit(Number(this._msWin.offsetWidth));
                break;
            default:
            case window._enums.SizeToContentType.SetSize:
                this._msWin.style.overflow = '';
                this._calcScale();
                this._work.style.overflow = '';
                this._msWin.style.position = 'relative';
                break;
            case window._enums.SizeToContentType.Crop:
                this._msWin.style.transform = ``;
                this._msWin.style.transformOrigin = '';
                this._work.style.overflow = 'hidden';
                this._msWin.style.position = 'relative';
                this._work.style.width = this._setValueUnit(this._width);
                this._work.style.height = this._setValueUnit(this._height);
                break;
            case window._enums.SizeToContentType.Scroll:
                this._msWin.style.transform = ``;
                this._msWin.style.transformOrigin = '';
                this._work.style.overflow = 'auto';
                this._msWin.style.position = 'relative';
                break;
        }
    }

    _calcScale() {
        const scY = Number(this._msWin.height);
        const scaleY = Number(this.height - 22) / scY;

        const scX = Number(this._msWin.width);
        const scaleX = Number(this.width - 2) / scX;
        const scale = scaleX > scaleY ? scaleY : scaleX;


        if (scale != 1) {
            if (this._msWin._proportiontype == 0) {
                this._msWin.style.transform = `scale(${scaleX},${scaleY})`;
            } else {
                this._msWin.style.transform = `scale(${scale})`;
            }
            this._msWin.style.transformOrigin = '0 0';
        } else {
            this._msWin.style.transform = ``;
            this._msWin.style.transformOrigin = '';
        }
    }

    _minimize() {
        this._work.style.display = this._mini ? 'none' : 'block';
    }

    close() {
        if (this._onclose) this._onclose();
        this._close.onclick = null;
        this._minimized.onclick = null;
        this.onmousedown = null;
        if (this._msWin) this._msWin.remove();
        delete this._msWin;
        $WinService.removeWindow(this);
    }

    /**
     * Очистка окна
     *
     * @memberof MSPopUpWindow
     */
    _clearWin() {
        while (this.firstChild) {
            this.removeChild(this.firstChild);
        }
    }

    /**
     * Установка приоритета окана на самый верх
     *
     * @memberof MSPopUpWindow
     */
    _upWindow() {
        if (!this.parentNode) return;
        this.parentNode.childNodes.forEach(element => {
            if (element.nodeName == 'MS-POPUP') {
                if (element !== this) {
                    element.style.zIndex = element.modal ? '10002' : '10000';
                    if (!element.modal) element._popup.classList.remove('active');
                } else {
                    element.style.zIndex = element.modal ? '10003' : '10001';
                    element._popup.classList.add('active');
                }
            }
        });
    }

    colorValues(color) {
        if (!color)
            return;
        if (color.toLowerCase() === 'transparent')
            return [0, 0, 0, 0];
        if (color[0] === '#') {
            if (color.length < 7) {
                color = '#' + color[1] + color[1] + color[2] + color[2] + color[3] + color[3] + (color.length > 4 ? color[4] + color[4] : '');
            }
            return [parseInt(color.substr(1, 2), 16),
            parseInt(color.substr(3, 2), 16),
            parseInt(color.substr(5, 2), 16),
            color.length > 7 ? parseInt(color.substr(7, 2), 16) / 255 : 1];
        }
        if (color.indexOf('rgb') === -1) {
            var temp_elem = document.body.appendChild(document.createElement('fictum'));
            var flag = 'rgb(1, 2, 3)';
            temp_elem.style.color = flag;
            if (temp_elem.style.color !== flag) {
                document.body.removeChild(temp_elem);
                return;
            }
            temp_elem.style.color = color;
            if (temp_elem.style.color === flag || temp_elem.style.color === '') {
                document.body.removeChild(temp_elem);
                return;
            }
            color = getComputedStyle(temp_elem).color;
            document.body.removeChild(temp_elem);
        }
        if (color.indexOf('rgb') === 0) {
            if (color.indexOf('rgba') === -1)
                color += ',1';
            return color.match(/[\.\d]+/g).map((a) => {
                return +a
            });
        }
    }

    colourIsLight(r, g, b) {
        var a = 1 - (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        return (a < 0.5);
    }
}
