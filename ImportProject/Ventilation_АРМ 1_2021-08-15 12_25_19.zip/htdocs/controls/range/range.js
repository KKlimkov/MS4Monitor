"use strict";
import { Basic } from "../basic.js";
import { getFormattedValue } from "../../lib/utils.js";
/**
 * @class MSRange
 * @extends Basic
 * @classdesc ��������������/������������ �������� ���������
 * */
export class MSRange extends Basic {

    static get observedAttributes() {
        return super.observedAttributes.concat([
            'orientation',
            'minvalue',
            'maxvalue',
            'min',
            'max',
            'forecolor',
            'foreborderwidth',
            'foreborderfill',
            'incrementstep',
            'precision',
            'locksize'
        ]);
    }

    constructor() {
        super();
        this.shRoot = this.attachShadow({ mode: 'closed' });
        this.shRoot.innerHTML = `
            <style>
                :host .range {
                    user-select: none;
                    position: relative;
                    width: 100%;
                    height: 100%;
                    background-color: yellowgreen;
                    box-sizing: border-box;
                }
                :host .thumb-container {
                    user-select: none;
                    display: flex;
                    position: absolute;
                    width: 20px;
                    height: 100%;
                    box-sizing: border-box;
                    cursor: pointer;
                }
                :host .thumb-pseudo {
                    user-select: none;
                    background-color: #ebe6c0;
                    opacity: 0;
                    position: absolute;
                    filter: contrast(0.5);
                    cursor: move;
                }
                :host .thumb-pseudo:hover {
                    opacity: 1;
                }
                :host .thumb {
                    user-select: none;
                    background-color: burlywood;
                    width: 100%;
                    height: 100%;
                    box-sizing: border-box;
                }
                :host .thumb:hover {
                    cursor: pointer;
                }
                :host .thumb-pseudo-horiz {
                    width: 5px;
                    height: 100%;
                }
                :host #thumb-before.thumb-pseudo-horiz {
                    left: -5px;
                    bottom: auto;
                }
                :host .thumb-pseudo-vert {
                    width: 100%;
                    height: 5px;
                }
                :host #thumb-before.thumb-pseudo-vert {
                    bottom: -5px;
                    left: auto;
                }
                :host .thumb-pseudo-horiz {
                    cursor: w-resize;
                }
                :host .thumb-pseudo-vert {
                    cursor: s-resize;
                }
                :host .view-value {
                    display: none;
                    position: absolute;
                    font-size: 10px;
                    white-space: nowrap;
                    padding: 1px;
                    z-index: 99999;
                    border: solid 1px #5e5e5e;
                    background-color: #ccf58c;
                }
                :host .toggle-view .view-value {
                    display: block;
                }
                :host .toggle-view-ps .thumb-pseudo {
                    opacity: 1;
                }
            </style>
            <div class="range">
                <div class="thumb-container">
                    <div id="min-value" class="view-value"></div>
                    <div id="thumb-before" class="thumb-pseudo"></div>
                    <div id="thumb" class="thumb"></div>
                    <div id="thumb-after" class="thumb-pseudo"></div>
                    <div id="max-value" class="view-value"></div>
                </div>
            </div>
        `;

        this.style.overflow = 'visible';
        this._range = this.shRoot.querySelector('.range');
        this._thumbContainer = this.shRoot.querySelector('.thumb-container');
        this._thumb = this.shRoot.querySelector('#thumb');
        this._thumbBefore = this.shRoot.querySelector('#thumb-before');
        this._thumbAfter = this.shRoot.querySelector('#thumb-after');
        this._minValSpan = this.shRoot.querySelector('#min-value');
        this._maxValSpan = this.shRoot.querySelector('#max-value');

        this._shiftPseudo = -5;
        this._startCoords = {};
        this._new = {};
        this._inView = false;
        this._format = '';
        this._inc = 0;
        this._MIN_SIZE = 17;
        this._shiftViewBlock = -16;
        this._incrementstep = 1;

        this._onDocumentThumbMouseMove = this._onDocumentThumbMouseMove.bind(this);
        this._onDocumentThumbMouseUp = this._onDocumentThumbMouseUp.bind(this);
        this._onThumbMouseDown = this._onThumbMouseDown.bind(this);
        this._onThumbBeforeMouseMove = this._onThumbBeforeMouseMove.bind(this);
        this._onThumbMouseMove = this._onThumbMouseMove.bind(this);
        this._onThumbAfterMouseMove = this._onThumbAfterMouseMove.bind(this);
        this._onRangeWheel = this._onRangeWheel.bind(this);
        this._request = this._request.bind(this);
        this._onThumbMouseOver = this._onThumbMouseOver.bind(this);
        this._onThumbMouseOut = this._onThumbMouseOut.bind(this);
        this._onThumbConteinerMouseEnter = this._onThumbConteinerMouseEnter.bind(this);
        this._onThumbContainerMouseLeave = this._onThumbContainerMouseLeave.bind(this);
        this._onThumBoxMouseUp = this._onThumBoxMouseUp.bind(this);

        //this._rangeEvent = new CustomEvent('changerange');
        this._minvalue = 100;
        this._maxvalue = 150;
        this._min = 0;
        this._max = 200;
        this._precision = 0;
        this.backgroundcolor = "rgb(245,240,245)";
        this.forecolor = "rgb(191,191,191)";
        this.foreborderwidth = 1;
        this.foreborderfill = "BLACK";
    }

    get orientation() {
        return this._orientation;
    }
    set orientation(value) {
        this._orientation = value;
        const locksize = this._toBool(this.getAttribute('locksize'));
        if (locksize) return;
        if (value == 1) {
            this._toggleSizeRange(value);
            this._thumbBefore.classList.remove('thumb-pseudo-horiz');
            this._thumbAfter.classList.remove('thumb-pseudo-horiz');
            this._thumbBefore.classList.add('thumb-pseudo-vert');
            this._thumbAfter.classList.add('thumb-pseudo-vert');
            this._side = 'top';
        } else {
            this._toggleSizeRange(value);
            this._thumbBefore.classList.add('thumb-pseudo-horiz');
            this._thumbAfter.classList.add('thumb-pseudo-horiz');
            this._thumbBefore.classList.remove('thumb-pseudo-vert');
            this._thumbAfter.classList.remove('thumb-pseudo-vert');
            this._side = 'right';
        }
        this._initPositionViewBlock();
        this._setThumbValue();
    }
    get format() {
        return this._format;
    }
    set format(value) {
        this._format = value;
    }
    get precision() {
        return this._precision || 0;
    }
    set precision(value) {
        value = Number(value);
        this._precision = value;
    }

    get incrementstep() {
        return this._incrementstep !== undefined ? this._incrementstep : 1;
    }
    set incrementstep(value) {
        value = Number(value);
        if (isNaN(value)) {
            return;
        }
        this._incrementstep = value;
        // if (this._maxvalue - value >= this._min) {
        //     this._incrementstep = value;
        //     if (this._maxvalue - this._minvalue < value) {
        //         this.SetParameter('minvalue', this._maxvalue - value);
        //     }
        // } else if (this._minvalue + value <= this._max) {
        //     this._incrementstep = value;
        //     if (this._maxvalue - this._minvalue < value) {
        //         this.SetParameter('maxvalue', this._minvalue + value);
        //     }
        // }
    }

    get min() {
        return this._min;
    }
    set min(value) {
        value = Number(value);
        if (!isNaN(value) && !this._inView) {
            this._min = value;
            if (this._min + this.incrementstep <= this._max) {
                this._setThumbValue();
            }
        }
    }

    get max() {
        return this._max;
    }
    set max(value) {
        value = Number(value);
        if (!isNaN(value) && !this._inView) {
            this._max = value;
            if (this._max - this.incrementstep >= this._min) {
                this._setThumbValue();
            }
        }
    }

    get minvalue() {
        return this._minvalue;
    }
    set minvalue(value) {
        value = Number(value);
        if (!isNaN(value) && !this._inView) {
            this._minvalue = value;
            if (value >= this.min && value + this.incrementstep <= this.maxvalue) {
                this._setThumbValue();
            }
        }
    }

    get maxvalue() {
        return this._maxvalue;
    }
    set maxvalue(value) {
        value = Number(value);
        if (!isNaN(value) && !this._inView) {
            this._maxvalue = value;
            if (value <= this.max && value - this.incrementstep >= this.minvalue) {
                this._setThumbValue();
            }
        }
    }

    get width() {
        return this._width;
    }
    set width(value) {
        this._width = value;
        const tmp = Number(value);
        if (tmp) {
            this.style.width = this._setValueUnit(value);
        }
        this._setThumbValue();
    }

    get height() {
        return this._height;
    }
    set height(value) {
        this._height = value;
        const tmp = Number(value);
        if (tmp) {
            this.style.height = this._setValueUnit(value);
        }
        this._setThumbValue();
    }

    get forecolor() {
        return this._forecolor;
    }
    set forecolor(value) {
        this._forecolor = value;
        if (value && typeof value === 'string') {
            this._backgroundcolor = value;
            if (value.indexOf(' ') !== -1) {
                this._thumb.style.background = this._calcGradient(value);
                this._thumbBefore.style.background = this._calcGradient(value);
                this._thumbAfter.style.background = this._calcGradient(value);
            } else {
                this._thumb.style.backgroundColor = value;
                this._thumbBefore.style.backgroundColor = value;
                this._thumbAfter.style.backgroundColor = value;
            }
        }
    }

    get foreborderwidth() {
        return this._foreborderwidth || 0;
    }
    set foreborderwidth(value) {
        value = Number(value);
        if (!isNaN(value)) {
            this._foreborderwidth = value;
            this._thumb.style.borderStyle = value ? 'solid' : 'none';
            this._thumb.style.borderWidth = this._setValueUnit(value);
            this._leftCoord = this._shiftPseudo - this._foreborderwidth * 2;
            this._setThumbValue();
        }
    }

    get borderthickness() {
        return parseInt(this.style.borderWidth, 10) || 0;
    }
    set borderthickness(value) {
        super.borderthickness = value;
        this._setThumbValue();
    }

    get foreborderfill() {
        return this._foreborderfill;
    }
    set foreborderfill(value) {
        this._foreborderfill = value;
        this._thumb.style.borderColor = value;
    }

    get backgroundcolor() {
        return this._backgroundcolor;
    }
    set backgroundcolor(value) {
        this._backgroundcolor = value;
        if (value && typeof value === 'string') {
            this._backgroundcolor = value;
            if (value.indexOf(' ') !== -1) {
                this._range.style.background = this._calcGradient(value);
            } else {
                this._range.style.backgroundColor = value;
            }
        }
    }

    set resource(value) {
        if (value) {
            value = this._resource = this.getResourceFromList(value);
            if (value.toLocaleLowerCase().endsWith('svg')) {
                this._svgResource = true;
                this.style.borderWidth = 0;
            }
            this._calcBacgraund(this._range);
            this._calcBlockShadow();
        } else {
            this._range.style.backgroundImage = ``;
        }
    }
    set backgroundtile(value) {
        this._backgroundtile = window._enums.TileType[value];
        if (this._resource && this._resource != "") {
            this._calcBacgraund(this._range);
        }
    }

    inTrend(format) {
        this._format = format || '';
        this._inTrend = true;
        this._minvalue = 0;
        this._maxvalue = 0;
        this._min = 0;
        this._max = 0;
        //this._rangeEvent = new CustomEvent('changerange');
    }

    outTrend() {
        this._format = '';
        this._inTrend = false;
    }

    connectedCallback() {
        const locksize = this._toBool(this.getAttribute('locksize'));
        this._thumb.addEventListener('mousedown', this._onThumbMouseDown);
        this._thumb.addEventListener('touchstart', this._onThumbMouseDown);

        if (!locksize) {
            this._thumbBefore.addEventListener('mousedown', this._onThumbMouseDown);
            this._thumbBefore.addEventListener('touchstart', this._onThumbMouseDown);
            this._thumbAfter.addEventListener('mousedown', this._onThumbMouseDown);
            this._thumbAfter.addEventListener('touchstart', this._onThumbMouseDown);
        }

        this._range.addEventListener('wheel', this._onRangeWheel);
        this._thumbContainer.addEventListener('mouseover', this._onThumbMouseOver);
        this._thumbContainer.addEventListener('mouseout', this._onThumbMouseOut);
        this._thumbContainer.addEventListener('mouseenter', this._onThumbConteinerMouseEnter);
        this._thumbContainer.addEventListener('mouseleave', this._onThumbContainerMouseLeave);
        this._thumbContainer.addEventListener('mouseup', this._onThumBoxMouseUp);
        this._setThumbValue();
    }

    disconnectedCallback() {
        super.disconnectedCallback();
        this._thumb.removeEventListener('mousedown', this._onThumbMouseDown);
        this._thumb.removeEventListener('touchstart', this._onThumbMouseDown);
        this._thumbBefore.removeEventListener('mousedown', this._onThumbMouseDown);
        this._thumbBefore.removeEventListener('touchstart', this._onThumbMouseDown);
        this._thumbAfter.removeEventListener('mousedown', this._onThumbMouseDown);
        this._thumbAfter.removeEventListener('touchstart', this._onThumbMouseDown);
        this._range.removeEventListener('wheel', this._onRangeWheel);
        this._thumbContainer.removeEventListener('mouseover', this._onThumbMouseOver);
        this._thumbContainer.removeEventListener('mouseout', this._onThumbMouseOut);
        this._thumbContainer.removeEventListener('mouseenter', this._onThumbConteinerMouseEnter);
        this._thumbContainer.removeEventListener('mouseleave', this._onThumbContainerMouseLeave);
        this._thumbContainer.removeEventListener('mouseup', this._onThumBoxMouseUp);

        delete this._onDocumentThumbMouseMove
        delete this._onDocumentThumbMouseUp
        delete this._onThumbMouseDown
        delete this._onThumbBeforeMouseMove
        delete this._onThumbMouseMove
        delete this._onThumbAfterMouseMove
        delete this._onRangeWheel
        delete this._request
        delete this._onThumbMouseOver
        delete this._onThumbMouseOut
        delete this._onThumbConteinerMouseEnter
        delete this._onThumbContainerMouseLeave
        delete this._onThumBoxMouseUp
    }

    _showCurrentParams(minval, maxval) {
        if (this._inTrend) {
            this._minValSpan.innerText = this._format
                ? getFormattedValue(this._format, minval)
                : this._adjustValue(minval);
        } else {
            this._minValSpan.innerText = this._adjustValue(minval);
        }
        if (this._inTrend) {
            this._maxValSpan.innerText = this._format
                ? getFormattedValue(this._format, maxval)
                : this._adjustValue(maxval);
        } else {
            this._maxValSpan.innerText = this._adjustValue(maxval);
        }
    }

    _initPositionViewBlock() {
        const { width: maxWidth, height: maxHeight } = this._maxValSpan.getBoundingClientRect();
        const { width: minWidth, height: minHeight } = this._minValSpan.getBoundingClientRect();
        this._label = {
            max: {
                width: maxWidth,
                height: maxHeight
            },
            min: {
                width: minWidth,
                height: minHeight
            }
        }
        this._maxValSpan.style.top = this._shiftViewBlock + 'px';
        if (this._orientation == 1) {
            this._minValSpan.style.bottom = this._shiftViewBlock + 'px';
            this._minValSpan.style.left = '0';
            this._minValSpan.style.transform = `translateX(-100%)`;
            this._maxValSpan.style.transform = `translateX(-100%)`;
            this._maxValSpan.style.right = '';
        } else {
            this._minValSpan.style.top = this._shiftViewBlock + 'px';
            this._minValSpan.style.right = '';
            this._minValSpan.style.transform = `translateX(-100%)`;
            this._maxValSpan.style.right = '0';
            this._maxValSpan.style.transform = `translateX(100%)`;
        }
    }

    _onThumbConteinerMouseEnter() {
        this._thumb.style.opacity = '0.5';
        this._range.classList.add('toggle-view');
        const { ticksOnPx } = this._getTicks();
        this._ticksOnPx = ticksOnPx;
        const minSize = this._MIN_SIZE < this.foreborderwidth * 2 ? this.foreborderwidth * 2 : this._MIN_SIZE;
        this._calcScale();
        this._showCurrentParams(this._minvalue, this._maxvalue);
        this._initPositionViewBlock();
        this._calcViewCoords(this._minvalue, this._maxvalue);
    }

    _onThumbContainerMouseLeave() {
        if (!this._inView) {
            this._range.classList.remove('toggle-view');
            this._thumb.style.opacity = '1';
        }
    }

    _onThumbMouseOver(evt) {
        evt.stopPropagation();
        evt.target.id === 'thumb'
            ? this._range.classList.add('toggle-view-ps')
            : this._range.classList.remove('toggle-view-ps');
    };

    _onThumbMouseOut(evt) {
        evt.stopPropagation();
        this._range.classList.remove('toggle-view-ps');
    };

    _onRangeWheel(evt) {
        if (this._inTrend) {
            return false;
        }
        const { ticksOnPx } = this._getTicks();
        const size = (this._maxvalue - this._minvalue) / this._ticksOnPx;
        this._koef = this._incrementstep * size * 0.01;
        const delta = evt.wheelDelta;
        if (delta > 0) {
            if (this._minvalue + this.incrementstep >= this._maxvalue) {
                this._minvalue = this._maxvalue - this.incrementstep;
                this._inc = 0;
                return false;
            }
            if (this._inc < this._incrementstep) {
                this._downwheel = false;
            }
            if (this._downwheel) {
                this._inc -= this._koef;
            } else {
                this._upwheel = true;
                this._inc += this._koef;
            }
            if (this._minvalue + this._inc > this._maxvalue) {
                this._minvalue = this._maxvalue;
            } else {
                this._minvalue += this._inc;
                this._maxvalue -= this._inc;
            }
            if (this._minvalue + this.incrementstep > this._maxvalue) {
                this._minvalue = this._maxvalue - this.incrementstep;
            }
        } else {
            if (this._minvalue <= this._min) {
                this._minvalue = this._min;
                this._limitLeftWheel = true;
            } else {
                this._limitLeftWheel = false;
            }
            if (this._maxvalue >= this._max) {
                this._maxvalue = this._max;
                this._limitRightWheel = true;
            } else {
                this._limitRightWheel = false;
            }
            if (this._limitLeftWheel && this._limitRightWheel) {
                return false;
            }
            if (this._inc < this._incrementstep) {
                this._upwheel = false;
            }
            if (this._upwheel) {
                this._inc -= this._koef;
            } else {
                this._downwheel = true;
                this._inc += this._koef;
            }
            this._minvalue -= this._inc;
            this._maxvalue += this._inc;
            if (this._minvalue < this._min) {
                this._minvalue = this._min;
            }
            if (this._maxvalue > this._max) {
                this._maxvalue = this._max;
            }
        }
        this._showCurrentParams(this._minvalue, this._maxvalue);
        this._calcViewCoords(this._minvalue, this._maxvalue);
        this._requestId = requestAnimationFrame(this._request);
        return false;
    }

    _toggleSizeRange(orientation) {
        if (!this.rootOrientation) {
            this.rootOrientation = `${orientation}`;
            return;
        }
        const width = parseFloat(this.style.width);
        const height = parseFloat(this.style.height);
        this.width = height;
        this.height = width;
        this._thumbAfter.style[this._side] = '';
    }

    _changeValueState() {
        if (this.maxvalue < this._minvalue) {
            this._isEventChangeSize = true;
            this.SetParameter('maxvalue', this._minvalue);
            this._isEventChangeSize = false;
        }
    }

    _adjustValue(value) {
        if (!this._isNumeric(value)) {
            return 0;
        }
        if (value % 1 !== 0 && this._precision != undefined) {
            let symLength = (this._precision != undefined) ? this._precision : 0;
            const roundedVal = Number(value).toFixed(symLength);
            value = Number(roundedVal).toString();
        }
        return Number(value);
    }

    _onThumbMouseDown(evt) {
        if (evt.type != 'touchstart' && evt.which !== window._enums.ButtonKeyCode.MOUSE_LEFT) {
            return false;
        }
        this._initPositionViewBlock();
        this._inView = true;
        this._boxMouseUp = false;
        this._calcScale();
        cancelAnimationFrame(this._requestId);
        this._onDocThumbMouseMove = null;
        const delta = this._maxvalue - this._minvalue;
        if (delta < 0 || this._max - this.incrementstep <= this._min) {
            this._inView = false;
            return false;
        }
        switch (evt.target.id) {
            case 'thumb-before': this._onDocThumbMouseMove = this._onThumbBeforeMouseMove;
                this._isThumbBefore = true;
                break;
            case 'thumb': this._onDocThumbMouseMove = this._onThumbMouseMove;
                this._isThumb = true;
                break;
            case 'thumb-after': this._onDocThumbMouseMove = this._onThumbAfterMouseMove;
                this._isThumbAfter = true;
                break;
        }
        const { ticksOnPx } = this._getTicks();
        this._ticksOnPx = ticksOnPx;
        const minSize = this._MIN_SIZE < this.foreborderwidth * 2 ? this.foreborderwidth * 2 : this._MIN_SIZE;
        document.addEventListener('mousemove', this._onDocumentThumbMouseMove);
        document.addEventListener('mouseup', this._onDocumentThumbMouseUp);
        document.addEventListener('touchmove', this._onDocumentThumbMouseMove);
        document.addEventListener('touchend', this._onDocumentThumbMouseUp);
        this._startCoords = {
            x: typeof evt.clientX === 'undefined' ? evt.changedTouches[0].clientX : evt.clientX,
            y: typeof evt.clientY === 'undefined' ? evt.changedTouches[0].clientY : evt.clientY,
            minView: minSize * this._ticksOnPx,
            minvalue: this._minvalue,
            delta: delta,
            right: this._max - delta,
        };
    }

    _calcScale() {
        if (this._scale) {
            return;
        }
        let size;
        if (this.angle && this.angle != 0) {
            const div = document.createElement('div');
            div.style.opacity = '0';
            div.style.width = this.width;
            div.style.height = this.height;
            this.parentElement.appendChild(div);
            size = div.getBoundingClientRect();
            div.remove();
        } else {
            size = this.getBoundingClientRect();
        }
        this._scale = {
            x: size.width / this.width,
            y: size.height / this.height
        };
    }

    _checkNewThumbValue(min, max, value) {
        if (value < min) {
            value = min;
        }
        if (value > max) {
            value = max;
        }
        return value;
    }

    _getShift(evt) {
        let coord;
        const clientX = typeof evt.clientX === 'undefined' ? evt.changedTouches[0].clientX : evt.clientX;
        const clientY = typeof evt.clientY === 'undefined' ? evt.changedTouches[0].clientY : evt.clientY;
        this._shift = {
            x: (this._startCoords.x - clientX) / this._scale.x * this._ticksOnPx,
            y: (this._startCoords.y - clientY) / this._scale.y * this._ticksOnPx
        };
        const angle = (this._rotate || 0) % 360;
        if (angle === 0) {
            coord = (this._orientation == 1) ? -this._shift.y : this._shift.x;
        } else if (angle === 90 || angle === -270) {
            coord = (this._orientation == 1) ? this._shift.x : this._shift.y;
        } else if (angle === 270 || angle === -90) {
            coord = (this._orientation == 1) ? -this._shift.x : -this._shift.y;
        } else if (angle === 180 || angle === -180) {
            coord = (this._orientation == 1) ? this._shift.y : -this._shift.x;
        } else {
            const rad = Math.cos(angle * Math.PI / 180);
            coord = (this._orientation == 1) ? (-this._shift.y / rad) : (this._shift.x / rad);
        }
        return coord;
    }

    _onDocumentThumbMouseMove(evt) {
        this._currentShift = this._getShift(evt);
        this._onDocThumbMouseMove();
        this._setThumbValue(this._new.minvalue, this._new.maxvalue);
        if (this._inView) {
            this._showCurrentParams(this._new.minvalue, this._new.maxvalue);
            this._calcViewCoords();
        }
    }

    _onThumbBeforeMouseMove() {
        this._new.minvalue = this._checkNewThumbValue(this._min, this._maxvalue - this.incrementstep, this._startCoords.minvalue - this._currentShift);
        this._new.maxvalue = this._maxvalue;
    }

    _onThumbMouseMove() {
        this._new.minvalue = this._checkNewThumbValue(this._min, this._startCoords.right, this._startCoords.minvalue - this._currentShift);
        this._new.maxvalue = this._new.minvalue + this._startCoords.delta;
    }

    _onThumbAfterMouseMove() {
        this._new.maxvalue = this._checkNewThumbValue(this._minvalue + this.incrementstep, this._max, (this._startCoords.minvalue + this._startCoords.delta) - this._currentShift);
        this._new.minvalue = this._minvalue;
    }

    _calcViewCoords(minval = this._new.minvalue, maxval = this._new.maxvalue) {
        if (!this._scale) {
            return;
        }
        const maxWidth = this._label.max.width / this._scale.x;
        const minWidth = this._label.min.width / this._scale.x;
        const deltmax = (this._max - maxval) / this._ticksOnPx;
        const deltmin = (minval - this._min) / this._ticksOnPx;
        const deltmaxmin = (this._max - minval) / this._ticksOnPx;
        const deltminmax = (maxval - this._min) / this._ticksOnPx;

        const deltaMax = maxWidth - deltmax;
        if (deltaMax > 0 && this._orientation == '0') {
            this._maxValSpan.style.transform = `translateX(calc(100% - ${deltaMax}px))`;
        }
        const deltaMin = minWidth - deltmin;
        if (deltaMin > 0 && this._orientation == '0') {
            this._minValSpan.style.transform = `translateX(calc(-100% + ${deltaMin}px))`;
        }
        const shiftMin = maxWidth - deltmaxmin;
        if (shiftMin > 0 && this._orientation == '0') {
            this._minValSpan.style.transform = `translateX(calc(-100% - ${shiftMin}px))`;
        }
        const shiftMax = minWidth - deltminmax;
        if (shiftMax > 0 && this._orientation == '0') {
            this._maxValSpan.style.transform = `translateX(calc(100% + ${shiftMax}px))`;
        }
    }

    _getIncrementValue(newVal, secondValue, min = this._min, max = this._max) {
        let isMinus = (newVal - secondValue < 0);
        let maxStep = Math.round(Math.abs((newVal - secondValue) / this.incrementstep));
        let firstValue = isMinus
            ? secondValue - maxStep * this.incrementstep
            : secondValue + maxStep * this.incrementstep;
        if (firstValue < min) {
            firstValue = min;
            let summ = firstValue + this.incrementstep;
            secondValue = (summ > secondValue) ? summ : secondValue;
        }
        if (firstValue > max) {
            firstValue = max;
            let summ = firstValue - this.incrementstep;
            secondValue = (summ < secondValue) ? summ : secondValue;
        }
        return { firstValue, secondValue };
    }

    _onThumBoxMouseUp(evt) {
        const box = evt.target.closest('.thumb-container');
        if (box) {
            this._boxMouseUp = true;
        }
    }

    _onDocumentThumbMouseUp(evt) {
        this._inView = false;
        if (!this._boxMouseUp) {
            this._range.classList.remove('toggle-view');
            this._thumb.style.opacity = '1';
        }
        if (this._isThumb && !this._currentShift) {
            this._isThumb = false;
            document.removeEventListener('mousemove', this._onDocumentThumbMouseMove);
            document.removeEventListener('mouseup', this._onDocumentThumbMouseUp);
            document.removeEventListener('touchmove', this._onDocumentThumbMouseMove);
            document.removeEventListener('touchend', this._onDocumentThumbMouseUp);
            return;
        }
        if (this._isThumbBefore) {
            const values = this._getIncrementValue(this._new.minvalue, this._new.maxvalue);
            this._new.minvalue = values.firstValue;
            this._new.maxvalue = values.secondValue;
        } else if (this._isThumbAfter) {
            const values = this._getIncrementValue(this._new.maxvalue, this._new.minvalue);
            this._new.minvalue = values.secondValue;
            this._new.maxvalue = values.firstValue;
        }
        const currmin = this._adjustValue(this._new.minvalue);
        const currmax = this._adjustValue(this._new.maxvalue);

        this._isEventChangeSize = true;
        this.SetParameter('minvalue', currmin);
        this.SetParameter('maxvalue', currmax);
        this._isEventChangeSize = false;

        this.updateRange && this.updateRange();
        
        this._setThumbValue(currmin, currmax);
        this._showCurrentParams(currmin, currmax);
        this._calcViewCoords();
        this._isThumbBefore = false;
        this._isThumb = false;
        this._isThumbAfter = false;
        document.removeEventListener('mousemove', this._onDocumentThumbMouseMove);
        document.removeEventListener('mouseup', this._onDocumentThumbMouseUp);
        document.removeEventListener('touchmove', this._onDocumentThumbMouseMove);
        document.removeEventListener('touchend', this._onDocumentThumbMouseUp);
    }

    _setCoordsBorder(currentWidth) {
        this._thumbAfter.style[this._side] = (currentWidth < 1) ? `${this._leftCoord}px` : `-5px`;
    }

    _getTicks() {
        const blockSize = ((this._orientation == 1) ? this._height : this._width) - this.borderthickness * 2;
        const ticksOnPx = (this._max - this._min) / blockSize;
        return { ticksOnPx, blockSize };
    }

    _getNewParam(minvalue, maxvalue) {
        const minSize = this._MIN_SIZE < this.foreborderwidth * 2 ? this.foreborderwidth * 2 : this._MIN_SIZE;
        const { ticksOnPx } = this._getTicks();
        const delta = this.max - this.min + minSize * ticksOnPx;
        let perCoord = (minvalue - this.min) / (delta / 100);
        if (perCoord > 100) perCoord = 100;
        if (perCoord < 0) perCoord = 0
        let perSize = (maxvalue - minvalue) / (delta / 100);
        const minSizeTicks = minSize * ticksOnPx / (delta / 100);
        perSize += minSizeTicks;
        if (perSize + perCoord > 100) {
            perCoord = 100 - perSize;
        }
        return {
            coord: `${perCoord}%`,
            size: `${perSize}%`
        };
    }

    _request(time) {
        this._setThumbValue();
    }

    _setThumbValue(minvalue = this._minvalue, maxvalue = this._maxvalue) {
        if (this._min != undefined &&
            this._max != undefined &&
            this._width != undefined &&
            this._minvalue != undefined &&
            this._maxvalue != undefined &&
            this._height != undefined) {

            const param = this._getNewParam(minvalue, maxvalue);
            if (this._orientation == 1) {
                this._thumbContainer.style.bottom = param.coord;
                this._thumbContainer.style.height = param.size;
                this._thumbContainer.style.left = '0px';
                this._thumbContainer.style.width = '100%';
            } else {
                this._thumbContainer.style.left = param.coord;
                this._thumbContainer.style.width = param.size;
                this._thumbContainer.style.bottom = '0px';
                this._thumbContainer.style.height = '100%';
            }
            this._setCoordsBorder(param.size);
        }
    }
}
