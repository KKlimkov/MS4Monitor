﻿import { Basic } from "../basic.js";
import './pickr_min.js';
/**
 * @class MSColorPicker
 * @extends Basic
 * @classdesc Кнопка выбора цвета
 * */
export class MSColorPicker extends Basic {

    static get observedAttributes() {
        return super.observedAttributes.concat([
            'colorselect'
        ]);
    }

    constructor() {
        super();
        this.shRoot = this.attachShadow({ mode: 'open' });
        this.shRoot.innerHTML = `
        <style>
            .pickr{position:relative;overflow:visible;z-index:1}.pickr *{box-sizing:border-box}.pickr .pcr-button{border:unset;position:relative;height:100%;width:100%;padding:0;cursor:pointer;background:currentColor;transition:all .3s;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,sans-serif}.pickr .pcr-button:before{background:url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>');background-size:.5em;border-radius:.15em;z-index:-1}.pickr .pcr-button:after,.pickr .pcr-button:before{position:absolute;content:"";top:0;left:0;width:100%;height:100%}.pickr .pcr-button:after{background:url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" stroke="%2342445A" stroke-width="5px" stroke-linecap="round"><path d="M45,45L5,5"></path><path d="M45,5L5,45"></path></svg>') no-repeat 50%;background-size:70%;opacity:0}.pickr .pcr-button.clear{background:hsla(0,0%,100%,.25)}.pickr .pcr-button.clear:after{opacity:1}.pickr .pcr-button.clear:focus{box-shadow:0 0 0 1px #f1f3f4,0 0 0 3px #75797e}.pickr .pcr-button.disabled{cursor:not-allowed}.pcr-app button,.pcr-app input,.pickr button,.pickr input{outline:none;border:none}.pcr-app button:focus,.pcr-app input:focus,.pickr button:focus,.pickr input:focus{box-shadow:0 0 0 1px #f1f3f4,0 0 0 3px currentColor}.pcr-app{position:fixed;display:flex;flex-direction:column;z-index:10000;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,sans-serif;box-shadow:0 .15em 1.5em 0 rgba(0,0,0,.1),0 0 1em 0 rgba(0,0,0,.03);top:5px;height:15em;width:28.5em;max-width:95vw;padding:.8em;border-radius:.1em;background:#fff;opacity:0;visibility:hidden;transition:opacity .3s}.pcr-app.visible{visibility:visible;opacity:1}.pcr-app .swatches{display:flex;flex-wrap:wrap;margin-top:.75em}@supports (display:grid){.pcr-app .swatches{display:grid;align-items:center;justify-content:space-around;grid-template-columns:repeat(auto-fit,1.75em)}}.pcr-app .swatches>button{position:relative;width:1.75em;height:1.75em;border-radius:.15em;cursor:pointer;margin:2.5px;flex-shrink:0;justify-self:center;transition:all .15s;overflow:hidden;background:transparent;z-index:1}.pcr-app .swatches>button:before{position:absolute;content:"";top:0;left:0;width:100%;height:100%;background:url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>');background-size:6px;border-radius:.15em;z-index:-1}.pcr-app .swatches>button:after{content:"";position:absolute;top:0;left:0;width:100%;height:100%;background:currentColor;border:1px solid rgba(0,0,0,.05);border-radius:.15em;box-sizing:border-box}.pcr-app .swatches>button:hover{filter:brightness(1.05)}.pcr-app .pcr-interaction{display:flex;align-items:center;margin:.75em -.2em 0}.pcr-app .pcr-interaction>*{margin:0 .2em}.pcr-app .pcr-interaction input{letter-spacing:.07em;font-size:.75em;text-align:center;cursor:pointer;color:#75797e;background:#f1f3f4;border-radius:.15em;transition:all .15s;padding:.45em .5em}.pcr-app .pcr-interaction input:hover{filter:brightness(.975)}.pcr-app .pcr-interaction input:focus{box-shadow:0 0 0 1px #f1f3f4,0 0 0 3px rgba(66,133,244,.75)}.pcr-app .pcr-interaction .pcr-result{color:#75797e;text-align:left;flex-grow:1;min-width:1em;transition:all .2s;border-radius:.15em;background:#f1f3f4;cursor:text}.pcr-app .pcr-interaction .pcr-result::selection{background:#4285f4;color:#fff}.pcr-app .pcr-interaction .pcr-type.active{color:#fff;background:#4285f4}.pcr-app .pcr-interaction .pcr-clear,.pcr-app .pcr-interaction .pcr-save{width:auto;color:#fff}.pcr-app .pcr-interaction .pcr-clear:hover,.pcr-app .pcr-interaction .pcr-save:hover{filter:brightness(.925)}.pcr-app .pcr-interaction .pcr-save{background:#4285f4}.pcr-app .pcr-interaction .pcr-clear{background:#f44250}.pcr-app .pcr-interaction .pcr-clear:focus{box-shadow:0 0 0 1px #f1f3f4,0 0 0 3px rgba(244,66,80,.75)}.pcr-app .pcr-selection{display:flex;justify-content:space-between;flex-grow:1}.pcr-app .pcr-selection .pcr-picker{position:absolute;height:18px;width:18px;border:2px solid #fff;border-radius:100%;user-select:none;cursor:-moz-grab;cursor:-webkit-grabbing}.pcr-app .pcr-selection .pcr-color-preview{position:relative;z-index:1;width:2em;display:flex;flex-direction:column;justify-content:space-between;margin-right:.75em}.pcr-app .pcr-selection .pcr-color-preview:before{position:absolute;content:"";top:0;left:0;width:100%;height:100%;background:url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>');background-size:.5em;border-radius:.15em;z-index:-1}.pcr-app .pcr-selection .pcr-color-preview .pcr-last-color{cursor:pointer;transition:background-color .3s,box-shadow .3s;border-radius:.15em .15em 0 0;z-index:2}.pcr-app .pcr-selection .pcr-color-preview .pcr-current-color{border-radius:0 0 .15em .15em}.pcr-app .pcr-selection .pcr-color-preview .pcr-current-color,.pcr-app .pcr-selection .pcr-color-preview .pcr-last-color{background:currentColor;width:100%;height:50%}.pcr-app .pcr-selection .pcr-color-chooser,.pcr-app .pcr-selection .pcr-color-opacity,.pcr-app .pcr-selection .pcr-color-palette{position:relative;user-select:none;display:flex;flex-direction:column}.pcr-app .pcr-selection .pcr-color-palette{width:100%;z-index:1}.pcr-app .pcr-selection .pcr-color-palette .pcr-palette{flex-grow:1;border-radius:.15em}.pcr-app .pcr-selection .pcr-color-palette .pcr-palette:before{position:absolute;content:"";top:0;left:0;width:100%;height:100%;background:url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>');background-size:.5em;border-radius:.15em;z-index:-1}.pcr-app .pcr-selection .pcr-color-chooser,.pcr-app .pcr-selection .pcr-color-opacity{margin-left:.75em}.pcr-app .pcr-selection .pcr-color-chooser .pcr-picker,.pcr-app .pcr-selection .pcr-color-opacity .pcr-picker{left:50%;transform:translateX(-50%)}.pcr-app .pcr-selection .pcr-color-chooser .pcr-slider,.pcr-app .pcr-selection .pcr-color-opacity .pcr-slider{width:8px;flex-grow:1;border-radius:50em}.pcr-app .pcr-selection .pcr-color-chooser .pcr-slider{background:linear-gradient(180deg,red,#ff0,#0f0,#0ff,#00f,#f0f,red)}.pcr-app .pcr-selection .pcr-color-opacity .pcr-slider{background:linear-gradient(180deg,transparent,#000),url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>');background-size:100%,50%}
        </style>

        <div style="width:100%; height:100%">
            <div id="color-picker"></div>
        </div>
        `;
        this._pick = this.shRoot.getElementById('color-picker');
        // const node = this.getContainer();
        // node.appendChild(this.upWindow);
        this.pickr = new Pickr({
            el: this._pick,
            parent: window.__rootWin,
            default: '#42445A',
            defaultRepresentation: 'HEX',
            closeWithKey: 'Escape',
            comparison: true,

            swatches: [
                'rgba(244, 67, 54, 1)',
                'rgba(233, 30, 99, 1)',
                'rgba(156, 39, 176, 1)',
                'rgba(103, 58, 183, 1)',
                'rgba(63, 81, 181, 1)',
                'rgba(33, 150, 243, 1)',
                'rgba(3, 169, 244, 1)',
                'rgba(0, 188, 212, 1)',
                'rgba(0, 150, 136, 1)',
                'rgba(76, 175, 80, 1)',
                'rgba(139, 195, 74, 1)',
                'rgba(205, 220, 57, 1)',
                'rgba(255, 235, 59, 1)',
                'rgba(255, 193, 7, 1)'
            ],

            components: {

                preview: true,
                opacity: true,
                hue: true,

                interaction: {
                    input: true,
                    save: true
                },
            },
            strings: {
                save: 'Применить'
            }
        });

        this._setColor = (e) => {
            if (e) {
                const color = e.toRGBA().toString().replace(/\s+/g, '');
                this.SetParameter('colorselect', color);
            }
        };

        this.pickr.on('save', this._setColor);
        //
        this.borderthickness = 0;
        this.backgroundcolor = "rgb(245,240,245)";
        this.colorselect = "GRAY";
    }

    get isvisible() {
        return this._showElement;
    }
    set isvisible(value) {
        this._showElement = value;
        const isShow = (this.opacity === '' || this._toBool(this.opacity)) && this._toBool(value);
        this.style.display = isShow ? '' : 'none';
    }
    /**
     * Значение (выбор цвета)
     * @type {string}
     */
    get colorselect() {
        return this._colorselect;
    }
    set colorselect(value) {
        const color = this._colorValues(value);
        if (typeof color === 'undefined') { return; }
        const a = this.rgbaToHex(color);
        // const a = 'rgba('+color[0]+','+color[1]+','+color[2]+','+color[3]+')';
        this.pickr.options.default = a;
        this.pickr.getRoot().button.style.color = a;
        this.pickr.setColor(a, true);
        // this.pickr.setColorRepresentation(a);
        // console.log('hex',tt);

        this._colorselect = value;
    }
    /**
     * Конвертация из массива цветов в hex-формат
     * @param {array} parts массив цветов как в rgba
     * @return {string} цвет в шестнадцатеричном формате 
     * @example
     * rgbaToHex([64, 82, 182, 1.0]);
     * //Результат: "#4052b6ff"
     */
    rgbaToHex(parts) {
        let r = parts[0].toString(16), g = parts[1].toString(16), b = parts[2].toString(16), a;
        if (parts[3]) {
            a = (parts[3] * 255).toString(16);
        }

        r = r.length > 1 ? r : '0' + r;
        g = g.length > 1 ? g : '0' + g;
        b = b.length > 1 ? b : '0' + b;

        return ('#' + r + g + b + (a ? a : ''));
    }

    disconnectedCallback() {
        super.disconnectedCallback();
        this.pickr.off('save', this._setColor);
    }

    _colorValues(color) {
        if (!color)
            return;
        if (color.toLowerCase() === 'transparent')
            return [0, 0, 0, 0];
        if (color[0] === '#') {
            if (color.length < 7) {
                color = '#' + color[1] + color[1] + color[2] + color[2] + color[3] + color[3] + (color.length > 4 ? color[4] + color[4] : '');
            }
            return [parseInt(color.substr(1, 2), 16),
            parseInt(color.substr(3, 2), 16),
            parseInt(color.substr(5, 2), 16),
            color.length > 7 ? parseInt(color.substr(7, 2), 16) / 255 : 1];
        }
        if (color.indexOf('rgb') === -1) {
            var temp_elem = document.body.appendChild(document.createElement('fictum'));
            var flag = 'rgb(1, 2, 3)';
            temp_elem.style.color = flag;
            if (temp_elem.style.color !== flag) {
                document.body.removeChild(temp_elem);
                return;
            }
            temp_elem.style.color = color;
            if (temp_elem.style.color === flag || temp_elem.style.color === '') {
                document.body.removeChild(temp_elem);
                return;
            }
            color = getComputedStyle(temp_elem).color;
            document.body.removeChild(temp_elem);
        }
        if (color.indexOf('rgb') === 0) {
            if (color.indexOf('rgba') === -1)
                color += ',1';
            return color.match(/[\.\d]+/g).map((a) => {
                return +a;
            });
        }
    }

}