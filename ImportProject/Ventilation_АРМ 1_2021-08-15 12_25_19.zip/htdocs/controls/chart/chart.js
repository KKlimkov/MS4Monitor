﻿import { Trendbase } from "../trend/trendbase.js";
import { Pen } from "../trend/pen.js";
/**
 * @class MSChart
 * @extends Trendbase
 * @classdesc График XY
 * */
export class MSChart extends Trendbase {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'miny',
            'maxy'
        ]);
    }
    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<style>
                                    @import "controls/trend/trend.css";
                                </style>
                                <div class="t-main">
                                    <div class="t-left">
                                        <ms-toolbar id='toolbar' style="display: flex; width: 100%; height: 30px"
                                        buttons='[{"method": "Export", "class": "hmi-j-table", "tooltip": "Экспорт", "type": "button"},
                                        {"method": "ShowLegend", "class": "hmi-j-trend_legend", "tooltip": "Показать минилегенду", "type": "button"},
                                        {"method": "Print", "class": "hmi-j-print", "tooltip": "Печать", "type": "button"},
                                        {"method": "SaveImageAs", "class": "hmi-j-export", "tooltip": "Сохранить", "type": "button"}]'></ms-toolbar>
                                        <div style="top: 30px; position: relative;" id="trend" class="t-body"></div>
                                        <ms-datazoom id="datazoom" datazoomindex="0" format="f0" width="${this.attributes.width.value}" height="20" orientation="0" foreborderwidth="2"
                                        style="box-sizing: border-box; display: flex; left: 38; overflow: unset;"></ms-datazoom>
                                     </div>
                                    <div class="t-right">
                                        <ms-minilegend id="legend" style="right: 0" width='${this.attributes.legendwidth.value}' pens='${this.attributes.data.value}'></ms-minilegend>
                                    </div>
                                    <ms-datazoom id="ydatazoom" datazoomindex="1" format="f0" width="20" height="${(this.attributes.height.value - 100)}" min="0" max="100" minvalue="0" maxvalue="100" foreborderwidth="2" orientation="1"
                                    style="top: 50; right: 10; box-sizing: border-box; display: flex; overflow: unset;"></ms-datazoom>
                                </div>`;
        this.setParts(shadowRoot);
        this.createTrend();
        let penlimits = JSON.parse(this.attributes.penlimits.value);
        penlimits.max = +this.attributes.maxy.value;
        penlimits.min = +this.attributes.miny.value;
        this._penlimits = penlimits;
        this.createMarkAreaOption(penlimits);
        this.createDataZoom();
        this.msdatazoom.echarts = this.echarts;
        this.msdatazoom.updateForDatazoom = (start, end) => {
            this.echarts && this.echarts.dispatchAction({
                type: 'dataZoom',
                dataZoomIndex: 0,
                startValue: start,
                endValue: end
            });
        }
        this.msydatazoom.echarts = this.echarts;
        this.msydatazoom.min = this.miny;
        this.msydatazoom.max = this.maxy;
        this.msydatazoom.updateForDatazoom = (start, end) => {
            this.echarts && this.echarts.dispatchAction({
                type: 'dataZoom',
                dataZoomIndex: 1,
                startValue: start,
                endValue: end
            });
        }
        this.echarts.setOption({
            xAxis: {
                type: "value",
                scale: true,
                axisLabel: {
                    color: "#000000",
                    formatter: (value, index) => {
                        return String.format(this._xformat, value);
                    }
                },
                axisPointer: {
                    label: {
                        formatter: (value, index) => {
                            return String.format(this._xformat, value.value);
                        }
                    }
                }
            }
        });
        this.echarts.on("datazoom", () => {
            this.msdatazoom.minvalue = this.datazoom.startValue;
            this.msdatazoom.maxvalue = this.datazoom.endValue;
            this.msydatazoom.minvalue = this.ydatazoom.startValue;
            this.msydatazoom.maxvalue = this.ydatazoom.endValue;
        });
        this.toolbar.context = this;
    }
    changePenAttribute(attr, value) {
        let index = +attr.split('.')[1];
        let parameter = attr.split('.')[2];
        this.pens[index][parameter.toLowerCase()] = value;
        this.echarts.setOption({
            series: this.pens.series,
            yAxis: this.pens.yaxises
        });
    }
    createDataZoom() {
        this.echarts.setOption({
            dataZoom: [
                {
                    type: "inside",
                    filterMode: 'none',
                    xAxisIndex: 0
                },
                {
                    type: "inside",
                    filterMode: 'none',
                    yAxisIndex: 0
                }
            ]
        });
        this.datazoom = this.echarts.getModel().option.dataZoom[0];
        this.ydatazoom = this.echarts.getModel().option.dataZoom[1];
    }
    addDataSource() {

    }
    dummy() {
        return;
    }
    onStringPenChanged(path, value) {
        let i = path.split('.')[1];
        this.pens.series[i].data = value;
        this.echarts.setOption({
            series: this.pens.series
        });
        this.msdatazoom.min = this.datazoom.startValue;
        this.msdatazoom.max = this.datazoom.endValue;
        this.msdatazoom.minvalue = this.datazoom.startValue;
        this.msdatazoom.maxvalue = this.datazoom.endValue;
    }
    createYAxisesOption() {
        if (this.attributes.data.value === "") {
            this.pens.yaxises = {};
            return;
        }
        this.pens.yaxises = {
            type: 'value',
            splitLine: {
                lineStyle: {
                    color: this.attributes.gridfill.value
                },
                axisLine: {
                    lineStyle: {
                        width: +this.attributes.axisthicknessy.value
                    }
                },
                axisTick: {
                    lineStyle: {
                        width: +this.attributes.tickheighty.value,
                        color: this.attributes.tickcolory.value,
                        length: +this.attributes.tickwidthy.value
                    }
                }
            },
            min: +this.attributes.miny.value,
            max: +this.attributes.maxy.value
        };
    }
    createSeriesOption() {
        this.pens = [];
        this.pens.series = [];
        try {
            const pens = JSON.parse(this.attributes.data.value);
            let index = 0;
            for (let penname in pens) {
                let name = pens[penname].name;
                pens[penname].penname = name;
                this.pens.push(new Pen(pens[penname]));
                this.pens[index].updateYAxisesOffset = this.dummy;
                this.pens[index].updateSeriesAxises = this.dummy;
                this.pens[index].broadcast = this.dummy;
                this.pens[index]._echarts = this.echarts;
                this.pens[index].minilegend = this.legend;
                this.pens[index].idx = index;
                this.pens.series.push(this.pens[index].serie);
                index++;
            }
        } catch (e) {
            $ns.add({ type: 'info', time: new Date().toLocaleString(), title: 'График XY пуст', text: `В Графике XY ${this.id} отсутствуют перья` });
        }
    }
    applyMark(markarea, markline) {
        if (markarea.length > 0)
            this.echarts.setOption({ series: { markLine: { data: markline }, markArea: { silent: true, data: markarea } } });
    }
    set textcolor(value) {
        this.echarts.setOption({ title: { textStyle: { color: value } } });
        this.echarts.setOption({ xAxis: { axisLabel: { color: value } } });
        this.echarts.setOption({ xAxis: { nameTextStyle: { color: value } } });
        this.echarts.setOption({ yAxis: { axisLabel: { color: value } } });
    }
    get miny() {
        return this._miny;
    }
    set miny(value) {
        this._miny = +value;
        this.msydatazoom.min = this._miny;
        this.msydatazoom.minvalue = this._miny;
        this.pens.yaxises.min = this._miny;
        this._penlimits.min = this._miny;
        this.createMarkAreaOption(this._penlimits);
        this.echarts.setOption({ yAxis: this.pens.yaxises });
    }
    get maxy() {
        return this._maxy;
    }
    set maxy(value) {
        this._maxy = +value;
        this.msydatazoom.max = this._maxy;
        this.msydatazoom.maxvalue = this._maxy;
        this.pens.yaxises.max = this._maxy;
        this._penlimits.max = this._maxy;
        this.createMarkAreaOption(this._penlimits);
        this.echarts.setOption({ yAxis: this.pens.yaxises });
    }
}