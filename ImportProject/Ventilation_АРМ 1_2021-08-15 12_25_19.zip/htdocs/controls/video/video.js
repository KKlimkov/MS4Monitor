﻿import { Basic } from '../basic.js';
/**
 * @class MSVideo
 * @extends Basic
 * @classdesc Видео
 */
export class MSVideo extends Basic {
    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `
            <video controls style="width:100%;height:100%;object-fit:fill;">
        `;
        this._video = shadowRoot.querySelector('video');
    }
    /**
     * Имя ресурса для изображения фона
     * @type {string}
     */
    get resource() {
        return this._resource;
    }
    set resource(value) {
        this._resource = this.getResourceFromList(value);
        this._video.src = `resources/${this._resource}`;
    }
}