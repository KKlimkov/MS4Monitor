"use strict";
import { ActionFactory } from './../actions/ActionFactory.js';
import { ResourcesList } from '../generated/resourcesList.js';
import { doRequest } from '../lib/utils.js';
import { getSvgTemplate } from "../generated/svgtemplates.js"
/**
 * @class Basic
 * @extends HTMLElement
 * @classdesc Базовый класс для контролов
 */
export class Basic extends HTMLElement {
    static get formAssociated() { return true; }

    static get observedAttributes() {
        return [
            'skinresource',
            'width',
            'height',
            'x',
            'y',
            'z',
            'angle',
            'scalex',
            'scaley',
            'borderthickness',
            'bordercolor',
            'backgroundcolor',
            'cornerradius',
            'opacity',
            'borderstyle',
            'tooltip',
            'flash',
            'shadowsize',
            'shadowcolor',
            'resource',
            'backgroundtile',
            'isvisible',
            'isenabled',
            'dockstyle',
            'Links',
            'propLink',
            'actionlist',
            'horizontalalign',
            'verticalalign',
            'right',
            'bottom',
            'ItemIndex',
            'elname',
            'savestate',
            'mousecursorkind'
        ];
    }
    constructor() {
        super();
        this.Links = {};
        this.prop_link = {};
        this.actions = {};
        this._actionslist = {};
        this.permission = {};
        this.style.boxSizing = 'border-box';
        this.style.display = 'flex';
        this.style.overflow = 'hidden';
        this._cacheTransform = '';
        if (!this.style.position) {
            this.style.position = 'absolute';
        }
        this.isTouched = typeof window.ontouchstart === 'object';

        this._shadowcolor = "rgb(240,240,240)";
        this.style.borderStyle = 'solid';
        this.style.borderWidth = 1;
        this.style.borderColor = "GRAY";

        this._backgroundtile = 2;
        this._horizontalalign = 1;
        this._verticalalign = 1;
        this._dockstyle = 3;
        this._showElement = true;
        this._isenabled = true;
    }
    /**
     * Вызывается когда элемент встроен в DOM
     * @virtual
     * @see https://developer.mozilla.org/en-US/docs/Web/Web_Components/Using_custom_elements
     * */
    connectedCallback() {

    }

    updateItemState() {
        this.originPath = this.getOriginPath();
        let storedState = $ss.getItemState(this.originPath);
        storedState && this.applyStoredState(storedState);
    }

    saveItemState(stateMap) {
        if (typeof this.saveStateFlag === 'undefined') {
            this.saveStateFlag = this.calcSaveState();
        }
        if (this.saveStateFlag) {
            this.originPath = this.getOriginPath();
            $ss.saveItemState(this.originPath, stateMap);
        }
    }

    hasItemState() {
        this.originPath = this.getOriginPath();
        return $ss.hasItemState(this.originPath);
    }

    set savestate(value) {
        this._savestate = value;
    }

    get savestate() {
        return this._savestate;
    }

    calcSaveState() {
        let result, node = this;
        while (!result && node && !node.hasAttribute('root')) {
            result = Number(node.getAttribute('savestate'));
            if (node.nodeName === "MS-POPUP") {
                node = window.__rootWin;
            } else {
                node = node.parentNode;
            }
        }
        let globalState = window._globalParams.SaveStatePlace !== "Не сохранять";
        return result !== 2 && globalState
    }

    applyStoredState(storedState) {
        Object.keys(storedState).forEach(key => {
            this[key] = storedState[key];
        })
    }

    FindActionsById(actions, context) { //Чтобы получать текст сообщения при выполнении действий
        const types = $sw.ItemSubscription.Type.type;
        const target = context.currentTarget || context.target;
        let ms = this;
        if (typeof target !== "undefined" && target.nodeName === 'MS-WINDOW') {
            if (target.hasAttribute('root')) return;
            ms = target;
        }
        while (ms.nodeName !== 'MS-WINDOW') {
            ms = ms.parentElement;
        }
        const storeMs = ms;
        const parentId = ms.id;
        const typeId = this.typeid || ms.typeid || this.parentElement.typeid;
        this.parentWindowTypeId = typeId;
        for (const actionId of actions) {
            if (!this.actions[actionId]) {
                if (types[parentId] && types[parentId].actions[actionId]) {
                    this.actions[actionId] = new ActionFactory(types[parentId].actions[actionId], this);
                } else if (types[typeId] && types[typeId].actions[actionId]) {
                    this.actions[actionId] = new ActionFactory(types[typeId].actions[actionId], this);
                } else {
                    ms = storeMs;
                    do {
                        if (ms.id && types[ms.typeid] && types[ms.typeid].actions[actionId]) {
                            this.parentWindowTypeId = ms.typeid
                            this.actions[actionId] = new ActionFactory(types[ms.typeid].actions[actionId], this);
                            break;
                        }
                        ms = ms.parentElement;
                        while (ms && ms.nodeName !== 'MS-WINDOW') {
                            ms = ms.parentElement;
                        }
                    } while (ms);

                }

            }
        }
        ms = null;
    }

    /**
     * Вызов действия по событию
     * @param {array} actions действия, которые будут вызваны по событию
     * @param {element} context контекст действия (родитель)
     */
    async CallActionManager(actions, context) {
        const types = $sw.ItemSubscription.Type.type;
        const target = context.currentTarget || context.target;
        let ms = this;
        if (typeof target !== "undefined" && target.nodeName === 'MS-WINDOW') {
            if (target.hasAttribute('root')) return;
            ms = target;
        }
        while (ms.nodeName !== 'MS-WINDOW') {
            ms = ms.parentElement;
        }
        const storeMs = ms;
        const parentId = ms.id;
        const typeId = this.typeid || ms.typeid || this.parentElement.typeid;
        this.parentWindowTypeId = typeId;
        for (const actionId of actions) {
            if (!this.actions[actionId]) {
                if (types[parentId] && types[parentId].actions[actionId]) {
                    this.actions[actionId] = new ActionFactory(types[parentId].actions[actionId], this);
                } else if (types[typeId] && types[typeId].actions[actionId]) {
                    this.actions[actionId] = new ActionFactory(types[typeId].actions[actionId], this);
                } else {
                    ms = storeMs;
                    do {
                        if (ms.id && types[ms.typeid] && types[ms.typeid].actions[actionId]) {
                            this.parentWindowTypeId = ms.typeid
                            this.actions[actionId] = new ActionFactory(types[ms.typeid].actions[actionId], this);
                            break;
                        }
                        ms = ms.parentElement;
                        while (ms && ms.nodeName !== 'MS-WINDOW') {
                            ms = ms.parentElement;
                        }
                    } while (ms);

                }

            }
            const asy = typeof this.actions[actionId].AsyncCall !== 'undefined' ? this._toBool(this.actions[actionId].AsyncCall) : true;
            context.actionId = actionId;

            if (this.calcExecute(this.actions[actionId], context)) {
                await this.actions[actionId].execute(context, asy);
            }

        }
        ms = null;
    }


    calcExecute(action, context) {
        if (this.calcKeyState(action, context)) {
            if (Array.isArray(action.conditions)) {
                return action.conditions.reduce((acc, cur) => {
                    return acc || this.calcCondition(action, cur, context)
                }, false)
            } else return true;
        } else return false;
    }

    calcKeyState(action, context) {
        let flag;
        if (typeof action.parameters === 'object') {
            if (typeof action.parameters.key === 'string') {
                flag = flag || action.parameters.key.includes(context.key);
            }
            if (typeof action.parameters.keycode === 'string') {
                flag = flag || action.parameters.keycode === context.keyCode.toString();
            }
        }
        return typeof flag === 'undefined' || flag;
    }

    calcCondition(action, conditionObj, evtContext) {
        let result;
        let operandParam = action.parameters[conditionObj.Operand.type];
        let operandVal = typeof operandParam === 'undefined' ? conditionObj.Operand.value : operandParam;
        operandVal = typeof operandVal === 'string' && operandVal.includes("$event")
            ? action.calcParam(operandVal, evtContext) : operandVal;

        let valueParam = action.parameters[conditionObj.Value.type];
        let valueVal = typeof valueParam === 'undefined' ? conditionObj.Value.value : valueParam;
        valueVal = typeof operandVal === 'string' && valueVal.includes("$event")
            ? action.calcParam(valueVal, evtContext) : valueVal;

        switch (conditionObj.Comparer) {
            case 'Equal':
                result = operandVal.toString() === valueVal.toString();
                break;
            case 'NotEqual':
                result = operandVal.toString() !== valueVal.toString();
                break;
            case 'More':
                result = Number(operandVal) > Number(valueVal);
                break;
            case 'MoreEqual':
                result = Number(operandVal) >= Number(valueVal);
                break;
            case 'Less':
                result = Number(operandVal) < Number(valueVal);
                break;
            case 'LessEqual':
                result = Number(operandVal) <= Number(valueVal);
                break;
            case 'Contains':
                result = operandVal.toString().includes(valueVal.toString());
                break;
        }
        if (typeof conditionObj.ANDConditions === 'object') {
            let inner = conditionObj.ANDConditions.reduce((acc, cur) => {
                return acc || this.calcCondition(action, cur);
            }, false)
            return result && inner;
        }
        return result;
    }
    /**
     * ID типа родительского окна
     * @type {string}
     */
    get parentWindowTypeId() {
        return this._parentWindowTypeId;
    }
    set parentWindowTypeId(value) {
        this._parentWindowTypeId = value;
    }

    setPermission(usersList, permType, entry) {
        if (this.permission[usersList] == undefined) {
            this.permission[usersList] = {};
        }
        this.permission[usersList][permType] = entry;
    }

    getPermission(usersList, permType) {
        if (this.permission[usersList]) {
            var res = this.permission[usersList][permType];
            return res;
        }
        return false;
    }
    get elname() {
        return this._elname;
    }
    set elname(value) {
        this._elname = value;
    }

    /**
     * Образ
     * @type {string}
     */
    get skinresource() {
        return this._skinresource;
    }
    set skinresource(value) {
        if (value) {
            value = this.getResourceFromList(value);
            if (value && (this._isSVG(value) || this.issvg)) {
                this._skinresource = value;
                this._changeTemplate(value);
            }
        }
    }

    _changeTemplate(value) {
        const shRoot = this.shRoot || this.shadowRoot;
        if (!shRoot) return;
        this._rootBtn = shRoot.innerHTML;
        if (value.charAt(0) == '#') {
            const tag = value.substr(1);
            const template = getSvgTemplate(tag);
            if (template) {
                this.uid = Math.random().toString(36).substr(2, 9);
                const html = template.replace(/{id}/gi, this.uid);
                shRoot.innerHTML = html;
                this._initSkin();
            }
        } else {
            doRequest({ method: 'GET', body: '', url: `./resources/${value}` })
                .then(data => {
                    if (data) {
                        shRoot.innerHTML = this._getSkinTemplate(data);
                        this._initSkin();
                    }
                })
                .catch(error => {
                    console.log(error);
                });
        }
    }

    _getSkinTemplate(svg) {
        return `<label style="height:100%;width:100%; padding:0; margin:0;">${svg}<input type="radio" name="grp_${this._key}" style="height:0;width:0; padding:0; margin:0;visibility: hidden;"></label>`;
    }

    /**
     * Координата Х
     * @type {number}
     */
    get x() {
        return this._x;
    }
    set x(value) {
        this._x = value;
        this.style.left = this._setValueUnit(value);
    }
    /**
     * Координата Y
     * @type {number}
     */
    get y() {
        return this._y;
    }
    set y(value) {
        this._y = value;
        this.style.top = this._setValueUnit(value);
    }
    /**
     * Z-порядок
     * @type {number}
     */
    get z() {
        return this.style.zIndex;
    }
    set z(value) {
        if (this.parentElement && this.parentElement.updateZIndex) {
            this.parentElement.updateZIndex(Number(value))
        }
        this.style.zIndex = value;
    }
    /**
     * Ширина
     * @type {number}
     */
    get width() {
        if (this._width && this._width.indexOf && this._width.indexOf('%') > 0) {
            return this.offsetWidth;
        }
        return this._width;
    }
    set width(value) {
        this._width = value;
        const tmp = Number(value);
        if (tmp) {
            this.style.width = this._setValueUnit(value);
        }
    }
    /**
     * Высота
     * @type {number}
     */
    get height() {
        if (this._height && this._height.indexOf && this._height.indexOf('%') > 0) {
            return this.offsetHeight;
        }
        return this._height;
    }

    set height(value) {
        this._height = value;
        const tmp = Number(value);
        if (tmp) {
            this.style.height = this._setValueUnit(value);
        }
    }
    /**
     * Угол поворота
     * @type {number}
     */
    get angle() {
        return this._rotate;
    }
    set angle(value) {
        this._rotate = value;
        let transform_string = '';
        if (this._scalex && this._scalex != 1) {
            transform_string += ' scalex(' + this._scalex + ')';
        }
        if (this._scaley && this._scaley != 1) {
            transform_string += ' scaley(' + this._scaley + ')';
        }
        if (this._rotate && this._rotate != 0) {
            transform_string += ' rotate(' + this._rotate + 'deg)';
        }
        this._cacheTransform = transform_string;
        this.style.transform = transform_string;
    }
    /**
     * Масштаб Х
     * @type {number}
     */
    get scalex() {
        return this._scalex;
    }
    set scalex(value) {
        this._scalex = value;
        let transform_string = '';
        if (!isNaN(this._scaley) && this._scaley != 1) {
            transform_string += 'scaley(' + this._scaley + ')';
        }
        if (!isNaN(this._scalex) && this._scalex != 1) {
            transform_string += 'scalex(' + this._scalex + ')';
        }
        if (this._rotate && this._rotate != 0) {
            transform_string += 'rotate(' + this._rotate + 'deg) ';
        }
        this._cacheTransform = transform_string;
        this.style.transform = transform_string;
    }
    /**
     * Масштаб Y
     * @type {number}
     */
    get scaley() {
        return this._scaley;
    }
    set scaley(value) {
        this._scaley = value;
        let transform_string = '';
        if (!isNaN(this._scalex) && this._scalex != 1) {
            transform_string += 'scalex(' + this._scalex + ')';
        }
        if (!isNaN(this._scaley) && this._scaley != 1) {
            transform_string += 'scaley(' + this._scaley + ')';
        }
        if (this._rotate && this._rotate != 0) {
            transform_string += 'rotate(' + this._rotate + 'deg) ';
        }
        this._cacheTransform = transform_string;
        this.style.transform = transform_string;
    }
    /**
     * Толщина рамки
     * @type {number}
     */
    get borderthickness() {
        return this._borderthickness;
    }
    set borderthickness(value) {
        value = parseInt(value, 10);
        if (isNaN(value) || value < 0) {
            return;
        }
        this._borderthickness = value;
        this.style.borderWidth = this._setValueUnit(value);
    }
    /**
     * Цвет рамки
     * @type {string}
     */
    get bordercolor() {
        return this.style.borderColor;
    }
    set bordercolor(value) {
        this.style.borderColor = value;
    }
    /**
     * Цвет заливки
     * @type {string}
     */
    get backgroundcolor() {
        return this._backgroundcolor;
    }
    set backgroundcolor(value) {
        if (typeof value !== 'undefined' && typeof value === 'string') {
            this._backgroundcolor = value;
            if (value.indexOf(' ') !== -1) {
                this.style.background = this._calcGradient(value);
            } else {
                this.style.backgroundColor = value;
            }
        }
    }
    /**
     * Прозрачность
     * @type {number}
     */
    get opacity() {
        return this.style.opacity;
    }
    set opacity(value) {
        if (this._isNumeric(value)) {
            const opacity = value / 100;
            if (opacity >= 0 && opacity <= 1) {
                this.style.opacity = opacity;
                this.style.visibility = opacity && this._toBool(this._showElement) ? '' : 'hidden';
            }
        }
    }

    /**
     * Видимость
     * @type {bool}
     */
    get isvisible() {
        return this._showElement;
    }
    set isvisible(value) {
        this._showElement = value;
        const isShow = (this.opacity === '' || this._toBool(this.opacity)) && this._toBool(value);
        this.style.visibility = isShow ? '' : 'hidden';
    }

    /**
     * Скругление бортика
     * @type {number}
     */
    get cornerradius() {
        return this.style.borderRadius;
    }
    set cornerradius(value) {
        this.style.borderRadius = this._setValueUnit(value / 2);
    }
    /**
     * Стиль линии рамки
     * @type {string}
     */
    get borderstyle() {
        return this._borderstyle;
    }

    set borderstyle(value) {
        this._borderstyle = value;
        const type = window._enums.BorderStyleType[value];
        switch (type) {
            case 0:
                this.style.borderStyle = 'solid';
                break;
            case 1:
                this.style.borderStyle = 'dashed';
                break;
            case 2:
                this.style.borderStyle = 'dotted';
                break;
            case 3:
                this.style.borderStyle = 'hidden';
                break;
        }
    }
    /**
     * Текст всплывающей подсказки
     * @type {string}
     */
    get tooltip() {
        return this._tooltip;
    }
    set tooltip(value) {
        this._tooltip = value;
        this.dataset.tooltip = value;
    }

    /**
     * Мигание
     * @type {bool}
     */
    get flash() {
        return this._flash;
    }
    set flash(value) {
        this._flash = this._toBool(value);
        if (this._flash) {
            this.style.animation = `flash linear ${_globalParams.FlashInterval}ms infinite`;
        } else {
            this.style.animation = '';
        }
    }

    /**
    * Размер тени
    * @type {number}
    */
    get shadowsize() {
        return this._shadowsize;
    }
    set shadowsize(value) {
        value = parseInt(value, 10);
        if (value >= 0) {
            this._shadowsize = value;
            this._calcBlockShadow();
        }
    }

    /**
    * Цвет тени
    * @type {string}
    */
    get shadowcolor() {
        return this._shadowcolor;
    }
    set shadowcolor(value) {
        this._shadowcolor = value ? this._transformHexColor(value) : '';
        this._calcBlockShadow();
    }

    /**
     * Сформировать и присвоить тень, пригодную для CSS
     * */
    _calcBlockShadow() {
        if (this._svgResource) { this._calcSVGShadow(); }
        if (!this._shadowsize || !this._shadowcolor || this._svgResource) {
            this.style.boxShadow = '';
            return;
        }
        this.style.boxShadow = `
            ${this._shadowsize}px
            ${this._shadowsize}px
            1px 0
            ${this._shadowcolor}`;
    }

    /**
     * Имя ресурса для изображения фона
     * @type {string}
     */
    get resource() {
        return this._resource;
    }
    set resource(value) {
        if (value) {
            value = this._resource = this.getResourceFromList(value);
            if (value.toLocaleLowerCase().endsWith('svg')) {
                this._svgResource = true;
                this.style.borderWidth = 0;
            }
            this._calcBacgraund();
            this._calcBlockShadow();
        } else {
            this.style.backgroundImage = ``;
        }
    }

    _calcSVGShadow() {
        if (!this._shadowsize || !this._shadowcolor) {
            this.style.filter = '';
            return;
        }
        this.style.filter = `drop-shadow(
                ${this._shadowcolor}
                ${this._shadowsize}px
                ${this._shadowsize}px
                1px)`;
    }

    getResourceFromList(value) {
        if (ResourcesList.resourcesList[value] != undefined) {
            value = ResourcesList.resourcesList[value];
        }
        else {
            const res = this.tryFindResource(value);
            if (res !== undefined) {
                value = res;
            } else {
                value = value && value.replace(/ /g, '_');
            }
        }
        return value;
    }

    tryFindResource(value) {
        const result =
            Object.keys(ResourcesList.resourcesList)
                .filter(resName => resName.includes(value))
                .map(resName => {
                    return ResourcesList.resourcesList[resName];
                })
                .reduce((acc, key) => {
                    if (acc[key] !== undefined) {
                        acc[key]++;
                    } else {
                        acc[key] = 1;
                    }
                    return acc;
                },
                    {});
        const reduceSort = Object.keys(result).sort((a, b) => {
            return result[b] - result[a];
        });
        return reduceSort[0];
    }
    /**
     * Тип замостки для изображения фона
     * @type {number}
     */
    get backgroundtile() {
        return this._backgroundtile;
    }
    set backgroundtile(value) {
        this._backgroundtile = window._enums.TileType[value];
        if (this._resource && this._resource != "") {
            this._calcBacgraund();
        }
    }
    /**
     * Сформировать фон в формате CSS
     * @param {any} elem элемент, для которого задается фон
     */
    _calcBacgraund(elem = this) {
        switch (this._backgroundtile || 2) {
            case 0:
                elem.style.backgroundPosition = '';
                elem.style.backgroundRepeat = 'no-repeat';
                elem.style.backgroundSize = 'cover';
                elem.style.backgroundImage = '';
                break;
            case 1:
                elem.style.backgroundPosition = '';
                elem.style.backgroundRepeat = 'repeat';
                elem.style.backgroundSize = '';
                elem.style.backgroundImage = `url("resources/${this._resource}")`;
                break;
            case 2:
                elem.style.backgroundPosition = '';
                elem.style.backgroundRepeat = 'no-repeat';
                elem.style.backgroundSize = '100% 100%';
                elem.style.backgroundImage = `url("resources/${this._resource}")`;
                break;
            case 3:
                elem.style.backgroundPosition = 'center';
                elem.style.backgroundRepeat = 'no-repeat';
                elem.style.backgroundSize = '';
                elem.style.backgroundImage = `url("resources/${this._resource}")`;
                break;
        }

    }

    isPermissionEnable(elem) {
        if ($pm.hasPermissions) {
            return $pm.checkEnable(elem);
        }
        return true;
    }

    setControlDisable(value) {
        if ((typeof (this._isdisabledByPermission) === 'undefined' || this._isdisabledByPermission === false) && !value)
            return; //Элемент не был запрещен по правам доступа

        if (typeof (this._isenabled) === 'undefined') {
            this._isenabled = true;
        }
        this._isdisabledByPermission = value;
        let disable = value || !this._isenabled;
        if (disable) {
            this.disableElement();
        } else {
            this.enableElement();
        }
    }

    /**
     * Активность
     * @type {bool}
     */
    get isenabled() {
        return this._isenabled;
    }

    set isenabled(value) {
        this._isenabled = this._toBool(value);
        this._isdisabledByPermission = this.isPermissionEnable(this);
        let enable = this._isdisabledByPermission && this._isenabled;
        enable ? this.enableElement() : this.disableElement();
    }

    enableElement() {
        if (this._maskElement) {
            this._maskElement.remove();
            this._maskElement = null;
        }
        this.style.pointerEvents = this._pointerEvents ? this._pointerEvents : '';
        if (this._isSVG && this._path) {
            this._path.style.pointerEvents = this._pointerEvents ? this._pointerEvents : '';;
        }
    }

    disableElement() {
        if (this._maskElement) return;
        const base = this.shRoot ? this.shRoot : this.shadowRoot;
        this._pointerEvents = this.style.pointerEvents;
        const zIndex = parseInt(this.z || 1, 10);
        const maskElement = this.createMaskElement(zIndex);

        if (this.tagName != 'MS-WINDOW') {
            this.style.pointerEvents = 'none';
            if (this._isSVG && this._path) {
                this._path.style.pointerEvents = 'none';
            }
        }
        if (base) {
            base.appendChild(maskElement);
        } else {
            this.appendChild(maskElement);
        }
        this._maskElement = maskElement;
    }

    createMaskElement(zIndex) {
        let mask = document.createElement('div');
        mask.style.cssText = `position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        z-index: ${zIndex + 1};
        background-color: #808080;
        opacity: 0.5`;
        return mask;
    }

    get tabindex() {
        return this.attributes.tabindex ? this.attributes.tabindex.value : '0';
    }
    set tabindex(value) {
        this.attributes.tabindex = value;
    }

    get dockstyle() {
        return this._dockstyle;
    }
    set dockstyle(value) {
        this._dockstyle = value;
    }

    get Links() {
        return this._Links;
    }
    set Links(value) {
        this._Links = value;
    }

    get propLink() {
        return this.prop_link;
    }
    set propLink(value) {
        this.prop_link = value;
    }

    get actionlist() {
        return this._actionslist;
    }
    set actionlist(value) {
        try {
            const tmp = JSON.parse(value);
            for (const key in tmp) {
                if (this._actionslist.hasOwnProperty(key)) {
                    for (let i = 0; i < tmp[key].length; i++) {
                        if (this._actionslist[key].indexOf(tmp[key][i]) < 0) {
                            this._actionslist[key].push(tmp[key][i]);
                        }
                    }
                } else {
                    this._actionslist[key] = tmp[key];
                }
            }
        } catch (e) {
            if (this._actionslist === undefined) this._actionslist = [];
            return;
        }
        if (this.isTouched) {
            for (const key in this._actionslist) {
                switch (key) {
                    case 'mousedown':
                        this._actionslist['touchstart'] = this._actionslist[key];
                        break;
                    default:
                        break;
                }

            }
        }
        this.removeListeners();
        const useCapture = typeof this._useCapture === 'undefined' ? true : this._useCapture;
        if (('keydown' in this._actionslist || 'keypress' in this._actionslist || 'keyup' in this._actionslist) && !this.tabIndex) {
            this.tabIndex = 0;
        }

        for (const key in this._actionslist) {
            if (this._actionslist.hasOwnProperty(key)) {
                this.addEventListener(key, this.__Event, useCapture);
            }
        }
    }

    removeListeners() {
        for (const key in this._actionslist) {
            if (this._actionslist.hasOwnProperty(key)) {
                this.removeEventListener(key, this.__Event);
            }
        }
    }

    get horizontalalign() {
        return this._horizontalalign;
    }
    set horizontalalign(value) {
        this._horizontalalign = value;
        const align = window._enums.AlignVertical[value];
        if (align &&
            this.parentElement &&
            this.parentElement.localName === 'ms-pstack' &&
            this.parentElement.attributes.orientation &&
            this.parentElement.attributes.orientation.value == 1) {
            this.style.alignSelf = align;
        }
    }

    get verticalalign() {
        return this._verticalalign;
    }
    set verticalalign(value) {
        this._verticalalign = value;
        const align = window._enums.AlignHorizontal[value];
        if (align &&
            this.parentElement &&
            this.parentElement.localName === 'ms-pstack' &&
            this.parentElement.attributes.orientation &&
            this.parentElement.attributes.orientation.value == 0) {
            this.style.alignSelf = align;
        }
    }

    get right() {
        return this._right;
    }
    set right(v) {
        this._right = v;
        this.style.right = this._setValueUnit(v);
    }

    get bottom() {
        return this._bottom;
    }
    set bottom(v) {
        this._bottom = v;
        this.style.bottom = this._setValueUnit(v);
    }

    get ItemIndex() {
        return this._ItemIndex;
    }
    set ItemIndex(v) {
        this._ItemIndex = v;
    }

    get mousecursorkind() {
        return this._mousecursorkind || 0;
    }
    set mousecursorkind(value) {
        this._mousecursorkind = Number(value);
        let cursor = ''; // Стандартный
        switch (this._mousecursorkind) {
            case 1: // Рука
                cursor = 'pointer'
                break;
            case 2: // Перекрестие
                cursor = 'crosshair'
                break;
            case 3: // Текст
                cursor = 'text'
                break;
            case 4: // Запрет
                cursor = 'not-allowed'
                break;
            case 5: // Ожидание
                cursor = 'wait'
                break;
            case 6: // Помощь
                cursor = 'help'
                break;
            case 7: // Перемещение
                cursor = 'move'
                break;
        }
        this.style.cursor = cursor;
    }

    __Event(e) {
        if (typeof (this._isenabled) !== 'undefined' && this._isenabled) {
            if (e.type === "mouseenter" || e.type === "mouseleave") {
                if (typeof (e.path) === 'object' && e.path[0] !== e.target)
                    return;  //Данные события вызываются повторно для внутренних элементов контрола, path указывает на внутренности
            }

            if (typeof (this._actionslist) !== 'undefined' && this._actionslist[e.type]) { //TODO Bug 20488: Событие "Покидание мыши" вызывает ошибку - 
                //обработчик вызывается повторно уже после выполнения действия перехода на другое окно

                // e.stopPropagation();
                // e.preventDefault();
                //TODO: возможно перенести проверку в сами экшены
                //чтобы для открытия окна сначала не спрашивалось разрешение на действие
                if ($pm.hasPermissions) {
                    this.FindActionsById(this._actionslist[e.type], e); //Bug 20970: Не применяется текст для окон подтверждения
                    const options = {};
                    for (const actionId of this._actionslist[e.type]) {
                        const tmp = this.actions[actionId];
                        if (tmp && tmp.parameters && tmp.parameters.message) {
                            options.customText = tmp.parameters.message;
                            options.customDialogText = tmp.parameters.message;
                        }
                    }
                    this._paramsConfirm = $pm.resolveControl(this, "Action", this.CallActionManager.bind(this, this._actionslist[e.type], e), options);
                } else {
                    this.CallActionManager(this._actionslist[e.type], e);
                }
            }
        }
    }

    /**
     * Коллбек по изменению атрибутов элемента
     * @see https://w3c.github.io/webcomponents/spec/custom/
     * @param {string} attrName название атрибута
     * @param {*} oldVal старое значение атрибута
     * @param {*} newVal новое значение атрибута
     */
    attributeChangedCallback(attrName, oldVal, newVal) {
        if (oldVal !== newVal) {
            this[attrName] = newVal;
            if (this.prop_link[attrName]) {
                this.prop_link[attrName](
                    this.pId ? this.pId + '/' + this.id : this.id,
                    this.Links[attrName],
                    newVal,
                    attrName,
                    this.ItemIndex
                );
            }
        }
    }

    /**
     * Коллбек удаление компонента
     * @see https://w3c.github.io/webcomponents/spec/custom/
     */
    disconnectedCallback() {
        if (this.msWin) {
            this.msWin = null
            delete this.msWin;
        }
        if (Object.keys(this.actions).length > 0) {
            for (const key in this.actions) {
                if (this.actions.hasOwnProperty(key)) {
                    this.actions[key].destroy();
                    delete this.actions[key];
                }
            }
        }
        const keys = Object.keys(this.Links);
        if (keys.length > 0) {
            keys.forEach(key => {
                delete this.Links[key].LinkUp;
                delete this.Links[key];
            });
        }

        this.removeListeners();

        this.prop_link = [];
        delete this.actions;
        delete this._actionslist;
        delete this.permission;

        if (this.shRoot) delete this.shRoot
        if (this.shadowRoot) delete this.shadowRoot
    }

    /**
     * Добавить по связи указатель на функцию
     * @param {string} property свойство
     * @param {function} callback коллбек
     */
    AddLinkCallback(property, callback) {
        this.propLink[property.toLowerCase()] = callback;
    }
    /**
     * Добавить по связи новое действие
     * @param {string} id ID действия
     * @param {function} callback указатель на вызов действия
     */
    AddActionCallback(id, callback) {
        if (!this.actions[id]) {
            this.actions[id] = [];
        }
        this.actions[id].push(callback);
    }
    /**
     * Получить действие по id
     * @param {string} id ID действия
     * @return {object} действие
     */
    getAction(id) {
        for (let event in this.actions) {
            for (let i = 0; i < this.actions[event].length; i++)
                if (this.actions[event][i].id == id) {
                    return this.actions[event][i];
                }
        }
    }
    /**
     * Установить параметр
     * @param {any} Param имя параметра
     * @param {any} value новое значение
     * @param {boolean} [forced] изменять параметр принудительно (даже если новое значение не отличается от старого)
     * @param {number} [itemIndex] индекс структуры в массиве (только для сложных типов данных)
     * @param {any} [callback] коллбек
     */
    SetParameter(Param, value, forced, itemIndex, callback, attrName) {
        // fix: may be
        // отсечка базовых ссылок по стековой панели с окнами
        if (typeof itemIndex === 'number' && typeof this.ItemIndex === 'number' && itemIndex !== this.ItemIndex) {
            return;
        }
        //не надо присваивать некорректные данные
        if ((typeof value === 'number' && isNaN(value)) || value === undefined)
            return;
        if (!forced && this.prop_link[Param] && $pm.hasPermissions) {
            const uid = this._paramsConfirm || '';
            const options = {
                uid,
                cancel: () => {
                    this[Param] = this[Param];
                }
            }
            this._paramsConfirm = $pm.resolveControl(
                this,
                "Control",
                this.attributeChangedCallback.bind(this, Param, this[Param], value, itemIndex, attrName),
                options
            );
        } else {
            if (callback) { callback(); }
            this.attributeChangedCallback(Param, this[Param], value, itemIndex, attrName);
        }
    }

    getOriginPath() {
        let node = this;
        if (typeof node.originPath === 'string') return node.originPath;
        let res = [];
        while (node && !node.hasAttribute("root")) {
            if (node.id === "" && node.nodeName === "MS-POPUP") {
                const path = node.originPath;
                res.push(path);
                break;
            }
            if (typeof node.ItemIndex !== 'undefined') res.push(node.ItemIndex);
            res.push(node.id);
            node = node.parentNode;
        }
        return res.join("/");
    }

    /**
     * Установить единицы измерения
     * @param {string} value значение единиц измерения (%|px)
     * @return {string} значение с единицами измерения
     */
    _setValueUnit(value) {
        if (value == null) { return ''; }
        const val = value.toString();
        let e = val.charAt(val.length - 1);
        if (e === '%') {
            return val;
        } else {
            return val + 'px';
        }
    }
    /**
     * Конвертировать string в bool
     * @param {string} value конвертируемое значение
     * @returns {bool} результат конвертации
     */
    _toBool(value) {
        if (value) {
            if (typeof value == 'boolean') {
                return value;
            } else {
                switch (value.toString().toLowerCase().trim()) {
                    case "true": case "yes": case "1": return true;
                    case "false": case "no": case "0": case null: return false;
                    default: return Boolean(value);
                }
            }
        } else {
            return false;
        }
    }

    _transformHexColor(value) {
        let color = value;
        if (value.indexOf('#') === 0 && value.length === 9) {
            color = `#${value.slice(3)}${value.slice(1, 3)}`;
        }
        return color;
    }
    /**
     * Проверка является ли аргумент числом
     * @param {...any} args множество аргументов
     * @return {bool} true - число, false - не число
     */
    _isNumeric(...args) {
        return args.every(arg => {
            return !isNaN(parseFloat(arg)) && isFinite(arg);
        });
    }
    /**
     * Является ли ресурс SVG
     * @param {any} value имя ресурса
     * @return {bool} true - это SVG, false - не SVG
     */
    _isSVG(value) {
        return (/\.(svg)$/i).test(value);
    }
    /**
    * Расчет градиента
    * @param {string} colorParams параметры градиента 
    * @return {string} градиент для CSS
    * @example
    * _calcGradient("TopRightGradient BISQUE CRIMSON DARKBLUE")
    * //вернет "linear-gradient(to bottom left, BISQUE,CRIMSON,DARKBLUE)"
    */
    _calcGradient(colorParams) {
        if (typeof colorParams === 'string') colorParams = colorParams.split(' ');
        if (colorParams.length === 1) { return colorParams[0]; }
        let direction;
        switch (colorParams[0]) {
            case 'TopGradient':
                direction = 'linear-gradient(to bottom,';
                break;
            case 'BottomGradient':
                direction = 'linear-gradient(to top,';
                break;
            case 'RightGradient':
                direction = 'linear-gradient(to left,';
                break;
            case 'LeftGradient':
                direction = 'linear-gradient(to right,';
                break;
            case 'BottomRightGradient':
                direction = 'linear-gradient(to top left,';
                break;
            case 'TopLeftGradient':
                direction = 'linear-gradient(to bottom right,';
                break;
            case 'TopRightGradient':
                direction = 'linear-gradient(to bottom left,';
                break;
            case 'BottomLeftGradient':
                direction = 'linear-gradient(to top right,';
                break;
            case 'RadialGradient':
                const radiusScale = Math.ceil(100 - (100 / (colorParams.length - 7)));
                const colorArrayStringRadial = colorParams.slice(7).join(',');
                const cx = colorParams[3] * 100,
                    cy = colorParams[4] * 100,
                    rx = colorParams[5] * radiusScale,
                    ry = colorParams[6] * radiusScale;
                return `radial-gradient(${rx}% ${ry}% at ${cx}% ${cy}%, ${colorArrayStringRadial})`;
            case 'Solid':
                return colorParams[1];
        }

        colorParams.shift();
        return `${direction} ${colorParams.join(",")})`;

    }
    /**
     * Проверка подключен ли веб компомент. Если нет, то подключить
     * @param {string} tagname имя тега
     * @param {string} classname имя класса
     */
    checkComponent(tagname, classname) {
        if (!window.customElements.get(tagname, classname)) { window.customElements.define(tagname, classname); }
    }
}
/**
 * @class BasicSkin
 * @extends Basic
 * @classdesc Класс для контролов, которым может быть задан параметр Образ
 */
export class BasicSkin extends Basic {
    _showWarnSkin() {
        const message = `Образ ${this.localName} id='${this.getAttribute('id')}' не соотвествует принятому стандарту`;
        $ns.add({ type: 'warning', time: new Date().toLocaleString(), title: 'skin warning', text: message });
    }

    get resource() {
        return this._resource;
    }

    set resource(value) {
        this.setResource(value, this);
    }

    setResource(value, element) {
        if (!element) return;
        if (value && !this._isSkin) {
            this._resource = this.getResourceFromList(value);
            this._calcBacgraund(element);
        } else {
            element.style.backgroundImage = ``;
        }
    }
}