﻿import { Basic } from "../basic.js";
import { Converter } from '../../observer/converter.js'
import * as L from "../../lib/leaflet-src-esm.js"
import { toBool } from "../../lib/utils.js";

/*<link rel="stylesheet" href="/controls/map/leaflet.css" />
<div id='mapid' class='mapid'></div>*/

//problems:
//reinit markers after map load

export class MSMap extends Basic {

    static get observedAttributes() {
        return super.observedAttributes.concat([
            'paneldatasource',
            'markerstyles',
            'modelrefs',
            'tileserver',
            'tilesubdomains',
            'initpoint',
            'maxzoom',
            'minzoom',
            'maptype',
            'crs',
            'attribution',
            'doubleclickzoom',
        ]);
    }

    constructor() {
        super();
        this._mapElement = this.getElementsByClassName("mapid")[0];

        //'http://vec{s}.maps.yandex.net/tiles?l=map&v=4.55.2&z={z}&x={x}&y={y}&scale=2&lang=ru_RU'
        //'https://b.tile.openstreetmap.org/{z}/{x}/{y}.png'        
        //'http://tilessputnik.ru/{z}/{x}/{y}.png'
        //
        this._initpoint = [0, 0]
        this._initzoom = 2;
        this._maxzoom = 23;
        this._minzoom = 0;
        this._maptype = "0";
        this._doubleclickzoom = true;

        this._tilesize = 512;
        this._useindex = true;
        //
        this._markerProps = ["X", "Y", "Z", "Tooltip", "Width", "Height", "Opacity"];
        this._markerTypeConst = "MarkerType";


        this.currentMarkers = [];
        this.inited = false;

        this._useCapture = false; //used while setting up listeners in basic.js
        //need for prevent bubbling event propagation from opened in marker-popup map to ancestor map

        this.markerHandlers = this.fillHandlers();
    }

    afterInitialize() {
        if (!this.inited) {
            let uid = this.uid = Math.floor(Math.random() * 1e8).toString(16);
            this._mapElement.id += `_${uid}`;
            this._Lmap = L.map(`mapid_${this.id}_${uid}`, {
                crs: this.getCRS(this._crs),
                doubleClickZoom: this._doubleclickzoom,
            }).setView(this._initpoint, this._initzoom);
            this._Lmap.on('click', this.mapOnClick.bind(this));
            if (this._tileserver && Array.isArray(this._tileserver)) {
                if (this._maptype === "0") {
                    if (this._tileserver.length === 1) {
                        this.createMainTileMap(this._tileserver[0])
                    } else {
                        let tileArray = [...this._tileserver];
                        let main = tileArray.shift();
                        this.createMainTileMap(main);

                        let options = this.getMapOptions();
                        tileArray.forEach(url => L.tileLayer(url, options).addTo(this._Lmap));
                    }
                } else if (this._maptype === '1') {
                    let path = this._tileserver[0];
                    let tileResPath = `resources/${path}/{z}/tile-{x}-{y}.png`;
                    this.createMainTileMap(tileResPath);
                }
            } else if (this._maptype === "0" && this.hasAttribute("useyandex")) {
                let layerType = this.getAttribute("useyandex");
                this.createYandexLayer(layerType);
            }
            this.inited = true;
            if (typeof this._paneldatasource !== 'undefined') {
                this.processDataSource(this._paneldatasource);
            }
        }
    }

    attributeChangedCallback(attrName, oldVal, newVal, itemIndex, sourceAttrName) {
        if (attrName === 'paneldatasource') {
            if (typeof itemIndex !== 'undefined' && typeof sourceAttrName !== "undefined") {

                let paramStruct = this.modelParamsStruct[sourceAttrName];
                let dsField = paramStruct.FieldName;

                let currentValue = this._paneldatasource[itemIndex][dsField];
                let valueConvert = Converter.convert(paramStruct, currentValue, paramStruct.FieldType);
                //исходное значение может быть сконвертировано, 
                //тогда значение в источнике данных может отличаться, при том что изменений не было
                //так проверяем конвертацию сохраненного значения и новое значение                
                if (newVal != valueConvert) {
                    let value = Converter.convert(paramStruct, newVal, paramStruct.FieldType);
                    this._paneldatasource[itemIndex][dsField] = value;
                    if (typeof this.prop_link.paneldatasource === 'function') {
                        this.prop_link.paneldatasource(
                            this.pId ? this.pId + '/' + this.id : this.id,
                            this.Links["paneldatasource"],
                            this._paneldatasource,
                            "paneldatasource",
                            itemIndex
                        );
                    }
                }
            } else {
                this.paneldatasource = newVal;
            }
        } else {
            super.attributeChangedCallback(attrName, oldVal, newVal);
        }
    }

    createMainTileMap(url) {
        let options = this.getMapOptions();
        L.tileLayer(url, options).addTo(this._Lmap);
    }

    createYandexLayer(type) {
        let layer = type || "map";
        let options = this.getMapOptions();
        L.yandex(`yandex#${layer}`, options).addTo(this._Lmap);
    }

    getMapOptions() {
        let options = {
            maxZoom: this._maxzoom,
            minZoom: this._minzoom,
            reuseTiles: true,
            updateWhenIdle: false,
            subdomains: this._tilesubdomains || "",
            tileSize: this._tilesize,
            zoomOffset: -1,
            attribution: this._attribution,
        }
        return options;
    }

    get width() {
        return this._width;
    }
    set width(value) {
        this._width = value;
        const tmp = Number(value);
        if (tmp) {
            this._mapElement.style.width = this._setValueUnit(value);
        }
    }

    get height() {
        return this._height;
    }
    set height(value) {
        this._height = value;
        const tmp = Number(value);
        if (tmp) {
            this._mapElement.style.height = this._setValueUnit(value);
        }
    }

    get modelrefs() {
        return this._modelrefs;
    }
    set modelrefs(value) {
        try {
            var ds = JSON.parse(value);
        } catch (e) {
            ds = {};
        }
        this._modelrefs = ds;
    }

    get markerstyles() {
        return this._markerstyles;
    }
    set markerstyles(value) {
        try {
            var ds = JSON.parse(value);
        } catch (e) {
            ds = {};
        }
        this._markerstyles = ds;

        if (!this.modelParamsStruct) {
            this.calcModelParams(ds);
        }
    }

    get paneldatasource() {
        return this._paneldatasource;
    }
    set paneldatasource(value) {
        if (value && value.value) {
            this._paneldatasource_dataType = value.dataType;
            var ds = value.value;
        } else {
            try {
                ds = JSON.parse(value);
            } catch (ex) {
                ds = []
            }
        }
        this._paneldatasource = ds;
        if (this.inited) {
            this.processDataSource(ds);
        }
    }

    get maptype() {
        return this._maptype;
    }
    set maptype(value) {
        this._maptype = value;
    }

    get tileserver() {
        return this._tileserver;
    }
    set tileserver(value) {
        if (value) {
            let val = value.split(',');
            this._tileserver = val;
        }
    }

    get tilesubdomains() {
        return this._tilesubdomains;
    }
    set tilesubdomains(value) {
        if (value) {
            let val = value.split(',').map(x => x.trim());
            this._tilesubdomains = val;
        }
    }

    get initpoint() {
        return this._initpoint;
    }
    set initpoint(value) {
        let val = [];
        if (value && typeof value === 'string') {
            let sp = value.split(',');
            val = sp.map(x => Number(x));
            if (sp.length === 2) {
                this._initpoint = val;
            }
            if (sp.length === 3) {
                this._initpoint = [val[0], val[1]];
                this._initzoom = val[2];
            }
            if (typeof this._Lmap !== 'undefined') {
                this._Lmap.setView(this._initpoint, this._initzoom)
            }
        }
    }

    get maxzoom() {
        return this._maxzoom;
    }
    set maxzoom(value) {
        let val = Number(value);
        if (value !== null && !Number.isNaN(val) && val >= 0) {
            this._maxzoom = val;
            if (typeof this._Lmap !== 'undefined') {
                this._Lmap.setMaxZoom(this._maxzoom);
            }
        }
    }

    get minzoom() {
        return this._minzoom;
    }
    set minzoom(value) {
        let val = Number(value);
        if (value !== null && !Number.isNaN(val) && val >= 0) {
            this._minzoom = val;
            if (typeof this._Lmap !== 'undefined') {
                this._Lmap.setMinZoom(this._minzoom);
            }
        }
    }

    get crs() {
        return this._crs;
    }
    set crs(value) {
        this._crs = value;
    }

    getCRS(value) {
        let num = Number(value);
        switch (num) {
            case 1: return L.CRS.EPSG3857;
            case 2: return L.CRS.EPSG4326;
            case 3: return L.CRS.Simple;
            default: case 0: return L.CRS.EPSG3395;
        }
    }

    get attribution() {
        return this._attribution;
    }
    set attribution(value) {
        if (value !== null && typeof value !== 'undefined') {
            if (typeof this._Lmap !== 'undefined') {
                this._Lmap.attributionControl.removeAttribution(this._attribution);
                this._attribution = value.toString();
                this._Lmap.attributionControl.addAttribution(this._attribution);
            } else {
                this._attribution = value.toString();
            }
        }
    }

    get doubleclickzoom() {
        return this._doubleclickzoom;
    }
    set doubleclickzoom(value) {
        this._doubleclickzoom = toBool(value);
    }

    enableElement() {
        if (typeof this._maskElement !== 'undefined') {
            this._maskElement.remove();
            delete this._maskElement;
        }
    }

    disableElement() {
        if (typeof this._maskElement === 'undefined') {
            this._maskElement = this.createMaskElement(1500);
            this.appendChild(this._maskElement);
        }
    }

    calcModelParams() {
        let modelParams = { ...this._markerstyles }

        let dsParamsSet = new Set();
        let markerParamsSet = new Set();
        let markerTypeSet = new Set();
        let dsParamsStruct = {};
        let markerParamsStruct = {};
        let markerTypeStruct = {};
        let markerParamsMap = {};
        Object.entries(modelParams).forEach(val => {
            Object.keys(val[1]).forEach(key => {
                if (key == this._markerTypeConst) {
                    markerTypeStruct[key] = val[1][key];
                    markerTypeSet.add(val[0]);
                } else if (this._markerProps.includes(key)) {
                    markerParamsStruct[key] = val[1][key];
                    markerParamsSet.add(val[0]);
                    let fieldName = val[1][key] && val[1][key].FieldName;
                    markerParamsMap[fieldName] = key;
                } else {
                    dsParamsStruct[key.toLowerCase()] = val[1][key];
                    let fieldName = val[1][key] && val[1][key].FieldName;
                    dsParamsSet.add(fieldName);
                }
            })
        });
        this.markerParamsMap = markerParamsMap;
        this.modelParamsStruct = dsParamsStruct;
        this.markerParamsStruct = markerParamsStruct;
        this.markerTypeStruct = markerTypeStruct;
        this.dsParamsArray = Array.from(dsParamsSet);
        this.markerParamsArray = Array.from(markerParamsSet);
        this.typeFieldArray = Array.from(markerTypeSet);
    }

    fillHandlers() {
        let markerHandlers = {};
        markerHandlers["Width"] = this.changeMarkerSize.bind(this, "Width");
        markerHandlers["Height"] = this.changeMarkerSize.bind(this, "Height");
        markerHandlers["X"] = this.changeLocation.bind(this);
        markerHandlers["Y"] = this.changeLocation.bind(this);
        markerHandlers["Z"] = this.changeMarkerZ.bind(this);
        markerHandlers["Tooltip"] = this.changeTooltip.bind(this);
        markerHandlers["Opacity"] = this.changeMarkerOpacity.bind(this);
        return markerHandlers;
    }

    processDataSource(ds) {
        if (ds && Array.isArray(ds)) {
            if (this.needRecreate(ds)) {
                this.removeMarkers();
                this.createMarkers(ds)
            } else {
                this.updateDS(ds);
            }
        }
    }

    needRecreate(ds) {
        return this.currentMarkers.length === 0 || ds.length !== this.currentMarkers.length;
    }

    updateDS(ds) {
        const { toRecreate, toMarkerUpdate, toParamsUpdate } = this.compareDS(ds)

        if (toRecreate.length > 0) {
            let indexList = toRecreate.map(el => el.index);
            this.removeMarkers(indexList);
            this.createMarkers(toRecreate);
        }
        if (toMarkerUpdate.length > 0) {
            toMarkerUpdate.forEach(obj => {
                this.updateMarker(obj.item, obj.diffKeysUpdate.map(x => this.markerParamsMap[x]));
            })
        }
        if (toParamsUpdate.length > 0) {
            toParamsUpdate.forEach(item => {
                let markerEntry = this.currentMarkers[item.index];
                if (typeof markerEntry !== "undefined") {
                    if (markerEntry.hasParams) {
                        let { msWin } = this.getMarkerModels(markerEntry.marker);
                        this.setWindParams(msWin, item);
                        //TODO: set only different keys
                    }
                    if (markerEntry.popupOpened) {
                        this.setPopupParams(item.index);
                    }
                }
            })
        }
    }

    compareDS(ds) {
        let toRecreate = [], toParamsUpdate = [], toMarkerUpdate = [];
        let temp = [];

        ds.forEach((el, index) => {
            el.index = index;
            let markerEntry = this.currentMarkers[index];
            if (typeof markerEntry !== 'undefined') {
                let storedItem = markerEntry.item;
                if (typeof storedItem !== 'undefined'
                    && !this.compareEntry(el, storedItem, this.typeFieldArray)) {
                    toRecreate.push(el);
                } else {
                    temp.push(el);
                }
            }
        });
        temp.forEach(el => {
            let markerEntry = this.currentMarkers[el.index];
            if (typeof markerEntry !== 'undefined') {
                let storedItem = markerEntry.item;
                if (typeof storedItem !== 'undefined') {
                    let diffKeysUpdate = this.getDiffKeys(el, storedItem, this.markerParamsArray);
                    if (diffKeysUpdate.length > 0) {
                        toMarkerUpdate.push({ item: el, diffKeysUpdate });
                    } else if (!this.compareEntry(el, storedItem, this.dsParamsArray)) {
                        toParamsUpdate.push(el);
                    }
                }
            }
        });

        //then update current markers stored items
        ds.forEach(el => {
            this.currentMarkers[el.index].item = { ...el }
        })

        return {
            toRecreate,
            toMarkerUpdate,
            toParamsUpdate
        }
    }

    compareEntry(newItem, oldItem, keys = Object.keys(oldItem)) {
        // true if values are equal
        return keys.reduce((acc, cur) =>
            this.deepCompareByKey(newItem, oldItem, cur) && acc, true);
    }

    getDiffKeys(newItem, oldItem, keys = Object.keys(oldItem)) {
        //returns array of changed fields
        return keys.filter(cur => !this.deepCompareByKey(newItem, oldItem, cur));
    }

    deepCompareByKey(newItem, oldItem, key) {
        let newItemValue = this.extractItemValue(key, newItem);
        let oldItemValue = this.extractItemValue(key, oldItem);
        return newItemValue == oldItemValue;
    }

    createMarkers(ds) {
        let useIndexFlag = this._useindex;
        ds.forEach((item, ind) => {
            let markerId;
            if (useIndexFlag) {
                let { index } = item;
                markerId = index || ind;
            } else {
                markerId = item.Id;//TODO:resolve Id field
            }
            item.index = markerId;
            this.createMarker({ ...item }, markerId);
        });
    }

    removeMarkers(indexArray) {
        if (indexArray && indexArray.length > 0) {
            indexArray.forEach(ind => {
                let markerEntry = this.currentMarkers[ind];
                if (typeof markerEntry !== 'undefined') {
                    markerEntry.marker.removeFrom(this._Lmap);
                }
            })
        } else {
            this.currentMarkers.forEach(entry => {
                entry.marker.removeFrom(this._Lmap);
            })
            this.currentMarkers = [];
        }
    }

    updateMarker(item, diffKeys) {
        let markerEntry = this.currentMarkers[item.index];
        if (typeof markerEntry !== 'undefined' && typeof markerEntry.marker !== 'undefined') {
            for (let i = 0; i < diffKeys.length; i++) {
                let key = diffKeys[i];
                this.markerHandlers[key](markerEntry.marker, item);
            }
        }
    }

    changeMarkerSize(side, marker, item) {
        let icon = marker._icon;
        if (typeof icon !== 'undefined') {
            let val = this.getMarkerParamDSValue(side, item);
            if (typeof val !== 'undefined' && val !== null) {
                let prop = side.toLowerCase();
                let frame = icon.firstChild;
                icon.style[prop] = val;
                if (frame !== null) {
                    frame[prop] = val;
                    frame._msWin[prop] = val;
                }
            }
        }
    }

    changeLocation(marker, item) {
        let location = this.getLocation(item);
        marker.setLatLng(location);
    }

    changeMarkerZ(marker, item) {
        let z = this.getMarkerParamDSValue("Z", item);
        if (typeof z !== 'undefined') {
            marker.setZIndexOffset(Number(z));
        }
    }

    changeTooltip(marker, item) {
        let tooltip = this.getMarkerParamDSValue("Tooltip", item);
        if (tooltip && (typeof marker._tooltip === 'undefined' || tooltip != marker._tooltip._content)) {
            marker.bindTooltip(tooltip);
        }
    }

    changeMarkerOpacity(marker, item) {
        let opacity = this.getMarkerParamDSValue("Opacity", item);
        if (typeof opacity !== 'undefined') {
            marker.setOpacity(opacity / 100);

            let disabled = Number(opacity) === 0 && opacity !== null;

            this.setDisable(item.index, disabled);
            let { msWin } = this.getMarkerModels(marker);
            let isActive = typeof msWin === 'undefined' || this.isActive(msWin);

            this.toggleCursorStyle(item.index, !disabled && isActive);
        }
    }

    setDisable(markerId, disabled) {
        let markerEntry = this.currentMarkers[markerId];
        if (typeof markerEntry !== 'undefined') {
            markerEntry.disabled = disabled;
        }
    }

    getMarkerParam(key) {
        if (this._markerProps.includes(key) && this.markerParamsStruct[key]) {
            return this.markerParamsStruct[key];
        } else if (key == this._markerTypeConst && this.markerTypeStruct[key]) {
            return this.markerTypeStruct[key]
        }
    }

    getMarkerParamDSValue(key, item, convert = true) {
        let struct = this.getMarkerParam(key);
        if (typeof struct !== "undefined") {
            return this.getDSItemValue(struct, item, convert);
        }
    }

    getDSItemValue(struct, item, convert) {
        let fieldName = struct.FieldName;
        let value = this.extractItemValue(fieldName, item);
        if (convert && typeof value !== "undefined") {
            return Converter.convert(struct, value, struct.FieldType);
        } else {
            return value;
        }
    }

    extractItemValue(path, item) {
        if (typeof item === 'object' && item !== null) {
            let keys = path.split('.');
            if (keys.length === 1) {
                return item[keys[0]];
            } else {
                let result = { ...item };
                let i = 0;
                while (typeof keys[i] !== 'undefined') {
                    result = result[keys[i]]
                    i++;
                }
                return result;
            }
        }
    }

    setWindParams(windRef, item, popup) {
        if (typeof this.modelParamsStruct !== "undefined") {
            Object.entries(this.modelParamsStruct).forEach(val => {
                let key = val[0];
                let struct = val[1];
                let itemValue = this.getDSItemValue(struct, item, true);
                if (popup) {
                    if (windRef.hasAttribute(key) && !windRef.constructor.observedAttributes.includes(key)) {
                        windRef.SetParameter(key, itemValue, true);
                    }
                } else {
                    if (windRef.hasAttribute(key) || windRef.constructor.observedAttributes.includes(key)) {
                        windRef.SetParameter(key, itemValue, true);
                    }

                    this.toggleCursorStyle(item.index, this.isActive(windRef))
                }
            });
        }
    }

    getLocation(item) {
        let x, y;
        if (true/*настройка карты про формат координат*/) {
            x = this.getMarkerParamDSValue("X", item);
            y = this.getMarkerParamDSValue("Y", item);
        }
        return [y, x]; //lat long
        //значение y - lattitude - широта (значение 0 - экватор)
        //значение x - longitude - долгота (значение 0 - нулевой меридиан)
    }

    createMarker(item, markerId) {
        let markerEntry = { item, hasParams: false };
        this.currentMarkers[markerId] = markerEntry;

        let location = this.getLocation(item);
        let mTypeDef = this.getMarkerParamDSValue(this._markerTypeConst, item);
        if (typeof mTypeDef !== 'undefined') {
            if (this._modelrefs && this._modelrefs[mTypeDef]) {
                let icon;
                let modelId = this._modelrefs[mTypeDef];
                let winModel = $WinDefs.winDef[modelId];

                if (winModel) {
                    let windHtml = this.createFramedWindow(winModel);
                    icon = L.divIcon({
                        html: windHtml,
                        iconSize: [winModel.width, winModel.height],
                    });
                    markerEntry.marker = L.marker(location, { icon }).addTo(this._Lmap);

                    let { msWin } = this.getMarkerModels(markerEntry.marker);

                    this.setWindParams(msWin, item);
                    this.addTargets(msWin, markerId);
                    markerEntry.hasParams = true;
                }
            } else if (mTypeDef.toString().includes(".")) {
                //resolve resource for marker picture
                let iconObj = this.getMarkerIcon(mTypeDef);
                if (typeof iconObj !== 'undefined') {
                    let icon = L.icon({
                        iconUrl: iconObj.path,
                        iconSize: iconObj.size,
                    })
                    markerEntry.marker = L.marker(location, { icon }).addTo(this._Lmap);
                }
            }
        }
        if (typeof markerEntry.marker === 'undefined') {
            markerEntry.marker = L.marker(location).addTo(this._Lmap);
        }

        markerEntry.marker.on('click', this.markerOnClick.bind(this, markerId));

        //update markers by array of keys [Z, Width, Height, Tooltip, Opacity]         
        this.updateMarker(item, this._markerProps.slice(2));
    }

    getMarkerIcon(mTypeDef) {
        let resName, size = [40, 40];
        let spl = mTypeDef.split(".");
        resName = spl[0];
        if (spl.length === 3) {
            try {
                size = spl[1].split("x");
            } catch (e) {
                size = [40, 40];
            }
        }
        let path = this.getResourceFromList(resName)
        if (typeof path !== 'undefined') {
            return { path: `resources/${path}`, size };
        }
    }

    createFramedWindow(obj, options) {
        let param = "";
        const keys = Object.keys(obj);
        keys.forEach(key => {
            if (key !== 'windowTriggers') {
                param += ` ${key}="${obj[key]}"`;
            }
        });
        let frameParam = " borderthickness='0'";
        if (typeof options !== 'undefined') {
            frameParam += " x='0'";
            frameParam += ` y='${-(this.getFrameEdge(obj, options, "height"))}'`;
            frameParam += ` width='${this.getFrameEdge(obj, options, "width")}'`;
            frameParam += ` height='${this.getFrameEdge(obj, options, "height")}'`;
        } else {
            frameParam += ` width='${obj.width}'`;
            frameParam += ` height='${obj.height}'`;
        }
        return `<ms-frame ${frameParam}><ms-window${param} position='absolute'></ms-window></ms-frame>`;
    }

    getFrameEdge(wind, action, key) {
        let result;
        if (action.sizetocontent === 0) {
            result = wind[key]
        } else if (action.sizetocontent === 1) {
            const scaleY = Number(action.height) / Number(wind.height);
            const scaleX = Number(action.width) / Number(wind.width);
            const scale = scaleX > scaleY ? scaleY : scaleX;
            result = scale * wind[key]
        } else {
            result = (action[key] || wind[key]);
        }
        return result;
    }

    toggleCursorStyle(markerId, active) {
        let markerEntry = this.currentMarkers[markerId];

        if (typeof markerEntry !== 'undefined' && typeof markerEntry.marker !== 'undefined') {
            let node = markerEntry.marker._icon;
            if (typeof node !== 'undefined') {
                //disabled by opacity
                let disabled = typeof markerEntry.disabled === 'boolean' && markerEntry.disabled;

                if (active && !disabled) {
                    node.style.cursor = 'pointer';
                    node.style.pointerEvents = 'auto';
                } else {
                    node.style.cursor = 'grab';
                    node.style.pointerEvents = 'none';
                    this.closePopup(markerId);
                }
            }
        }
    }

    isActive(windNode) {
        return windNode.isenabled && windNode.isvisible;
    }

    mapOnClick(ev) {
        if (typeof this._actionslist.mapclick !== 'undefined'
            && this._actionslist.mapclick.length > 0) {
            let cusEv = new CustomEvent('mapclick', { detail: { x: ev.latlng.lng, y: ev.latlng.lat } });
            this.dispatchEvent(cusEv);
        }
    }

    markerOnClick(id, ev) {
        if (typeof this._actionslist.markerclick !== 'undefined'
            && this._actionslist.markerclick.length > 0) {
            let { item, marker, popupOpened, disabled } = this.currentMarkers[id];
            if (!disabled) {
                let { msWin } = this.getMarkerModels(marker);
                if ((typeof msWin === 'undefined' || this.isActive(msWin)) && typeof item !== 'undefined') {
                    let mtype = this.getMarkerParamDSValue(this._markerTypeConst, item, false);
                    let cusEv = new CustomEvent('markerclick', {
                        detail: {
                            id,
                            item,
                            markerType: mtype,
                            x: ev.latlng.lng,
                            y: ev.latlng.lat,
                            popupOpened
                        }
                    });
                    this.dispatchEvent(cusEv);
                }
            }
        }
    }

    openMarkerWindow(markerId, options) {
        let markerEntry = this.currentMarkers[markerId];
        if (typeof markerEntry !== 'undefined') {
            const winId = options.windowid;
            let winModel = $WinDefs.winDef[winId];
            if (!markerEntry.popupOpened && winModel && markerEntry.marker) {
                let wind = this.createFramedWindow(winModel, options);
                let opt = {
                    autoClose: options.closeonnewwindow,
                    closeOnClick: options.closeonlostfocus,
                    closeButton: true,
                };
                markerEntry.marker.bindPopup(wind, opt).openPopup();
                markerEntry.popupOpened = true;
                let { sizetocontent } = options;
                this.setPopupParams(markerId, sizetocontent);
                this.setCloseButton(markerEntry.marker._popup, winModel, options);
                markerEntry.marker.on('popupclose', this.closePopup.bind(this, markerId));
            }
            return markerEntry.marker;
        }
    }

    closePopup(markerId) {
        let markerEntry = this.currentMarkers[markerId];
        if (typeof markerEntry !== "undefined" && typeof markerEntry.marker !== 'undefined'
            && markerEntry.popupOpened) {
            markerEntry.popupOpened = false;
            markerEntry.marker.closePopup();
            markerEntry.marker.unbindPopup();
        }
    }

    setPopupParams(markerId, stc) {
        let markerEntry = this.currentMarkers[markerId];
        if (typeof markerEntry !== 'undefined') {
            let { msFrame, msWin } = this.getPopupModels(markerEntry.marker);
            if (typeof stc !== 'undefined') {
                msFrame.sizetocontent = stc;
            }
            this.addTargets(msWin, markerId);
            this.setWindParams(msWin, markerEntry.item, true);
        }
    }

    setCloseButton(popup, win, options) {
        if (typeof popup === 'undefined') return;

        let width = this.getFrameEdge(win, options, 'width');
        let height = this.getFrameEdge(win, options, 'height');
        let frame = popup._contentNode.firstChild;
        let offset = - Number(height);
        frame.y = offset;
        if (typeof width !== 'undefined' && typeof height !== 'undefined') {
            popup._closeButton.style.left = Number(width) - 20;
            popup._closeButton.style.top = offset;
            popup._closeButton.style.zIndex = '100';
        }
        if (options.canclose) {
            popup._closeButton.style.display = 'block';
        } else {
            popup._closeButton.style.display = 'none';
        }
    }

    addTargets(msWin, markerId) {
        let map = this;
        Object.keys(this.modelParamsStruct).forEach(key => {
            if (msWin.hasAttribute(key)) {
                if (typeof msWin.Links[key] !== 'undefined') {
                    msWin.Links[key].Targets.push({
                        el: map,
                        //HasBackward:false,
                        ItemId: map.id,
                        OneTime: false,
                        Operation: 'move',
                        PropertyPath: 'PanelDataSource',
                        Type: 'client',
                        ItemIndex: markerId,
                    });
                }
            }
        });
    }

    getPopupModels(marker) {
        if (typeof marker !== "undefined" && typeof marker._popup !== "undefined") {
            var msFrame = marker._popup._contentNode.firstChild;
            var msWin = msFrame._msWin = msFrame && msFrame.firstChild;
        }
        return { msFrame, msWin };
    }

    getMarkerModels(marker) {
        let msFrame = marker._icon.firstChild, msWin;
        if (msFrame !== null) {
            msWin = msFrame._msWin = msFrame && msFrame.firstChild;
        }
        return { msFrame, msWin };
    }

}