import { Basic } from '../basic.js';
/**
 * @class MSTap
 * @extends Basic
 * @classdesc �������� ��� ���������, ������� ��� ���
 * */
export class MSTap extends Basic {
    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `
            <div style="font-size:20px; display: flex;">${this.localName}</div>
        `;
        this.style.background = '#d2d2d2';
        this.style.opacity = '0.5';
        this.style.justifyContent = 'center';
        this.style.alignItems = 'center';

        this.style.position = 'absolute';
        this.style.display = 'flex';
        this.style.overflow = 'hidden'
        this.style.boxSizing = "border-box";
        this._main = shadowRoot.querySelector('ellipse');
    }
}