import { MSTextInput } from "../textinput/textinput.js";
/**
 * @class MSPassInput
 * @extends MSTextInput
 * @classdesc ������
 * */
export class MSPassInput extends MSTextInput {
    constructor() {
        super();
        this.shadowRoot.innerHTML = '<input type="password"></input>';
        this._text = this.shadowRoot.querySelector('input');
        this._text.style.backgroundColor = 'transparent';
        this._text.style.width = '100%';
        this._text.style.height = '100%';
        this._text.style.border = '0';
        this._text.onchange = this._onChange.bind(this);

        this._text.style.justifyContent = 'center'; //this.texthorizontalalign = 1;
        this._text.style.textAlign = 'center';
        this._text.style.alignItems = 'center'; //this.textverticalalign = 1;
        this._text.style.fontSize = 12;
        this._text.style.fontFamily = "Tahoma";

        this.textcolor = "BLACK";
    }

    get isenabled() {
        return !this._text.disabled;
    }
    set isenabled(value) {
        super.isenabled = value;
    }
}