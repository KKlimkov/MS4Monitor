﻿import { Basic } from '../basic.js';
import { getFormattedValue } from '../../lib/utils.js';
import { Converter } from '../../observer/converter.js';
import { DataTypes } from '../../generated/datatypes.js';
import { Inputs } from '../../lib/inputs.js';
import { deepCompare } from '../../lib/utils.js';

/**
 * @class MSDataTable
 * @extends Basic
 * @classdesc Таблица данных
 * */
export class MSDataTable extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'paneldatasource',
            'ispaged',
            'headerrowstyle',
            'tablecolumns',
            'rowstyle',
            'cellsstyle',
            'fieldstyles',
            'evencolor',
            'oddcolor',
            'gridtype',
            'sorter',
            'filrets'
        ]);
    }

    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `<style>
            /* Tabulator v4.6.3 (c) Oliver Folkerd */
            .tabulator{position:relative;border:1px solid #999;background-color:#888;font-size:14px;text-align:left;overflow:hidden;}.tabulator[tabulator-layout=fitDataFill] .tabulator-tableHolder .tabulator-table{min-width:100%}.tabulator.tabulator-block-select{-webkit-user-select:none;-ms-user-select:none;user-select:none}.tabulator .tabulator-header{position:relative;box-sizing:border-box;width:100%;border-bottom:1px solid #999;background-color:#e6e6e6;color:#555;font-weight:700;white-space:nowrap;overflow:hidden;-moz-user-select:none;-khtml-user-select:none;-webkit-user-select:none;-o-user-select:none}.tabulator .tabulator-header.tabulator-header-hidden{display:none}.tabulator .tabulator-header .tabulator-col{display:inline-block;position:relative;box-sizing:border-box;border-right:1px solid #aaa;background:#e6e6e6;text-align:left;vertical-align:bottom;overflow:hidden}.tabulator .tabulator-header .tabulator-col.tabulator-moving{position:absolute;border:1px solid #999;background:#cdcdcd;pointer-events:none}.tabulator .tabulator-header .tabulator-col .tabulator-col-content{box-sizing:border-box;position:relative;padding:4px}.tabulator .tabulator-header .tabulator-col .tabulator-col-content .tabulator-header-menu-button{padding:0 8px}.tabulator .tabulator-header .tabulator-col .tabulator-col-content .tabulator-header-menu-button:hover{cursor:pointer;opacity:.6}.tabulator .tabulator-header .tabulator-col .tabulator-col-content .tabulator-col-title{box-sizing:border-box;width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;vertical-align:bottom}.tabulator .tabulator-header .tabulator-col .tabulator-col-content .tabulator-col-title .tabulator-title-editor{box-sizing:border-box;width:100%;border:1px solid #999;padding:1px;background:#fff}.tabulator .tabulator-header .tabulator-col .tabulator-col-content .tabulator-arrow{display:inline-block;position:absolute;top:9px;right:8px;width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:6px solid #bbb}.tabulator .tabulator-header .tabulator-col.tabulator-col-group .tabulator-col-group-cols{position:relative;display:-ms-flexbox;display:flex;border-top:1px solid #aaa;overflow:hidden;margin-right:-1px}.tabulator .tabulator-header .tabulator-col:first-child .tabulator-col-resize-handle.prev{display:none}.tabulator .tabulator-header .tabulator-col .tabulator-header-filter{position:relative;box-sizing:border-box;margin-top:2px;width:100%;text-align:center}.tabulator .tabulator-header .tabulator-col .tabulator-header-filter textarea{height:auto!important}.tabulator .tabulator-header .tabulator-col .tabulator-header-filter svg{margin-top:3px}.tabulator .tabulator-header .tabulator-col .tabulator-header-filter input::-ms-clear{width:0;height:0}.tabulator .tabulator-header .tabulator-col.tabulator-sortable .tabulator-col-title{padding-right:25px}.tabulator .tabulator-header .tabulator-col.tabulator-sortable:hover{cursor:pointer;background-color:#cdcdcd}.tabulator .tabulator-header .tabulator-col.tabulator-sortable[aria-sort=none] .tabulator-col-content .tabulator-arrow{border-top:none;border-bottom:6px solid #bbb}.tabulator .tabulator-header .tabulator-col.tabulator-sortable[aria-sort=asc] .tabulator-col-content .tabulator-arrow{border-top:none;border-bottom:6px solid #666}.tabulator .tabulator-header .tabulator-col.tabulator-sortable[aria-sort=desc] .tabulator-col-content .tabulator-arrow{border-top:6px solid #666;border-bottom:none}.tabulator .tabulator-header .tabulator-col.tabulator-col-vertical .tabulator-col-content .tabulator-col-title{-ms-writing-mode:tb-rl;writing-mode:vertical-rl;text-orientation:mixed;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center}.tabulator .tabulator-header .tabulator-col.tabulator-col-vertical.tabulator-col-vertical-flip .tabulator-col-title{transform:rotate(180deg)}.tabulator .tabulator-header .tabulator-col.tabulator-col-vertical.tabulator-sortable .tabulator-col-title{padding-right:0;padding-top:20px}.tabulator .tabulator-header .tabulator-col.tabulator-col-vertical.tabulator-sortable.tabulator-col-vertical-flip .tabulator-col-title{padding-right:0;padding-bottom:20px}.tabulator .tabulator-header .tabulator-col.tabulator-col-vertical.tabulator-sortable .tabulator-arrow{right:calc(50% - 6px)}.tabulator .tabulator-header .tabulator-frozen{display:inline-block;position:absolute;z-index:10}.tabulator .tabulator-header .tabulator-frozen.tabulator-frozen-left{border-right:2px solid #aaa}.tabulator .tabulator-header .tabulator-frozen.tabulator-frozen-right{border-left:2px solid #aaa}.tabulator .tabulator-header .tabulator-calcs-holder{box-sizing:border-box;min-width:600%;background:#f3f3f3!important;border-top:1px solid #aaa;border-bottom:1px solid #aaa;overflow:hidden}.tabulator .tabulator-header .tabulator-calcs-holder .tabulator-row{background:#f3f3f3!important}.tabulator .tabulator-header .tabulator-calcs-holder .tabulator-row .tabulator-col-resize-handle{display:none}.tabulator .tabulator-header .tabulator-frozen-rows-holder{min-width:600%}.tabulator .tabulator-header .tabulator-frozen-rows-holder:empty{display:none}.tabulator .tabulator-tableHolder{position:relative;width:100%;white-space:nowrap;overflow:auto;-webkit-overflow-scrolling:touch}.tabulator .tabulator-tableHolder:focus{outline:none}.tabulator .tabulator-tableHolder .tabulator-placeholder{box-sizing:border-box;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;width:100%}.tabulator .tabulator-tableHolder .tabulator-placeholder[tabulator-render-mode=virtual]{min-height:100%;min-width:100%}.tabulator .tabulator-tableHolder .tabulator-placeholder span{display:inline-block;margin:0 auto;padding:10px;color:#ccc;font-weight:700;font-size:20px}.tabulator .tabulator-tableHolder .tabulator-table{position:relative;display:inline-block;background-color:#fff;white-space:nowrap;overflow:visible;color:#333}.tabulator .tabulator-tableHolder .tabulator-table .tabulator-row.tabulator-calcs{font-weight:700;background:#e2e2e2!important}.tabulator .tabulator-tableHolder .tabulator-table .tabulator-row.tabulator-calcs.tabulator-calcs-top{border-bottom:2px solid #aaa}.tabulator .tabulator-tableHolder .tabulator-table .tabulator-row.tabulator-calcs.tabulator-calcs-bottom{border-top:2px solid #aaa}.tabulator .tabulator-footer{padding:5px 10px;border-top:1px solid #999;background-color:#e6e6e6;text-align:right;color:#555;font-weight:700;white-space:nowrap;-ms-user-select:none;user-select:none;-moz-user-select:none;-khtml-user-select:none;-webkit-user-select:none;-o-user-select:none}.tabulator .tabulator-footer .tabulator-calcs-holder{box-sizing:border-box;width:calc(100% + 20px);margin:-5px -10px 5px;text-align:left;background:#f3f3f3!important;border-bottom:1px solid #aaa;border-top:1px solid #aaa;overflow:hidden}.tabulator .tabulator-footer .tabulator-calcs-holder .tabulator-row{background:#f3f3f3!important}.tabulator .tabulator-footer .tabulator-calcs-holder .tabulator-row .tabulator-col-resize-handle{display:none}.tabulator .tabulator-footer .tabulator-calcs-holder:only-child{margin-bottom:-5px;border-bottom:none}.tabulator .tabulator-footer .tabulator-paginator{color:#555;font-family:inherit;font-weight:inherit;font-size:inherit}.tabulator .tabulator-footer .tabulator-page-size{display:inline-block;margin:0 5px;padding:2px 5px;border:1px solid #aaa;border-radius:3px}.tabulator .tabulator-footer .tabulator-pages{margin:0 7px}.tabulator .tabulator-footer .tabulator-page{display:inline-block;margin:0 2px;padding:2px 5px;border:1px solid #aaa;border-radius:3px;background:hsla(0,0%,100%,.2)}.tabulator .tabulator-footer .tabulator-page.active{color:#d00}.tabulator .tabulator-footer .tabulator-page:disabled{opacity:.5}.tabulator .tabulator-footer .tabulator-page:not(.disabled):hover{cursor:pointer;background:rgba(0,0,0,.2);color:#fff}.tabulator .tabulator-col-resize-handle{position:absolute;right:0;top:0;bottom:0;width:5px}.tabulator .tabulator-col-resize-handle.prev{left:0;right:auto}.tabulator .tabulator-col-resize-handle:hover{cursor:ew-resize}.tabulator .tabulator-loader{position:absolute;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;top:0;left:0;z-index:100;height:100%;width:100%;background:rgba(0,0,0,.4);text-align:center}.tabulator .tabulator-loader .tabulator-loader-msg{display:inline-block;margin:0 auto;padding:10px 20px;border-radius:10px;background:#fff;font-weight:700;font-size:16px}.tabulator .tabulator-loader .tabulator-loader-msg.tabulator-loading{border:4px solid #333;color:#000}.tabulator .tabulator-loader .tabulator-loader-msg.tabulator-error{border:4px solid #d00;color:#590000}.tabulator-row{position:relative;box-sizing:border-box;min-height:22px;background-color:#fff}.tabulator-row.tabulator-row-even{background-color:#efefef}.tabulator-row.tabulator-selectable:hover{background-color:#bbb;cursor:pointer}.tabulator-row.tabulator-selected{background-color:#9abcea}.tabulator-row.tabulator-selected:hover{background-color:#769bcc;cursor:pointer}.tabulator-row.tabulator-row-moving{border:1px solid #000;background:#fff}.tabulator-row.tabulator-moving{position:absolute;border-top:1px solid #aaa;border-bottom:1px solid #aaa;pointer-events:none;z-index:15}.tabulator-row .tabulator-row-resize-handle{position:absolute;right:0;bottom:0;left:0;height:5px}.tabulator-row .tabulator-row-resize-handle.prev{top:0;bottom:auto}.tabulator-row .tabulator-row-resize-handle:hover{cursor:ns-resize}.tabulator-row .tabulator-frozen{display:inline-block;position:absolute;background-color:inherit;z-index:10}.tabulator-row .tabulator-frozen.tabulator-frozen-left{border-right:2px solid #aaa}.tabulator-row .tabulator-frozen.tabulator-frozen-right{border-left:2px solid #aaa}.tabulator-row .tabulator-responsive-collapse{box-sizing:border-box;padding:5px;border-top:1px solid #aaa;border-bottom:1px solid #aaa}.tabulator-row .tabulator-responsive-collapse:empty{display:none}.tabulator-row .tabulator-responsive-collapse table{font-size:14px}.tabulator-row .tabulator-responsive-collapse table tr td{position:relative}.tabulator-row .tabulator-responsive-collapse table tr td:first-of-type{padding-right:10px}.tabulator-row .tabulator-cell{display:inline-block;position:relative;box-sizing:border-box;padding:4px;border-right:1px solid #aaa;vertical-align:middle;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.tabulator-row .tabulator-cell.tabulator-editing{border:1px solid #1d68cd;padding:0}.tabulator-row .tabulator-cell.tabulator-editing input,.tabulator-row .tabulator-cell.tabulator-editing select{border:1px;background:transparent}.tabulator-row .tabulator-cell.tabulator-validation-fail{border:1px solid #d00}.tabulator-row .tabulator-cell.tabulator-validation-fail input,.tabulator-row .tabulator-cell.tabulator-validation-fail select{border:1px;background:transparent;color:#d00}.tabulator-row .tabulator-cell:first-child .tabulator-col-resize-handle.prev{display:none}.tabulator-row .tabulator-cell.tabulator-row-handle{display:-ms-inline-flexbox;display:inline-flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;-moz-user-select:none;-khtml-user-select:none;-webkit-user-select:none;-o-user-select:none}.tabulator-row .tabulator-cell.tabulator-row-handle .tabulator-row-handle-box{width:80%}.tabulator-row .tabulator-cell.tabulator-row-handle .tabulator-row-handle-box .tabulator-row-handle-bar{width:100%;height:3px;margin-top:2px;background:#666}.tabulator-row .tabulator-cell .tabulator-data-tree-branch{display:inline-block;vertical-align:middle;height:9px;width:7px;margin-top:-9px;margin-right:5px;border-bottom-left-radius:1px;border-left:2px solid #aaa;border-bottom:2px solid #aaa}.tabulator-row .tabulator-cell .tabulator-data-tree-control{display:-ms-inline-flexbox;display:inline-flex;-ms-flex-pack:center;justify-content:center;-ms-flex-align:center;align-items:center;vertical-align:middle;height:11px;width:11px;margin-right:5px;border:1px solid #333;border-radius:2px;background:rgba(0,0,0,.1);overflow:hidden}.tabulator-row .tabulator-cell .tabulator-data-tree-control:hover{cursor:pointer;background:rgba(0,0,0,.2)}.tabulator-row .tabulator-cell .tabulator-data-tree-control .tabulator-data-tree-control-collapse{display:inline-block;position:relative;height:7px;width:1px;background:transparent}.tabulator-row .tabulator-cell .tabulator-data-tree-control .tabulator-data-tree-control-collapse:after{position:absolute;content:"";left:-3px;top:3px;height:1px;width:7px;background:#333}.tabulator-row .tabulator-cell .tabulator-data-tree-control .tabulator-data-tree-control-expand{display:inline-block;position:relative;height:7px;width:1px;background:#333}.tabulator-row .tabulator-cell .tabulator-data-tree-control .tabulator-data-tree-control-expand:after{position:absolute;content:"";left:-3px;top:3px;height:1px;width:7px;background:#333}.tabulator-row .tabulator-cell .tabulator-responsive-collapse-toggle{display:-ms-inline-flexbox;display:inline-flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;-moz-user-select:none;-khtml-user-select:none;-webkit-user-select:none;-o-user-select:none;height:15px;width:15px;border-radius:20px;background:#666;color:#fff;font-weight:700;font-size:1.1em}.tabulator-row .tabulator-cell .tabulator-responsive-collapse-toggle:hover{opacity:.7}.tabulator-row .tabulator-cell .tabulator-responsive-collapse-toggle.open .tabulator-responsive-collapse-toggle-close{display:initial}.tabulator-row .tabulator-cell .tabulator-responsive-collapse-toggle.open .tabulator-responsive-collapse-toggle-open,.tabulator-row .tabulator-cell .tabulator-responsive-collapse-toggle .tabulator-responsive-collapse-toggle-close{display:none}.tabulator-row .tabulator-cell .tabulator-traffic-light{display:inline-block;height:14px;width:14px;border-radius:14px}.tabulator-row.tabulator-group{box-sizing:border-box;border-bottom:1px solid #999;border-right:1px solid #aaa;border-top:1px solid #999;padding:5px;padding-left:10px;background:#ccc;font-weight:700;min-width:100%}.tabulator-row.tabulator-group:hover{cursor:pointer;background-color:rgba(0,0,0,.1)}.tabulator-row.tabulator-group.tabulator-group-visible .tabulator-arrow{margin-right:10px;border-left:6px solid transparent;border-right:6px solid transparent;border-top:6px solid #666;border-bottom:0}.tabulator-row.tabulator-group.tabulator-group-level-1{padding-left:30px}.tabulator-row.tabulator-group.tabulator-group-level-2{padding-left:50px}.tabulator-row.tabulator-group.tabulator-group-level-3{padding-left:70px}.tabulator-row.tabulator-group.tabulator-group-level-4{padding-left:90px}.tabulator-row.tabulator-group.tabulator-group-level-5{padding-left:110px}.tabulator-row.tabulator-group .tabulator-group-toggle{display:inline-block}.tabulator-row.tabulator-group .tabulator-arrow{display:inline-block;width:0;height:0;margin-right:16px;border-top:6px solid transparent;border-bottom:6px solid transparent;border-right:0;border-left:6px solid #666;vertical-align:middle}.tabulator-row.tabulator-group span{margin-left:10px;color:#d00}.tabulator-menu{position:absolute;display:inline-block;box-sizing:border-box;background:#fff;border:1px solid #aaa;box-shadow:0 0 5px 0 rgba(0,0,0,.2);font-size:14px;overflow-y:auto;-webkit-overflow-scrolling:touch;z-index:10000}.tabulator-menu .tabulator-menu-item{padding:5px 10px;-webkit-user-select:none;-ms-user-select:none;user-select:none}.tabulator-menu .tabulator-menu-item.tabulator-menu-item-disabled{opacity:.5}.tabulator-menu .tabulator-menu-item:not(.tabulator-menu-item-disabled):hover{cursor:pointer;background:#efefef}.tabulator-menu .tabulator-menu-separator{border-top:1px solid #aaa}.tabulator-edit-select-list{position:absolute;display:inline-block;box-sizing:border-box;max-height:200px;background:#fff;border:1px solid #aaa;font-size:14px;overflow-y:auto;-webkit-overflow-scrolling:touch;z-index:10000}.tabulator-edit-select-list .tabulator-edit-select-list-item{padding:4px;color:#333}.tabulator-edit-select-list .tabulator-edit-select-list-item.active{color:#fff;background:#1d68cd}.tabulator-edit-select-list .tabulator-edit-select-list-item:hover{cursor:pointer;color:#fff;background:#1d68cd}.tabulator-edit-select-list .tabulator-edit-select-list-notice{padding:4px;color:#333;text-align:center}.tabulator-edit-select-list .tabulator-edit-select-list-group{border-bottom:1px solid #aaa;padding:4px;padding-top:6px;color:#333;font-weight:700}.tabulator-print-fullscreen{position:absolute;top:0;bottom:0;left:0;right:0;z-index:10000}body.tabulator-print-fullscreen-hide>:not(.tabulator-print-fullscreen){display:none!important}.tabulator-print-table{border-collapse:collapse}.tabulator-print-table .tabulator-data-tree-branch{display:inline-block;vertical-align:middle;height:9px;width:7px;margin-top:-9px;margin-right:5px;border-bottom-left-radius:1px;border-left:2px solid #aaa;border-bottom:2px solid #aaa}.tabulator-print-table .tabulator-data-tree-control{display:-ms-inline-flexbox;display:inline-flex;-ms-flex-pack:center;justify-content:center;-ms-flex-align:center;align-items:center;vertical-align:middle;height:11px;width:11px;margin-right:5px;border:1px solid #333;border-radius:2px;background:rgba(0,0,0,.1);overflow:hidden}.tabulator-print-table .tabulator-data-tree-control:hover{cursor:pointer;background:rgba(0,0,0,.2)}.tabulator-print-table .tabulator-data-tree-control .tabulator-data-tree-control-collapse{display:inline-block;position:relative;height:7px;width:1px;background:transparent}.tabulator-print-table .tabulator-data-tree-control .tabulator-data-tree-control-collapse:after{position:absolute;content:"";left:-3px;top:3px;height:1px;width:7px;background:#333}.tabulator-print-table .tabulator-data-tree-control .tabulator-data-tree-control-expand{display:inline-block;position:relative;height:7px;width:1px;background:#333}.tabulator-print-table .tabulator-data-tree-control .tabulator-data-tree-control-expand:after{position:absolute;content:"";left:-3px;top:3px;height:1px;width:7px;background:#333}
            [class^="hmi-j-"], [class*=" hmi-j-"] {
                /* use !important to prevent issues with browser extensions that change fonts */
                font-family: 'hmi' !important;
                speak: none;
                font-style: normal;
                font-weight: normal;
                font-variant: normal;
                text-transform: none;
                line-height: 1;
            }
            .hmi-j-filter:before {
                content: "\\e90e";
            }
            span.disable {
                display: none;
            }
        </style>
        <style></style>
        <div></div>`;
        this._main = shadowRoot.querySelector('div');
        this._style = shadowRoot.querySelectorAll('style')[1];
        this._filters = {};
        this._hHeight = 0;
        this._gridtype = 0;
        this.afterSwitch = this.afterSwitch.bind(this);
        window.addEventListener("ms_message", this.afterSwitch);
    }

    afterSwitch(message) {
        const data = message.data;
        switch (data.event) {
            case "afterswitch":
                if ($pm.hasPermissions) {
                    const col = this.table.getColumns();
                    for (const iterator of col) {
                        const el = iterator.getElement().querySelector('span.hmi-j-filter');
                        if (el) {
                            if ($pm.checkAllow($pm.getEntryFromElement(this, 'DataTableFilter'))) {
                                el.classList.remove('disable');
                            } else {
                                el.classList.add('disable');
                            }
                        }
                    }
                    this.table.redraw(true);
                }
                break;
        }
    }

    enums(type) {
        if (!this._enums) {
            this._enums = {};
        }
        if (!this._enums[type]) {
            if (DataTypes.dataTypes[type] && DataTypes.dataTypes[type].DataType !== `ElementaryType`) {
                this._enums[type] = {};
                const en = DataTypes.dataTypes[type].DisplayValues;
                for (let i = 0; i < en.length; i++) {
                    const el = en[i];
                    this._enums[type][i] = el;
                    this._enums[type][el] = i;
                }
            }
        }
        return this._enums[type];
    }

    connectedCallback() {
        if (typeof this.saveStateFlag === 'undefined') {
            this.saveStateFlag = this.calcSaveState();
        }
        if (this.saveStateFlag) {
            this.updateItemState();
        }
    }

    disconnectedCallback() {
        window.removeEventListener("ms_message", this.afterSwitch);
        this._saveState();
        super.disconnectedCallback();
        if (this.table && this.table.destroy) {
            this.table.destroy();
            this.table = null;
        }
    }

    get paneldatasource() {
        const tmp = JSON.parse(JSON.stringify(this._tabledata && this._tabledata.value ? this._tabledata.value : Array.isArray(this._tabledata) ? this._tabledata : []));
        for (const iterator of tmp) {
            if (typeof iterator.$__index !== 'undefined') delete iterator.$__index;
        }
        return tmp;
    }
    set paneldatasource(v) {
        let first = true;
        if (this._tabledata) first = false;
        if (Array.isArray(v.value)) {
            this._dataType = v.dataType;
            this._tabledata = JSON.parse(JSON.stringify(v.value));
            for (let i = 0; i < this._tabledata.length; i++) {
                this._tabledata[i]['$__index'] = i;
            }
            this._tableType = DataTypes.dataTypes[v.dataType];
            this._elementType = DataTypes.dataTypes[this._tableType.TypeOfElementsName];
            if (!this._tablecolumns) this._tablecolumns = JSON.parse(this.getAttribute('tablecolumns')).column;
            this._loadState();
            if (!Array.isArray(this._tablecolumns)) this._tablecolumns = [this._tablecolumns];
            if (!this.table) {
                this._createTable();
            }
            this._updateData();
            if (first) this.table.redraw(true);
        } else {
            this._tabledata = v.value;
        }
    }

    _createTable() {
        this.columns = [];
        this._keyColums = {};
        if (!this._headerstyle) this._headerstyle = JSON.parse(this.attributes.headerrowstyle.value);
        if (!this._tablecolumns) {
            this._tablecolumns = JSON.parse(this.getAttribute('tablecolumns')).column;
            if (!Array.isArray(this._tablecolumns)) this._tablecolumns = [this._tablecolumns];
        }

        const formatter = (cell, formatterParams, onRendered) => {
            const ft = this._elementType.Fields[cell.getField()];
            let format = formatterParams.format || formatterParams.cel.valueformat;
            cell.getElement().style.textAlign = window._enums.AlignText[formatterParams.cel.horizontalalign];
            let val = cell.getValue();
            switch (ft) {
                case 'DATE':
                    format = format ? format : 'dd-MM-yyyy';
                    break;
                case 'DATE_AND_TIME':
                    format = format ? format : 'dd-MM-yyyy HH:mm:ss';
                    break;
                case 'TIME':
                    format = format ? format : 'dd.HH:mm:ss';
                    break;
                case 'TOD':
                case 'TIME_OF_DAY':
                    format = format ? format : 'HH:mm:ss';
                    break;
                default:
                    if (this.enums(ft)) {
                        val = this.enums(ft)[val];
                    }
            }

            return getFormattedValue(format, val, ft);
        }
        const colSort = [];
        const titleFormatter = (cell, formatterParams, onRendered) => {
            if (formatterParams.cel.enablefilter) {
                if ($pm.hasPermissions) {
                    if ($pm.checkAllow($pm.getEntryFromElement(this, 'DataTableFilter'))) {
                        return `<span class="btn hmi-j-filter"></span>${cell.getValue()}`;
                    } else {
                        return `<span class="btn hmi-j-filter disable"></span>${cell.getValue()}`;
                    }
                } else {
                    return `<span class="btn hmi-j-filter"></span>${cell.getValue()}`;
                }

            }
            return cell.getValue();
        };
        const fnSize = document.createElement('span');
        fnSize.style.fontSize = this._headerstyle.fontsize;
        fnSize.style.fontStyle = this._toBool(this._headerstyle.fontitalic) ? 'italic' : 'normal';
        fnSize.style.textDecoration = this._toBool(this._headerstyle.fontunderlined) ? 'underline' : '';
        fnSize.style.fontWeight = this._toBool(this._headerstyle.fontbold);
        fnSize.style.fontFamily = this._headerstyle.fontname;
        document.body.appendChild(fnSize);

        for (let i = 0; i < this._tablecolumns.length; i++) {
            if (this._tablecolumns[i].sort != 0) {
                colSort.push({
                    dir: this._tablecolumns[i].sort == 1 ? 'asc' : 'desc',
                    position: this._tablecolumns[i].sortposition,
                    column: this._tablecolumns[i].field
                });
            }
            const w = Number(this._tablecolumns[i].columnwidth);
            const ind = this.columns.push({
                title: this._tablecolumns[i].displayname,
                field: this._tablecolumns[i].field,
                visible: this._toBool(this._tablecolumns[i].visibility),
                hozAlign: window._enums.AlignText[this._tablecolumns[i].horizontalalign],
                formatterParams: { format: this._tablecolumns[i].valueformat, cel: this._tablecolumns[i] },
                titleFormatterParams: { cel: this._tablecolumns[i] },
                headerClick: (e, col) => {
                    if (e.target.tagName === 'SPAN') {
                        e.stopImmediatePropagation();
                        const field = col.getField();
                        const indexOf = this._tablecolumns.findIndex(e => {
                            return e.field === field;
                        });
                        if (indexOf > -1) {
                            let options;
                            const inputNum = new Inputs(this._main);
                            const title = `Фильтр для ${this._tablecolumns[indexOf].displayname}`;
                            if (this._filters) {
                                this._oldFilters = JSON.parse(JSON.stringify(this._filters));
                            }
                            switch (this._tablecolumns[indexOf].fieldtype) {
                                case 'TIME':
                                    options = { timeformat: this._tablecolumns[indexOf].valueformat, utc: false };
                                    const val_min_t = this._filters[field] && this._filters[field]['min'] ? this._filters[field]['min'].value : '';
                                    const val_max_t = this._filters[field] && this._filters[field]['max'] ? this._filters[field]['max'].value : '';
                                    inputNum.inputBoxIntervalRange(e, title, { min: val_min_t, max: val_max_t }, options, (res) => {
                                        if (res == null) return;
                                        let setFilt = true;
                                        let text = [];
                                        if (isNaN(res.min) && isNaN(res.max)) {
                                            delete this._filters[field];
                                            setFilt = false;
                                        } else {
                                            this._filters[field] = {};
                                            if (!isNaN(res.min)) {
                                                this._filters[field]['min'] = {
                                                    field: field,
                                                    type: '>=',
                                                    value: res.min
                                                };
                                                text.push(`>= ${res.min}`);
                                            }
                                            if (!isNaN(res.max)) {
                                                this._filters[field]['max'] = {
                                                    field: field,
                                                    type: '<=',
                                                    value: res.max
                                                };
                                                text.push(`<= ${res.max}`);
                                            }
                                        }
                                        this._setFilter(col, setFilt, text.join(', '));
                                    });
                                    break;
                                case 'TOD':
                                    if (!options) options = { datetimetype: 3, utc: false };
                                case 'DT':
                                    if (!options) options = { datetimetype: 1, utc: false };
                                case 'DATE':
                                    if (!options) options = { datetimetype: 0, utc: false };
                                    const val_min_dt = this._filters[field] && this._filters[field]['min'] ? this._filters[field]['min'].value : '';
                                    const val_max_dt = this._filters[field] && this._filters[field]['max'] ? this._filters[field]['max'].value : '';
                                    inputNum.inputBoxDataRange(e, title, { min: val_min_dt, max: val_max_dt }, options, (res) => {
                                        if (res == null) return;
                                        let setFilt = true;
                                        let text = [];
                                        if (typeof res.min !== 'number' && typeof res.max !== 'number') {
                                            delete this._filters[field];
                                            setFilt = false;
                                        } else {
                                            this._filters[field] = {};
                                            if (typeof res.min === 'number') {
                                                this._filters[field]['min'] = {
                                                    field: field,
                                                    type: '>=',
                                                    value: res.min
                                                };
                                                text.push(`>= ${res.min}`);
                                            }
                                            if (typeof res.max === 'number') {
                                                this._filters[field]['max'] = {
                                                    field: field,
                                                    type: '<=',
                                                    value: res.max
                                                };
                                                text.push(`<= ${res.max}`);
                                            }
                                        }
                                        this._setFilter(col, setFilt, text.join(', '));
                                    });
                                    break;
                                case 'STRING':
                                    const val_str = this._filters[field] ? this._filters[field]['val'].value : '';
                                    inputNum.inputBoxText(e, title, val_str, (res) => {
                                        if (res == null) return;
                                        let setFilt = true;
                                        if (res == '') {
                                            delete this._filters[field];
                                            setFilt = false;
                                        } else {
                                            this._filters[field] = {
                                                val: {
                                                    field: field,
                                                    type: 'like',
                                                    value: res
                                                }
                                            };
                                        }

                                        this._setFilter(col, setFilt, `содержит "${res}"`);
                                    });
                                    break;
                                case 'BOOL':
                                    const val_bool = this._filters[field] ? this._filters[field]['val'].value : 'all';
                                    const opt = [
                                        { value: 'true', name: 'Да' },
                                        { value: 'false', name: 'Нет' },
                                        { value: 'all', name: 'Все' }
                                    ]
                                    inputNum.inputBoxSelect(e, title, opt, val_bool.toString(), (res) => {
                                        if (res == null) return;
                                        let setFilt = true;
                                        if (res == '' || res == 'all') {
                                            delete this._filters[field];
                                            setFilt = false;
                                        } else {
                                            this._filters[field] = {
                                                val: {
                                                    field: field,
                                                    type: '=',
                                                    value: this._toBool(res)
                                                }
                                            };
                                        }
                                        this._setFilter(col, setFilt, `равно ${res}`);
                                    });
                                    break;
                                case 'BYTE':
                                case 'DINT':
                                case 'INT':
                                case 'LINT':
                                case 'SINT':
                                case 'UDINT':
                                case 'UINT':
                                case 'ULINT':
                                case 'USINT':
                                case 'REAL':
                                case 'LREAL':
                                case 'WORD':
                                case 'LWORD':
                                case 'DWORD':
                                    const val_min = this._filters[field] && this._filters[field]['min'] ? this._filters[field]['min'].value : '';
                                    const val_max = this._filters[field] && this._filters[field]['max'] ? this._filters[field]['max'].value : '';
                                    inputNum.inputBoxNumberRange(e, title, { min: val_min, max: val_max }, (res) => {
                                        if (res == null) return;
                                        let setFilt = true;
                                        let text = [];
                                        if (typeof res.min !== 'number' && typeof res.max !== 'number') {
                                            delete this._filters[field];
                                            setFilt = false;
                                        } else {
                                            this._filters[field] = {};
                                            if (typeof res.min === 'number') {
                                                this._filters[field]['min'] = {
                                                    field: field,
                                                    type: '>=',
                                                    value: res.min
                                                };
                                                text.push(`>= ${res.min}`);
                                            }
                                            if (typeof res.max === 'number') {
                                                this._filters[field]['max'] = {
                                                    field: field,
                                                    type: '<=',
                                                    value: res.max
                                                };
                                                text.push(`<= ${res.max}`);
                                            }
                                        }
                                        this._setFilter(col, setFilt, text.join(', '));
                                    });
                                    break;
                                default:
                                    const en = DataTypes.dataTypes[this._tablecolumns[indexOf].fieldtype].DisplayValues;
                                    let val_enum;
                                    if (this._filters[field]) {
                                        val_enum = new Array(en.length).fill(false);
                                        this._filters[field].val.value.forEach(el => {
                                            val_enum[el] = true;
                                        });
                                    } else {
                                        val_enum = [];
                                    }
                                    inputNum.inputBoxEnum(e, title, en, val_enum, null, (res) => {
                                        let setFilt = true;
                                        const isFilt = res.reduce((acc, val) => acc += val);
                                        delete this._filters[field];
                                        if (isFilt > 0 && isFilt < en.length) {
                                            this._filters[field] = {}
                                            const inA = []
                                            for (let i = 0; i < res.length; i++) {
                                                if (res[i]) {
                                                    inA.push(i);
                                                }
                                            }
                                            this._filters[field]['val'] = {
                                                field: field,
                                                type: 'in',
                                                value: inA
                                            };

                                        }
                                        this._setFilter(col, setFilt);
                                    });
                            }
                        }
                        return false;
                    }
                },
                formatter: formatter,
                titleFormatter: titleFormatter
            });
            if (w) {
                this.columns[ind - 1].width = w;
            } else {
                const star = this._tablecolumns[i].columnwidth.split('*').length - 1;
                if (star > 0) {
                    this.columns[ind - 1].widthGrow = star;
                } else {
                    fnSize.innerText = this._tablecolumns[i].displayname;
                    this.columns[ind - 1].width = fnSize.getBoundingClientRect().width + 40;
                }

            }
            this._keyColums[this._tablecolumns[i].field] = {
                cellsstyle: this._tablecolumns[i].cellsstyle
            }
        }

        fnSize.remove();
        colSort.sort((a, b) => {
            return a.position - b.position;
        })
        let isInited = false;
        this.table = new Tabulator(this._main, {
            autoResize: true,
            virtualDom: true,
            virtualDomBuffer: 100,
            index: '$__index',
            layout: 'fitColumns',
            locale: 'ru',
            tooltips: false,
            addRowPos: 'bottom',
            pagination: this._toBool(this.attributes.ispaged.value) ? 'local' : false,
            movableColumns: true,
            columns: this.columns,
            headerSortTristate: true,
            dataSorted: (sorter, row) => {
                if (isInited) {
                    const sotrOut = [];
                    for (let i = 0; i < sorter.length; i++) {
                        const element = sorter[i];
                        sotrOut.push({
                            dir: sorter[i].dir,
                            column: sorter[i].field
                        });
                    }
                    this.saveItemState({ sorter: sotrOut });
                }
            },
            cellClick: (e, cell) => {
                const fild = cell.getField();
                const row = cell.getRow().getPosition();
                const cellvalue = cell.getValue();
                const cellEl = cell.getElement();
                const r = JSON.parse(JSON.stringify(cell.getData()));
                delete r.$__index;
                let event = new CustomEvent('cellclick', { detail: { fild: fild, row: row, rowvalue: r, cellvalue: cellvalue, el: cellEl, pageX: e.pageX, pageY: e.pageY } });
                this.dispatchEvent(event);
                event = null;
            },
            rowDblClick: (e, row) => {
                if ($pm.hasPermissions) {
                    if ($pm.checkAllow($pm.getEntryFromElement(this, 'DataTableEdit'))) {
                        this._edRec(row);
                    }
                } else {
                    this._edRec(row);
                }
            },
            rowFormatter: (row) => {
                const data = row.getData();
                for (const key in data) {
                    if (this._fieldstyles && this._fieldstyles.hasOwnProperty(key)) {
                        const style = this._fieldstyles[key];
                        for (const k in style) {
                            const el = style[k];
                            const resault = Converter.convert(el, data[key], el.FieldType);
                            const div = row.getElement();
                            this.setStyle(k, resault, div);
                        }
                    }
                    if (this._keyColums && this._keyColums[key] && this._keyColums[key]['cellsstyle']) {
                        if (this._cellsstyle && this._cellsstyle.hasOwnProperty(this._keyColums[key].cellsstyle)) {
                            const style = this._cellsstyle[this._keyColums[key].cellsstyle];
                            for (const k in style) {
                                const el = style[k];
                                const resault = Converter.convert(el, data[el.FieldName], el.FieldType);
                                const cell = row.getCell(key);
                                if (cell) {
                                    const div = row.getCell(key).getElement();
                                    this.setStyle(k, resault, div);
                                }
                            }
                        }

                    }
                }
                row.normalizeHeight();
            },
            langs: {
                'ru': {
                    'columns': {
                        'name': 'Название', //replace the title of column name with the value "Name";
                    },
                    'pagination': {
                        'first': 'Первая', //text for the first page button
                        'first_title': 'Первая страница', //tooltip text for the first page button
                        'last': 'Последняя',
                        'last_title': 'Последняя страница',
                        'prev': 'Предыдущая',
                        'prev_title': 'Предыдущая страница',
                        'next': 'Следующая',
                        'next_title': 'Следующая страница',
                    },
                }
            },
        });
        this.table.setSort(colSort);
        this.table.element.style.width = this._width + "px";
        this.table.element.getElementsByClassName('tabulator-tableHolder')[0].style.backgroundColor = this.getAttribute('backgroundcolor');
        this._headerstyle.backgroundcolor = this._calcGradient(this._headerstyle.backgroundcolor);
        let headers = this.table.element.getElementsByClassName('tabulator-col');
        let headertexts = this.table.element.getElementsByClassName('tabulator-col-title');
        for (let i = 0; i < headers.length; i++) {
            headers[i].style.height = this._hHeight > 0 ? this._hHeight : this._headerstyle.height;
            headers[i].style.background = this._headerstyle.backgroundcolor;
            headertexts[i].style.color = this._headerstyle.textcolor;
            headertexts[i].style.fontSize = this._headerstyle.fontsize;
            headertexts[i].style.fontStyle = this._toBool(this._headerstyle.fontitalic) ? 'italic' : 'normal';
            headertexts[i].style.textDecoration = this._toBool(this._headerstyle.fontunderlined) ? 'underline' : '';
            headertexts[i].style.fontWeight = this._toBool(this._headerstyle.fontbold);
            headertexts[i].style.fontFamily = this._headerstyle.fontname;
        }
        isInited = true;
    }

    _setFilter(col, setFilt, text) {
        if ($pm.hasPermissions) {
            const inTable = this._tablecolumns.find((el) => {
                return el.field === col.getField();
            });
            const options = {
                cancel: () => {
                    this._filters = this._oldFilters;
                },
                customText: `${this.elname}  ${setFilt ? `Включена фильтрация столбца ${inTable.displayname} : ${text}` : `Отключена фильтрация столбца ${inTable.displayname}`}`
            }
            $pm.resolveControl(this, "DataTableFilter", this._successSetFilter.bind(this, col, setFilt), options);
        } else {
            this._successSetFilter(col, setFilt);
        }
    }

    _setFilterToTable() {
        this.table.clearFilter();
        for (const key in this._filters) {
            const el = this._filters[key];
            for (const k in el) {
                const e = el[k];
                this.table.addFilter(e.field, e.type, e.value);
            }
        }
    }

    _successSetFilter(col, setFilt) {
        this.saveItemState({ filrets: this._filters });
        this._setFilterToTable();
        if (setFilt) {
            if (this._headerstyle && this._headerstyle.backgroundcolorfilter) {
                col.getElement().style.backgroundColor = this._headerstyle.backgroundcolorfilter;
                col.getElement().firstChild.firstChild.style.color = this._headerstyle.textcolorfilter;
            } else {
                col.getElement().style.filter = `brightness(${this._headerAkcent})`;
            }
        } else {
            if (this._headerstyle && this._headerstyle.backgroundcolorfilter) {
                col.getElement().style.backgroundColor = this._headerstyle.backgroundcolor;
                col.getElement().firstChild.firstChild.style.color = this._headerstyle.textcolor;
            } else {
                col.getElement().style.filter = '';
            }
        }
    }

    _updateData() {
        let s;
        this.table.blockRedraw();
        if (this._tabledata.length < this.table.getDataCount()) {
            const offset = this.table.getDataCount() - this._tabledata.length;
            for (let i = 0; i < offset; i++) {
                this.table.deleteRow(this.table.getDataCount() - 1);
            }
        }

        this.table.updateOrAddData(this._tabledata);
        const filters = this.table.getFilters();

        if (filters.length > 0) {
            this.table.clearFilter();
            this.table.setFilter(filters);
            s = this.table.element.getElementsByClassName('tabulator-tableHolder')[0].scrollTop;
        }
        const sorter = this.table.getSorters();
        if (sorter.length > 0) {
            this.table.setSort(sorter);
            s = this.table.element.getElementsByClassName('tabulator-tableHolder')[0].scrollTop;
        }

        this.table.restoreRedraw();
        if (typeof s === 'number') this.table.element.getElementsByClassName('tabulator-tableHolder')[0].scrollTop = s;
    }

    setStyle(key, value, div) {
        switch (key) {
            case 'FontItalic':
                if (value) {
                    div.style.fontStyle = 'italic';
                }
                break;
            case 'FontBold':
                if (value) {
                    div.style.fontWeight = 'bold';
                }
                break;
            case 'FontUnderlined':
                if (value) {
                    div.style.textDecoration = 'underline';
                }
                break;

            case 'TextColor':
                if (value) {
                    div.style.color = value;
                }
                break;
            case 'FontSize':
                if (value) {
                    div.style.fontSize = `${value}px`;
                }
                break;
            case 'FontName':
                if (value) {
                    div.style.fontFamily = `${value}`;
                }
                break;
            case 'BackgroundColor':
                if (value) {
                    div.style.backgroundColor = value;
                }
                break;
            case 'BorderColor':
                if (value) {
                    //trStyle += `--main-c:${resault};`;
                }
                break;
            case 'BorderThickness':
                if (value) {
                    //trStyle += `--main-w:${resault};`;
                }
                break;
            default:
                break;
        }
    }

    get sorter() {
        return this._sorter;
    }
    set sorter(v) {
        this._sorter = v;
        this.table.setSort(v);
    }

    get filrets() {
        return this._filters;
    }
    set filrets(v) {
        this._filters = v;
        this._setFilterToTable();
        for (const key in this._filters) {
            const col = this.table.getColumn(key);
            if (col) {
                if (this._headerstyle && this._headerstyle.backgroundcolorfilter) {
                    col.getElement().style.backgroundColor = this._headerstyle.backgroundcolorfilter;
                    col.getElement().firstChild.firstChild.style.color = this._headerstyle.textcolorfilter;
                } else {
                    col.getElement().style.filter = `brightness(${this._headerAkcent})`;
                }
            }
        }

    }

    get gridtype() {
        return this._gridtype;
    }
    set gridtype(v) {
        this._gridtype = Number(v);
        if (this._rowstyle) this.genRowStyle();
    }

    get backgroundcolor() {
        return this.getAttribute('backgroundcolor');
    }
    set backgroundcolor(v) {
        if (this.table) {
            this.table.element.getElementsByClassName('tabulator-tableHolder')[0].style.backgroundColor = v;
        }
    }

    get evencolor() {
        return this._evencolor ? this._evencolor : this.getAttribute('evencolor');
    }
    set evencolor(v) {
        this._evencolor = v;
    }

    get oddcolor() {
        return this._oddcolor ? this._oddcolor : this.getAttribute('oddcolor');
    }
    set oddcolor(v) {
        this._oddcolor = v;
    }

    get ispaged() {
        return this.table.pagination;
    }
    set ispaged(v) {
        if (this.table) {
            if (this._toBool(v))
                this.table.options.pagination = 'local';
            else
                this.table.options.pagination = false;
        }
    }
    get tablecolumns() {
        return this._tablecolumns;
    }
    set tablecolumns(v) {
        if (!this.table)
            this._createTable();
        for (let key in this._tablecolumns) {
            this.columns.push({
                title: this._tablecolumns[key].DisplayName,
                field: this._tablecolumns[key].Field,
                width: +this._tablecolumns[key].ColumnWidth,
                hozAlign: window._enums.AlignHorizontal[this._tablecolumns[key].HorizontalAlign]
            });
        }
        this.table.options.columns = this.columns;
    }
    get headerrowstyle() {
        this._headerstyle;
    }
    set headerrowstyle(v) {
        if (!this.table)
            return;
        try {
            this._headerstyle = JSON.parse(v);
            const color = this._colorValues(this._headerstyle.backgroundcolor);
            if (color) {
                const p = this._colourIsLight(color[0], color[1], color[2]) ? -1 : 1;
                this._headerAkcent = p ? 1.25 : '80%';
            }
        } catch (e) {
            this._headerstyle = null;
            return;
        }
        const headers = this.table.element.getElementsByClassName('tabulator-col');
        if (headers) {
            for (let i = 0; i < headers.length; i++) {
                headers[i].style.height = this._headerstyle.Height;
            }
        }
    }

    get rowstyle() {
        return this._rowstyle;
    }
    set rowstyle(v) {
        try {
            this._rowstyle = JSON.parse(v);
            if (this._rowstyle.backgroundcolor) this.oddcolor = this._rowstyle.backgroundcolor;
            if (this._rowstyle.backgroundcoloreven) this.evencolor = this._rowstyle.backgroundcoloreven;
            this.genRowStyle();
        } catch (e) {
            this._rowstyle = null;
        }
    }

    genRowStyle() {
        this._style.innerHTML = `
        .tabulator-row .tabulator-cell {
          display: inline-block;
          position: relative;
          box-sizing: border-box;
          padding: 4px;
          vertical-align: middle;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .tabulator-row {
          position: relative;
          box-sizing: border-box;
          min-height: 22px;
          background-color: ${this._rowstyle.backgroundcolor};
          font-family: ${this._rowstyle.fontname};
          font-size: ${this._rowstyle.fontsize}px;
          ${this._rowstyle.fontitalic ? 'font-style: "italic";' : ''}
          ${this._rowstyle.fontbold ? 'font-weight: "bold";' : ''}
          ${this._gridtype === 1 || this._gridtype === 2 ? `border-bottom: 1px solid ${this._rowstyle.bordercolor} !important;` : `border-bottom: 1px none !important;`};
        }
        .tabulator-cell {
          ${this._gridtype === 0 || this._gridtype === 2 ? `border-right: 1px solid ${this._rowstyle.bordercolor} !important;` : `border-right: 1px none !important;`};
        }
        .tabulator-row.tabulator-row-odd {
          background-color: ${this.oddcolor || "#ffffff"};
        }
        
        .tabulator-row.tabulator-row-even {
          background-color: ${this.evencolor || "#efefef"};
        }
        
        .tabulator-row.tabulator-selectable:hover {
          background-color: #bbb;
          cursor: pointer;
        }`;
    }

    get cellsstyle() {
        return this._cellsstyle;
    }
    set cellsstyle(v) {
        try {
            this._cellsstyle = JSON.parse(v);
        } catch (e) {
            this._cellsstyle = null;
        }
    }

    get fieldstyles() {
        return this._fieldstyles;
    }
    set fieldstyles(v) {
        try {
            this._fieldstyles = JSON.parse(v);
        } catch (e) {
            this._fieldstyles = null;
        }
    }

    _saveState() {
        const save = [];
        if (this.table && this.table.getColumnLayout) {
            const col = this.table.getColumns();
            col.forEach(el => {
                save.push({ width: el._column.width });
            });
            let headers = Number(/.\d/.exec(this.table.element.querySelector('[role="columnheader"]').style.height));
            const s = { col: save, header: headers };
            sessionStorage.setItem(`dtable_${$sw.serverState.UserData.user}_${this.id}_state`, JSON.stringify(s));
        }
    }
    _loadState() {
        try {
            const save = JSON.parse(sessionStorage.getItem(`dtable_${$sw.serverState.UserData.user}_${this.id}_state`)) || [];
            for (let i = 0; i < save.col.length; i++) {
                this._tablecolumns[i].columnwidth = save.col[i].width;
            }
            this._hHeight = save.header;
        } catch (error) {

        }
    }

    attributeChangedCallback(attrName, oldVal, newVal) {
        if (attrName.indexOf('tablecolumns') != -1 && this.table) {
            const args = attrName.split('.');
            const index = args[1];
            switch (args[2]) {
                case 'displayname':
                    this.table.element.getElementsByClassName('tabulator-col-title')[index].textContent = newVal;
                    break;
                case 'visibility':
                    if (newVal) {
                        this.table.getColumns()[index].show();
                    } else {
                        this.table.getColumns()[index].hide();
                    }
                    break;
                case 'sort':
                    const colSort = [];
                    if (newVal != 0) {
                        colSort.push({
                            dir: newVal == 1 ? 'asc' : 'desc',
                            column: this._tablecolumns[index].field
                        });
                        this.table.setSort(colSort);
                    } else {
                        this.table.clearSort();
                    }
                    break;
                case 'horizontalalign':
                    this._tablecolumns[index].horizontalalign = newVal;
                    this.table.redraw(true);
                    break;
                case 'valueformat':
                    this._tablecolumns[index].valueformat = newVal;
                    this.table.redraw(true);
                    break;
                case 'columnwidth':
                    this.table.getColumns()[index].getDefinition().width = newVal;
                    this.table.redraw(true);
            }
            this.table.redraw();
        } else if (attrName === 'paneldatasource') {
            if (!deepCompare(oldVal, newVal) && typeof newVal === 'object') {
                const value = JSON.parse(JSON.stringify(newVal.value || []));
                for (const iterator of value) {
                    if (typeof iterator.$__index !== 'undefined') delete iterator.$__index;
                }
                this[attrName] = newVal;
                if (this.prop_link[attrName]) {
                    this.prop_link[attrName](
                        this.pId ? this.pId + '/' + this.id : this.id,
                        this.Links[attrName],
                        value,
                        attrName,
                        this.ItemIndex
                    );
                }
            }
        } else {
            super.attributeChangedCallback(attrName, oldVal, newVal);
        }
    }

    _edRec(row) {
        if (this._disableedit || this._openDisabled) return;
        if (this._tablecolumns.filter(e => !e.disableedit).length === 0) return;
        const item = row.getData();
        this._openDisabled = true;
        const elRect = this.getBoundingClientRect();
        const sc = elRect.width / this.width;
        const inputs = new Inputs(this._in);
        const html = this._generateForm(item);
        inputs.inputBoxCustom(null, html, null, (v) => {
            if ($pm.hasPermissions) {
                const form = v.querySelector('form');
                const fields = JSON.parse(form.dataset.fields).map(el => { return el.split('.')[0]; });
                const data = this._extractValue(form);
                const items = {};
                for (let i = 0; i < fields.length; i++) {
                    items[fields[i]] = data[i];
                }
                const txtFildList = [];
                for (const key in items) {
                    if (items.hasOwnProperty(key)) {
                        if (!key.startsWith('$')) {
                            txtFildList.push(` ${key}=${items[key]}`);
                        }
                    }
                }
                const option = { customText: `${this.elname} Изменение записи :${txtFildList.join(',')}` };
                $pm.resolveControl(this, "DataTableEdit", this._successEdit.bind(this, v, item), option);
            } else {
                this._successEdit(v, item);
            }
        }, {
            toBody: false,
            alignToElement: true,
            element: this,
            showFocus: false,
            msPopup: true,
            scale: sc,
            title: 'Редактирование',
            afterInit: (nodes) => {
                const el = nodes.querySelectorAll('input[lenHelper]')
                for (const iterator of el) {
                    iterator.oninput = this._lenHelper;
                }
            },
            onCancel: (e) => {
                this._openDisabled = false;
            }
        });
    }

    _successEdit(v, item) {
        let isCh = false;
        const _tabledata = JSON.parse(JSON.stringify(this._tabledata));
        const form = v.querySelector('form');
        const fields = JSON.parse(form.dataset.fields);
        this._openDisabled = false;
        const values = this._extractValue(form);
        const ind = item.$__index;
        for (let i = 0; i < fields.length; i++) {
            const fl = fields[i];
            if (this._tabledata[ind][fl] !== values[i]) {
                isCh = true;
                _tabledata[ind][fl] = values[i];
            }
        }
        if (isCh) {
            for (const iterator of _tabledata) {
                if (typeof iterator.$__index !== 'undefined') delete iterator.$__index;
            }
            const val = {
                dataType: this._dataType,
                value: _tabledata
            }
            this.SetParameter('paneldatasource', val, true);
        }
    }

    _extractValue(form) {
        const res = [];
        for (let i = 0; i < form.length; i++) {
            const el = form[i];
            let item = '';
            if (_enums.Types[el.dataset.type]) {
                switch (_enums.Types[el.dataset.type].type) {
                    case 'number':
                    case 'wordNumber':
                        item = Number(el.value) || 0;
                        break;
                    case 'boolean':
                        item = this._toBool(el.checked);
                        break;
                    case 'date':
                        item = el.value;
                        if (item > 0) {
                            const timeOffset = new Date(item).getTimezoneOffset() * 60000;
                            item = item - timeOffset;
                        }
                        break;
                    default:
                        item = el.value;
                }
            } else if (DataTypes.dataTypes[el.dataset.type] && DataTypes.dataTypes[el.dataset.type].DataType === `EnumeratedType`) {
                item = Number(el.value) || 0;
            }
            res.push(item);
        }
        return res;
    }

    _generateForm(values) {
        if (!values) values = {};
        let res = '';
        let fields = [];
        for (let i = 0; i < this._tablecolumns.length; i++) {
            if (this._tablecolumns[i].disableedit) continue;
            const el = this._tablecolumns[i];
            fields.push(el.field);
            res += '<tr>';
            if (_enums.Types[el.fieldtype]) {
                let val = values[el.field];
                switch (_enums.Types[el.fieldtype].type) {
                    case 'string':
                        let maxLen = '';
                        let lenHelp = '';
                        let onInput = '';
                        if (this._tablecolumns[i].valueformat) {
                            val = String.format(this._tablecolumns[i].valueformat, val.trimRight());
                            const tf = /^[t].?\d?$/i.test(this._tablecolumns[i].valueformat);
                            if (tf) {
                                const len = this._tablecolumns[i].valueformat.slice(1);
                                maxLen = len ? ` maxlength="${len}"` : '';
                                lenHelp = len ? `<span id="lh" style="color:gray;font-size:60%;">(${val.length}/${len})</span>` : '';
                                onInput = len ? ` lenHelper` : '';
                            }
                        }
                        res += `<td>${this._tablecolumns[i].displayname}</td>
                                <td><input${onInput} data-type="${el.fieldtype}" type="text" id="${el.field}" name="${el.field}" value="${val || ''}"${maxLen}></td><td>${lenHelp}</td>`;
                        break;
                    case 'boolean':
                        const chk = val ? ' checked' : '';
                        res += `<td>${this._tablecolumns[i].displayname}</td>
                                <td><input data-type="${el.fieldtype}" type="checkbox" id="${el.field}" name="${el.field}"${chk}></td><td></td>`;
                        break;
                    case 'number':
                    case 'wordNumber':
                        const max = _enums.Types[el.fieldtype].description.max || Infinity;
                        const min = _enums.Types[el.fieldtype].description.mix || -Infinity;
                        res += `<td>${this._tablecolumns[i].displayname}</td>
                                <td><ms-numericupdown showbuttons="false" fontsize="16" data-type="${el.fieldtype}" backgroundcolor="" allownull="false" id="${el.field}" name="${el.field}" value="${val || 0}" minvalue="${min}" maxvalue="${max}" style="width:100%;border:1px solid;position:relative;"></ms-numericupdown></td><td></td>`;
                        break;
                    case 'date':
                        // if (val > 0) {
                        //     const timeOffset = new Date(val).getTimezoneOffset() * 60000;
                        //     val = val + timeOffset;
                        // }
                        let datetimetype = 1;
                        if (_enums.Types[el.fieldtype].description.descType === 'tod') {
                            datetimetype = 3;
                        }
                        res += `<td>${this._tablecolumns[i].displayname}</td>
                                <td><ms-dtpicker fontsize="16" data-type="${el.fieldtype}" utc="false" backgroundcolor="" id="${el.field}" isreadonly="false" allownull="true" datetimetype="${datetimetype}" name="${el.field}" value="${val || ''}" style="width:100%;border:1px solid;position:relative;"></ms-dtpicker></td><td></td>`;
                        break;
                    default:
                        break;
                }
            } else if (DataTypes.dataTypes[el.fieldtype] && DataTypes.dataTypes[el.fieldtype].DataType === `EnumeratedType`) {
                let options = '';
                for (let ind = 0; ind < DataTypes.dataTypes[el.fieldtype].Values.length; ind++) {
                    const element = DataTypes.dataTypes[el.fieldtype].Values[ind];
                    options += `<option value="${ind}">${element}</option>`;
                }
                res += `<td>${this._tablecolumns[i].displayname}</td>
                        <td><select data-type="${el.fieldtype}" id="${el.field}" name="${el.field}">${options}</select></td><td></td>`;

            }
            res += '</tr>';

        }
        return `<style>
        #inputbody {
            width: max-content;
            min-width: 320px;
            margin: 5px;
        }
        td {
            padding: 2px 0;
        }
        tr input,select{
            width: 100%;
            border: gray 1px solid;
            font-size: 16px;
            height: 1.5em;
        }
        tr input,select :not(:last-child){
            margin: 2px 0;
        }</style>
        <form style="display: flex; flex-direction: column;" data-fields='${JSON.stringify(fields)}'><table>${res}</table></form>`;
    }

    _colorValues(color) {
        if (!color)
            return;
        if (color.toLowerCase() === 'transparent')
            return [0, 0, 0, 0];
        if (color[0] === '#') {
            if (color.length < 7) {
                color = '#' + color[1] + color[1] + color[2] + color[2] + color[3] + color[3] + (color.length > 4 ? color[4] + color[4] : '');
            }
            return [parseInt(color.substr(1, 2), 16),
            parseInt(color.substr(3, 2), 16),
            parseInt(color.substr(5, 2), 16),
            color.length > 7 ? parseInt(color.substr(7, 2), 16) / 255 : 1];
        }
        if (color.indexOf('rgb') === -1) {
            const temp_elem = document.body.appendChild(document.createElement('fictum'));
            const flag = 'rgb(1, 2, 3)';
            temp_elem.style.color = flag;
            if (temp_elem.style.color !== flag) {
                document.body.removeChild(temp_elem);
                return;
            }
            temp_elem.style.color = color;
            if (temp_elem.style.color === flag || temp_elem.style.color === '') {
                document.body.removeChild(temp_elem);
                return;
            }
            color = getComputedStyle(temp_elem).color;
            document.body.removeChild(temp_elem);
        }
        if (color.indexOf('rgb') === 0) {
            if (color.indexOf('rgba') === -1)
                color += ',1';
            return color.match(/[\.\d]+/g).map((a) => {
                return +a
            });
        }
    }

    _colourIsLight(r, g, b) {
        var a = 1 - (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        return (a < 0.5);
    }

}