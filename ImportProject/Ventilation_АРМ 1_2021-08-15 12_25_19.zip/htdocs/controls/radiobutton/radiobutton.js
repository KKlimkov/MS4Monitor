"use strict";

import { BasicSkin } from "../basic.js";
import { color2Matrix } from "../../lib/utils.js";
/**
 * @class MSRadioButton
 * @extends BasicSkin
 * @classdesc �����������
 * */
export class MSRadioButton extends BasicSkin {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'ischecked',
            'textcolor'
        ]);
    }

    constructor() {
        super();
        this._key = this.parentNode.id;
        this.shRoot = this.attachShadow({ mode: 'closed' });
        this.shRoot.innerHTML = `
        <input type="radio" name="grp_${this._key}" style="pointer-events: none;height:0;width:0; padding:0; margin:0; visibility: hidden;">
        <label style="background-color:#dedede; box-sizing: border-box; position:relative;height:100%;width:100%; padding:0; margin:0;">
            <div style='pointer-events: none; width: 60%; height: 60%;border-radius:${this.attributes.cornerradius ? this.attributes.cornerradius.value : 0}px; background-color:black; position: absolute; transform: translate(-50%, -50%); top: 50%; left: 50%'></div>    
        </label>
        `;
        this._main = this.shRoot.querySelector('input');
        this._point = this.shRoot.querySelector('div');
        this._label = this.shRoot.querySelector('label');
        this._label.onclick = (e) => {
            if (this._main.checked) return;
            this._main.checked = true;
            const evt = document.createEvent("HTMLEvents");
            evt.initEvent("change", false, true);
            this._main.dispatchEvent(evt);
        }

        this._main.onchange = this._onChange.bind(this);
        this.textcolor = "BLACK";
        this.backgroundcolor = "rgb(245,240,245)";
        this.cornerradius = 500;
    }

    get backgroundcolor() {
        return this._backgroundcolor;
    }
    set backgroundcolor(value) {
        if (value && typeof value === 'string') {
            this._backgroundcolor = value;
            if (this._isSkin) {
                const color = color2Matrix(value);
                this._rgbaMatrix.setAttribute('values', color);
                this._backColor = color;
            } else {
                this._label.style.backgroundColor = this._calcGradient(value);
            }
        }
    }

    get resource() {
        return this._resource;
    }
    set resource(value) {
        this.setResource(value, this._label);
    }

    get backgroundtile() {
        return this._backgroundtile;
    }
    set backgroundtile(value) {
        this._backgroundtile = window._enums.TileType[value];
        if (this._resource && this._resource != "") {
            this._calcBacgraund(this._label);
        }
    }

    get cornerradius() {
        return this.style.borderRadius;
    }
    set cornerradius(value) {
        const valPoint = 0.6 * value / 2;
        const val = this._setValueUnit(value / 2);
        this.style.borderRadius = val;
        this._point.style.borderRadius = valPoint + 'px';
    }

    get textcolor() {
        return this._point.style.backgroundColor;
    }
    set textcolor(value) {
        if (!this._isSkin) {
            this._point.style.backgroundColor = value ? value : 'black';
        }
    }

    get ischecked() {
        return this._ischecked;
    }
    set ischecked(value) {
        this._ischecked = value
        this._main.checked = this._toBool(value);
        this._point.style.visibility = this._main.checked ? '' : 'hidden';
        this._main.onchange();
    }

    _initSkin() {
        this._skin = this.shRoot.querySelector('svg');
        this._skin ? this._setEventsForSkin() : this._setInitInnerHtml();
    }

    _setEventsForSkin() {
        this._skin.style.width = '100%';
        this._skin.style.height = '100%';
        this._svgOn = this._skin.querySelector('#on');
        this._svgOff = this._skin.querySelector('#off');
        this._rgbaMatrix = this._skin.querySelector('#BackgroundColor');
        if (this._svgOn && this._svgOff && this._rgbaMatrix) {
            this._isSkin = true;
            this.classList.add('inputable');
            this.style.borderStyle = 'none';
            this.style.overflow = 'visible';
            this._main = this.shRoot.querySelector('input');
            if (this._backColor) {
                const color = color2Matrix(this._backColor);
                this._rgbaMatrix.setAttribute('values', color);
            }
            if (this._toBool(this._ischecked)) {
                this._setOn();
            }
            this._main.onchange = (e) => { this._onSVGChange(e) };
        } else {
            this._setInitInnerHtml();
        }
    }

    _setInitInnerHtml() {
        this.shRoot.innerHTML = this._rootBtn;
        this._main = this.shRoot.querySelector('input');
        this._showWarnSkin();
    }

    _onSVGChange(e) {
        this._onChange(e);
        if (this._isSkin) {
            e.target.checked ? this._setOn() : this._setOff();
        }
    }

    _setOn() {
        this._svgOn.style.display = 'inline';
        this._svgOff.style.display = 'none';
    }

    _setOff() {
        this._svgOn.style.display = 'none';
        this._svgOff.style.display = 'inline';
    }

    _onChange(e) {
        this.SetParameter('ischecked', this._main.checked);
        if (this._main.checked) {
            const radioBtns = this.parentElement.querySelectorAll(`ms-radiobutton`);
            [...radioBtns].forEach(element => {
                if (element.shRoot) {
                    const input = element.shRoot.querySelector(`[name="grp_${this._key}"]`);
                    if (this.parentElement.id == element.parentElement.id) {
                        if (input != this._main) {
                            element.SetParameter('ischecked', false);
                            if (element._isSkin) {
                                element._setOff();
                            }
                        }
                    }
                }
            });
        }
    }
}
