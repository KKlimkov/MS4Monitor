import { BasicSVG } from "../basicsvg.js";
/**
 * @class MSPolygon
 * @extends BasicSVG
 * @classdesc �������
 * */
export class MSPolygon extends BasicSVG {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'bordergeometry'
        ]);
    }

    constructor() {
        super();
        this._createInnerSVG('path');
        this._path.setAttribute('shape-rendering', 'geometricPrecision');
        this._path.setAttribute('vector-effect', 'non-scaling-stroke');
        this._main.style.pointerEvents = 'none';
        this._path.style.pointerEvents = 'auto';
        this.borderthickness = 2;
        this._d = 'M0,0';
    }

    afterInitialize() {
        this._path.setAttribute('d', this._d);
        const size = this._path.getBBox();
        this._main.setAttribute('viewBox', `${size.x} ${size.y} ${size.width} ${size.height}`);
    }

    set width(value) {
        this._width = value;
        const tmp = Number(value);
        if (tmp) {
            this.style.width = this._setValueUnit(value);
            this._main.setAttribute('width', this._setValueUnit(value));
        }
    }

    set height(value) {
        this._height = value;
        const tmp = Number(value);
        if (tmp) {
            this.style.height = this._setValueUnit(value);
            this._main.setAttribute('height', this._setValueUnit(value));
        }
    }

    get bordergeometry() {
        return this._d;
    }
    set bordergeometry(value) {
        if (this._isValidD(value)) {
            this._d = value;
            this.afterInitialize();
        } else {
            $ns.add({
                type: 'warning',
                time: new Date().toLocaleString(),
                title: "������ ���������",
                text: `���������� ������ �������� ${value} ��������� "���������" ��� id="${this.id}"}`
            });
        }
    }

    /**
     * �������� ������������ ���� ��� ���������
     * @param {string} value ����������� ��������
     * @return {bool} ��������� ��������
     */
    _isValidD(value) {
        const regEverythingAllowed = /[MmZzLlHhVvCcSsQqTtAa0-9-,.\s]/g;

        const containsIllegalCharacter = !!value.replace(regEverythingAllowed, '').length;
        const containsAdjacentLetters = /[a-zA-Z][a-zA-Z]/.test(value);
        const invalidStart = /^[0-9-,.]/.test(value);
        const invalidEnd = /.*[-,.]$/.test(value.trim());

        return !(containsIllegalCharacter || containsAdjacentLetters || invalidStart || invalidEnd);
    }

    /**
     * ����������� ����
     * @type {string}
     */
    get resource() {
        return this._resource;
    }
    set resource(value) {
        this._resource = value;
        if (this._resource) {
            if (this._pattern) this._pattern.remove();

            this._resource = this.getResourceFromList(value);
            this._pattern = document.createElementNS(this._svgNS, 'pattern');
            this._pattern.setAttributeNS('', 'height', '100%');
            this._pattern.setAttributeNS('', 'width', '100%');
            this._pattern.id = `patt_${this.id}`;
            this._pattern_img = document.createElementNS(this._svgNS, 'image');
            this._pattern_img.setAttributeNS('', 'height', '100%');
            this._pattern_img.setAttributeNS('', 'width', '100%');
            this._pattern_img.setAttributeNS('', 'href', `resources/${this._resource}`);
            this._pattern.appendChild(this._pattern_img);
            this._main.appendChild(this._pattern);
            this._path.setAttributeNS('', 'fill', `url(#${this._pattern.id})`);
        } else {
            this._path.setAttributeNS('', 'fill', `${this.backgroundcolor}`);
            this._pattern.remove();
        }
    }
}