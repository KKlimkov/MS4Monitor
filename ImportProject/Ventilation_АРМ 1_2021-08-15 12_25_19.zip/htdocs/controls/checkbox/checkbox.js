"use strict";
import { BasicSkin } from "../basic.js";
import { color2Matrix } from "../../lib/utils.js";
/**
 * @class MSCheckBox
 * @extends BasicSkin
 * @classdesc ���������� �������� CheckBox
 * */
export class MSCheckBox extends BasicSkin {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'ischecked',
            'textcolor',
            'notsendbackwardconnection'
        ]);
    }

    constructor() {
        super();
        this._lockLink = this.getAttribute("notsendbackwardconnection");
        this.shRoot = this.attachShadow({ mode: 'open' });
        this.shRoot.innerHTML = `<div for="ch" style="box-sizing: border-box; position:relative;height:100%;width:100%; padding:0; margin:0;">
            <svg style='visibility: hidden;width: 70%; height: 70%;position: absolute;border-radius:${this.attributes.cornerradius ? this.attributes.cornerradius.value : 0}px; transform: translate(-50%, -50%); top: 50%; left: 50%' viewBox="0 0 12 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M11.9142 1.41421L4.20711 9.12132L0 4.91421L1.41421 3.5L4.20711 6.29289L10.5 0L11.9142 1.41421Z" fill="black"/>
            </svg>
        </div>
        <input type="checkbox" id="ch" style="height:0;width:0; padding:0; margin:0; display:none;">
        `;
        this.style.userSelect = 'none';
        this._main = this.shRoot.querySelector('input');
        this._label = this.shRoot.querySelector('div');
        this._svg = this.shRoot.querySelector('svg');
        this._path = this.shRoot.querySelector('path');

        this._label.onclick = (e) => {
            this._interaction = true;
            let param = !this._main.checked;
            this.SetParameter('ischecked', param);
            this._interaction = false;
        };
        this.backgroundcolor = "rgb(245,240,245)";
    }

    get notsendbackwardconnection(){
        return this._lockLink;
    }
    set notsendbackwardconnection(value){
        this._lockLink = this._toBool(value);
    }

    get resource() {
        return this._resource;
    }
    set resource(value) {
        this.setResource(value, this._label);
    }

    get backgroundtile() {
        return this._backgroundtile;
    }
    set backgroundtile(value) {
        this._backgroundtile = window._enums.TileType[value];
        if (this._resource && this._resource != "") {
            this._calcBacgraund(this._label);
        }
    }

    get backgroundcolor() {
        return this._backgroundcolor;
    }
    set backgroundcolor(value) {
        if (value && typeof value === 'string') {
            this._backgroundcolor = value;
            if (this._isSkin) {
                const color = color2Matrix(value);
                this._rgbaMatrix.setAttribute('values', color);
                this._backColor = color;
            } else {
                this._label.style.backgroundColor = this._calcGradient(value);
            }
        }
    }

    get textcolor() {
        return this._path.getAttribute('fill');
    }
    set textcolor(value) {
        if (!this._isSkin) {
            this._path.setAttribute('fill', value);
        }
    }

    get ischecked() {
        return this._ischecked;
    }
    set ischecked(value) {
        this._ischecked = value;
        this._main.checked = this._toBool(value);
        this._svg.style.visibility = this._main.checked ? '' : 'hidden';
    }

    _initSkin() {
        this._skin = this.shRoot.querySelector('svg');
        this._skin ? this._setEventsForSkin() : this._setInitInnerHtml();
    }

    _setEventsForSkin() {
        this._skin.style.width = '100%';
        this._skin.style.height = '100%';
        this._svgOn = this._skin.querySelector('#on');
        this._svgOff = this._skin.querySelector('#off');
        this._rgbaMatrix = this._skin.querySelector('#BackgroundColor');
        if (this._svgOn && this._svgOff && this._rgbaMatrix) {
            this._isSkin = true;
            this.classList.add('inputable');
            this.style.borderStyle = 'none';
            this.style.overflow = 'visible';
            this._main = this.shRoot.querySelector('input');
            if (this._backColor) {
                const color = color2Matrix(this._backColor);
                this._rgbaMatrix.setAttribute('values', color);
            }
            this._main.onchange = (e) => { this._onSVGChange(e) };
        } else {
            this._setInitInnerHtml();
        }
    }

    _setInitInnerHtml() {
        this.shRoot.innerHTML = this._rootBtn;
        this._main = this.shRoot.querySelector('input');
        this._showWarnSkin();
    }

    _onSVGChange(e) {
        this._interaction = true;
        this.SetParameter('ischecked', e.target.checked);
        this._interaction = false;
        if (this._isSkin) {
            if (e.target.checked) {
                this._svgOn.style.display = 'inline';
                this._svgOff.style.display = 'none';
            } else {
                this._svgOn.style.display = 'none';
                this._svgOff.style.display = 'inline';
            }
        }
    }

    /**
     * ������� �� ��������� ��������� ��������
     * @see https://w3c.github.io/webcomponents/spec/custom/
     * @param {string} attrName �������� ��������
     * @param {*} oldVal ������ �������� ��������
     * @param {*} newVal ����� �������� ��������
     */
    attributeChangedCallback(attrName, oldVal, newVal) {
        if (oldVal !== newVal) {
            if (attrName === 'ischecked' && !this._interaction) {
                if (this._lockLink) {
                    this[attrName] = newVal
                    return;
                }
            }
            if (oldVal != newVal) {
                this[attrName] = newVal;
                if (this.prop_link[attrName]) {
                    this.prop_link[attrName](
                        this.pId ? this.pId + '/' + this.id : this.id,
                        this.Links[attrName],
                        newVal,
                        attrName,
                        this.ItemIndex,
                        null,
                        this._lockLink
                    );
                }
            }
        }
    }

    disconnectedCallback(){
        this._label.onclick = null;
        this._main = null
        this._label = null
        this._svg = null
        this._path = null
        super.disconnectedCallback()
    } 

}