import { Basic } from '../basic.js';
import { deepCompare } from '../../lib/utils.js';
/**
 * @class MSWindow
 * @extends Basic
 * @classdesc Окно
 */
export class MSWindow extends Basic {
    static get observedAttributes() {
        return super.observedAttributes.concat([
            'template',
            'typeid',
            'position',
            'proportiontype',
            'typed'
        ]);
    }
    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        // if (document.body.querySelector('ms-window') == this) {
        //     this.width = window.innerWidth;
        //     this.height = window.innerHeight;
        // }
        this._cacheClass = {};
        shadowRoot.innerHTML = '<slot></slot>';
        this.eventListener = this.eventListener.bind(this);
        window.addEventListener("ms_message", this.eventListener);
        this.proportiontype = 4;
        this.contentMaxZIndex = 0;
        //proto basic
        this.backgroundcolor = "rgb(245,240,245)";
        //this.borderstyle = 0;
        //this.style.borderWidth = 0;
        //this.style.borderColor = "GRAY";
        if (!this.hasAttribute('root')) this.style.boxSizing = 'border-box';
        else this.style.boxSizing = 'content-box';
        this.mergeParam();
    }

    eventListener(message) {
        const data = message.data;
        switch (data.event) {
            case "afterswitch":
                this.changeUser();
                break;
        }
    }
    mergeParam() {
        if ($WinDefs.winDef[this.typeid]) {
            const def = $WinDefs.winDef[this.typeid];
            for (const key in def) {
                if (key == 'actionlist') {
                    this.actionlist = JSON.stringify(JSON.parse(def[key]));
                    continue;
                }
                if (typeof def[key] === 'object' && def[key] !== null) {
                    this[key] = JSON.parse(JSON.stringify(def[key]));
                } else if (this.getAttribute(key) == null) {
                    this[key] = JSON.parse(JSON.stringify(def[key]));
                }
            }
        }
    }

    changeUser() {
        if (this.isenabled && this._maskElement) {
            this.isenabled = true;
        }
        $pm.controlEnable(this.childNodes);
    }

    get isContainer() {
        return true;
    }

    isPopup() {
        return this.parentNode && this.parentNode.nodeName === "MS-POPUP";
    }

    get template() {
        return this._templateId;
    }
    set template(value) {
        this._templateId = value;
        const template = document.querySelector(`template#${value}`);
        if (template) {
            this.innerHTML = template.innerHTML;
            this._calcScale();
        } else if ($WinDefs.winDef[this.id]) {
            const win = JSON.parse(JSON.stringify($WinDefs.winDef[this.id]));
            this._isWinDefTemplate = true;
            for (const key in win) {
                if (win.hasOwnProperty(key)) {
                    if (key !== 'template') {
                        this[key] = win[key];
                    }
                }
            }
            this._isWinDefTemplate = false;
            this._connectedWindow();
        }
    }

    get proportiontype() {
        return this._proportiontype;
    }
    set proportiontype(value) {
        this._proportiontype = Number(value);
        this._calcScale();
    }

    /**
     * Ширина
     * @type {number}
     */
    get width() {
        return this._width;
    }
    set width(value) {
        super.width = value;
        if (this.isPopup()) {
            this.parentNode.onResizeContent();
        }
        this._calcScale();
    }
    /**
     * Высота
     * @type {number}
     */
    get height() {
        return this._height;
    }

    set height(value) {
        super.height = value;
        if (this.isPopup()) {
            this.parentNode.onResizeContent();
        }
        this._calcScale();
    }

    /**
     * Видимость
     * @type {bool}
     */
    get isvisible() {
        return this._showElement;
    }
    set isvisible(value) {
        this._showElement = value;
        const isShow = (this.opacity === '' || this._toBool(this.opacity)) && this._toBool(value);
        if (!this._isInited) {
            this.style.visibility = isShow ? '' : 'hidden';
        } else {
            if (this.style.visibility === 'hidden') this.style.visibility = '';
            this.style.display = isShow ? 'flex' : 'none';
        }
    }

    _initSkin() {
        this._main = this.shadowRoot.querySelector('svg');
    }

    setSvgParams(svgPath, value) {
        if (this.issvg) {
            let paths = svgPath.split(":");
            if (paths[0] === 'svg') paths = paths.splice(1);
            this.svg(paths, value);
        }
    }

    svg(path, value) {
        const items = this._main.querySelectorAll(`[id=${path[0]}]`);
        if (items.length > 0) {
            for (let i = 0; i < items.length; i++) {
                const item = items[i];
                switch (path[1]) {
                    case 'fill':
                        item.style.fill = value;
                        break;
                    case 'Content':
                        item.textContent = value;
                        break;
                    case 'class':
                        if (path[2]) {
                            if (this._cacheClass[path[2]]) {
                                item.classList.remove(this._cacheClass[path[2]]);
                            }
                        } else {
                            while (item.classList.length > 0) {
                                item.classList.remove(item.classList.item(0));
                            }
                        }
                        if (value && value.trim().length > 0)
                            item.classList.add(value);
                        break;
                    default:
                        if (path[0] == 'feColorMatrixBodyFilter' || item.nodeName === 'feColorMatrix') {
                            const color = this._colorValues(value);
                            if (color) {
                                const r = (color[0] / 255).toFixed(2);
                                const g = (color[1] / 255).toFixed(2);
                                const b = (color[2] / 255).toFixed(2);
                                value = `${r} 0 0 0 0 0 ${g} 0 0 0 0 0 ${b} 0 0 0 0 0 ${color[3]} 0`;
                            }
                            // item.setAttribute(path[1], matrix);
                        }
                        if (item.attributes.getNamedItem(path[1])) {
                            item.setAttribute(path[1], value);
                        } else {
                            for (const key in this._cacheClass) {
                                const el = this._cacheClass[key];
                                if (el) {
                                    const items = this._main.querySelectorAll(`.${el}`);
                                    for (let index = 0; index < items.length; index++) {
                                        items[index].classList.toggle(el);
                                        requestAnimationFrame(() => {
                                            items[index].classList.toggle(el);
                                        })
                                    }
                                }
                            }
                        }
                }
            }
            if (path[1] === 'class' && path[2]) {
                if (value) {
                    this._cacheClass[path[2]] = value;
                }
            }
        } else if (path[0] === 'AvaryBorder') {
            const style = document.createElement('style');
            style.type = 'text/css';
            style.innerHTML = '#AvaryBorder {display:none;} #AvaryBorder.Alarm {display:block; stroke:rgb(255,0,0);} #AvaryBorder.Warning {display:block; stroke:rgb(255,170,0);}';
            this._main.appendChild(style);
            const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            rect.setAttribute('id', 'AvaryBorder');
            let x, y;
            if (this._main.viewBox) {
                x = this._main.viewBox.baseVal.x
                y = this._main.viewBox.baseVal.y
            }
            rect.setAttribute('x', x || 0);
            rect.setAttribute('y', y || 0);
            rect.setAttribute('height', '100%');
            rect.setAttribute('width', '100%');
            rect.style.fill = 'rgb(0,0,0)';
            rect.style.strokeWidth = '1';
            rect.style.fillOpacity = '0';
            rect.innerHTML = `<animate xmlns="http://www.w3.org/2000/svg" attributeName="opacity" attributeType="XML" begin="0s; animEnd.end" dur="1s" values="0;1;0" repeatCount="indefinite"/>`;
            this._main.appendChild(rect);
            this.svg(path, value);
        }
    }

    _calcScale() {
        if (this.hasAttribute('root')) return;
        if (typeof this._proportiontype === 'undefined') return;
        if (this.typeid && this.typeid != this.id) {
            const msWin = $WinDefs.winDef[this.typeid];
            let scY, scaleY, scX, scaleX;
            switch (this._proportiontype) {
                case 0:
                    // if (Number(this.height) < Number(this.width)) {
                    scY = Number(msWin.height);
                    scaleY = Number(this.height) / scY;
                    // } else {
                    scX = Number(msWin.width);
                    scaleX = Number(this.width) / scX;
                    // }
                    break;
                case 1:
                    scX = scY = Number(msWin.width);
                    scaleX = scaleY = Number(this.width) / scX;
                    break;
                case 2:
                    scX = scY = Number(msWin.height);
                    scaleX = scaleY = Number(this.height) / scY;
                    break;
                case 3:
                    if (Number(this.height) < Number(this.width)) {
                        scX = scY = Number(msWin.height);
                        scaleX = scaleY = Number(this.height) / scY;
                    } else {
                        scX = scY = Number(msWin.width);
                        scaleX = scaleY = Number(this.width) / scX;
                    }
                    break;
                case 4:
                    if (Number(this.height) > Number(this.width)) {
                        scX = scY = Number(msWin.height);
                        scaleX = scaleY = Number(this.height) / scY;
                    } else {
                        scX = scY = Number(msWin.width);
                        scaleX = scaleY = Number(this.width) / scX;
                    }
                    break;
            }

            if (scaleX != 1 || scaleY != 1) {
                if (scaleX === scaleY) {
                    this.style.transform = `${this._cacheTransform} scale(${scaleX})`;
                } else {
                    this.style.transform = `${this._cacheTransform} scale(${scaleX},${scaleY})`;
                }
                this.style.transformOrigin = '0 0';
                this.style.width = this._setValueUnit(msWin.width);
                this.style.height = this._setValueUnit(msWin.height);
            } else {
                this.style.transform = this._cacheTransform;
                this.style.transformOrigin = '';
                this.style.width = this._setValueUnit(this.width);
                this.style.height = this._setValueUnit(this.height);
            }
        }
    }

    get typeid() {
        return this.getAttribute('typeid');
    }
    set typeid(value) {
        this.setAttribute('typeid', value);
    }

    get typed() {
        return this._typed;
    }
    set typed(value) {
        this._typed = value;
    }

    get position() {
        return this._position;
    }
    set position(value) {
        this._position = value;
        this.style.position = value;
    }

    updateZIndex(value /*:Number*/) {
        if (value > this.contentMaxZIndex) this.contentMaxZIndex = value;
        if (this._maskElement) {
            this._maskElement.style.zIndex = this.contentMaxZIndex + 1;
        }
    }

    disableElement() {
        if (this._maskElement || !this._isInited) return;
        const base = this.shRoot ? this.shRoot : this.shadowRoot;
        this._pointerEvents = this.style.pointerEvents;

        let zIndex = 0;
        this.childNodes.forEach(el => {
            if (Number(el.z) && zIndex < el.z) zIndex = Number(el.z);
        })
        const maskElement = this.createMaskElement(zIndex);

        base.append(maskElement);
        this._maskElement = maskElement;
    }

    connectedCallback() {
        if (!this._isWinDefTemplate) {
            this._connectedWindow();
            // super.connectedCallback();
            // const event = new CustomEvent('ms_message');
            // event.data = { event: 'windowStart', window: this };
            // window.dispatchEvent(event);
        }
        this._isInited = true;
        this.isvisible = this.isvisible;
        if (!this.isenabled) {
            this.disableElement();
        }
    }
    afterInitialize() {

        for (let i = 0; i < this.children.length; i++) {
            if (this.children[i].afterInitialize) this.children[i].afterInitialize();
        }
    }

    _connectedWindow() {
        if (!this._winStart) {
            this._winStart = true;
            const event = new CustomEvent('ms_message');
            event.data = { event: 'windowStart', window: this };
            window.dispatchEvent(event);
        }
    }

    disconnectedCallback() {
        this.innerHTML = ''
        window.removeEventListener("ms_message", this.eventListener);
        let event = new CustomEvent('ms_message');
        event.data = { event: 'windowRemove', window: this };
        window.dispatchEvent(event);
        delete event.data.window;
        event = null
        delete this.windowTriggers;
        super.disconnectedCallback();
    }


    /**
     * Коллбек по изменению атрибутов элемента
     * @see https://w3c.github.io/webcomponents/spec/custom/
     * @param {string} attrName название атрибута
     * @param {*} oldVal старое значение атрибута
     * @param {*} newVal новое значение атрибута
     */
    attributeChangedCallback(attrName, oldVal, newVal) {
        if (!deepCompare(oldVal, newVal)) {
            const struct = attrName.split('.');
            if (struct.length > 1) {
                const val = newVal.dataType && newVal.value ? newVal.value : newVal;
                // this[attrName] = val;
                let value = this;
                for (let i = 0; i < struct.length - 1; i++) {
                    value = value[struct[i]];
                }
                const keys = Object.keys(value);
                const i = keys.findIndex(el => el.toLowerCase() === struct[struct.length - 1]);

                if (value[keys[i]] != val) {
                    value[keys[i]] = val;
                    if (this.prop_link[struct[0]]) {
                        this.prop_link[struct[0]](
                            this.pId ? this.pId + '/' + this.id : this.id,
                            this.Links[struct[0]],
                            this[struct[0]],
                            struct[0],
                            this.ItemIndex
                        );
                    }
                }
            } else {
                const val = newVal && newVal.dataType && newVal.value ? newVal.value : newVal
                super.attributeChangedCallback(attrName, oldVal, val);
            }
        }
    }
}
